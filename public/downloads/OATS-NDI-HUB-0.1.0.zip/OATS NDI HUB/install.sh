#!/bin/zsh
# OATS NDI HUB installer: copies this folder to ~/Applications/OATS NDI HUB, checks the NDI runtime and Rosetta,
# installs the login item (autostart) and starts everything. Re-running updates an existing install in place.
emulate -L zsh; setopt err_exit pipe_fail
SRC=${0:A:h}
DEST="$HOME/Applications/OATS NDI HUB"
PLIST="$HOME/Library/LaunchAgents/com.fooknoats.oatsndihub.plist"
say() { print -r -- "• $*"; }
echo "OATS NDI HUB $(head -1 $SRC/VERSION) installer"
echo
[[ -f /usr/local/lib/libndi.dylib ]] || { echo "!! NDI runtime not found (/usr/local/lib/libndi.dylib). Install NDI Tools from https://ndi.video/tools/ then run this again."; exit 1; }
say "NDI runtime: $(strings /usr/local/lib/libndi.dylib 2>/dev/null | grep -m1 -oE 'NDI SDK APPLE [^\"]*' || echo found)"
if [[ -e /Library/Apple/usr/libexec/oah/libRosettaRuntime ]]; then say "Rosetta 2: installed"; else echo "!! Rosetta 2 is needed by the camera and display senders:  softwareupdate --install-rosetta --agree-to-license"; echo "   (the hub itself runs without it). Continuing."; fi
if [[ -d $DEST ]]; then
  say "updating existing install in $DEST (settings and presets kept)"
  for m in oats-hub oats-cam oats-screen; do "$DEST/$m/"*.sh stop >/dev/null 2>&1 || true; done
  for keep in oats-cam/presets.json oats-cam/audio.json oats-cam/cam.env oats-hub/hub.env oats-screen/screen.env; do [[ -f "$DEST/$keep" ]] && cp "$DEST/$keep" "/tmp/oatsndihub.$(basename $keep)"; done
fi
mkdir -p "$DEST"
rsync -a --delete --exclude 'logs/*' --exclude 'run/*' "$SRC/" "$DEST/"
for keep in oats-cam/presets.json oats-cam/audio.json oats-cam/cam.env oats-hub/hub.env oats-screen/screen.env; do f="/tmp/oatsndihub.$(basename $keep)"; [[ -f $f ]] && mv "$f" "$DEST/$keep"; done
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true
say "installed to $DEST"
cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.fooknoats.oatsndihub</string>
  <key>ProgramArguments</key><array><string>/bin/zsh</string><string>$DEST/autostart.sh</string></array>
  <key>RunAtLoad</key><true/>
  <key>StandardOutPath</key><string>$DEST/oats-hub/logs/autostart.log</string>
  <key>StandardErrorPath</key><string>$DEST/oats-hub/logs/autostart.log</string>
</dict></plist>
PL
launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST"
say "login item installed (com.fooknoats.oatsndihub): starts the hub, the camera sender and the display sender at login"
"$DEST/autostart.sh" now
echo
ip=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo localhost)
echo "Done. Hub:  http://$ip:7080/    multiview:  http://$ip:7080/multiview"
echo "Camera sender: $DEST/oats-cam/cam.sh status   (set CAM_DEVICE in oats-cam/cam.env for a camera other than the Insta360 Link 2)"
echo "Display sender: off by default; enable with  touch \"$DEST/oats-screen/ENABLED\"  then  oats-screen/screen.sh start"
