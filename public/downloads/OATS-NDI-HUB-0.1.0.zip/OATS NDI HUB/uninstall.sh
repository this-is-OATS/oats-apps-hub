#!/bin/zsh
DEST="$HOME/Applications/OATS NDI HUB"; PLIST="$HOME/Library/LaunchAgents/com.fooknoats.oatsndihub.plist"
for m in oats-hub oats-cam oats-screen; do "$DEST/$m/"*.sh stop >/dev/null 2>&1 || true; done
launchctl unload "$PLIST" 2>/dev/null || true; rm -f "$PLIST"
echo "stopped and removed the login item. The folder $DEST is left for you to delete (it holds your presets and settings)."
