import Foundation

/// libndi loaded at runtime with dlopen/dlsym (types from ndi_min.h via the bridging header).
final class NDILib {
    struct LoadError: Error, CustomStringConvertible { let description: String }
    let handle: UnsafeMutableRawPointer
    let initialize: fn_initialize
    let destroy: fn_destroy
    let version: fn_version
    let send_create: fn_send_create
    let send_destroy: fn_send_destroy
    let send_send_video_v2: fn_send_video
    let send_get_no_connections: fn_send_get_no_connections
    let send_capture: fn_send_capture
    let send_free_metadata: fn_send_free_metadata
    let send_add_connection_metadata: fn_send_add_connection_metadata
    let send_clear_connection_metadata: fn_send_clear_connection_metadata
    let send_get_tally: fn_send_get_tally

    init(path: String) throws {
        guard let h = dlopen(path, RTLD_NOW | RTLD_LOCAL) else { throw LoadError(description: "dlopen(\(path)) failed: \(String(cString: dlerror()))") }
        handle = h
        func s<T>(_ name: String) throws -> T {
            guard let p = dlsym(h, name) else { throw LoadError(description: "dlsym failed: \(name)") }
            return unsafeBitCast(p, to: T.self)
        }
        initialize = try s("NDIlib_initialize"); destroy = try s("NDIlib_destroy"); version = try s("NDIlib_version")
        send_create = try s("NDIlib_send_create"); send_destroy = try s("NDIlib_send_destroy")
        send_send_video_v2 = try s("NDIlib_send_send_video_v2")
        send_get_no_connections = try s("NDIlib_send_get_no_connections")
        send_capture = try s("NDIlib_send_capture"); send_free_metadata = try s("NDIlib_send_free_metadata")
        send_add_connection_metadata = try s("NDIlib_send_add_connection_metadata")
        send_clear_connection_metadata = try s("NDIlib_send_clear_connection_metadata")
        send_get_tally = try s("NDIlib_send_get_tally")
    }
    var versionText: String { version().map { String(cString: $0) } ?? "?" }
}

let fourccUYVY: UInt32 = UInt32(UInt8(ascii: "U")) | UInt32(UInt8(ascii: "Y")) << 8 | UInt32(UInt8(ascii: "V")) << 16 | UInt32(UInt8(ascii: "Y")) << 24
