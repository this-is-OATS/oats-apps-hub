import Foundation
import ScreenCaptureKit
import CoreMedia
import CoreVideo

/// ScreenCaptureKit capture of one display. Keeps the latest BGRA pixel buffer; the sender paces frames itself
/// (SCK only delivers frames when something changes, NDI receivers want a steady stream).
final class ScreenCapture: NSObject, SCStreamOutput, SCStreamDelegate {
    private var stream: SCStream?
    private let lock = NSLock()
    private var latest: CVPixelBuffer?
    private(set) var frames: UInt64 = 0
    private(set) var lastFrameNs: UInt64 = 0
    var onError: ((String) -> Void)?

    static func displays(timeout: TimeInterval = 15) -> Result<[SCDisplay], Error> {
        let sem = DispatchSemaphore(value: 0)
        var result: Result<[SCDisplay], Error> = .failure(NSError(domain: "oats-screen", code: 1, userInfo: [NSLocalizedDescriptionKey: "SCShareableContent timed out after \(Int(timeout)) s (screen recording permission prompt not answered?)"]))
        SCShareableContent.getExcludingDesktopWindows(false, onScreenWindowsOnly: true) { content, error in
            if let e = error { result = .failure(e) } else { result = .success(content?.displays ?? []) }
            sem.signal()
        }
        _ = sem.wait(timeout: .now() + timeout)
        return result
    }
    static func describe(_ d: SCDisplay) -> String {
        "display \(d.displayID)\(CGDisplayIsMain(d.displayID) != 0 ? " (main)" : "") \(d.width)x\(d.height) at (\(Int(d.frame.origin.x)),\(Int(d.frame.origin.y)))"
    }
    /// `which`: "main", "secondary" (first non-main, by position left to right), or a CGDirectDisplayID
    static func pick(_ which: String, from ds: [SCDisplay]) -> SCDisplay? {
        let sorted = ds.sorted { $0.frame.origin.x < $1.frame.origin.x }
        switch which {
        case "main": return sorted.first { CGDisplayIsMain($0.displayID) != 0 }
        case "secondary": return sorted.first { CGDisplayIsMain($0.displayID) == 0 } ?? (sorted.count > 1 ? sorted[1] : nil)
        default: return UInt32(which).flatMap { id in sorted.first { $0.displayID == id } }
        }
    }

    func start(display: SCDisplay, width: Int, height: Int, fps: Int, cursor: Bool) throws {
        let filter = SCContentFilter(display: display, excludingWindows: [])
        let cfg = SCStreamConfiguration()
        cfg.width = width; cfg.height = height
        cfg.pixelFormat = kCVPixelFormatType_32BGRA
        cfg.minimumFrameInterval = CMTime(value: 1, timescale: CMTimeScale(fps))
        cfg.queueDepth = 5
        cfg.showsCursor = cursor
        cfg.colorSpaceName = CGColorSpace.sRGB
        let s = SCStream(filter: filter, configuration: cfg, delegate: self)
        try s.addStreamOutput(self, type: .screen, sampleHandlerQueue: DispatchQueue(label: "oats-screen.capture", qos: .userInteractive))
        let sem = DispatchSemaphore(value: 0); var err: Error? = nil
        s.startCapture { e in err = e; sem.signal() }
        if sem.wait(timeout: .now() + 15) == .timedOut { throw NSError(domain: "oats-screen", code: 2, userInfo: [NSLocalizedDescriptionKey: "startCapture timed out"]) }
        if let e = err { throw e }
        stream = s
    }
    func stop() { let sem = DispatchSemaphore(value: 0); stream?.stopCapture { _ in sem.signal() }; _ = sem.wait(timeout: .now() + 2) }

    func stream(_ stream: SCStream, didOutputSampleBuffer sb: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .screen, sb.isValid, let pb = CMSampleBufferGetImageBuffer(sb) else { return }
        if let atts = CMSampleBufferGetSampleAttachmentsArray(sb, createIfNecessary: false) as? [[SCStreamFrameInfo: Any]],
           let st = atts.first?[.status] as? Int, st != SCFrameStatus.complete.rawValue { return }   // idle / blank / suspended: keep the last good frame
        lock.lock(); latest = pb; frames &+= 1; lastFrameNs = monoNs(); lock.unlock()
    }
    func stream(_ stream: SCStream, didStopWithError error: Error) { onError?("stream stopped: \(error.localizedDescription)") }

    /// The most recent complete frame (retained), or nil before the first one.
    func current() -> CVPixelBuffer? { lock.lock(); defer { lock.unlock() }; return latest }
}
let fourccBGRA: UInt32 = UInt32(UInt8(ascii: "B")) | UInt32(UInt8(ascii: "G")) << 8 | UInt32(UInt8(ascii: "R")) << 16 | UInt32(UInt8(ascii: "A")) << 24
