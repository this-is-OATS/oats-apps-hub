import Foundation
import CoreVideo
import ScreenCaptureKit

// oats-screen: a display as an NDI source (ScreenCaptureKit -> libndi, BGRA), paced at a fixed frame rate.
//   oats-screen [--name NAME] [--display secondary|main|ID] [--size WxH] [--fps 30] [--no-cursor] [--log-dir DIR] [--libndi PATH] [--list]

let usage = "usage: oats-screen [--name NAME] [--display secondary|main|ID] [--size WxH] [--fps N] [--no-cursor] [--log-dir DIR] [--libndi PATH] [--list]"

@main
struct OatsScreen {
    static func main() {
        signal(SIGPIPE, SIG_IGN)
        setvbuf(stdout, nil, _IOLBF, 0)
        var name = "Display 2", which = "secondary", width = 0, height = 0, fps = 30, cursor = true, logDir = "", list = false, libPath = "/usr/local/lib/libndi.dylib"
        var a = Array(CommandLine.arguments.dropFirst())
        func next(_ k: String) -> String { guard !a.isEmpty else { print("\(k) needs a value\n\(usage)"); exit(64) }; return a.removeFirst() }
        while !a.isEmpty {
            let k = a.removeFirst()
            switch k {
            case "--name": name = next(k)
            case "--display": which = next(k)
            case "--size": let p = next(k).split(separator: "x"); guard p.count == 2, let w = Int(p[0]), let h = Int(p[1]) else { print("--size WxH"); exit(64) }; width = w; height = h
            case "--fps": guard let v = Int(next(k)), v > 0, v <= 120 else { print("--fps N"); exit(64) }; fps = v
            case "--no-cursor": cursor = false
            case "--log-dir": logDir = next(k)
            case "--libndi": libPath = next(k)
            case "--list": list = true
            case "-h", "--help": print(usage); exit(0)
            default: print("unknown option \(k)\n\(usage)"); exit(64)
            }
        }
        if !logDir.isEmpty && !Logger.shared.open(dir: logDir, prefix: "oats-screen") { print("cannot open a log in \(logDir)"); exit(78) }
        let activity = ProcessInfo.processInfo.beginActivity(options: [.userInitiated, .latencyCritical], reason: "oats-screen NDI send"); _ = activity
        olog("oats-screen starting pid=\(getpid()) \(processArchText()) name='\(name)' display=\(which) fps=\(fps) cursor=\(cursor) NDI_CONFIG_DIR=\(ProcessInfo.processInfo.environment["NDI_CONFIG_DIR"] ?? "(not set)")")

        let displays: [SCDisplay]
        switch ScreenCapture.displays() {
        case .success(let ds): displays = ds
        case .failure(let e):
            olog("oats-screen: cannot list displays: \(e.localizedDescription)")
            olog("  -> Screen Recording permission: System Settings > Privacy & Security > Screen & System Audio Recording: enable Terminal, then `screen.sh restart`")
            Logger.shared.sync(); exit(77)
        }
        if list { for d in displays { print(ScreenCapture.describe(d)) }; exit(0) }
        guard let disp = ScreenCapture.pick(which, from: displays) else {
            olog("oats-screen: no display '\(which)'. Displays: \(displays.map(ScreenCapture.describe).joined(separator: "; "))"); Logger.shared.sync(); exit(69)
        }
        let w = width > 0 ? width : disp.width, h = height > 0 ? height : disp.height
        olog("capturing \(ScreenCapture.describe(disp)) -> \(w)x\(h) @ \(fps) fps BGRA")

        let lib: NDILib
        do { lib = try NDILib(path: libPath) } catch { olog("oats-screen: \(error)"); exit(78) }
        guard lib.initialize() else { olog("oats-screen: NDIlib_initialize failed"); exit(70) }
        olog("libndi \(lib.versionText)")
        var inst: NDIlib_send_instance_t? = nil
        name.withCString { n in var c = NDIlib_send_create_t(p_ndi_name: n, p_groups: nil, clock_video: false, clock_audio: false); inst = lib.send_create(&c) }
        guard let send = inst else { olog("oats-screen: NDIlib_send_create failed"); exit(70) }
        olog("NDI sender '\(name)' created")

        let cap = ScreenCapture()
        cap.onError = { msg in olog("oats-screen: \(msg): exit 70 (supervisor restarts)"); Logger.shared.sync(); _exit(70) }
        do { try cap.start(display: disp, width: w, height: h, fps: fps, cursor: cursor) } catch {
            let msg = error.localizedDescription
            olog("oats-screen: start capture failed: \(msg)")
            if msg.lowercased().contains("permission") || msg.contains("-3801") { olog("  -> Screen Recording permission needed for Terminal"); Logger.shared.sync(); exit(77) }
            Logger.shared.sync(); exit(70)
        }

        var sigs: [DispatchSourceSignal] = []
        for s in [SIGTERM, SIGINT] {
            signal(s, SIG_IGN)
            let src = DispatchSource.makeSignalSource(signal: s, queue: .main)
            src.setEventHandler {
                olog("oats-screen: signal \(s): stop capture + NDIlib_send_destroy, exit")
                let back = Thread { usleep(2_000_000); olog("oats-screen: shutdown hung: _exit(75)"); Logger.shared.sync(); _exit(75) }; back.start()
                cap.stop(); lib.send_destroy(send); lib.destroy()
                olog("oats-screen exit 0"); Logger.shared.sync(); _exit(0)
            }
            src.resume(); sigs.append(src)
        }

        // pacing loop: send the latest frame every 1/fps (repeats the last frame when the screen is static)
        var sent: UInt64 = 0, repeats: UInt64 = 0, lastSentFrame: UInt64 = 0, sendMsMax = 0.0, stalls50 = 0, stalls1s = 0
        let pacer = Thread {
            let period = UInt64(1_000_000_000 / UInt64(fps))
            var nextT = monoNs()
            while true {
                nextT &+= period
                let now = monoNs()
                if nextT > now { usleep(UInt32((nextT - now) / 1000)) } else if now - nextT > period * 4 { nextT = now }   // fell behind: resync
                guard let pb = cap.current() else { continue }
                CVPixelBufferLockBaseAddress(pb, .readOnly)
                if let base = CVPixelBufferGetBaseAddress(pb) {
                    var f = NDIlib_video_frame_v2_t()
                    f.xres = Int32(CVPixelBufferGetWidth(pb)); f.yres = Int32(CVPixelBufferGetHeight(pb))
                    f.FourCC = fourccBGRA; f.frame_rate_N = Int32(fps); f.frame_rate_D = 1
                    f.picture_aspect_ratio = 0; f.frame_format_type = 1; f.timecode = Int64.max
                    f.p_data = base.assumingMemoryBound(to: UInt8.self); f.line_stride_in_bytes = Int32(CVPixelBufferGetBytesPerRow(pb))
                    let t0 = monoNs()
                    lib.send_send_video_v2(send, &f)
                    let ms = Double(monoNs() - t0) / 1e6
                    if ms > sendMsMax { sendMsMax = ms }
                    if ms > 1000 { stalls1s += 1 } else if ms > 50 { stalls50 += 1 }
                    sent &+= 1
                    if cap.frames == lastSentFrame { repeats &+= 1 } else { lastSentFrame = cap.frames }
                }
                CVPixelBufferUnlockBaseAddress(pb, .readOnly)
            }
        }
        pacer.name = "ndi-pace"; pacer.qualityOfService = .userInteractive; pacer.start()

        let statusPath = logDir.isEmpty ? "" : (logDir as NSString).appendingPathComponent("screen-status.json")
        var lastSent: UInt64 = 0, lastT = monoNs()
        let start = monoNs()
        let status = DispatchSource.makeTimerSource(queue: .global(qos: .utility))
        status.schedule(deadline: .now() + 5, repeating: 5)
        status.setEventHandler {
            let now = monoNs(), dt = Double(now - lastT) / 1e9
            let rate = Double(sent - lastSent) / max(dt, 0.001); lastSent = sent; lastT = now
            let conns = Int(lib.send_get_no_connections(send, 0))
            olog("STATUS fps=\(String(format: "%.2f", rate)) sent=\(sent) captured=\(cap.frames) repeats=\(repeats) ndi_conns=\(conns) send_ms max=\(String(format: "%.1f", sendMsMax)) stalls>50ms=\(stalls50) >1s=\(stalls1s)")
            if !statusPath.isEmpty {
                let d: [String: Any] = ["name": name, "display": ScreenCapture.describe(disp), "format": "\(w)x\(h) @ \(fps) fps BGRA", "fps": rate, "sent": Int(sent), "captured": Int(cap.frames), "repeats": Int(repeats),
                                        "ndi_connections": conns, "send_ms_max": sendMsMax, "stalls_over_50ms": stalls50, "stalls_over_1s": stalls1s, "uptime_s": Double(now - start) / 1e9, "pid": Int(getpid()), "arch": processArchText(), "updated": ISO8601DateFormatter().string(from: Date())]
                if let j = try? JSONSerialization.data(withJSONObject: d, options: [.prettyPrinted, .sortedKeys]) { try? j.write(to: URL(fileURLWithPath: statusPath), options: .atomic) }
            }
        }
        status.resume()
        RunLoop.main.run()
    }
}
