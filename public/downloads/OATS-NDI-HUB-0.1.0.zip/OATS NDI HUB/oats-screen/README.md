# oats-screen: a display as an NDI source

Sends one display of this Mac as NDI ("Display 2" = the second monitor by default) with ScreenCaptureKit
-> libndi (BGRA, x86_64 under Rosetta like oats-ndi). Frames are paced at a fixed rate and the last frame is
repeated while the screen is static, so receivers always see a steady stream.

    screen.sh start | stop | restart | status | log [N] | list | build

Settings (`screen.env` or env): SCREEN_NAME "Display 2", SCREEN_DISPLAY secondary|main|<CGDisplayID>,
SCREEN_SIZE (native 1920x1080; set e.g. 1280x720 to scale), SCREEN_FPS 30, SCREEN_ARCH x86_64,
SCREEN_EXTRA e.g. `--no-cursor`. NDI_CONFIG_DIR defaults to ../oats-m0/ndi-config (machine name OBS.HOST).
Started at login by oats-m0/autostart.sh. Needs Screen Recording permission for Terminal (exit 77 = missing).
