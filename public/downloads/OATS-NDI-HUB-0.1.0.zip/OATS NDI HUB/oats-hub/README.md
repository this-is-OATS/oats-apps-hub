# oats-hub: NDI multiview + PTZ control in the browser

Finds every NDI source on the LAN, receives each at proxy bandwidth, and serves a web page with a
multiview grid, a big program view, and PTZ controls (joystick, zoom, 8 presets, autofocus) that call the
NDI receiver PTZ functions directly. Free PTZ for any NDI camera that advertises it (oats-cam does).
Selecting a camera lights its NDI tally (program).

    http://<this mac>:7080/          control page: program view + controls + tile strip (phone / tablet / laptop on the LAN)
    http://<this mac>:7080/multiview full-screen multiview for a wall monitor or Display 2: auto grid, names, PTZ/MIC/LIVE tags,
                                     clock. F = fullscreen, 1-9 columns, 0 auto. Click = select + tally, double-click = open the
                                     control page on that camera. Filters: ?only=link,viz  ?hide=vectorworks
    hub.sh start | stop | restart | status | log [N] | build

Settings (`hub.env` or env): HUB_PORT 7080, HUB_PREVIEW_FPS 12, HUB_QUALITY 0.6, HUB_ARCH arm64,
HUB_EXTRA e.g. `--no-tally` or `--full` (full-bandwidth receive instead of the 640x360 proxy).
NDI_CONFIG_DIR defaults to ../oats-m0/ndi-config. Started at login by oats-m0/autostart.sh.

## Controls

- Click a tile to select. Joystick pad: drag = pan/tilt speed, release = stop. Speed slider scales it.
- Zoom: slider = absolute, hold −/+ = zoom speed.
- Presets 1-8: tap recalls, hold 0.7 s stores. Keyboard: arrows, +/−, 1-8 (shift stores), space stops.
- Home = pan 0 tilt 0 zoom out.
- Voice button / key V: speech-only mode on the selected camera's mic (oats-cam voice gate). FEEDBACK badge + toast when
  the sender auto-muted on a howl (last 60 s), with the frequency and event count.
- Audio button / key A: toggles the selected camera's mic into its NDI feed (oats-cam senders; HUB_AUDIO_CTL maps
  source short name -> the sender's UDP control port, default "Link Cam=127.0.0.1:7001"). Tiles show MIC when on.

## API

    GET  /api/sources                       -> {sources:[{id,name,url,connected,ptz,frames,width,height,age_ms,tally}], selected}
    POST /api/select/<id>|none              tally follows the selection (unless --no-tally)
    POST /api/ptz/<id>/speed      {pan,tilt}      -1..1      POST /api/ptz/<id>/abs    {pan,tilt}
    POST /api/ptz/<id>/zoom_speed {zoom}          -1..1      POST /api/ptz/<id>/zoom   {zoom}  0..1
    POST /api/ptz/<id>/store {index}   /recall {index,speed}   /af   /focus {distance}   /wb_auto   /exposure_auto   /stop
    POST /api/audio/<id>/on|off|toggle|status|voice-on|voice-off|voice-toggle -> {ok, audio, voice}   (sources with a control port)
                       source status carries voice, gate_open, feedback_hz, feedback_age_s, feedback_events
    GET  /ws           WebSocket: every source's preview pushed as encoded, binary frames [id len][id utf8][jpeg]
                       (both pages use this; one connection for all tiles, since browsers cap ~6 connections per host)
    GET  /mjpeg/<id>   multipart MJPEG preview        GET /jpeg/<id>   one frame (polling fallback)
    GET  /<file>       static from www/

ids are the NDI name lower-cased with runs of non-alphanumerics as "-": "OBS.HOST (Link Cam)" -> obs-host-link-cam.

## Code

`src/hub.swift` Source (one libndi receiver per NDI name, BGRA proxy frames -> JPEG via ImageIO at
HUB_PREVIEW_FPS, condition-variable fan-out to MJPEG clients, PTZ passthrough, tally) and Hub (finder
thread, drop after 60 s unseen). `src/http.swift` small threaded HTTP/1.1 server. `src/app.swift` routes.
`www/index.html` the page (vanilla JS, pointer events, works on phones).

## Next (phase 2, the public web viewer)

Keep this hub as the control surface and add per-camera H.264 (VideoToolbox) pushed to mediamtx for
WebRTC/HLS to viewers off the LAN. MJPEG previews are LAN-only by design (bandwidth, no audio).
