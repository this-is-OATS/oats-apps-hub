import Foundation
import CryptoKit

/// Tiny threaded HTTP/1.1 server (POSIX sockets): GET/POST routing, JSON, static files, long-lived MJPEG responses.
struct HTTPRequest { let method: String; let path: String; let query: [String: String]; let headers: [String: String]; let body: Data }

final class HTTPConn {
    let fd: Int32
    init(fd: Int32) { self.fd = fd }
    @discardableResult func write(_ d: Data) -> Bool {
        var ok = true
        d.withUnsafeBytes { (p: UnsafeRawBufferPointer) in
            var off = 0
            while off < p.count {
                let n = Darwin.send(fd, p.baseAddress! + off, p.count - off, 0)
                if n <= 0 { if n < 0 && errno == EINTR { continue }; ok = false; return }
                off += n
            }
        }
        return ok
    }
    @discardableResult func write(_ s: String) -> Bool { write(Data(s.utf8)) }
    func respond(_ status: Int, _ type: String, _ body: Data, extra: String = "") {
        write("HTTP/1.1 \(status) \(status == 200 ? "OK" : status == 404 ? "Not Found" : status == 400 ? "Bad Request" : "Error")\r\nContent-Type: \(type)\r\nContent-Length: \(body.count)\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\(extra)\r\n")
        write(body)
    }
    func json(_ obj: Any, status: Int = 200) {
        let d = (try? JSONSerialization.data(withJSONObject: obj, options: [.sortedKeys])) ?? Data("{}".utf8)
        respond(status, "application/json", d)
    }
    func close() { Darwin.close(fd) }

    // MARK: WebSocket (server side: unmasked frames out, a reader thread that only watches for close)
    private(set) var wsClosed = false
    /// Answer the HTTP upgrade. Returns false (and sends 400) if the request is not a WebSocket handshake.
    func upgradeWebSocket(_ req: HTTPRequest) -> Bool {
        guard req.headers["upgrade"]?.lowercased() == "websocket", let key = req.headers["sec-websocket-key"] else {
            respond(400, "text/plain", Data("websocket upgrade expected".utf8)); return false
        }
        let accept = Data(Insecure.SHA1.hash(data: Data((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").utf8))).base64EncodedString()
        guard write("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: \(accept)\r\n\r\n") else { return false }
        var tv = timeval(tv_sec: 0, tv_usec: 0); setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))   // no read timeout any more
        let reader = Thread { [self] in
            var buf = [UInt8](repeating: 0, count: 4096)
            while true {
                let n = recv(fd, &buf, buf.count, 0)
                if n <= 0 { wsClosed = true; return }
                if n >= 1, buf[0] & 0x0f == 0x8 { wsClosed = true; return }           // close frame
                if n >= 1, buf[0] & 0x0f == 0x9 { _ = write(Data([0x8A, 0x00])) }     // ping -> empty pong
            }
        }
        reader.stackSize = 256 * 1024; reader.start()
        return true
    }
    /// One binary frame (opcode 2). Returns false when the client is gone.
    func wsSendBinary(_ payload: Data) -> Bool {
        if wsClosed { return false }
        var hdr = Data([0x82])
        let n = payload.count
        if n < 126 { hdr.append(UInt8(n)) }
        else if n < 65536 { hdr.append(126); hdr.append(UInt8(n >> 8)); hdr.append(UInt8(n & 0xff)) }
        else { hdr.append(127); for i in (0..<8).reversed() { hdr.append(UInt8((UInt64(n) >> (8 * UInt64(i))) & 0xff)) } }
        return write(hdr) && write(payload)
    }
}

final class HTTPServer {
    typealias Handler = (HTTPRequest, HTTPConn) -> Void
    let port: UInt16
    var handler: Handler
    private var lfd: Int32 = -1
    init(port: UInt16, handler: @escaping Handler) { self.port = port; self.handler = handler }

    func start() throws {
        lfd = socket(AF_INET, SOCK_STREAM, 0)
        guard lfd >= 0 else { throw NSError(domain: "http", code: 1, userInfo: [NSLocalizedDescriptionKey: "socket: \(String(cString: strerror(errno)))"]) }
        var one: Int32 = 1
        setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, socklen_t(MemoryLayout<Int32>.size))
        var addr = sockaddr_in(); addr.sin_family = sa_family_t(AF_INET); addr.sin_port = port.bigEndian; addr.sin_addr.s_addr = INADDR_ANY
        let r = withUnsafePointer(to: &addr) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(lfd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
        guard r == 0 else { throw NSError(domain: "http", code: 2, userInfo: [NSLocalizedDescriptionKey: "bind :\(port): \(String(cString: strerror(errno)))"]) }
        guard listen(lfd, 64) == 0 else { throw NSError(domain: "http", code: 3, userInfo: [NSLocalizedDescriptionKey: "listen: \(String(cString: strerror(errno)))"]) }
        let t = Thread { [self] in
            while true {
                var a = sockaddr_in(); var len = socklen_t(MemoryLayout<sockaddr_in>.size)
                let cfd = withUnsafeMutablePointer(to: &a) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { accept(lfd, $0, &len) } }
                if cfd < 0 { if errno == EINTR { continue }; usleep(10_000); continue }
                var nd: Int32 = 1; setsockopt(cfd, IPPROTO_TCP, TCP_NODELAY, &nd, socklen_t(MemoryLayout<Int32>.size))
                var tv = timeval(tv_sec: 10, tv_usec: 0); setsockopt(cfd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
                let ct = Thread { [self] in self.serve(cfd) }
                ct.stackSize = 512 * 1024; ct.start()
            }
        }
        t.name = "http-accept"; t.start()
    }

    private func serve(_ fd: Int32) {
        let conn = HTTPConn(fd: fd)
        defer { conn.close() }
        var buf = Data(); var tmp = [UInt8](repeating: 0, count: 16384)
        var headerEnd: Range<Data.Index>? = nil
        while headerEnd == nil && buf.count < 1_000_000 {
            let n = recv(fd, &tmp, tmp.count, 0)
            if n <= 0 { return }
            buf.append(tmp, count: n)
            headerEnd = buf.range(of: Data("\r\n\r\n".utf8))
        }
        guard let he = headerEnd, let head = String(data: buf[buf.startIndex..<he.lowerBound], encoding: .utf8) else { return }
        var lines = head.components(separatedBy: "\r\n")
        let reqLine = lines.removeFirst().split(separator: " ")
        guard reqLine.count >= 2 else { return }
        var headers: [String: String] = [:]
        for l in lines { if let c = l.firstIndex(of: ":") { headers[l[..<c].trimmingCharacters(in: .whitespaces).lowercased()] = l[l.index(after: c)...].trimmingCharacters(in: .whitespaces) } }
        var body = Data(buf[he.upperBound...])
        let clen = Int(headers["content-length"] ?? "0") ?? 0
        while body.count < clen && clen < 10_000_000 {
            let n = recv(fd, &tmp, min(tmp.count, clen - body.count), 0)
            if n <= 0 { return }
            body.append(tmp, count: n)
        }
        let target = String(reqLine[1])
        var path = target; var query: [String: String] = [:]
        if let q = target.firstIndex(of: "?") {
            path = String(target[..<q])
            for kv in target[target.index(after: q)...].split(separator: "&") {
                let p = kv.split(separator: "=", maxSplits: 1).map { String($0).removingPercentEncoding ?? String($0) }
                if let k = p.first { query[k] = p.count > 1 ? p[1] : "" }
            }
        }
        let req = HTTPRequest(method: String(reqLine[0]), path: path.removingPercentEncoding ?? path, query: query, headers: headers, body: body)
        handler(req, conn)
    }
}
