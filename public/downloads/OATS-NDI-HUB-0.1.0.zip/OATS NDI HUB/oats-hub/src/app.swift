import Foundation

// oats-hub: NDI multiview + PTZ control in the browser. Finds every NDI source on the LAN, receives each one at proxy
// bandwidth, serves MJPEG previews and a PTZ/preset API that calls the NDI receiver PTZ functions (free, no license).
//
//   oats-hub [--port 7080] [--www DIR] [--log-dir DIR] [--preview-fps 12] [--quality 0.6] [--full] [--no-tally] [--libndi PATH]

let usage = "usage: oats-hub [--port 7080] [--www DIR] [--log-dir DIR] [--preview-fps 12] [--quality 0.6] [--full] [--no-tally] [--libndi PATH]"

@main
struct OatsHub {
    static func main() {
        signal(SIGPIPE, SIG_IGN)
        setvbuf(stdout, nil, _IOLBF, 0)
        var port: UInt16 = 7080, www = "www", logDir = "", previewFps = 12.0, quality = 0.6, bandwidth: Int32 = 0, tally = true, libPath = "/usr/local/lib/libndi.dylib"
        var a = Array(CommandLine.arguments.dropFirst())
        func next(_ k: String) -> String { guard !a.isEmpty else { print("\(k) needs a value\n\(usage)"); exit(64) }; return a.removeFirst() }
        while !a.isEmpty {
            let k = a.removeFirst()
            switch k {
            case "--port": port = UInt16(next(k)) ?? 7080
            case "--www": www = next(k)
            case "--log-dir": logDir = next(k)
            case "--preview-fps": previewFps = Double(next(k)) ?? 12
            case "--quality": quality = Double(next(k)) ?? 0.6
            case "--full": bandwidth = 100
            case "--no-tally": tally = false
            case "--libndi": libPath = next(k)
            case "-h", "--help": print(usage); exit(0)
            default: print("unknown option \(k)\n\(usage)"); exit(64)
            }
        }
        if !logDir.isEmpty && !Logger.shared.open(dir: logDir, prefix: "oats-hub") { print("cannot open a log in \(logDir)"); exit(78) }
        olog("oats-hub starting pid=\(getpid()) \(processArchText()) port \(port) www \(www) preview \(previewFps) fps q\(quality) bandwidth \(bandwidth == 0 ? "proxy" : "full") tally=\(tally) NDI_CONFIG_DIR=\(ProcessInfo.processInfo.environment["NDI_CONFIG_DIR"] ?? "(not set)")")
        let lib: NDILib
        do { lib = try NDILib(path: libPath) } catch { olog("oats-hub: \(error)"); exit(78) }
        guard lib.initialize() else { olog("oats-hub: NDIlib_initialize failed"); exit(70) }
        olog("libndi \(lib.versionText)")
        let hub = Hub(lib: lib, previewFps: previewFps, quality: quality, bandwidth: bandwidth, tallyOn: tally)
        hub.start()

        let server = HTTPServer(port: port) { req, conn in
            let parts = req.path.split(separator: "/").map(String.init)
            switch (req.method, parts.first ?? "") {
            case ("GET", ""):
                serveFile(conn, (www as NSString).appendingPathComponent("index.html"))
            case ("GET", "multiview") where parts.count == 1:
                serveFile(conn, (www as NSString).appendingPathComponent("multiview.html"))
            case ("GET", "api") where parts.count == 2 && parts[1] == "sources":
                conn.json(["sources": hub.list(), "selected": (hub.selected as Any?) ?? NSNull(), "host": Host.current().localizedName ?? "", "time": ISO8601DateFormatter().string(from: Date())])
            case ("POST", "api") where parts.count == 3 && parts[1] == "select":
                let id = parts[2] == "none" ? nil : parts[2]
                if let id = id, hub.source(id) == nil { conn.json(["ok": false, "error": "no such source"], status: 404); return }
                hub.select(id); conn.json(["ok": true, "selected": (id as Any?) ?? NSNull()])
            case ("POST", "api") where parts.count == 4 && parts[1] == "ptz":
                guard let src = hub.source(parts[2]) else { conn.json(["ok": false, "error": "no such source"], status: 404); return }
                let body = (try? JSONSerialization.jsonObject(with: req.body)) as? [String: Any] ?? [:]
                let (ok, err) = src.ptz(parts[3], body)
                if !ok { olog("ptz \(src.id) \(parts[3]) \(body): \(err)") }
                conn.json(["ok": ok, "error": err])
            case (_, "api") where parts.count == 4 && parts[1] == "audio" && (req.method == "POST" || req.query["text"] != nil):   // GET ...?text=1 for Shortcuts hotkeys
                guard let src = hub.source(parts[2]) else { conn.json(["ok": false, "error": "no such source"], status: 404); return }
                guard src.control != nil else { conn.json(["ok": false, "error": "no audio control for this source (HUB_AUDIO_CTL)"], status: 400); return }
                guard ["on", "off", "toggle", "status", "voice-on", "voice-off", "voice-toggle"].contains(parts[3]) else { conn.json(["ok": false, "error": "on|off|toggle|status|voice-on|voice-off|voice-toggle"], status: 400); return }
                if let r = src.audioCommand(parts[3].replacingOccurrences(of: "-", with: " ")) {
                    olog("audio \(src.id) \(parts[3]) -> \(r)")
                    if req.query["text"] != nil { conn.respond(200, "text/plain; charset=utf-8", Data("\(Hub.shortName(src.name)) mic \(src.audio == "on" ? "ON (in the NDI feed)" : "muted")".utf8)) }
                    else { conn.json(["ok": true, "audio": (src.audio as Any?) ?? NSNull(), "voice": (src.voice as Any?) ?? NSNull(), "reply": r]) }
                }
                else if req.query["text"] != nil { conn.respond(502, "text/plain; charset=utf-8", Data("\(Hub.shortName(src.name)): sender did not answer (oats-cam running?)".utf8)) }
                else { conn.json(["ok": false, "error": "sender did not answer on its control port"], status: 502) }
            case ("GET", "ws") where parts.count == 1:
                // push every source's preview as it is encoded: binary frames [id length][id utf8][jpeg]
                guard conn.upgradeWebSocket(req) else { return }
                var last: [String: UInt64] = [:]
                while !conn.wsClosed {
                    var sentAny = false
                    for s in hub.sourcesSnapshot() {
                        let (seq, d) = s.latest()
                        guard seq > 0, seq != last[s.id], !d.isEmpty else { continue }
                        last[s.id] = seq
                        var frame = Data([UInt8(min(s.id.utf8.count, 255))]); frame.append(Data(s.id.utf8.prefix(255))); frame.append(d)
                        guard conn.wsSendBinary(frame) else { return }
                        sentAny = true
                    }
                    usleep(sentAny ? 2_000 : 8_000)
                }
            case ("GET", "mjpeg") where parts.count == 2:
                guard let src = hub.source(parts[1]) else { conn.respond(404, "text/plain", Data("no such source".utf8)); return }
                mjpeg(conn, src)
            case ("GET", "jpeg") where parts.count == 2:
                guard let src = hub.source(parts[1]) else { conn.respond(404, "text/plain", Data("no such source".utf8)); return }
                if let (_, d) = src.waitFrame(after: 0, timeout: 2), !d.isEmpty { conn.respond(200, "image/jpeg", d) } else { conn.respond(404, "text/plain", Data("no frame yet".utf8)) }
            case ("GET", _):
                let rel = parts.joined(separator: "/")
                guard !rel.contains("..") else { conn.respond(400, "text/plain", Data("bad path".utf8)); return }
                serveFile(conn, (www as NSString).appendingPathComponent(rel))
            default:
                conn.respond(404, "text/plain", Data("not found".utf8))
            }
        }
        do { try server.start() } catch { olog("oats-hub: \(error.localizedDescription)"); exit(70) }
        olog("http://\(ipText()):\(port)/  (multiview + PTZ)")

        for s in [SIGTERM, SIGINT] {
            signal(s, SIG_IGN)
            let src = DispatchSource.makeSignalSource(signal: s, queue: .main)
            src.setEventHandler { olog("oats-hub: signal \(s): exit 0"); Logger.shared.sync(); _exit(0) }
            src.resume(); gSignals.append(src)
        }
        let status = DispatchSource.makeTimerSource(queue: .global(qos: .utility))
        status.schedule(deadline: .now() + 10, repeating: 10)
        status.setEventHandler {
            let l = hub.list()
            olog("STATUS sources=\(l.count) " + l.map { "\($0["id"] ?? "?")[\(($0["connected"] as? Bool) == true ? "on" : "off")\(($0["ptz"] as? Bool) == true ? ",ptz" : "")] f=\($0["frames"] ?? 0) age=\($0["age_ms"] ?? -1)ms" }.joined(separator: " ") + " selected=\(hub.selected ?? "-")")
        }
        status.resume()
        RunLoop.main.run()
    }

    static func serveFile(_ conn: HTTPConn, _ path: String) {
        guard let d = FileManager.default.contents(atPath: path) else { conn.respond(404, "text/plain", Data("not found".utf8)); return }
        let ext = (path as NSString).pathExtension.lowercased()
        let type = ["html": "text/html; charset=utf-8", "js": "application/javascript", "css": "text/css", "png": "image/png", "svg": "image/svg+xml", "json": "application/json", "ico": "image/x-icon"][ext] ?? "application/octet-stream"
        conn.respond(200, type, d)
    }

    /// multipart/x-mixed-replace stream of the source's latest JPEGs until the client goes away.
    static func mjpeg(_ conn: HTTPConn, _ src: Source) {
        guard conn.write("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=oatsframe\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n") else { return }
        var last: UInt64 = 0
        while true {
            guard let (seq, d) = src.waitFrame(after: last, timeout: 5) else {
                if src.stopping { return }
                if !conn.write("--oatsframe\r\nContent-Type: text/plain\r\nContent-Length: 0\r\n\r\n\r\n") { return }   // keepalive
                continue
            }
            last = seq
            if !conn.write("--oatsframe\r\nContent-Type: image/jpeg\r\nContent-Length: \(d.count)\r\n\r\n") || !conn.write(d) || !conn.write("\r\n") { return }
        }
    }

    static func ipText() -> String {
        var ifa: UnsafeMutablePointer<ifaddrs>? = nil
        guard getifaddrs(&ifa) == 0, let first = ifa else { return "localhost" }
        defer { freeifaddrs(ifa) }
        var p: UnsafeMutablePointer<ifaddrs>? = first
        while let cur = p {
            if let sa = cur.pointee.ifa_addr, sa.pointee.sa_family == sa_family_t(AF_INET), String(cString: cur.pointee.ifa_name) == "en0" {
                var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                if getnameinfo(sa, socklen_t(sa.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 { return String(cString: host) }
            }
            p = cur.pointee.ifa_next
        }
        return "localhost"
    }
}
var gSignals: [DispatchSourceSignal] = []
