import Foundation

final class NDILib {
    struct LoadError: Error, CustomStringConvertible { let description: String }
    let initialize: fn_initialize, destroy: fn_destroy, version: fn_version
    let find_create_v2: fn_find_create_v2, find_destroy: fn_find_destroy, find_wait_for_sources: fn_find_wait_for_sources, find_get_current_sources: fn_find_get_current_sources
    let recv_create_v3: fn_recv_create_v3, recv_connect: fn_recv_connect, recv_destroy: fn_recv_destroy, recv_capture_v2: fn_recv_capture_v2
    let recv_free_video_v2: fn_recv_free_video_v2, recv_free_metadata: fn_recv_free_metadata, recv_get_no_connections: fn_recv_get_no_connections
    let recv_set_tally: fn_recv_set_tally, recv_get_performance: fn_recv_get_performance
    let ptz_is_supported: fn_recv_ptz_is_supported
    let ptz_pan_tilt: fn_recv_ptz_ff, ptz_pan_tilt_speed: fn_recv_ptz_ff, ptz_zoom: fn_recv_ptz_f, ptz_zoom_speed: fn_recv_ptz_f
    let ptz_store_preset: fn_recv_ptz_i, ptz_recall_preset: fn_recv_ptz_if, ptz_auto_focus: fn_recv_ptz_v, ptz_focus: fn_recv_ptz_f
    let ptz_white_balance_auto: fn_recv_ptz_v, ptz_exposure_auto: fn_recv_ptz_v

    init(path: String) throws {
        guard let h = dlopen(path, RTLD_NOW | RTLD_LOCAL) else { throw LoadError(description: "dlopen(\(path)) failed: \(String(cString: dlerror()))") }
        func s<T>(_ name: String) throws -> T {
            guard let p = dlsym(h, name) else { throw LoadError(description: "dlsym failed: \(name)") }
            return unsafeBitCast(p, to: T.self)
        }
        initialize = try s("NDIlib_initialize"); destroy = try s("NDIlib_destroy"); version = try s("NDIlib_version")
        find_create_v2 = try s("NDIlib_find_create_v2"); find_destroy = try s("NDIlib_find_destroy")
        find_wait_for_sources = try s("NDIlib_find_wait_for_sources"); find_get_current_sources = try s("NDIlib_find_get_current_sources")
        recv_create_v3 = try s("NDIlib_recv_create_v3"); recv_connect = try s("NDIlib_recv_connect"); recv_destroy = try s("NDIlib_recv_destroy")
        recv_capture_v2 = try s("NDIlib_recv_capture_v2"); recv_free_video_v2 = try s("NDIlib_recv_free_video_v2"); recv_free_metadata = try s("NDIlib_recv_free_metadata")
        recv_get_no_connections = try s("NDIlib_recv_get_no_connections"); recv_set_tally = try s("NDIlib_recv_set_tally"); recv_get_performance = try s("NDIlib_recv_get_performance")
        ptz_is_supported = try s("NDIlib_recv_ptz_is_supported")
        ptz_pan_tilt = try s("NDIlib_recv_ptz_pan_tilt"); ptz_pan_tilt_speed = try s("NDIlib_recv_ptz_pan_tilt_speed")
        ptz_zoom = try s("NDIlib_recv_ptz_zoom"); ptz_zoom_speed = try s("NDIlib_recv_ptz_zoom_speed")
        ptz_store_preset = try s("NDIlib_recv_ptz_store_preset"); ptz_recall_preset = try s("NDIlib_recv_ptz_recall_preset")
        ptz_auto_focus = try s("NDIlib_recv_ptz_auto_focus"); ptz_focus = try s("NDIlib_recv_ptz_focus")
        ptz_white_balance_auto = try s("NDIlib_recv_ptz_white_balance_auto"); ptz_exposure_auto = try s("NDIlib_recv_ptz_exposure_auto")
    }
    var versionText: String { version().map { String(cString: $0) } ?? "?" }
}
