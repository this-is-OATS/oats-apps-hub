// Minimal NDI 6 C ABI declarations for oats-hub (receiver side). Mirrors oats-m0/src/ndi_min.h layouts.
#include <stdint.h>
#include <stdbool.h>

typedef void *NDIlib_find_instance_t;
typedef void *NDIlib_recv_instance_t;

typedef struct NDIlib_source_t { const char *p_ndi_name; const char *p_url_address; } NDIlib_source_t;
typedef struct NDIlib_find_create_t { bool show_local_sources; const char *p_groups; const char *p_extra_ips; } NDIlib_find_create_t;
typedef struct NDIlib_recv_create_v3_t {
    NDIlib_source_t source_to_connect_to;
    int32_t color_format;       // 0 = BGRX_BGRA, 100 = fastest, 101 = best
    int32_t bandwidth;          // -10 metadata only, 0 lowest (proxy), 10 audio only, 100 highest
    bool allow_video_fields;
    const char *p_ndi_recv_name;
} NDIlib_recv_create_v3_t;
typedef struct NDIlib_video_frame_v2_t {
    int32_t xres; int32_t yres; uint32_t FourCC; int32_t frame_rate_N; int32_t frame_rate_D; float picture_aspect_ratio;
    int32_t frame_format_type; int64_t timecode; uint8_t *p_data; int32_t line_stride_in_bytes; const char *p_metadata; int64_t timestamp;
} NDIlib_video_frame_v2_t;
typedef struct NDIlib_metadata_frame_t { int32_t length; int64_t timecode; char *p_data; } NDIlib_metadata_frame_t;
typedef struct NDIlib_tally_t { bool on_program; bool on_preview; } NDIlib_tally_t;
typedef struct NDIlib_recv_performance_t { int64_t video_frames; int64_t audio_frames; int64_t metadata_frames; } NDIlib_recv_performance_t;

typedef bool (*fn_initialize)(void);
typedef void (*fn_destroy)(void);
typedef const char *(*fn_version)(void);
typedef NDIlib_find_instance_t (*fn_find_create_v2)(const NDIlib_find_create_t *);
typedef void (*fn_find_destroy)(NDIlib_find_instance_t);
typedef bool (*fn_find_wait_for_sources)(NDIlib_find_instance_t, uint32_t);
typedef const NDIlib_source_t *(*fn_find_get_current_sources)(NDIlib_find_instance_t, uint32_t *);
typedef NDIlib_recv_instance_t (*fn_recv_create_v3)(const NDIlib_recv_create_v3_t *);
typedef void (*fn_recv_connect)(NDIlib_recv_instance_t, const NDIlib_source_t *);
typedef void (*fn_recv_destroy)(NDIlib_recv_instance_t);
// 0 none, 1 video, 2 audio, 3 metadata, 4 error, 100 status change
typedef int32_t (*fn_recv_capture_v2)(NDIlib_recv_instance_t, NDIlib_video_frame_v2_t *, void *, NDIlib_metadata_frame_t *, uint32_t);
typedef void (*fn_recv_free_video_v2)(NDIlib_recv_instance_t, const NDIlib_video_frame_v2_t *);
typedef void (*fn_recv_free_metadata)(NDIlib_recv_instance_t, const NDIlib_metadata_frame_t *);
typedef int (*fn_recv_get_no_connections)(NDIlib_recv_instance_t);
typedef bool (*fn_recv_set_tally)(NDIlib_recv_instance_t, const NDIlib_tally_t *);
typedef void (*fn_recv_get_performance)(NDIlib_recv_instance_t, NDIlib_recv_performance_t *, NDIlib_recv_performance_t *);
typedef bool (*fn_recv_ptz_is_supported)(NDIlib_recv_instance_t);
typedef bool (*fn_recv_ptz_f)(NDIlib_recv_instance_t, float);
typedef bool (*fn_recv_ptz_ff)(NDIlib_recv_instance_t, float, float);
typedef bool (*fn_recv_ptz_i)(NDIlib_recv_instance_t, int);
typedef bool (*fn_recv_ptz_if)(NDIlib_recv_instance_t, int, float);
typedef bool (*fn_recv_ptz_v)(NDIlib_recv_instance_t);
