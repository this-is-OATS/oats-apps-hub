#!/bin/zsh
# OATS NDI HUB login item: waits for the network, then starts the hub, the camera sender (if the camera is present)
# and the display sender (if oats-screen/ENABLED exists). "autostart.sh now" skips the login wait.
D=${0:A:h}
[[ ${1:-} == now ]] || sleep 15
for i in {1..60}; do ipconfig getifaddr en0 >/dev/null 2>&1 || ipconfig getifaddr en1 >/dev/null 2>&1 && break; sleep 2; done
echo "$(date '+%F %T') autostart"
$D/oats-hub/hub.sh start
$D/oats-cam/cam.sh start
[[ -f $D/oats-screen/ENABLED ]] && $D/oats-screen/screen.sh start
exit 0
