import Foundation
import Accelerate
let sr = 48000, hop = 512
let det = FeedbackDetector()!
var buf = [Float](repeating: 0, count: hop); var t = 0
for b in 0..<140 {
    for i in 0..<hop { let s = Float(t + i) / Float(sr); let a = powf(10, (-40 + min(s / 1.5, 1) * 34) / 20); buf[i] = a * sinf(2 * .pi * 1000 * s) + 0.001 * Float.random(in: -1...1) }
    t += hop
    let hit = buf.withUnsafeBufferPointer { det.process($0.baseAddress!, channels: 1, samples: hop, rate: sr) }
    if b % 10 == 0 || hit != nil { print(String(format: "hop %3d t=%.2fs peak %.1f dBFS papr %.1f band %.1f flux %.2f hz %.0f %@", b, Double(t) / Double(sr), det.lastPeakDb, det.lastPaprDb, det.lastBandDb, det.lastFlux, det.lastHz, hit.map { "HIT \($0)" } ?? "")) }
}
