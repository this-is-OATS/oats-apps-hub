// fbtest: synthetic signals through FeedbackDetector (feedback + voice gate), no camera needed.
import Foundation
import Accelerate

let sr = 48000, hop = 512
func dbfs(_ x: Float) -> Float { powf(10, x / 20) }
func run(_ name: String, voice: Bool, _ gen: (Int) -> Float, seconds: Double) -> (hits: [Float], openFrac: Double, firstOpenS: Double?, lastCloseS: Double?) {
    let det = FeedbackDetector()!; det.voiceEnabled = voice
    var hits: [Float] = []; var open = 0, total = 0; var firstOpen: Double? = nil; var lastClose: Double? = nil; var wasOpen = false
    var buf = [Float](repeating: 0, count: hop); var t = 0
    let blocks = Int(seconds * Double(sr)) / hop
    for _ in 0..<blocks {
        for i in 0..<hop { buf[i] = gen(t + i) }; t += hop
        if let hz = buf.withUnsafeBufferPointer({ det.process($0.baseAddress!, channels: 1, samples: hop, rate: sr) }) { hits.append(hz) }
        total += 1; if det.voiceOpen { open += 1 }
        let now = Double(t) / Double(sr)
        if det.voiceOpen && !wasOpen { if firstOpen == nil { firstOpen = now } }
        if !det.voiceOpen && wasOpen { lastClose = now }
        wasOpen = det.voiceOpen
    }
    print(String(format: "%-46@ hits=%@ open=%.0f%%%@%@", name as NSString, hits.map { String(Int($0)) }.joined(separator: ",") as NSString, Double(open) / Double(total) * 100,
                 firstOpen.map { String(format: " firstOpen=%.2fs", $0) } ?? "", lastClose.map { String(format: " lastClose=%.2fs", $0) } ?? ""))
    return (hits, Double(open) / Double(total), firstOpen, lastClose)
}
var rng = SystemRandomNumberGenerator()
func noise() -> Float { Float.random(in: -1...1, using: &rng) }

// 1. howl: 1 kHz swelling -40 -> -6 dBFS over 1.5 s then steady, on -60 dBFS noise  => expect one hit near 1000 Hz
let r1 = run("howl 1 kHz swell (-40 -> -6 dBFS)", voice: false, { i in let s = Double(i) / Double(sr); let a = dbfs(-40 + Float(min(s / 1.5, 1)) * 34); return a * sinf(2 * .pi * 1000 * Float(s)) + dbfs(-60) * noise() }, seconds: 3)
// 2. steady tone -22 dBFS (synth note, no growth) => expect no hit
let r2 = run("steady 440 Hz tone -22 dBFS (no growth)", voice: false, { i in dbfs(-22) * sinf(2 * .pi * 440 * Float(i) / Float(sr)) + dbfs(-60) * noise() }, seconds: 3)
// 3. speech-like: syllable bursts of band-limited noise with pitch harmonics, 4 Hz, on quiet floor; voice gate on => open during speech, closed after
let r3 = run("speech-like bursts (voice gate on)", voice: true, { i in
    let s = Double(i) / Double(sr); let env: Float = s > 0.6 && s < 2.4 ? Float(max(0, sin(2 * .pi * 4 * s))) : 0
    var v: Float = 0; for h in 1...8 { v += sinf(2 * .pi * (130 + 20 * sinf(Float(s) * 3)) * Float(h) * Float(s)) / Float(h) }
    return env * (0.15 * v + 0.08 * noise()) + dbfs(-70) * noise() }, seconds: 4)
// 4. hum 120 Hz + harmonics at -30 dBFS (voice gate on) => gate closed, no feedback hit
let r4 = run("mains hum 120 Hz + harmonics (voice gate on)", voice: true, { i in var v: Float = 0; for h in 1...5 { v += sinf(2 * .pi * 120 * Float(h) * Float(i) / Float(sr)) / Float(h) }; return dbfs(-30) * v + dbfs(-70) * noise() }, seconds: 3)
// 5. howl while voice gate on => still detected
let r5 = run("howl 2.5 kHz swell (voice gate on)", voice: true, { i in let s = Double(i) / Double(sr); let a = dbfs(-45 + Float(min(s / 1.0, 1)) * 40); return a * sinf(2 * .pi * 2500 * Float(s)) + dbfs(-65) * noise() }, seconds: 3)
var ok = true
func check(_ c: Bool, _ what: String) { print((c ? "  PASS " : "  FAIL ") + what); if !c { ok = false } }
check(r1.hits.count >= 1 && abs(r1.hits[0] - 1000) < 60, "howl detected near 1000 Hz")
check(r2.hits.isEmpty, "steady tone not flagged")
check(r3.hits.isEmpty && r3.openFrac > 0.25 && r3.openFrac < 0.8 && (r3.lastCloseS ?? 0) > 2.4 && (r3.lastCloseS ?? 9) < 3.6, "voice gate opens for speech, closes within ~1 s after")
check(r4.hits.isEmpty && r4.openFrac < 0.05, "hum keeps the gate closed, no feedback flag")
check(r5.hits.count >= 1 && abs(r5.hits[0] - 2500) < 100, "howl detected with the voice gate on")
print(ok ? "ALL PASS" : "SOME FAILED"); exit(ok ? 0 : 1)
