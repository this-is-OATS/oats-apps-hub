// ndilisten: receive an NDI source's AUDIO on this machine and measure it: level, frame size, and one-way latency
// (frame.timestamp is the sender's clock in 100 ns UTC; same host => exact). Optionally wait for a 1 kHz test tone
// and report when it appears (acoustic + capture + transport path when the tone is played through the speakers).
//   ndilisten "OBS.HOST (Link Cam)" SECONDS [--tone]
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <math.h>
#include <sys/time.h>
#include <unistd.h>

typedef void *NDIlib_recv_instance_t;
typedef struct { const char *p_ndi_name; const char *p_url_address; } NDIlib_source_t;
typedef struct { NDIlib_source_t source_to_connect_to; int32_t color_format; int32_t bandwidth; bool allow_video_fields; const char *p_ndi_recv_name; } NDIlib_recv_create_v3_t;
typedef struct { int32_t sample_rate; int32_t no_channels; int32_t no_samples; int64_t timecode; float *p_data; int32_t channel_stride_in_bytes; const char *p_metadata; int64_t timestamp; } NDIlib_audio_frame_v2_t;
bool NDIlib_initialize(void);
NDIlib_recv_instance_t NDIlib_recv_create_v3(const NDIlib_recv_create_v3_t *);
void NDIlib_recv_destroy(NDIlib_recv_instance_t);
int32_t NDIlib_recv_capture_v2(NDIlib_recv_instance_t, void *, NDIlib_audio_frame_v2_t *, void *, uint32_t);
void NDIlib_recv_free_audio_v2(NDIlib_recv_instance_t, const NDIlib_audio_frame_v2_t *);

static int64_t now100ns(void) { struct timeval tv; gettimeofday(&tv, NULL); return ((int64_t)tv.tv_sec * 1000000 + tv.tv_usec) * 10; }

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: ndilisten \"HOST (Name)\" SECONDS [--tone]\n"); return 64; }
    double secs = atof(argv[2]); bool tone = argc > 3 && !strcmp(argv[3], "--tone");
    if (!NDIlib_initialize()) { fprintf(stderr, "NDIlib_initialize failed\n"); return 70; }
    NDIlib_recv_create_v3_t c = { { argv[1], NULL }, 100, 10 /* audio only */, false, "ndilisten" };
    NDIlib_recv_instance_t r = NDIlib_recv_create_v3(&c);
    if (!r) { fprintf(stderr, "recv_create failed\n"); return 70; }
    int64_t t0 = now100ns(); int frames = 0; double latMin = 1e9, latMax = 0, latSum = 0; double peakDb = -120, rmsSum = 0;
    int sr = 0, ch = 0, ns = 0; int64_t firstTone = 0, firstFrame = 0; int gaps = 0; int64_t lastArr = 0;
    // Goertzel at 1 kHz for the tone test
    while (now100ns() - t0 < (int64_t)(secs * 1e7)) {
        NDIlib_audio_frame_v2_t a; memset(&a, 0, sizeof a);
        int t = NDIlib_recv_capture_v2(r, NULL, &a, NULL, 200);
        if (t != 2) continue;
        int64_t arr = now100ns();
        if (!firstFrame) firstFrame = arr;
        if (lastArr && arr - lastArr > 600000) gaps++;   // > 60 ms between audio frames
        lastArr = arr;
        frames++; sr = a.sample_rate; ch = a.no_channels; ns = a.no_samples;
        if (a.timestamp > 0) { double lat = (arr - a.timestamp) / 10000.0; if (lat < latMin) latMin = lat; if (lat > latMax) latMax = lat; latSum += lat; }
        double e = 0, pk = 0; float *d = a.p_data;
        for (int i = 0; i < ns; i++) { double v = d[i]; e += v * v; if (fabs(v) > pk) pk = fabs(v); }
        double rms = sqrt(e / (ns ? ns : 1)); rmsSum += rms; double pdb = 20 * log10(pk + 1e-9); if (pdb > peakDb) peakDb = pdb;
        if (tone && !firstTone && sr > 0) {
            double w = 2 * M_PI * 1000.0 / sr, coeff = 2 * cos(w), s0 = 0, s1 = 0, s2 = 0;
            for (int i = 0; i < ns; i++) { s0 = d[i] + coeff * s1 - s2; s2 = s1; s1 = s0; }
            double p = s1 * s1 + s2 * s2 - coeff * s1 * s2, toneRms = sqrt(2 * p) / ns;
            if (toneRms > 0.6 * rms && rms > 0.001) firstTone = arr;
        }
        NDIlib_recv_free_audio_v2(r, &a);
    }
    printf("source %s: %d audio frames in %.1f s", argv[1], frames, secs);
    if (frames) printf(" (%d Hz x%d, %d samples = %.1f ms per frame, ~%.1f fps)", sr, ch, ns, 1000.0 * ns / (sr ? sr : 1), frames / secs);
    printf("\n");
    if (frames) {
        printf("  level: mean RMS %.1f dBFS, peak %.1f dBFS; arrival gaps >60 ms: %d\n", 20 * log10(rmsSum / frames + 1e-9), peakDb, gaps);
        if (latMax > 0) printf("  one-way latency sender->this receiver (same host clock): min %.1f ms, avg %.1f ms, max %.1f ms\n", latMin, latSum / frames, latMax);
        else printf("  (frames carry no sender timestamp)\n");
        if (tone) { if (firstTone) printf("  1 kHz tone first heard %.0f ms after this listener started\n", (firstTone - t0) / 10000.0); else printf("  tone not detected\n"); }
    }
    NDIlib_recv_destroy(r);
    return frames ? 0 : 1;
}
