#include "uvc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>
#include <IOKit/usb/USB.h>

struct uvc_dev {
    IOUSBDeviceInterface **dev;
    IOUSBInterfaceInterface **intf;   // VideoControl interface (may be NULL if we fall back to the device pipe)
    int intf_open;                    // USBInterfaceOpen succeeded
    int vc_if;                        // bInterfaceNumber of the VideoControl interface
    int ct_id, pu_id;
    uint32_t ct_controls;
    char err[256];
};

static void seterr(uvc_dev *d, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); vsnprintf(d->err, sizeof d->err, fmt, ap); va_end(ap);
}

// Walk the configuration descriptor: locate the VC interface (class 14 subclass 1), then its class-specific
// descriptors (bDescriptorType 0x24): subtype 2 = input terminal (wTerminalType 0x0201 camera), 5 = processing unit.
static int parse_config(uvc_dev *d, const uint8_t *p, size_t len) {
    size_t i = 0; int in_vc = 0; d->vc_if = -1; d->ct_id = d->pu_id = 0; d->ct_controls = 0;
    while (i + 2 <= len) {
        uint8_t bl = p[i], bt = p[i + 1];
        if (bl < 2 || i + bl > len) break;
        if (bt == kUSBInterfaceDesc && bl >= 9) {
            in_vc = (p[i + 5] == 14 && p[i + 6] == 1);
            if (in_vc && d->vc_if < 0) d->vc_if = p[i + 2];
        } else if (in_vc && bt == 0x24) {
            uint8_t sub = p[i + 2];
            if (sub == 0x02 && bl >= 8) {                         // VC_INPUT_TERMINAL
                uint16_t tt = p[i + 4] | (p[i + 5] << 8);
                if (tt == 0x0201 && d->ct_id == 0) {              // ITT_CAMERA
                    d->ct_id = p[i + 3];
                    if (bl >= 15) {
                        uint8_t csz = p[i + 14]; uint32_t bm = 0;
                        for (int k = 0; k < csz && k < 4 && 15 + k < bl; k++) bm |= (uint32_t)p[i + 15 + k] << (8 * k);
                        d->ct_controls = bm;
                    }
                }
            } else if (sub == 0x05 && bl >= 4 && d->pu_id == 0) { // VC_PROCESSING_UNIT
                d->pu_id = p[i + 3];
            }
        }
        i += bl;
    }
    return d->vc_if >= 0;
}

static IOUSBInterfaceInterface **open_interface(uvc_dev *d, io_service_t devsvc) {
    io_iterator_t it = 0; IOUSBInterfaceInterface **res = NULL;
    if (IORegistryEntryGetChildIterator(devsvc, kIOServicePlane, &it) != kIOReturnSuccess) return NULL;
    io_service_t s;
    while ((s = IOIteratorNext(it))) {
        CFTypeRef n = IORegistryEntryCreateCFProperty(s, CFSTR(kUSBInterfaceNumber), kCFAllocatorDefault, 0);
        int num = -1;
        if (n) { if (CFGetTypeID(n) == CFNumberGetTypeID()) CFNumberGetValue(n, kCFNumberIntType, &num); CFRelease(n); }
        if (num == d->vc_if) {
            IOCFPlugInInterface **plug = NULL; SInt32 score = 0;
            if (IOCreatePlugInInterfaceForService(s, kIOUSBInterfaceUserClientTypeID, kIOCFPlugInInterfaceID, &plug, &score) == kIOReturnSuccess && plug) {
                IOUSBInterfaceInterface **intf = NULL;
                (*plug)->QueryInterface(plug, CFUUIDGetUUIDBytes(kIOUSBInterfaceInterfaceID), (LPVOID *)&intf);
                IODestroyPlugInInterface(plug);
                if (intf) {
                    IOReturn kr = (*intf)->USBInterfaceOpen(intf);
                    d->intf_open = (kr == kIOReturnSuccess);
                    if (!d->intf_open) snprintf(d->err, sizeof d->err, "USBInterfaceOpen: 0x%08x (will use the device control pipe)", kr);
                    res = intf;
                }
            }
            IOObjectRelease(s);
            break;
        }
        IOObjectRelease(s);
    }
    IOObjectRelease(it);
    return res;
}

uvc_dev *uvc_open(uint16_t vid, uint16_t pid, char *err, size_t errlen) {
    uvc_dev *d = calloc(1, sizeof *d);
    CFMutableDictionaryRef m = IOServiceMatching(kIOUSBDeviceClassName);
    int v = vid, p = pid;
    CFNumberRef cv = CFNumberCreate(NULL, kCFNumberIntType, &v), cp = CFNumberCreate(NULL, kCFNumberIntType, &p);
    CFDictionarySetValue(m, CFSTR(kUSBVendorID), cv); CFDictionarySetValue(m, CFSTR(kUSBProductID), cp);
    CFRelease(cv); CFRelease(cp);
    io_iterator_t it = 0;
    if (IOServiceGetMatchingServices(kIOMainPortDefault, m, &it) != kIOReturnSuccess) { snprintf(err, errlen, "IOServiceGetMatchingServices failed"); free(d); return NULL; }
    io_service_t svc = IOIteratorNext(it); IOObjectRelease(it);
    if (!svc) { snprintf(err, errlen, "no USB device %04x:%04x", vid, pid); free(d); return NULL; }
    IOCFPlugInInterface **plug = NULL; SInt32 score = 0;
    IOReturn kr = IOCreatePlugInInterfaceForService(svc, kIOUSBDeviceUserClientTypeID, kIOCFPlugInInterfaceID, &plug, &score);
    if (kr != kIOReturnSuccess || !plug) { snprintf(err, errlen, "device plugin: 0x%08x", kr); IOObjectRelease(svc); free(d); return NULL; }
    (*plug)->QueryInterface(plug, CFUUIDGetUUIDBytes(kIOUSBDeviceInterfaceID), (LPVOID *)&d->dev);
    IODestroyPlugInInterface(plug);
    if (!d->dev) { snprintf(err, errlen, "QueryInterface(device) failed"); IOObjectRelease(svc); free(d); return NULL; }
    IOUSBConfigurationDescriptorPtr cfg = NULL;
    kr = (*d->dev)->GetConfigurationDescriptorPtr(d->dev, 0, &cfg);
    if (kr != kIOReturnSuccess || !cfg) { snprintf(err, errlen, "GetConfigurationDescriptorPtr: 0x%08x", kr); uvc_close(d); IOObjectRelease(svc); return NULL; }
    uint16_t total = USBToHostWord(cfg->wTotalLength);
    if (!parse_config(d, (const uint8_t *)cfg, total)) { snprintf(err, errlen, "no VideoControl interface in descriptor (%u bytes)", total); uvc_close(d); IOObjectRelease(svc); return NULL; }
    d->intf = open_interface(d, svc);
    if (!d->intf) { // fall back: device control pipe; opening the device is optional for pipe 0 requests
        (*d->dev)->USBDeviceOpen(d->dev);
    }
    IOObjectRelease(svc);
    return d;
}

void uvc_close(uvc_dev *d) {
    if (!d) return;
    if (d->intf) { if (d->intf_open) (*d->intf)->USBInterfaceClose(d->intf); (*d->intf)->Release(d->intf); }
    if (d->dev) { (*d->dev)->USBDeviceClose(d->dev); (*d->dev)->Release(d->dev); }
    free(d);
}

int uvc_interface_number(const uvc_dev *d) { return d->vc_if; }
int uvc_camera_terminal(const uvc_dev *d) { return d->ct_id; }
int uvc_processing_unit(const uvc_dev *d) { return d->pu_id; }
uint32_t uvc_ct_controls(const uvc_dev *d) { return d->ct_controls; }
const char *uvc_last_error(const uvc_dev *d) { return d->err; }

static int request(uvc_dev *d, uint8_t bmRequestType, uint8_t bRequest, uint8_t unit, uint8_t cs, void *buf, uint16_t len, int *iokit) {
    IOUSBDevRequest r;
    memset(&r, 0, sizeof r);
    r.bmRequestType = bmRequestType;
    r.bRequest = bRequest;
    r.wValue = (uint16_t)(cs << 8);
    r.wIndex = (uint16_t)((unit << 8) | (d->vc_if & 0xff));
    r.wLength = len;
    r.pData = buf;
    IOReturn kr;
    if (d->intf && d->intf_open) kr = (*d->intf)->ControlRequest(d->intf, 0, &r);
    else kr = (*d->dev)->DeviceRequest(d->dev, &r);
    if (iokit) *iokit = (int)kr;
    if (kr != kIOReturnSuccess) { seterr(d, "request 0x%02x cs 0x%02x unit %d: IOKit 0x%08x", bRequest, cs, unit, kr); return -1; }
    return (int)r.wLenDone;
}

int uvc_get(uvc_dev *d, uint8_t unit, uint8_t cs, uint8_t req, void *buf, uint16_t len, int *iokit) {
    return request(d, 0xA1, req, unit, cs, buf, len, iokit);   // IN | class | interface
}
int uvc_set(uvc_dev *d, uint8_t unit, uint8_t cs, const void *buf, uint16_t len, int *iokit) {
    return request(d, 0x21, UVC_SET_CUR, unit, cs, (void *)buf, len, iokit);   // OUT | class | interface
}

int uvc_reenumerate(uint16_t vid, uint16_t pid, char *err, size_t errlen) {
    CFMutableDictionaryRef m = IOServiceMatching(kIOUSBDeviceClassName);
    int v = vid, p = pid;
    CFNumberRef cv = CFNumberCreate(NULL, kCFNumberIntType, &v), cp = CFNumberCreate(NULL, kCFNumberIntType, &p);
    CFDictionarySetValue(m, CFSTR(kUSBVendorID), cv); CFDictionarySetValue(m, CFSTR(kUSBProductID), cp);
    CFRelease(cv); CFRelease(cp);
    io_service_t svc = IOServiceGetMatchingService(kIOMainPortDefault, m);
    if (!svc) { snprintf(err, errlen, "no USB device %04x:%04x", vid, pid); return -1; }
    IOCFPlugInInterface **plug = NULL; SInt32 score = 0; IOUSBDeviceInterface **dev = NULL;
    IOReturn kr = IOCreatePlugInInterfaceForService(svc, kIOUSBDeviceUserClientTypeID, kIOCFPlugInInterfaceID, &plug, &score);
    IOObjectRelease(svc);
    if (kr != kIOReturnSuccess || !plug) { snprintf(err, errlen, "device plugin: 0x%08x", kr); return kr; }
    (*plug)->QueryInterface(plug, CFUUIDGetUUIDBytes(kIOUSBDeviceInterfaceID), (LPVOID *)&dev);
    IODestroyPlugInInterface(plug);
    if (!dev) { snprintf(err, errlen, "QueryInterface failed"); return -1; }
    kr = (*dev)->USBDeviceOpenSeize(dev);
    if (kr != kIOReturnSuccess) { snprintf(err, errlen, "USBDeviceOpenSeize: 0x%08x", kr); (*dev)->Release(dev); return kr; }
    kr = (*dev)->USBDeviceReEnumerate(dev, 0);
    snprintf(err, errlen, "USBDeviceReEnumerate: 0x%08x", kr);
    (*dev)->USBDeviceClose(dev); (*dev)->Release(dev);
    return kr;
}
