import Foundation
import AVFoundation
import CoreMedia

/// Microphone capture (the camera's own mic by default) -> planar float for NDI. Capture runs all the time so the
/// toggle is instant; `on` gates the send. Toggled by UDP control ("audio on|off|toggle|status") or SIGUSR1.
final class AudioCapture: NSObject, AVCaptureAudioDataOutputSampleBufferDelegate {
    let output = AVCaptureAudioDataOutput()
    let queue = DispatchQueue(label: "oats-cam.audio", qos: .userInteractive)
    var onAudio: ((UnsafePointer<Float>, Int, Int, Int) -> Void)?   // planar data, channels, samples, sampleRate
    private(set) var device: AVCaptureDevice?
    private(set) var frames: UInt64 = 0
    private(set) var sampleRate = 0, channels = 0
    private var planar = [Float]()

    static func devices() -> [AVCaptureDevice] {
        var types: [AVCaptureDevice.DeviceType] = []
        if #available(macOS 14.0, *) { types = [.microphone, .external] } else { types = [.builtInMicrophone, .externalUnknown] }
        return AVCaptureDevice.DiscoverySession(deviceTypes: types, mediaType: .audio, position: .unspecified).devices
    }
    static func pick(match: String) -> AVCaptureDevice? {
        let all = devices()
        return all.first { $0.localizedName.localizedCaseInsensitiveContains(match) || $0.uniqueID == match } ?? (match == "default" ? AVCaptureDevice.default(for: .audio) : nil)
    }
    static func authorize(timeoutS: Double) -> String? {
        switch AVCaptureDevice.authorizationStatus(for: .audio) {
        case .authorized: return nil
        case .denied: return "microphone access denied (System Settings > Privacy & Security > Microphone: enable Terminal)"
        case .restricted: return "microphone access restricted"
        default:
            olog("audio: microphone permission not yet granted: waiting for the macOS prompt (click Allow) up to \(Int(timeoutS)) s")
            let sem = DispatchSemaphore(value: 0); var ok = false
            AVCaptureDevice.requestAccess(for: .audio) { ok = $0; sem.signal() }
            if sem.wait(timeout: .now() + timeoutS) == .timedOut { return "microphone prompt not answered" }
            return ok ? nil : "microphone access denied at the prompt"
        }
    }

    /// Attach to the (already configured) session. Returns nil on success or a reason.
    func attach(to session: AVCaptureSession, device d: AVCaptureDevice) -> String? {
        do {
            let input = try AVCaptureDeviceInput(device: d)
            session.beginConfiguration()
            defer { session.commitConfiguration() }
            guard session.canAddInput(input) else { return "cannot add audio input \(d.localizedName)" }
            session.addInput(input)
            // macOS lets us ask for the delivery format: 48 kHz float32 non-interleaved (= NDI FLTP, no conversion)
            output.audioSettings = [AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: 48000, AVLinearPCMBitDepthKey: 32,
                                    AVLinearPCMIsFloatKey: true, AVLinearPCMIsNonInterleaved: true, AVLinearPCMIsBigEndianKey: false]
            output.setSampleBufferDelegate(self, queue: queue)
            guard session.canAddOutput(output) else { return "cannot add audio output" }
            session.addOutput(output)
            device = d
            return nil
        } catch { return "audio input: \(error.localizedDescription)" }
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sb: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let fd = CMSampleBufferGetFormatDescription(sb), let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(fd)?.pointee else { return }
        let n = CMSampleBufferGetNumSamples(sb); guard n > 0 else { return }
        let ch = Int(asbd.mChannelsPerFrame), sr = Int(asbd.mSampleRate)
        let isFloat = asbd.mFormatFlags & kAudioFormatFlagIsFloat != 0, nonInter = asbd.mFormatFlags & kAudioFormatFlagIsNonInterleaved != 0
        var ablSize = 0
        CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sb, bufferListSizeNeededOut: &ablSize, bufferListOut: nil, bufferListSize: 0, blockBufferAllocator: nil, blockBufferMemoryAllocator: nil, flags: 0, blockBufferOut: nil)
        let ablPtr = UnsafeMutableRawPointer.allocate(byteCount: max(ablSize, MemoryLayout<AudioBufferList>.size), alignment: 16)
        defer { ablPtr.deallocate() }
        let abl = ablPtr.assumingMemoryBound(to: AudioBufferList.self)
        var block: CMBlockBuffer? = nil
        guard CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sb, bufferListSizeNeededOut: nil, bufferListOut: abl, bufferListSize: ablSize, blockBufferAllocator: nil, blockBufferMemoryAllocator: nil, flags: kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment, blockBufferOut: &block) == noErr else { return }
        let buffers = UnsafeMutableAudioBufferListPointer(abl)
        if planar.count < ch * n { planar = [Float](repeating: 0, count: ch * n) }
        planar.withUnsafeMutableBufferPointer { out in
            if isFloat && nonInter {
                for c in 0..<min(ch, buffers.count) { if let p = buffers[c].mData?.assumingMemoryBound(to: Float.self) { (out.baseAddress! + c * n).update(from: p, count: n) } }
            } else if isFloat, let p = buffers[0].mData?.assumingMemoryBound(to: Float.self) {       // interleaved float
                for i in 0..<n { for c in 0..<ch { out[c * n + i] = p[i * ch + c] } }
            } else if asbd.mBitsPerChannel == 16, let p = buffers[0].mData?.assumingMemoryBound(to: Int16.self) {   // interleaved int16
                for i in 0..<n { for c in 0..<ch { out[c * n + i] = Float(p[i * ch + c]) / 32768 } }
            } else { return }
            frames &+= 1; sampleRate = sr; channels = ch
            if frames == 1 || frames % 3000 == 0 {
                var rms: Float = 0; vDSP_rmsqv(out.baseAddress!, 1, &rms, vDSP_Length(ch * n))
                var raw: Float = 0; if let p0 = buffers[0].mData?.assumingMemoryBound(to: Float.self) { vDSP_rmsqv(p0, 1, &raw, vDSP_Length(Int(buffers[0].mDataByteSize) / 4)) }
                let pw = connection.audioChannels.first.map { String(format: "%.0f", $0.averagePowerLevel) } ?? "?"
                olog("audio dbg: buf#\(frames) n=\(n) ch=\(ch) flags=0x\(String(asbd.mFormatFlags, radix: 16)) bits=\(asbd.mBitsPerChannel) bpf=\(asbd.mBytesPerFrame) abl=\(buffers.count) bytes=\(buffers[0].mDataByteSize) rawRMS=\(String(format: "%.5f", raw)) planarRMS=\(String(format: "%.5f", rms)) sessionPower=\(pw) dB")
            }
            if frames == 1 { olog("audio: first buffer \(n) samples = \(String(format: "%.1f", Double(n) / Double(max(sr, 1)) * 1000)) ms at \(sr) Hz x\(ch) \(isFloat ? "float" : "int") \(nonInter ? "planar" : "interleaved") (sender latency ~ one buffer)") }
            onAudio?(UnsafePointer(out.baseAddress!), ch, n, sr)
        }
    }
}

/// Tiny UDP control socket: "audio on|off|toggle|status" -> replies "audio on" / "audio off".
final class ControlPort {
    let port: UInt16
    var handler: ((String) -> String)?
    init(port: UInt16) { self.port = port }
    func start() -> String? {
        let fd = socket(AF_INET, SOCK_DGRAM, 0)
        guard fd >= 0 else { return "socket: \(String(cString: strerror(errno)))" }
        var one: Int32 = 1; setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, socklen_t(MemoryLayout<Int32>.size))
        var addr = sockaddr_in(); addr.sin_family = sa_family_t(AF_INET); addr.sin_port = port.bigEndian; addr.sin_addr.s_addr = inet_addr("127.0.0.1")
        let r = withUnsafePointer(to: &addr) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
        guard r == 0 else { return "bind 127.0.0.1:\(port): \(String(cString: strerror(errno)))" }
        let t = Thread { [self] in
            var buf = [UInt8](repeating: 0, count: 512)
            while true {
                var from = sockaddr_in(); var flen = socklen_t(MemoryLayout<sockaddr_in>.size)
                let n = withUnsafeMutablePointer(to: &from) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { recvfrom(fd, &buf, buf.count, 0, $0, &flen) } }
                guard n > 0 else { continue }
                let cmd = String(decoding: buf[0..<n], as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
                let reply = handler?(cmd) ?? "?"
                _ = withUnsafePointer(to: &from) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { p in reply.withCString { sendto(fd, $0, strlen($0), 0, p, flen) } } }
            }
        }
        t.name = "control"; t.start()
        return nil
    }
}

// MARK: feedback detection
import Accelerate

/// Acoustic feedback (howl) detector: a 1024-point Hann FFT every 512 samples; feedback is a narrowband peak that dominates
/// the spectrum (peak-to-average > paprDb), is loud (> levelDbfs), stays on the same bin for `holdHops` hops (~320 ms) and
/// grows (>= growDb since the streak began, or is already very loud). Music notes have harmonics (low PAPR) and don't grow.
final class FeedbackDetector {
    let n = 1024, hop = 512
    private let setup: FFTSetup
    private let window: [Float]
    private var ring = [Float](repeating: 0, count: 1024)
    private var fill = 0
    private var real = [Float](repeating: 0, count: 512), imag = [Float](repeating: 0, count: 512), mag = [Float](repeating: 0, count: 512)
    private var streakBin = -1, streak = 0, streakStartDb: Float = -120
    var paprDb: Float = 12, levelDbfs: Float = -50, holdHops = 30, growDb: Float = 6   // PAPR of a pure tone caps near 23 dB; tonality > 20 dB is the main tone test
    private(set) var lastPeakDb: Float = -120, lastPaprDb: Float = 0, lastHz: Float = 0, lastTonalityDb: Float = 0
    private var lastHitNs: UInt64 = 0
    // voice gate (speech mode): open while the 300..3400 Hz band is well above the tracked noise floor, the spectrum is not a
    // pure tone, and it changes frame to frame (speech is non-stationary; howls, hum and fans are not); hangover after speech.
    var voiceEnabled = false { didSet { voiceOpen = !voiceEnabled; hang = 0 } }
    private(set) var voiceOpen = true
    var voiceSnrDb: Float = 9, voiceFluxMin: Float = 0.4, voiceHangHops = 70   // speech flux 0.4..13 live; harmonic hum beats at <0.3
    private var prevMag = [Float](repeating: 0, count: 512)
    private var havePrev = false
    private var floorDb: Float = -60
    private var hang = 0
    private(set) var lastBandDb: Float = -120, lastFlux: Float = 0, lastFloorDb: Float = -60

    init?() {
        guard let s = vDSP_create_fftsetup(10, FFTRadix(kFFTRadix2)) else { return nil }
        setup = s
        var w = [Float](repeating: 0, count: 1024); vDSP_hann_window(&w, 1024, Int32(vDSP_HANN_DENORM)); window = w
    }
    deinit { vDSP_destroy_fftsetup(setup) }
    func reset() { streak = 0; streakBin = -1; hang = 0; havePrev = false; if voiceEnabled { voiceOpen = false } }

    /// Feed planar float audio. Returns the feedback frequency (Hz) once when an event is confirmed.
    func process(_ data: UnsafePointer<Float>, channels: Int, samples: Int, rate: Int) -> Float? {
        var hit: Float? = nil
        var i = 0
        while i < samples {
            let take = min(n - fill, samples - i)
            for k in 0..<take {
                var v: Float = 0
                for c in 0..<channels { v += data[c * samples + i + k] }
                ring[fill + k] = v / Float(channels)
            }
            fill += take; i += take
            if fill == n {
                if let hz = analyze(rate: rate) { hit = hz }
                for k in 0..<hop { ring[k] = ring[k + hop] }
                fill = hop
            }
        }
        return hit
    }
    private func analyze(rate: Int) -> Float? {
        var windowed = [Float](repeating: 0, count: n)
        vDSP_vmul(ring, 1, window, 1, &windowed, 1, vDSP_Length(n))
        real.withUnsafeMutableBufferPointer { rp in
            imag.withUnsafeMutableBufferPointer { ip in
                var split = DSPSplitComplex(realp: rp.baseAddress!, imagp: ip.baseAddress!)
                windowed.withUnsafeBufferPointer { wp in
                    wp.baseAddress!.withMemoryRebound(to: DSPComplex.self, capacity: n / 2) { vDSP_ctoz($0, 2, &split, 1, vDSP_Length(n / 2)) }
                }
                vDSP_fft_zrip(setup, &split, 1, 10, FFTDirection(FFT_FORWARD))
                split.imagp[0] = 0   // drop the packed Nyquist term from bin 0
                vDSP_zvmags(&split, 1, &mag, 1, vDSP_Length(n / 2))
            }
        }
        // bins 3.. (skip DC/rumble below ~140 Hz)
        var peak: Float = 0; var peakIdx: vDSP_Length = 0; var mean: Float = 0
        mag.withUnsafeBufferPointer { mp in
            vDSP_maxvi(mp.baseAddress! + 3, 1, &peak, &peakIdx, vDSP_Length(n / 2 - 3))
            vDSP_meanv(mp.baseAddress! + 3, 1, &mean, vDSP_Length(n / 2 - 3))
        }
        let idx = Int(peakIdx) + 3
        let norm: Float = 20 * log10f(Float(n) / 2)              // full-scale sine with this window/packing -> ~0 dBFS
        let peakDb = 10 * log10f(max(peak, 1e-12)) - norm
        let papr = 10 * log10f(max(peak, 1e-12) / max(mean, 1e-12))
        // tonality: the peak against its neighbourhood (±3..12 bins). A pure tone has nothing there (>25 dB);
        // voiced speech and hum have harmonics 2-5 bins away (<15 dB).
        var nsum: Float = 0; var ncnt = 0
        for k in max(3, idx - 12)...min(n / 2 - 1, idx + 12) where abs(k - idx) > 2 { nsum += mag[k]; ncnt += 1 }
        let tonality = 10 * log10f(max(peak, 1e-12) / max(nsum / Float(max(ncnt, 1)), 1e-12))
        lastPeakDb = peakDb; lastPaprDb = papr; lastTonalityDb = tonality
        // voice activity
        var band: Float = 0
        mag.withUnsafeBufferPointer { vDSP_sve($0.baseAddress! + 6, 1, &band, 68) }   // bins 6..73 = 280..3420 Hz
        let bandDb = 10 * log10f(max(band, 1e-12)) - norm
        // spectral flux, energy-weighted, speech band only: steady tones/hum ~0, speech large (noise-only frames fail the SNR test)
        var flux: Float = 0, tot: Float = 0
        for k in 6..<74 { flux += abs(mag[k] - prevMag[k]); tot += mag[k] }
        for k in 3..<(n / 2) { prevMag[k] = mag[k] }
        let fluxN = havePrev && tot > 0 ? flux / tot : 0
        havePrev = true
        let speech = bandDb > floorDb + voiceSnrDb && tonality < 20 && fluxN > voiceFluxMin
        if bandDb < floorDb { floorDb = bandDb } else if !speech { floorDb = min(floorDb + 0.01, bandDb) }   // noise floor: fast down, ~1 dB/s up
        floorDb = max(floorDb, -95)
        lastBandDb = bandDb; lastFlux = fluxN; lastFloorDb = floorDb
        if voiceEnabled { if speech { hang = voiceHangHops } else if hang > 0 { hang -= 1 }; voiceOpen = hang > 0 } else { voiceOpen = true; hang = 0 }
        guard papr > paprDb, tonality > 20, peakDb > levelDbfs else { streak = 0; streakBin = -1; return nil }
        if abs(idx - streakBin) <= 1 { streak += 1 } else { streakBin = idx; streak = 1; streakStartDb = peakDb }
        guard streak >= holdHops, peakDb - streakStartDb >= growDb || peakDb > -15 else { return nil }
        streak = 0; streakBin = -1
        let now = monoNs(); if now - lastHitNs < 2_000_000_000 { return nil }; lastHitNs = now   // one event per 2 s
        lastHz = Float(idx) * Float(rate) / Float(n)
        return lastHz
    }
}

// MARK: self-echo (monitoring loop) detection
/// Looks for the sender's OWN transmitted audio coming back through the mic with a delay: speakers in the room playing the
/// NDI feed. Normalised cross-correlation of the last 200 ms of mic against the last 1 s of sent audio (both at 8 kHz),
/// lags 40..900 ms. A clear peak at a stable lag for 3 consecutive checks (~0.75 s) = loop detected (even when it is not
/// loud enough to howl). Cheap: one vDSP correlation every 250 ms.
final class EchoDetector {
    let rate = 8000, hist = 8000, win = 1600                 // 1 s of sent history, 200 ms analysis window
    let minLag = 320, maxLag = 7200                          // 40 ms .. 900 ms
    private var sent = [Float](repeating: 0, count: 8000)    // ring of what we transmitted (8 kHz mono)
    private var mic = [Float](repeating: 0, count: 8000)     // ring of what we heard
    private var sentW = 0, micW = 0, sinceCheck = 0
    private var decim = 0, accS: Float = 0, accM: Float = 0
    private var lastLag = -1, streak = 0
    private var lastHitNs: UInt64 = 0
    private(set) var lastCorr: Float = 0, lastLagMs = 0, lastLoopMs = 0
    var threshold: Float = 0.45, holdChecks = 3

    /// Feed the planar block that was just SENT (post-gain) and the raw MIC block it came from (same length), at `sr` Hz.
    /// Returns the loop lag in ms once per confirmed event.
    func process(sentBlock: UnsafePointer<Float>, micBlock: UnsafePointer<Float>, channels: Int, samples: Int, sr: Int) -> Int? {
        let step = max(1, sr / rate)                          // 48000 -> 6 : box-average decimation (good enough for correlation)
        for i in 0..<samples {
            var s: Float = 0, m: Float = 0
            for c in 0..<channels { s += sentBlock[c * samples + i]; m += micBlock[c * samples + i] }
            accS += s / Float(channels); accM += m / Float(channels); decim += 1
            if decim == step {
                sent[sentW] = accS / Float(step); mic[micW] = accM / Float(step)
                sentW = (sentW + 1) % hist; micW = (micW + 1) % hist
                accS = 0; accM = 0; decim = 0; sinceCheck += 1
            }
        }
        guard sinceCheck >= rate / 4 else { return nil }      // every 250 ms
        sinceCheck = 0
        return check()
    }
    private func linear(_ ring: [Float], _ w: Int) -> [Float] { Array(ring[w..<hist] + ring[0..<w]) }   // oldest .. newest
    private func check() -> Int? {
        let m = linear(mic, micW), s = linear(sent, sentW)
        let micSeg = Array(m[(hist - win)...])                                  // newest 200 ms of mic
        var micE: Float = 0; vDSP_svesq(micSeg, 1, &micE, vDSP_Length(win))
        guard micE > 1e-6 else { streak = 0; lastCorr = 0; return nil }        // silence
        // correlate micSeg against sent at lag L: sent segment ending L samples before the mic segment's end
        var best: Float = 0, bestLag = -1
        var lag = minLag
        while lag <= maxLag {
            let start = hist - win - lag; guard start >= 0 else { break }
            var dot: Float = 0, e: Float = 0
            s.withUnsafeBufferPointer { sp in
                vDSP_dotpr(sp.baseAddress! + start, 1, micSeg, 1, &dot, vDSP_Length(win))
                vDSP_svesq(sp.baseAddress! + start, 1, &e, vDSP_Length(win))
            }
            if e > 1e-6 { let c = dot / sqrtf(e * micE); if c > best { best = c; bestLag = lag } }
            lag += 8                                                            // 1 ms steps
        }
        lastCorr = best; lastLagMs = bestLag > 0 ? bestLag * 1000 / rate : 0
        if best >= threshold, bestLag > 0, lastLag < 0 || abs(bestLag - lastLag) <= 40 { streak += 1; lastLag = bestLag } else { streak = 0; lastLag = bestLag }
        guard streak >= holdChecks else { return nil }
        streak = 0
        let now = monoNs(); if now - lastHitNs < 3_000_000_000 { return nil }; lastHitNs = now
        lastLoopMs = lastLagMs
        return lastLagMs
    }
}
