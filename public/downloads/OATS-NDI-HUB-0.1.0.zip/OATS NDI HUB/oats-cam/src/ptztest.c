// ptztest: drive an NDI source's PTZ from the receiver side (what a multiviewer does), to test oats-cam end to end.
//   ptztest "MAC.LOCALDOMAIN (Link Cam)" cmd...   cmds: speed PAN TILT SECS | zoomspeed Z SECS | abs PAN TILT | zoom Z |
//                                                   store N | recall N | af | wait SECS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>

typedef void *NDIlib_recv_instance_t;
typedef struct { const char *p_ndi_name; const char *p_url_address; } NDIlib_source_t;
typedef struct { NDIlib_source_t source_to_connect_to; int32_t color_format; int32_t bandwidth; bool allow_video_fields; const char *p_ndi_recv_name; } NDIlib_recv_create_v3_t;
bool NDIlib_initialize(void);
NDIlib_recv_instance_t NDIlib_recv_create_v3(const NDIlib_recv_create_v3_t *);
void NDIlib_recv_destroy(NDIlib_recv_instance_t);
int32_t NDIlib_recv_capture_v2(NDIlib_recv_instance_t, void *, void *, void *, uint32_t);
int NDIlib_recv_get_no_connections(NDIlib_recv_instance_t);
bool NDIlib_recv_ptz_is_supported(NDIlib_recv_instance_t);
bool NDIlib_recv_ptz_zoom(NDIlib_recv_instance_t, float);
bool NDIlib_recv_ptz_zoom_speed(NDIlib_recv_instance_t, float);
bool NDIlib_recv_ptz_pan_tilt(NDIlib_recv_instance_t, float, float);
bool NDIlib_recv_ptz_pan_tilt_speed(NDIlib_recv_instance_t, float, float);
bool NDIlib_recv_ptz_store_preset(NDIlib_recv_instance_t, int);
bool NDIlib_recv_ptz_recall_preset(NDIlib_recv_instance_t, int, float);
bool NDIlib_recv_ptz_auto_focus(NDIlib_recv_instance_t);

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: ptztest \"HOST (Name)\" cmd...\n"); return 64; }
    if (!NDIlib_initialize()) { fprintf(stderr, "NDIlib_initialize failed\n"); return 70; }
    NDIlib_recv_create_v3_t c = { { argv[1], NULL }, 100 /* fastest */, -10 /* metadata only */, false, "ptztest" };
    NDIlib_recv_instance_t r = NDIlib_recv_create_v3(&c);
    if (!r) { fprintf(stderr, "recv_create failed\n"); return 70; }
    // let the connection come up (metadata-only); poll until PTZ is reported or 5 s pass
    bool ptz = false;
    for (int i = 0; i < 50 && !ptz; i++) { NDIlib_recv_capture_v2(r, NULL, NULL, NULL, 100); ptz = NDIlib_recv_ptz_is_supported(r); }
    printf("connected=%d ptz_supported=%d\n", NDIlib_recv_get_no_connections(r), ptz);
    for (int i = 2; i < argc; i++) {
        const char *k = argv[i]; bool ok = false;
        if (!strcmp(k, "speed") && i + 3 < argc) { float p = atof(argv[i+1]), t = atof(argv[i+2]), s = atof(argv[i+3]); ok = NDIlib_recv_ptz_pan_tilt_speed(r, p, t); printf("pan_tilt_speed %.2f %.2f -> %d; hold %.1fs\n", p, t, ok, s); usleep((useconds_t)(s * 1e6)); ok = NDIlib_recv_ptz_pan_tilt_speed(r, 0, 0); printf("stop -> %d\n", ok); i += 3; }
        else if (!strcmp(k, "zoomspeed") && i + 2 < argc) { float z = atof(argv[i+1]), s = atof(argv[i+2]); ok = NDIlib_recv_ptz_zoom_speed(r, z); printf("zoom_speed %.2f -> %d; hold %.1fs\n", z, ok, s); usleep((useconds_t)(s * 1e6)); ok = NDIlib_recv_ptz_zoom_speed(r, 0); printf("stop -> %d\n", ok); i += 2; }
        else if (!strcmp(k, "abs") && i + 2 < argc) { float p = atof(argv[i+1]), t = atof(argv[i+2]); ok = NDIlib_recv_ptz_pan_tilt(r, p, t); printf("pan_tilt %.2f %.2f -> %d\n", p, t, ok); i += 2; }
        else if (!strcmp(k, "zoom") && i + 1 < argc) { float z = atof(argv[i+1]); ok = NDIlib_recv_ptz_zoom(r, z); printf("zoom %.2f -> %d\n", z, ok); i += 1; }
        else if (!strcmp(k, "store") && i + 1 < argc) { ok = NDIlib_recv_ptz_store_preset(r, atoi(argv[i+1])); printf("store %s -> %d\n", argv[i+1], ok); i += 1; }
        else if (!strcmp(k, "recall") && i + 1 < argc) { ok = NDIlib_recv_ptz_recall_preset(r, atoi(argv[i+1]), 1.0f); printf("recall %s -> %d\n", argv[i+1], ok); i += 1; }
        else if (!strcmp(k, "af")) { ok = NDIlib_recv_ptz_auto_focus(r); printf("auto_focus -> %d\n", ok); }
        else if (!strcmp(k, "wait") && i + 1 < argc) { usleep((useconds_t)(atof(argv[i+1]) * 1e6)); i += 1; }
        else { fprintf(stderr, "bad command at '%s'\n", k); break; }
        NDIlib_recv_capture_v2(r, NULL, NULL, NULL, 50);   // give the metadata a moment to go out
    }
    usleep(300000);
    NDIlib_recv_destroy(r);
    return 0;
}
