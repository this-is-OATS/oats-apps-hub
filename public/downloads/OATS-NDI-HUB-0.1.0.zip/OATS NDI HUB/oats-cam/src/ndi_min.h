// Minimal hand-written NDI 6 C ABI declarations for oats-cam (no SDK headers on disk); mirrors oats-m0/src/ndi_min.h.
#include <stdint.h>
#include <stdbool.h>

typedef void *NDIlib_send_instance_t;

typedef struct NDIlib_send_create_t {
    const char *p_ndi_name;
    const char *p_groups;
    bool clock_video;
    bool clock_audio;
} NDIlib_send_create_t;

typedef struct NDIlib_video_frame_v2_t {
    int32_t xres;
    int32_t yres;
    uint32_t FourCC;
    int32_t frame_rate_N;
    int32_t frame_rate_D;
    float picture_aspect_ratio;
    int32_t frame_format_type;      // 1 = progressive
    int64_t timecode;               // INT64_MAX = synthesize
    uint8_t *p_data;
    int32_t line_stride_in_bytes;
    const char *p_metadata;
    int64_t timestamp;
} NDIlib_video_frame_v2_t;

typedef struct NDIlib_metadata_frame_t {
    int32_t length;
    int64_t timecode;
    char *p_data;
} NDIlib_metadata_frame_t;

typedef struct NDIlib_tally_t {
    bool on_program;
    bool on_preview;
} NDIlib_tally_t;

// NDIlib_audio_frame_v2_t: planar float (FLTP), channel_stride_in_bytes between channel planes.
typedef struct NDIlib_audio_frame_v2_t {
    int32_t sample_rate;
    int32_t no_channels;
    int32_t no_samples;
    int64_t timecode;
    float *p_data;
    int32_t channel_stride_in_bytes;
    const char *p_metadata;
    int64_t timestamp;
} NDIlib_audio_frame_v2_t;
typedef void (*fn_send_audio_v2)(NDIlib_send_instance_t, const NDIlib_audio_frame_v2_t *);

typedef bool (*fn_initialize)(void);
typedef void (*fn_destroy)(void);
typedef const char *(*fn_version)(void);
typedef NDIlib_send_instance_t (*fn_send_create)(const NDIlib_send_create_t *);
typedef void (*fn_send_destroy)(NDIlib_send_instance_t);
typedef void (*fn_send_video)(NDIlib_send_instance_t, const NDIlib_video_frame_v2_t *);
typedef int (*fn_send_get_no_connections)(NDIlib_send_instance_t, uint32_t);
// 0 none, 3 metadata, 4 error, 100 status change
typedef int32_t (*fn_send_capture)(NDIlib_send_instance_t, NDIlib_metadata_frame_t *, uint32_t);
typedef void (*fn_send_free_metadata)(NDIlib_send_instance_t, const NDIlib_metadata_frame_t *);
typedef void (*fn_send_add_connection_metadata)(NDIlib_send_instance_t, const NDIlib_metadata_frame_t *);
typedef void (*fn_send_clear_connection_metadata)(NDIlib_send_instance_t);
typedef bool (*fn_send_get_tally)(NDIlib_send_instance_t, NDIlib_tally_t *, uint32_t);
