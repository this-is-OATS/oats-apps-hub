import Foundation
import AVFoundation
import CoreMedia
import CoreVideo

struct CamInfo { let device: AVCaptureDevice; let vid: Int; let pid: Int }

/// AVFoundation camera capture delivering 2vuy (UYVY) pixel buffers.
final class Capture: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    let session = AVCaptureSession()
    let output = AVCaptureVideoDataOutput()
    let queue = DispatchQueue(label: "oats-cam.capture", qos: .userInteractive)
    var onFrame: ((CVPixelBuffer) -> Void)?
    var onError: ((String) -> Void)?
    private(set) var frames: UInt64 = 0
    private(set) var dropped: UInt64 = 0
    private(set) var lastFrameNs: UInt64 = 0
    private var intervalSumNs: UInt64 = 0
    private var observers: [NSObjectProtocol] = []

    static func devices() -> [AVCaptureDevice] {
        var types: [AVCaptureDevice.DeviceType] = [.builtInWideAngleCamera]
        if #available(macOS 14.0, *) { types.append(.external) } else { types.append(.externalUnknown) }
        return AVCaptureDevice.DiscoverySession(deviceTypes: types, mediaType: .video, position: .unspecified).devices
    }
    static func usbIDs(_ d: AVCaptureDevice) -> (Int, Int)? {
        // modelID like "UVC Camera VendorID_11802 ProductID_19460"
        let m = d.modelID
        guard let v = m.range(of: "VendorID_"), let p = m.range(of: "ProductID_") else { return nil }
        let vs = m[v.upperBound...].prefix { $0.isNumber }, ps = m[p.upperBound...].prefix { $0.isNumber }
        guard let vi = Int(vs), let pi = Int(ps) else { return nil }
        return (vi, pi)
    }
    static func describe(_ d: AVCaptureDevice) -> String {
        let ids = usbIDs(d).map { String(format: " usb %04x:%04x", $0.0, $0.1) } ?? ""
        return "\(d.localizedName) [\(d.modelID)]\(ids) uid=\(d.uniqueID)"
    }
    static func formatText(_ f: AVCaptureDevice.Format) -> String {
        let dim = CMVideoFormatDescriptionGetDimensions(f.formatDescription)
        let st = CMFormatDescriptionGetMediaSubType(f.formatDescription)
        let cc = String(bytes: [UInt8(st >> 24 & 0xff), UInt8(st >> 16 & 0xff), UInt8(st >> 8 & 0xff), UInt8(st & 0xff)], encoding: .ascii) ?? "?"
        let fr = f.videoSupportedFrameRateRanges.map { String(format: "%.0f-%.0f", $0.minFrameRate, $0.maxFrameRate) }.joined(separator: ",")
        return "\(dim.width)x\(dim.height) \(cc) @\(fr)"
    }
    static func pick(match: String) -> CamInfo? {
        let all = devices()
        // prefer a real UVC device (has VendorID/ProductID) whose name contains the match; never a virtual camera unless asked by name
        let named = all.filter { $0.localizedName.localizedCaseInsensitiveContains(match) || $0.uniqueID == match }
        let uvc = named.filter { usbIDs($0) != nil }
        guard let d = uvc.first ?? named.first else { return nil }
        let ids = usbIDs(d) ?? (0, 0)
        return CamInfo(device: d, vid: ids.0, pid: ids.1)
    }

    /// Request camera permission (prompt attributed to the launching app, e.g. Terminal). Returns nil on success or a reason.
    static func authorize(timeoutS: Double) -> String? {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: return nil
        case .denied: return "camera access denied for this app (System Settings > Privacy & Security > Camera: enable Terminal)"
        case .restricted: return "camera access restricted by policy"
        default:
            olog("camera permission not yet granted: waiting for the macOS prompt (click Allow) up to \(Int(timeoutS)) s")
            let sem = DispatchSemaphore(value: 0); var ok = false
            AVCaptureDevice.requestAccess(for: .video) { ok = $0; sem.signal() }
            if sem.wait(timeout: .now() + timeoutS) == .timedOut { return "camera permission prompt not answered in \(Int(timeoutS)) s" }
            return ok ? nil : "camera access denied at the prompt"
        }
    }

    func start(cam: CamInfo, width: Int, height: Int, fps: Int) throws {
        let d = cam.device
        // choose the format: exact size, fps in range; prefer 2vuy, then 420v, then anything
        let want: [FourCharCode] = [kCVPixelFormatType_422YpCbCr8, kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange, kCVPixelFormatType_420YpCbCr8BiPlanarFullRange]
        var best: AVCaptureDevice.Format? = nil; var bestRank = Int.max
        for f in d.formats {
            let dim = CMVideoFormatDescriptionGetDimensions(f.formatDescription)
            guard Int(dim.width) == width, Int(dim.height) == height else { continue }
            guard f.videoSupportedFrameRateRanges.contains(where: { $0.minFrameRate - 0.01 <= Double(fps) && Double(fps) <= $0.maxFrameRate + 0.01 }) else { continue }
            let st = CMFormatDescriptionGetMediaSubType(f.formatDescription)
            let rank = want.firstIndex(of: st) ?? 10
            if rank < bestRank { best = f; bestRank = rank }
        }
        guard let fmt = best else {
            let avail = d.formats.map(Capture.formatText).joined(separator: "; ")
            throw NSError(domain: "oats-cam", code: 1, userInfo: [NSLocalizedDescriptionKey: "no \(width)x\(height)@\(fps) format on \(d.localizedName); available: \(avail)"])
        }
        session.beginConfiguration()
        let input = try AVCaptureDeviceInput(device: d)
        guard session.canAddInput(input) else { throw NSError(domain: "oats-cam", code: 2, userInfo: [NSLocalizedDescriptionKey: "cannot add camera input"]) }
        session.addInput(input)
        output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_422YpCbCr8]
        output.alwaysDiscardsLateVideoFrames = true
        output.setSampleBufferDelegate(self, queue: queue)
        guard session.canAddOutput(output) else { throw NSError(domain: "oats-cam", code: 3, userInfo: [NSLocalizedDescriptionKey: "cannot add video output"]) }
        session.addOutput(output)
        session.commitConfiguration()

        let nc = NotificationCenter.default
        observers.append(nc.addObserver(forName: .AVCaptureSessionRuntimeError, object: session, queue: nil) { [weak self] n in
            let e = (n.userInfo?[AVCaptureSessionErrorKey] as? NSError)?.localizedDescription ?? "unknown"
            self?.onError?("capture runtime error: \(e)")
        })
        observers.append(nc.addObserver(forName: .AVCaptureDeviceWasDisconnected, object: d, queue: nil) { [weak self] _ in
            self?.onError?("camera disconnected")
        })
        session.startRunning()
        chosenDevice = d; chosenFormat = fmt; chosenFps = fps
        applyFormat("start")
    }
    /// Apply the chosen format AFTER the session runs, and again after any later begin/commitConfiguration (adding
    /// audio): on macOS the session applies its own preset at commit/start and replaces our choice (seen 2026-10-25:
    /// 1080p 420v 25 fps instead of 2vuy 30). Setting it on the running session makes the input dictate the format.
    private var chosenDevice: AVCaptureDevice?; private var chosenFormat: AVCaptureDevice.Format?; private var chosenFps = 30
    func applyFormat(_ why: String) {
        guard let d = chosenDevice, let fmt = chosenFormat else { return }
        do {
            try d.lockForConfiguration()
            d.activeFormat = fmt
            // the camera's own duration for the matched range (cameras report e.g. 1000000/30000030, not exactly 1/30)
            if let r = fmt.videoSupportedFrameRateRanges.first(where: { $0.minFrameRate - 0.01 <= Double(chosenFps) && Double(chosenFps) <= $0.maxFrameRate + 0.01 }) {
                d.activeVideoMinFrameDuration = r.minFrameDuration; d.activeVideoMaxFrameDuration = r.maxFrameDuration
            }
            d.unlockForConfiguration()
        } catch { olog("capture: lockForConfiguration failed (\(why)): \(error.localizedDescription)"); return }
        let md = d.activeVideoMinFrameDuration
        olog("capture (\(why)): active format \(Capture.formatText(d.activeFormat)) at \(String(format: "%.3f", Double(md.timescale) / Double(max(md.value, 1)))) fps, output 2vuy")
    }
    func stop() { session.stopRunning() }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        frames &+= 1
        let now = monoNs()
        if frames > 1 && frames <= 61 { intervalSumNs &+= now &- lastFrameNs; if frames == 61 { olog("capture: mean interval over 60 frames \(String(format: "%.2f", Double(intervalSumNs) / 60 / 1e6)) ms (\(String(format: "%.2f", 60e9 / Double(intervalSumNs))) fps) pts \(CMSampleBufferGetPresentationTimeStamp(sampleBuffer).seconds)") } }
        lastFrameNs = now
        onFrame?(pb)
    }
    func captureOutput(_ output: AVCaptureOutput, didDrop sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) { dropped &+= 1 }
}
