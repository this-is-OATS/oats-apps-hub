// uvc.h: minimal UVC (USB Video Class) control-request access for a camera on macOS via IOKit.
// Finds the device by VID/PID, parses its configuration descriptor for the VideoControl interface and
// the camera (input) terminal, and issues class-specific SET_CUR / GET_* requests on the control pipe.
// Works alongside AVFoundation holding the stream (the control pipe is not exclusive).
#include <stdint.h>
#include <stddef.h>

typedef struct uvc_dev uvc_dev;

// Camera terminal control selectors (UVC 1.5 table A-12)
enum { UVC_CT_FOCUS_ABSOLUTE = 0x06, UVC_CT_FOCUS_AUTO = 0x08, UVC_CT_ZOOM_ABSOLUTE = 0x0B, UVC_CT_ZOOM_RELATIVE = 0x0C,
       UVC_CT_PANTILT_ABSOLUTE = 0x0D, UVC_CT_PANTILT_RELATIVE = 0x0E };
// Requests (table A-8)
enum { UVC_SET_CUR = 0x01, UVC_GET_CUR = 0x81, UVC_GET_MIN = 0x82, UVC_GET_MAX = 0x83, UVC_GET_RES = 0x84,
       UVC_GET_LEN = 0x85, UVC_GET_INFO = 0x86, UVC_GET_DEF = 0x87 };

// Open the first device matching vid/pid. On failure returns NULL and writes a reason into err.
uvc_dev *uvc_open(uint16_t vid, uint16_t pid, char *err, size_t errlen);
void uvc_close(uvc_dev *d);
int uvc_interface_number(const uvc_dev *d);     // VideoControl interface number
int uvc_camera_terminal(const uvc_dev *d);      // camera (input) terminal unit id, 0 if none found
int uvc_processing_unit(const uvc_dev *d);      // processing unit id, 0 if none
uint32_t uvc_ct_controls(const uvc_dev *d);     // camera terminal bmControls bitmap (bit 9 zoom abs, 11 pan/tilt abs, 12 pan/tilt rel)
// Control request on unit `unit` (terminal or processing unit), selector cs. Return bytes transferred, or -errno-ish (<0) with
// the IOKit return code in *iokit if non-NULL.
int uvc_get(uvc_dev *d, uint8_t unit, uint8_t cs, uint8_t req, void *buf, uint16_t len, int *iokit);
int uvc_set(uvc_dev *d, uint8_t unit, uint8_t cs, const void *buf, uint16_t len, int *iokit);
const char *uvc_last_error(const uvc_dev *d);
// Software replug: USB re-enumeration of the device (needs the device-level open; returns 0 on success, IOKit code otherwise).
int uvc_reenumerate(uint16_t vid, uint16_t pid, char *err, size_t errlen);
