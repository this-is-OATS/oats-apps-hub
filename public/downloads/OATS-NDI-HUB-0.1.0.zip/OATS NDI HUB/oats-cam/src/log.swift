import Foundation

final class Logger {
    static let shared = Logger()
    private var fh: FileHandle?
    private let q = DispatchQueue(label: "oats-cam.log")
    private(set) var path = ""
    func open(dir: String, prefix: String) -> Bool {
        let f = DateFormatter(); f.dateFormat = "yyyyMMdd-HHmmss"
        path = (dir as NSString).appendingPathComponent("\(prefix)-\(f.string(from: Date())).log")
        guard FileManager.default.createFile(atPath: path, contents: nil, attributes: [.posixPermissions: 0o600]) else { return false }
        fh = FileHandle(forWritingAtPath: path)
        return fh != nil
    }
    func line(_ s: String) {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
        let t = "\(f.string(from: Date())) \(s)\n"
        q.sync {
            print(t, terminator: "")
            if let d = t.data(using: .utf8) { fh?.write(d) }
        }
    }
    func sync() { q.sync { try? fh?.synchronize() } }
}
func olog(_ s: String) { Logger.shared.line(s) }
func monoNs() -> UInt64 { var t = timespec(); clock_gettime(CLOCK_MONOTONIC, &t); return UInt64(t.tv_sec) * 1_000_000_000 + UInt64(t.tv_nsec) }
func processArchText() -> String {
    #if arch(x86_64)
    var r: Int32 = 0; var n = MemoryLayout<Int32>.size
    if sysctlbyname("sysctl.proc_translated", &r, &n, nil, 0) == 0, r == 1 { return "x86_64 (Rosetta 2)" }
    return "x86_64"
    #else
    return "arm64"
    #endif
}
