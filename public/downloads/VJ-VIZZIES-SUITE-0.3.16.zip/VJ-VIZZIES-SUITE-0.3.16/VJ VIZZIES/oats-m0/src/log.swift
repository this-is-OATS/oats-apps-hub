import Foundation
import Darwin

// Logging: every line goes to stdout AND <log-dir>/oats-m0-<YYYYmmdd-HHMMSS>.log, one write(2) per
// line (no user-space buffering, so nothing is lost on _exit), timestamps with milliseconds.

final class Logger {
    static let shared = Logger()
    private var mutex = pthread_mutex_t()
    private var fileFD: Int32 = -1
    private(set) var path: String = ""

    private init() { pthread_mutex_init(&mutex, nil) }

    // The render thread never waits on the log (2026-11-06): its lines are queued and written by logWriter. Under
    // heavy memory pressure a write(2) to the log file can block for seconds; the render thread logs on every clip
    // change, and waiting behind such a write stopped frames until the watchdog restarted the player (the log went
    // silent before the restart and the STALL line itself never got written). Queued lines keep their timestamps and
    // reach the file before any later line written under the mutex, or at the latest when logWriter runs.
    private var noWaitThread: pthread_t? = nil
    private var pendLock = os_unfair_lock()
    private var pending: [[UInt8]] = []
    private var pendDropped = 0
    private let logWriter = DispatchQueue(label: "log-writer", qos: .utility)

    /// Called once by the render thread before it logs anything.
    func markNoWaitThread() { noWaitThread = pthread_self() }

    /// The log rotates at 50 MB: <name>.log -> <name>.log.1 -> .2 -> .3 (3 kept, the oldest is dropped).
    static let rotateBytes: Int64 = 50 * 1024 * 1024
    static let keepRotated = 3
    private var written: Int64 = 0

    func open(dir: String, prefix: String = "oats-m0") -> Bool {
        let stamp = Logger.stamp(format: "%Y%m%d-%H%M%S", withMillis: false)
        try? FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true)
        chmod(dir, 0o700)                                   // logs hold addresses and OSC history: this user only
        let p = (dir as NSString).appendingPathComponent("\(prefix)-\(stamp).log")
        let fd = Darwin.open(p, O_WRONLY | O_CREAT | O_APPEND, 0o600)
        guard fd >= 0 else { return false }
        fchmod(fd, 0o600)
        pthread_mutex_lock(&mutex)
        fileFD = fd
        path = p
        written = 0
        pthread_mutex_unlock(&mutex)
        return true
    }

    /// Called with the mutex held.
    private func rotateLocked() {
        guard fileFD >= 0, !path.isEmpty else { return }
        close(fileFD)
        let fm = FileManager.default
        try? fm.removeItem(atPath: path + ".\(Logger.keepRotated)")
        for i in stride(from: Logger.keepRotated - 1, through: 1, by: -1) { _ = rename(path + ".\(i)", path + ".\(i + 1)") }
        _ = rename(path, path + ".1")
        fileFD = Darwin.open(path, O_WRONLY | O_CREAT | O_APPEND, 0o600)
        written = 0
        let note = Array((Logger.stamp() + " log rotated at 50 MB (older lines in \((path as NSString).lastPathComponent).1 .. .\(Logger.keepRotated))\n").utf8)
        if fileFD >= 0 { note.withUnsafeBytes { _ = writeAll(fileFD, UnsafeMutableRawPointer(mutating: $0.baseAddress!), $0.count) } }
    }

    static func stamp(format: String = "%Y-%m-%d %H:%M:%S", withMillis: Bool = true) -> String {
        var tv = timeval()
        gettimeofday(&tv, nil)
        var t = time_t(tv.tv_sec)
        var tmv = tm()
        localtime_r(&t, &tmv)
        var buf = [Int8](repeating: 0, count: 64)
        let n = strftime(&buf, 64, format, &tmv)
        let base = String(cString: Array(buf[0..<n]) + [0])
        return withMillis ? base + String(format: ".%03d", Int(tv.tv_usec) / 1000) : base
    }

    /// Text from the network (OSC addresses and strings, sACN source names, NDI metadata) can carry control
    /// characters; a newline would forge a second log line. Every control character becomes '?'.
    static func clean(_ s: String) -> String {
        guard s.utf8.contains(where: { $0 < 0x20 || $0 == 0x7f }) else { return s }
        return String(String.UnicodeScalarView(s.unicodeScalars.map { ($0.value < 0x20 || $0.value == 0x7f) ? Unicode.Scalar(UInt8(0x3F)) : $0 }))
    }

    func line(_ s: String) {
        let text = Logger.stamp() + " " + Logger.clean(s) + "\n"
        let bytes = Array(text.utf8)
        if let nw = noWaitThread, pthread_equal(nw, pthread_self()) != 0 {
            os_unfair_lock_lock(&pendLock)
            if pending.count < 4096 { pending.append(bytes) } else { pendDropped += 1 }
            let first = pending.count == 1
            os_unfair_lock_unlock(&pendLock)
            if first { logWriter.async { self.drain() } }
            return
        }
        pthread_mutex_lock(&mutex)
        drainLocked()
        writeLocked(bytes)
        pthread_mutex_unlock(&mutex)
    }

    private func drain() {
        pthread_mutex_lock(&mutex)
        drainLocked()
        pthread_mutex_unlock(&mutex)
    }

    /// Called with the mutex held: the render thread's queued lines first.
    private func drainLocked() {
        os_unfair_lock_lock(&pendLock)
        let p = pending, d = pendDropped
        if !p.isEmpty { pending = [] }
        pendDropped = 0
        os_unfair_lock_unlock(&pendLock)
        for b in p { writeLocked(b) }
        if d > 0 { writeLocked(Array((Logger.stamp() + " log: \(d) render-thread line(s) dropped (queue full)\n").utf8)) }
    }

    /// Called with the mutex held.
    private func writeLocked(_ b: [UInt8]) {
        var bytes = b
        bytes.withUnsafeMutableBytes { raw in
            _ = writeAll(1, raw.baseAddress!, raw.count)
            if fileFD >= 0 { _ = writeAll(fileFD, raw.baseAddress!, raw.count) }
        }
        written += Int64(bytes.count)
        if written >= Logger.rotateBytes { rotateLocked() }
    }

    /// Flush to disk; used before _exit on a watchdog stall.
    func sync() {
        pthread_mutex_lock(&mutex)
        drainLocked()
        if fileFD >= 0 { fsync(fileFD) }
        pthread_mutex_unlock(&mutex)
    }

    private func writeAll(_ fd: Int32, _ p: UnsafeMutableRawPointer, _ n: Int) -> Bool {
        var off = 0
        while off < n {
            let r = write(fd, p + off, n - off)
            if r < 0 { if errno == EINTR { continue }; return false }
            off += r
        }
        return true
    }
}

@inline(__always) func olog(_ s: String) { Logger.shared.line(s) }

/// Rate limiter for noisy log lines (malformed packets, fuzzing): at most `perSecond` lines per second,
/// then one summary line with the number suppressed.
final class LogLimiter {
    private let perSecond: Int
    private let summary: String
    private var windowStart: UInt64 = 0
    private var count = 0
    private var suppressed = 0
    private let lock = NSLock()
    init(perSecond: Int, summary: String = "similar lines suppressed in the last second") { self.perSecond = perSecond; self.summary = summary }

    func log(_ s: @autoclosure () -> String) {
        lock.lock()
        let now = nowTicks()
        if ticksToSec(now &- windowStart) >= 1.0 {
            if suppressed > 0 { Logger.shared.line("(\(suppressed) \(summary))") }
            windowStart = now; count = 0; suppressed = 0
        }
        count += 1
        let emit = count <= perSecond
        if !emit { suppressed += 1 }
        lock.unlock()
        if emit { Logger.shared.line(s()) }
    }
}
