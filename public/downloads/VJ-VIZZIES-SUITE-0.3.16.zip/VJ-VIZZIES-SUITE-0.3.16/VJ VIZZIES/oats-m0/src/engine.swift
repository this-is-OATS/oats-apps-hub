import Foundation
import Metal
import CoreGraphics
import ImageIO
import Darwin

// Render loop (one thread, user-interactive QoS) and snapshot writer. The GUI preview (preview.swift) adds a downsample
// dispatch to some frames' command buffers while clients watch.
//
// Pacing: own clock with mach_wait_until. Render one frame ahead: at tick k the frame rendered during tick k-1 is handed
// out (output window, NDI ring), then frame k+1 is encoded and committed for the next tick. Three shared UYVY buffers.
// NDI (2026-10-22, ndiout.swift): the render thread never calls NDI. The command buffer also copies the UYVY frame (or
// its soft version) into a free slot of the shared frame ring; once the GPU is done the slot is published (one atomic
// store) and the sender (the x86_64 helper or the native thread) picks it up. A sender that falls behind costs dropped
// NDI frames, never a render or HDMI frame.
// All motion integrates the real time of the tick a frame will be shown at, never "per frame sent".

struct SnapshotInfo {
    var count = 0
    var lastUnix = 0.0
    var meanLuma = -1.0
    var path = ""
    var ms = 0.0
}

final class SnapshotStore {
    private let lock = NSLock()
    private var s = SnapshotInfo()
    func with<T>(_ body: (inout SnapshotInfo) -> T) -> T { lock.lock(); defer { lock.unlock() }; return body(&s) }
}
let gSnapshot = SnapshotStore()

final class NDIInfo {
    private let lock = NSLock()
    private var _connections = 0
    private var _products: [String] = []
    var connections: Int { lock.lock(); defer { lock.unlock() }; return _connections }
    var products: [String] { lock.lock(); defer { lock.unlock() }; return _products }
    func set(connections: Int) { lock.lock(); _connections = connections; if connections == 0 { _products = [] }; lock.unlock() }
    func add(product: String) {
        lock.lock()
        if !_products.contains(product) { _products.append(product); if _products.count > 8 { _products.removeFirst() } }
        lock.unlock()
    }
}
let gNDI = NDIInfo()

/// Per-stage GPU time (2026-10-23): timestamp counters at the start and end of each stage's encoder (Apple GPUs sample
/// at stage boundaries only, so each stage gets its own encoder; ns on Apple silicon). Stages: fractal (fractal /
/// deep zoom + upscale + loop fade), layers (generators + composite / card), master (master FX), output (analysis,
/// to_uyvy, preview, NDI copy). status.json render.stages_ms_p95 over the last 120 frames; a stage that did not run
/// counts 0. Unavailable (no counters): render.timing "unavailable", the encoders are split the same way.
final class GPUStages {
    static let names = ["fractal", "layers", "master", "output"]
    static let slots = 4, perFrame = 12                  // 6 encoders x 2 samples; at most 2 frames are in flight
    let sb: MTLCounterSampleBuffer?
    let note: String
    private let lock = NSLock()
    private var hist = [[Double]](repeating: [], count: 4)
    private var next = 0
    private var resolved: Int64 = 0, failed: Int64 = 0

    init(dev: MTLDevice?) {
        var b: MTLCounterSampleBuffer? = nil, n = "unavailable (no Metal device)"
        if let d = dev {
            if !d.supportsCounterSampling(.atStageBoundary) { n = "unavailable (no stage-boundary counter sampling)" }
            else if let ts = d.counterSets?.first(where: { $0.name == MTLCommonCounterSet.timestamp.rawValue }) {
                let sd = MTLCounterSampleBufferDescriptor()
                sd.counterSet = ts; sd.sampleCount = GPUStages.slots * GPUStages.perFrame; sd.storageMode = .shared
                sd.label = "oats stage timestamps"
                do { b = try d.makeCounterSampleBuffer(descriptor: sd); n = "counters (stage boundaries)" }
                catch { n = "unavailable (\(error.localizedDescription))" }
            } else { n = "unavailable (no timestamp counter set)" }
        }
        sb = b; note = n
    }

    /// One frame's encoders: which sample pairs belong to which stage.
    final class Frame {
        let base: Int
        var pairs: [(stage: Int, k: Int)] = []
        init(base: Int) { self.base = base }
    }
    func beginFrame() -> Frame {
        let f = Frame(base: (next % GPUStages.slots) * GPUStages.perFrame)
        next &+= 1
        return f
    }
    private func attach(_ f: Frame, _ stage: Int) -> (Int, Int)? {
        guard sb != nil, f.pairs.count < GPUStages.perFrame / 2 else { return nil }
        let k = f.pairs.count
        f.pairs.append((stage, k))
        return (f.base + 2 * k, f.base + 2 * k + 1)
    }
    func compute(_ cb: MTLCommandBuffer, _ f: Frame, stage: Int) -> MTLComputeCommandEncoder? {
        guard let ix = attach(f, stage) else { return cb.makeComputeCommandEncoder() }
        let pd = MTLComputePassDescriptor()
        pd.sampleBufferAttachments[0].sampleBuffer = sb
        pd.sampleBufferAttachments[0].startOfEncoderSampleIndex = ix.0
        pd.sampleBufferAttachments[0].endOfEncoderSampleIndex = ix.1
        return cb.makeComputeCommandEncoder(descriptor: pd)
    }
    func blit(_ cb: MTLCommandBuffer, _ f: Frame, stage: Int) -> MTLBlitCommandEncoder? {
        guard let ix = attach(f, stage) else { return cb.makeBlitCommandEncoder() }
        let pd = MTLBlitPassDescriptor()
        pd.sampleBufferAttachments[0].sampleBuffer = sb
        pd.sampleBufferAttachments[0].startOfEncoderSampleIndex = ix.0
        pd.sampleBufferAttachments[0].endOfEncoderSampleIndex = ix.1
        return cb.makeBlitCommandEncoder(descriptor: pd)
    }
    /// After the command buffer: resolve this frame's samples (completion handler thread; a few hundred bytes).
    func finish(_ cb: MTLCommandBuffer, _ f: Frame) {
        guard let s = sb, !f.pairs.isEmpty else { return }
        cb.addCompletedHandler { [self] done in
            guard done.status == .completed, let data = try? s.resolveCounterRange(f.base..<(f.base + 2 * f.pairs.count)) else {
                self.lock.lock(); self.failed += 1; self.lock.unlock(); return
            }
            var ms = [Double](repeating: 0, count: 4)
            var bad = false
            data.withUnsafeBytes { raw in
                let v = raw.bindMemory(to: MTLCounterResultTimestamp.self)
                for p in f.pairs where 2 * p.k + 1 < v.count {
                    let a = v[2 * p.k].timestamp, b = v[2 * p.k + 1].timestamp
                    if a == MTLCounterErrorValue || b == MTLCounterErrorValue || b < a { bad = true; continue }
                    ms[p.stage] += Double(b - a) / 1e6
                }
            }
            self.lock.lock()
            if bad { self.failed += 1 }
            self.resolved += 1
            for i in 0..<4 { self.hist[i].append(ms[i]); if self.hist[i].count > 120 { self.hist[i].removeFirst(self.hist[i].count - 120) } }
            self.lock.unlock()
        }
    }
    func p95() -> [Double] {
        lock.lock(); let h = hist; lock.unlock()
        return h.map { v in
            guard !v.isEmpty else { return 0 }
            let s = v.sorted()
            return (s[min(s.count - 1, Int(Double(s.count) * 0.95))] * 100).rounded() / 100
        }
    }
    func statusDict(gpuMsLast: Double) -> [String: Any] {
        let p = p95()
        lock.lock(); let (r, f) = (resolved, failed); lock.unlock()
        var st: [String: Any] = [:]
        for (i, n) in GPUStages.names.enumerated() { st[n] = p[i] }
        return ["stages": st, "stages_sum_ms_p95": (p.reduce(0, +) * 100).rounded() / 100,
                "gpu_ms_last": (gpuMsLast * 100).rounded() / 100, "timing": note, "frames_timed": r, "timing_errors": f,
                "window_frames": 120, "note": "stages: ms p95 over the last 120 frames, per stage (0 = did not run)"]
    }
    func logText() -> String {
        guard sb != nil else { return "" }
        let p = p95()
        return String(format: " gpu_stages_p95=frac %.1f/layers %.1f/master %.1f/out %.1f ms", p[0], p[1], p[2], p[3])
    }
}
let gGPUStages = GPUStages(dev: MTLCreateSystemDefaultDevice())

/// The fractal's view width spans this many pixels: the canvas width on 16:9 and wider canvases (a wide wall shows more
/// of the plane left and right at the same height), h x 16/9 on taller ones (portrait shows more above and below).
/// Square pixels everywhere: never stretched. 1920x1080 -> 1920 (unchanged).
@inline(__always) func fracRefW(_ w: Int, _ h: Int) -> Double { min(Double(w), Double(h) * 16 / 9) }

/// The preview's picture inside its 16:9 frame (x, y, w, h): the whole canvas, letterboxed (16:9 canvases fill it).
func previewLetterbox(_ sw: Int, _ sh: Int, _ dw: Int, _ dh: Int) -> SIMD4<UInt32> {
    if sw * dh == sh * dw { return SIMD4<UInt32>(0, 0, UInt32(dw), UInt32(dh)) }
    if sw * dh > sh * dw { let ch = max(1, dw * sh / sw); return SIMD4<UInt32>(0, UInt32((dh - ch) / 2), UInt32(dw), UInt32(ch)) }
    let cw = max(1, dh * sw / sh); return SIMD4<UInt32>(UInt32((dw - cw) / 2), 0, UInt32(cw), UInt32(dh))
}

final class Engine {
    let cfg: Config
    let w: Int, h: Int                                 // the canvas (mapping.swift: --canvas / mapping.json; 1920x1080 default)
    let dev: MTLDevice
    let queue: MTLCommandQueue
    let pMandel: MTLComputePipelineState
    let pNoise: MTLComputePipelineState
    let pPack: MTLComputePipelineState
    let pPreview: MTLComputePipelineState
    let pSolo: MTLComputePipelineState                 // GUI PREVIEW monitor: one layer by itself (preview.swift ?layer=n)
    let pPert: MTLComputePipelineState                 // deep zoom (normal content), classic Mandelbrot
    let pPert2: MTLComputePipelineState                // deep zoom: every formula, orbit traps, fold c, bailout
    let pDirect: MTLComputePipelineState               // float32 z: kaleido fold, Julia morph, warp (depth <= 1e4.5)
    let pFade: MTLComputePipelineState                 // endless-zoom loop: frozen last frame -> new dive crossfade
    let pUp: MTLComputePipelineState                   // governor: bilinear upscale to 1080p
    let pComp: MTLComputePipelineState                 // M2a: fractal layer + 4 clip layers -> canvas
    private let fxPipeLock = NSLock()
    private var pCompFX = [MTLComputePipelineState?](repeating: nil, count: 16)   // fx.swift: composite_fx variants (stage bits), compiled in the background
    let pAna: MTLComputePipelineState                  // dominant colours: canvas -> 64x36 (analysis.swift)
    let pMaster: MTLComputePipelineState               // fx.swift: master FX slot, canvas -> canvas2
    let fxrt: FXRuntime                                // fx.swift: phases, spin, glides, Trails history
    let pGen: MTLComputePipelineState                  // gen.swift: procedural generators -> per-layer texture
    let genrt: GenRuntime                              // gen.swift: generator textures + phases
    let pCard: MTLComputePipelineState                 // testcard.swift: test card / NDI card -> canvas
    let cards: TestCards                               // testcard.swift: text overlay (CoreText, ~1 Hz)
    let analysis: Analysis
    let canvas: MTLTexture                             // M2a: 16-bit float composite (to_uyvy reads it)
    let dummy: MTLTexture                              // 1x1 black for empty clip slots
    let layerEngine: LayerEngine
    let tex: MTLTexture
    let fracTex: MTLTexture                            // the fractal at the governor's internal resolution (top-left)
    let loopTex: MTLTexture                            // loop: copy of the last fractal frame before the jump
    let fadeTex: MTLTexture                            // loop: crossfade output (the fractal layer reads it while fading)
    let orbits: OrbitWorker
    let bufs: [MTLBuffer]
    let snapBuf: MTLBuffer
    let pvBufs: [[MTLBuffer]]                          // GUI preview: [size][slot] BGRA8, see preview.swift
    let pNdiHalf: MTLComputePipelineState              // NDI copy, native-soft: 2x2 box to 960x540
    let pNdiBlur: MTLComputePipelineState              // NDI copy, native-soft: 3x3 tent at 1920x1080
    let pNdiFit: MTLComputePipelineState               // NDI copy, any other canvas: letterboxed into 1920x1080 / 960x540
    let renderDone = DispatchSemaphore(value: 0)
    private let snapQueue = DispatchQueue(label: "snapshot", qos: .utility)
    private let errLimiter = LogLimiter(perSecond: 1)      // GPU errors: at most 1 line/s
    private let snapLock = NSLock()
    private var snapInFlight = false

    // render-thread-only state
    private var log10W = log10(3.0)
    private var palAccum = 0.0
    private var deepStart = 0.0
    private var simT = 0.0
    private var lastContent: Content
    private var noiseFrame: Int64 = 0
    private var pvFrame: Int64 = 0
    private var gov = Governor()
    private var desired = CentreSpec.target(0)         // centre asked for; drawn once its orbit is ready
    private var pendingReset = false                   // target change: back to depth 0 when its orbit arrives
    private var encodedNormal = false                  // the command buffer just encoded drew the normal content
    private var encodedFixed: Int? = nil               // its resolution override (nil = governor)
    private var lastKey = ""                           // jump detection (governor): centre, overrides, content
    private var lastIterOverride = 0, lastResOverride = 0
    private var lastContentNormal = false
    // DMX v0 (dmx.swift): frame freeze, reset to target, glides over the packet interval
    private var frozen: Control? = nil
    private var lastResetSeq = 0
    private var depthGlide = Glide(), depthGlideOn = false
    private var layerOpGlide = [Glide](repeating: Glide(), count: compCount)   // DMX Layer 16 ch 1 (opacity)
    private var colorSm = SIMD4<Double>(1, 1, 1, 0), colorT = -1.0   // colour link, smoothed (~100 ms)
    private var anaFrame: Int64 = 0
    private var fracSpin = 0.0, seenSpinReset = 0      // fractal spin angle (degrees), accumulated in the render loop
    private var dimGlide = Glide(), palOffGlide = Glide(wrap: 1), rotGlide = Glide(wrap: 360), offXGlide = Glide(), offYGlide = Glide()
    // endless-zoom loop + formula modifiers (render thread)
    private var pendingResetDepth = 0.0                // presets: the depth a target change lands at
    private var wildSSN = 4                            // Wild twist supersampling: 2x2, sticky 1x2 once the governor had to go below 900p
    private var seenDiveSeq = 0, diveArmed = false, diveUntil = -1.0   // "Dive on select": 1.5 s zoom-in burst after a place change
    private var loopPhase = "off", loopCount = 0, loopT0 = 0.0, loopFadeDur = 1.0
    private var loopPalPhase = 0.0                     // palette phase carried over by Minibrot loop switches
    private let miniCache = MiniCache()
    private var juliaPh = 0.0
    private let phrt = PhaserRuntime()                 // fractal phasers (phasers.swift)
    private let audrt = AudioModRuntime()              // audio react routes (audio.swift)
    private var phaserBeat = 0.0                       // the tempo beat the phasers saw last (held while frozen)
    private var encodedNDI: (slot: Int, w: Int, h: Int)? = nil   // the NDI ring slot the command buffer just encoded writes
    private var encodedDone: DispatchSemaphore? = nil   // signalled by the command buffer's completed handler: run() waits on it with a bound
    private var encodedCommit: UInt64 = 0               // when it was committed (LATE line: how long after commit the GPU started)
    private var encodedLoopTurn = false                 // it draws a loop turnaround frame (the "loop turnaround" measurable in run())
    private var encodedLayersMs = 0.0, encodedRecMs = 0.0   // encode() breakdown for the LATE line: clip layers step, recorder
    private var residencySet: AnyObject? = nil          // macOS 15+: the render resources kept resident (no page-in inside a frame)
    private let holdLimiter = LogLimiter(perSecond: 1)  // "GPU busy: holding the last frame" lines

    struct InitError: Error, CustomStringConvertible { let description: String }

    init(cfg: Config) throws {
        self.cfg = cfg
        self.lastContent = cfg.startContent
        w = gCanvasW; h = gCanvasH
        guard let d = MTLCreateSystemDefaultDevice() ?? MTLCopyAllDevices().first else { throw InitError(description: "no Metal device") }
        dev = d
        olog("Metal device=\(d.name) headless=\(d.isHeadless) unified=\(d.hasUnifiedMemory)")
        let tc0 = nowTicks()
        let lib: MTLLibrary
        do { lib = try d.makeLibrary(source: shaderSource, options: nil) }
        catch { throw InitError(description: "shader compile error: \(error)") }
        olog(String(format: "runtime MSL compile %.1f ms", ticksToSec(nowTicks() - tc0) * 1000))
        func pipe(_ n: String) throws -> MTLComputePipelineState {
            guard let f = lib.makeFunction(name: n) else { throw InitError(description: "no kernel \(n)") }
            return try d.makeComputePipelineState(function: f)
        }
        pMandel = try pipe("mandel")
        pNoise = try pipe("noise")
        pPack = try pipe("to_uyvy")
        pPreview = try pipe("preview_down")
        pSolo = try pipe("preview_solo")
        pPert = try pipe("mandel_pert")
        pPert2 = try pipe("fractal_pert2")
        pDirect = try pipe("fractal_direct")
        pFade = try pipe("loop_fade")
        pUp = try pipe("upscale")
        pComp = try pipe("composite")
        pAna = try pipe("analyze_down")
        pMaster = try pipe("master_fx")
        pGen = try pipe("generator")
        pCard = try pipe("testcard")
        cards = TestCards(dev: d, w: w, h: h, cfg: cfg)
        pNdiHalf = try pipe("uyvy_half")
        pNdiBlur = try pipe("uyvy_blur")
        pNdiFit = try pipe("uyvy_fit")
        genrt = GenRuntime(dev: d, w: w, h: h)
        guard let fr = FXRuntime(dev: d, w: w, h: h) else { throw InitError(description: "fx texture allocation failed") }
        fxrt = fr
        guard let an = Analysis(dev: d) else { throw InitError(description: "analysis buffer allocation failed") }
        analysis = an; gAnalysisImpl = an
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: h, mipmapped: false)
        td.usage = [.shaderRead, .shaderWrite]
        td.storageMode = .private
        guard let t = d.makeTexture(descriptor: td), let ft = d.makeTexture(descriptor: td), let lt = d.makeTexture(descriptor: td),
              let fdt = d.makeTexture(descriptor: td), let q = d.makeCommandQueue() else { throw InitError(description: "Metal allocation failed") }
        tex = t
        fracTex = ft
        loopTex = lt
        fadeTex = fdt
        queue = q
        let cd = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: w, height: h, mipmapped: false)
        cd.usage = [.shaderRead, .shaderWrite]
        cd.storageMode = .private
        let dd = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .bgra8Unorm, width: 1, height: 1, mipmapped: false)
        dd.usage = [.shaderRead]
        guard let cv = d.makeTexture(descriptor: cd), let dm = d.makeTexture(descriptor: dd), let le = LayerEngine(dev: d) else {
            throw InitError(description: "Metal allocation failed (canvas / clip texture cache)")
        }
        var black: UInt32 = 0
        dm.replace(region: MTLRegionMake2D(0, 0, 1, 1), mipmapLevel: 0, withBytes: &black, bytesPerRow: 4)
        canvas = cv; dummy = dm; layerEngine = le
        olog("clip layers: \(layerCount) layers over the fractal, 16-bit float canvas, AVPlayer + CVMetalTextureCache (BGRA), cover scaling")
        guard let ow = OrbitWorker(device: d, first: desired, iterations: 500) else { throw InitError(description: "reference orbit buffer allocation failed") }
        orbits = ow
        let to0 = nowTicks()
        guard ow.waitFirst(timeout: 3) else { throw InitError(description: "first reference orbit not ready after 3 s") }
        olog(String(format: "deep zoom: perturbation engine, %d targets, start target %@, first reference orbit in %.1f ms; zoom 1 ... 1e%.0f",
                    zoomTargets.count, desired.name, ticksToSec(nowTicks() &- to0) * 1000, zoomDepthMax))
        let stride = w * 2
        var bs: [MTLBuffer] = []
        for _ in 0..<3 {
            guard let b = d.makeBuffer(length: stride * h, options: .storageModeShared) else { throw InitError(description: "buffer allocation failed") }
            bs.append(b)
        }
        bufs = bs
        guard let sb = d.makeBuffer(length: stride * h, options: .storageModeShared) else { throw InitError(description: "snapshot buffer allocation failed") }
        snapBuf = sb
        // Residency (2026-10-24): the loop textures (loopTex, fadeTex) and the orbit buffers sit idle for a minute or more
        // between loops; on a swapping Mac the OS paged them out and the turnaround frame paid their page-in inside one
        // command buffer (CPU in encode() + the GPU starting late: 978 ms on 2026-10-23, watchdog restart). A residency
        // set on the render queue keeps every render resource resident; without one (older macOS) encode() touches the
        // loop textures each frame while a loop is set (keepWarm).
        if #available(macOS 15.0, *) {
            do {
                let rd = MTLResidencySetDescriptor()
                rd.label = "oats render resources"
                rd.initialCapacity = 24
                let rs = try d.makeResidencySet(descriptor: rd)
                for a in [t, ft, lt, fdt, cv, dm] as [MTLAllocation] { rs.addAllocation(a) }
                for b in bs { rs.addAllocation(b) }
                rs.addAllocation(sb)
                for b in ow.buffers { rs.addAllocation(b) }
                rs.commit()
                rs.requestResidency()
                q.addResidencySet(rs)
                residencySet = rs
                olog("Metal residency set: \(rs.allocationCount) render resources kept resident (loop textures, orbit buffers, frame buffers)")
            } catch { olog("Metal residency set unavailable (\(error)): the loop textures are touched every frame instead") }
        } else { olog("Metal residency sets need macOS 15: the loop textures are touched every frame while a loop is set") }
        // Warm the snapshot path here, before the render loop runs: the first blit encoder and the first GPU use
        // of snapBuf took 150 ms inside encode() on a fresh build under Rosetta (a 181 ms sender frame gap on the
        // first /oats/system/snapshot, logs/oats-m0-20261021-134313.log). One blit at init moves that cost out.
        let tw0 = nowTicks()
        if let wcb = q.makeCommandBuffer(), let blit = wcb.makeBlitCommandEncoder() {
            blit.copy(from: bs[0], sourceOffset: 0, to: sb, destinationOffset: 0, size: stride * h)
            blit.endEncoding()
            wcb.commit()
            wcb.waitUntilCompleted()
            _ = sb.contents().load(as: UInt8.self)
        }
        olog(String(format: "snapshot blit path warmed in %.1f ms", ticksToSec(nowTicks() &- tw0) * 1000))
        // GUI preview buffers (3 slots per size), and one run of preview_down per size here, for the same reason.
        var pv: [[MTLBuffer]] = []
        for pw in previewAllWidths {                    // program sizes, then the PREVIEW monitor's (solo) sizes
            var row: [MTLBuffer] = []
            for _ in 0..<previewSlots {
                guard let b = d.makeBuffer(length: pw * previewHeight(pw) * 4, options: .storageModeShared) else { throw InitError(description: "preview buffer allocation failed") }
                row.append(b)
            }
            pv.append(row)
        }
        pvBufs = pv
        let tp0 = nowTicks()
        if let wcb = q.makeCommandBuffer(), let enc = wcb.makeComputeCommandEncoder() {
            let tgP = MTLSize(width: pPreview.threadExecutionWidth, height: max(1, pPreview.maxTotalThreadsPerThreadgroup / pPreview.threadExecutionWidth), depth: 1)
            enc.setComputePipelineState(pPreview)
            enc.setBuffer(bs[0], offset: 0, index: 0)
            for (si, pw) in previewWidths.enumerated() {
                var pq = SIMD4<UInt32>(UInt32(w), UInt32(h), UInt32(pw), UInt32(previewHeight(pw)))
                var lb = previewLetterbox(w, h, pw, previewHeight(pw))
                enc.setBuffer(pv[si][0], offset: 0, index: 1)
                enc.setBytes(&pq, length: MemoryLayout<SIMD4<UInt32>>.size, index: 2)
                enc.setBytes(&lb, length: MemoryLayout<SIMD4<UInt32>>.size, index: 3)
                enc.dispatchThreads(MTLSize(width: pw, height: previewHeight(pw), depth: 1), threadsPerThreadgroup: tgP)
            }
            enc.endEncoding()
            wcb.commit()
            wcb.waitUntilCompleted()
        }
        gPreview.attach(bufs: pv)
        olog(String(format: "preview kernel warmed in %.1f ms", ticksToSec(nowTicks() &- tp0) * 1000))
        gControl.with { $0.content = cfg.startContent }
        // composite_fx variants: compiled off the start-up path (until one is ready, its frames draw without FX)
        let plainThreads = pComp.maxTotalThreadsPerThreadgroup
        DispatchQueue.global(qos: .userInitiated).async { [self] in
            let tfx = nowTicks()
            var th: [Int] = []
            for bits in [5, 0, 1, 4, 2, 3, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15] {     // common ones first
                let cv = MTLFunctionConstantValues()
                for k in 0..<4 { var b = bits & (1 << k) != 0; cv.setConstantValue(&b, type: .bool, index: k) }
                do {
                    let p = try d.makeComputePipelineState(function: try lib.makeFunction(name: "composite_fx", constantValues: cv))
                    fxPipeLock.lock(); pCompFX[bits] = p; fxPipeLock.unlock()
                    th.append(p.maxTotalThreadsPerThreadgroup)
                } catch { olog("fx: composite_fx variant \(bits) FAILED: \(error)") }
            }
            olog(String(format: "fx: composite_fx %d variants compiled in %.0f ms (threads/group %d .. %d; plain composite %d)", th.count,
                        ticksToSec(nowTicks() &- tfx) * 1000, th.min() ?? 0, th.max() ?? 0, plainThreads))
        }
    }

    func start() {
        let t = Thread { [self] in
            pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0)
            Logger.shared.markNoWaitThread()             // log.swift: render lines are queued, never wait on file I/O
            self.run()
        }
        t.name = "render"
        t.qualityOfService = .userInteractive
        t.stackSize = 1 << 21
        t.start()
        if cfg.noNdiMeta { olog("--no-ndi-meta: the NDI sender reads no receiver metadata (connections polled 2x/s)") }
    }

    // MARK: render

    private func encode(index bi: Int, at t: Double) -> MTLCommandBuffer? {
        encodedNDI = nil
        var takeSnap = false
        snapLock.lock(); let inFlight = snapInFlight; snapLock.unlock()
        let live: Control = gControl.with { c in
            let copy = c
            if !c.dmx.freeze {                         // frozen: requests wait until the freeze ends
                c.zoomSet = nil
                c.targetRequest = nil
                c.targetDepth = nil
                c.centerRequest = nil
            }
            if c.snapshotRequest && !inFlight { c.snapshotRequest = false; takeSnap = true }
            return copy
        }
        // DMX freeze (Master control 20-29): the look is held from the first frozen frame and time stands still;
        // only the dimmer, blackout and safe look stay live (a frozen frame can still be faded out).
        var c = live
        let freeze = live.dmx.freeze
        if freeze {
            if frozen == nil {
                var f = live; f.zoomSet = nil; f.targetRequest = nil; f.centerRequest = nil
                frozen = f
                olog("DMX freeze: holding the frame (dimmer and blackout stay live)")
            }
            c = frozen!
            c.dimmer = live.dimmer; c.blackout = live.blackout
            c.dmx.blackout = live.dmx.blackout; c.dmx.safeLook = live.dmx.safeLook; c.dmx.freeze = true
            c.dmx.smooth = live.dmx.smooth; c.dmx.interval = live.dmx.interval
        } else if frozen != nil { frozen = nil; olog("DMX freeze off") }
        if let ti = c.targetRequest, ti >= 0, ti < zoomTargets.count {
            desired = CentreSpec.target(ti)
            pendingReset = !c.keepDepth && c.dmx.depth == nil     // console depth (DMX ch 7-8) keeps its depth
            pendingResetDepth = 0
            if let td = c.targetDepth, c.dmx.depth == nil { pendingReset = true; pendingResetDepth = td }   // preset: land at its depth
        }
        if let cc = c.centerRequest { desired = cc; pendingReset = false }
        let tPrev = simT
        let dtReal = max(0, min(5, t - simT))
        simT = t
        let dt = freeze ? 0 : dtReal
        let am = audrt.step(c.audioRoutes, gAudio.features(), dt: dtReal, frozen: freeze)   // audio react (held while frozen)
        if freeze { deepStart += dtReal }                  // DEEP holds its frame too
        let sm = c.dmx.smooth, gd = c.dmx.interval
        var depthJump = false
        if let z = c.zoomSet { depthJump = abs(z - log10W) >= 1; log10W = z }
        if c.dmx.resetSeq != lastResetSeq {                // DMX Fractal control "reset to target": depth 0
            if c.dmx.resetSeq > lastResetSeq {
                if log10WidthMax - log10W >= 1 { depthJump = true }
                log10W = log10WidthMax
                olog("DMX reset to target: depth 0")
            }
            lastResetSeq = c.dmx.resetSeq
        }
        if let dd = c.dmx.depth, !c.dmx.freezeZoom {
            // console control (DMX ch 7-8): glide from the depth shown to the DMX depth over one packet interval
            if !depthGlideOn { depthGlide.set(log10WidthMax - log10W); depthGlideOn = true }
            let d = depthGlide.step(dd, t: t, start: tPrev, dur: gd, smooth: sm)
            let nw = min(log10WidthMax, max(log10WidthMin, log10WidthMax - d))
            if abs(nw - log10W) >= 1 { depthJump = true }
            log10W = nw
        } else {
            depthGlideOn = false
            let speed = c.dmx.freezeZoom ? 0 : c.zoomSpeed * c.effectSpeed
            log10W = min(log10WidthMax, max(log10WidthMin, log10W - speed * dt))
        }
        palAccum = (palAccum + c.paletteSpeed * c.effectSpeed * dt).truncatingRemainder(dividingBy: 1)
        let palOff = palOffGlide.step(c.paletteOffset, t: t, start: tPrev, dur: gd, smooth: sm)
        let rot0 = rotGlide.step(c.rotation, t: t, start: tPrev, dur: gd, smooth: sm)
        if c.fractalSpinReset != seenSpinReset { seenSpinReset = c.fractalSpinReset; fracSpin = 0 }
        fracSpin = (fracSpin + min(2, max(-2, c.fractalSpin)) * 360 * dt * c.effectSpeed).truncatingRemainder(dividingBy: 360)
        let rot = rot0 + fracSpin                         // spin: the same rotation of the delta coordinates, so deep zoom stays exact
        let offX = offXGlide.step(c.offsetX, t: t, start: tPrev, dur: gd, smooth: sm)
        let offY = offYGlide.step(c.offsetY, t: t, start: tPrev, dur: gd, smooth: sm)
        let safe = c.dmx.safeLook                          // Master control 30-39: blackout off, normal content, dimmer 100%
        let startup = gStartup.current(t: t)              // cold start: the startup card until the first control input
        let content: Content = safe ? .normal : (startup ?? c.content)
        let dimV = dimGlide.step(safe ? 1 : min(1, max(0, c.dimmer)), t: t, start: tPrev, dur: gd, smooth: sm)
        let blackout = !safe && (c.blackout || c.dmx.blackout)
        if content != lastContent {
            if content == .deep { deepStart = t }
            olog("content \(lastContent.rawValue) -> \(content.rawValue)")
            lastContent = content
        }

        var p = OatsParams()
        p.cx = Float(-0.743643887037151)
        p.cy = Float(0.131825904205330)
        p.maxIter = 500
        p.w = UInt32(w); p.h = UInt32(h)
        p.use2020 = 0                                   // BT.709 at every canvas size (the output window, preview, snapshot and NDI decode 709)
        let dim = blackout ? 0.0 : min(1, max(0, dimV * (safe ? 1 : am.dimMul)))   // audio dimmer pulse (not in safe look)
        p.dimmer = Float(dim)
        p.flash = Float(blackout || safe ? 0 : am.flash)  // audio strobe flash (to_uyvy)
        var viewW = pow(10, log10W)
        let pso: MTLComputePipelineState
        var pert: (pp: OatsPertParams, slot: OrbitSlot, kind: Int, x: [SIMD4<Float>])? = nil
        var fadeAlpha: Double? = nil, copyLoop = false, keepWarm = false
        var fi: FractalInfo? = nil
        var phShown = [Double](repeating: 0, count: phaserCount), spreadShown = c.frac.spread, phNoteText = ""
        var phPausedOut: [String?] = [nil, nil, nil]
        switch content {
        case .normal:
            // phasers (phasers.swift): LFOs move what is drawn, never the base values (auto-zoom, loop, owners untouched)
            let pbN = gPlayback.with { ($0.beat, $0.at, $0.rate, $0.frozen) }
            if !freeze { phaserBeat = pbN.0 + (pbN.3 ? 0 : max(0, min(1, t - pbN.1)) * pbN.2 / 60) }
            // "0/s is stopped": HOLD pauses the zoom breathe, Cycle 0 the spread / offset phasers (unless "run even when stopped")
            let zHold = (c.zoomSpeed == 0 || c.dmx.freezeZoom) && c.frac.loop == .off
            let cyc0 = c.paletteSpeed == 0
            var pm = phrt.step(c.frac.phasers, dt: dt * c.effectSpeed, beat: phaserBeat, hold: zHold, cycle0: cyc0, free: c.frac.phaserFree,
                               rdt: freeze ? 0 : dtReal, speed0: c.effectSpeed <= 0.0005 && !c.frac.phaserFree)
            let phPaused = phrt.paused.map { $0?.rawValue }
            if am.fractal {                            // audio react: in phaser units, on top of the phasers
                func cl(_ v: Double) -> Double { min(1, max(-1, v)) }
                pm.spread = cl(pm.spread + am.spread); pm.zoom = cl(pm.zoom + am.zoom); pm.rotation = cl(pm.rotation + am.rotation)
                pm.palette = cl(pm.palette + am.palette); pm.julia = cl(pm.julia + am.julia); pm.trapsize = cl(pm.trapsize + am.trapsize)
            }
            var fm = c.frac
            let direct = fm.direct                     // the base look's path: the phasers never move the depth cap
            var phNote: [String] = []
            if pm.julia != 0 || pm.warp != 0 {
                if direct {
                    fm.julia = min(1, max(0, fm.julia + 0.5 * pm.julia))
                    fm.warp = min(0.5, max(-0.5, fm.warp + 0.15 * pm.warp))
                    if !fm.direct { fm.julia = 0.001 }  // stay on the direct path (no kernel / depth-cap switch mid-wave)
                } else { phNote.append("Julia morph / warp phasers act on a direct-path look only (Julia, kaleido or warp on)") }
            }
            if fm.trap != .off {
                fm.trapSize = min(4, max(0.01, fm.trapSize * pow(2, pm.trapsize)))
                fm.trapMix = min(1, max(0, fm.trapMix + 0.5 * pm.trapmix))
            } else if pm.trapsize != 0 || pm.trapmix != 0 { phNote.append("trap phasers need an orbit trap") }
            let fz = fm.foldZ, fcE = fm.foldCEff                 // Wild fold of z / Clean (or advanced) fold of c
            let foldN = fz.n > 0 ? fz.n : fcE.n
            let twist = foldN >= 1 ? pm.twist * Double.pi / Double(foldN) : 0
            if pm.twist != 0 && foldN < 1 { phNote.append("kaleido twist needs Twist or Fold c on") }
            if (pm.orbitX != 0 || pm.orbitY != 0) && fm.julia <= 0.0005 { phNote.append("Julia orbit shows with Julia morph on") }
            let spreadV = min(1, max(-1, fm.spread + pm.spread))    // -1 spread ... +1 tighten
            let densMul = pow(4.0, spreadV), crisp = max(0, spreadV) * 0.85
            phShown = phrt.shown; spreadShown = spreadV; phNoteText = phNote.joined(separator: "; "); phPausedOut = phPaused
            let cap = direct ? directDepthMax : zoomDepthMax
            if log10W < log10WidthMax - cap { log10W = log10WidthMax - cap }   // fold / Julia / warp: float32 z, depth capped
            let base0 = c.iterOverride > 0 ? c.iterOverride : autoIterations(depth: log10WidthMax - log10W)
            let slot = orbits.use(desired, iterations: base0, formula: fm.formula)
            if pendingReset, let s = slot, s.centre.key == desired.key, s.formula == fm.formula {
                log10W = log10WidthMax - min(cap, max(0, pendingResetDepth)); pendingReset = false
            }
            // Dive on select: once the new place's orbit is drawn, zoom in by itself for 1.5 s (about 2 decades, eased out)
            if c.diveSeq != seenDiveSeq { seenDiveSeq = c.diveSeq; diveArmed = true }
            if diveArmed, !pendingReset, let s = slot, s.centre.key == desired.key { diveArmed = false; diveUntil = t + 1.5 }
            if t < diveUntil && c.dmx.depth == nil && !freeze {
                let left = diveUntil - t
                log10W = max(log10WidthMax - cap, log10W - 1.6 * min(1, left / 0.5) * dt)
            }
            // endless zoom: Minibrot loop (on a nucleus target: zoom until the minibrot fills the frame like the set at
            // depth 0, matched scale + turn + palette phase, then depth 0) or Dive & return (any target, at the loop depth)
            var mini: MiniInfo? = nil
            var loopKind = "off", loopNote = "", loopEnd = 0.0
            if fm.loop != .off, let s = slot {
                let per = s.centre.index > 0 ? zoomTargets[s.centre.index - 1].period : 0
                if fm.loop == .minibrot {
                    if per > 0 && s.formula == .mandelbrot && !direct && fcE.n == 0 && s.centre.key == desired.key {
                        mini = miniCache.get(s.centre, period: per)
                        if mini == nil { loopNote = "measuring the minibrot (size, turn, colours)" }
                        else if mini!.endDepth > zoomDepthMax - 0.05 { loopNote = "minibrot deeper than the zoom limit: dive & return"; mini = nil }
                    } else if per == 0 {
                        loopNote = "\(s.centre.name) is not a minibrot: dive & return (minibrot targets: " + zoomTargets.filter { $0.period > 0 }.map { $0.name }.joined(separator: ", ") + ")"
                    } else {
                        loopNote = s.formula != .mandelbrot ? "minibrot loop is Mandelbrot only: dive & return" : (direct ? "wild twist / Julia / warp / power on: dive & return" : "twist / fold c on: dive & return")
                    }
                }
                loopKind = mini != nil ? "minibrot" : "dive"
                loopEnd = mini?.endDepth ?? min(fm.loopDepth, cap - 0.05)
            }
            let moving = c.dmx.depth == nil && !c.dmx.freezeZoom && c.zoomSpeed * c.effectSpeed > 0 && !freeze
            var loopCopy = false
            if loopPhase == "wait", let s = slot, s.centre.key == desired.key { loopPhase = "fade"; loopT0 = t }
            var fadeA: Double? = nil
            if loopPhase == "wait" { fadeA = 0 }
            if loopPhase == "fade" {
                let a = (t - loopT0) / max(0.05, loopFadeDur)
                if a >= 1 { loopPhase = "dive" } else { fadeA = max(0, a) }
            }
            if loopPhase != "fade" && loopPhase != "wait" {
                loopPhase = loopKind == "off" ? "off" : (moving ? "dive" : "idle")
                if loopPhase == "dive" && log10WidthMax - log10W >= loopEnd - 1e-9 {
                    loopCopy = true; fadeA = 0; loopCount += 1; depthJump = true
                    if let mi = mini {
                        log10W = min(log10WidthMax, log10W + mi.endDepth)       // the minibrot frame = depth 0 (keeps the overshoot)
                        if mi.colourK.isFinite { loopPalPhase = (loopPalPhase + mi.colourK * 0.03).truncatingRemainder(dividingBy: 1) }
                        loopFadeDur = max(0.2, fm.loopFade * 0.5)
                        loopPhase = "fade"; loopT0 = t
                        olog(String(format: "loop %d: minibrot %@ filled the frame at depth %.3f: back to depth 0 (matched scale, turn %.1f deg, palette)",
                                    loopCount, desired.name, mi.endDepth, -mi.argDeg))
                    } else {
                        log10W = log10WidthMax
                        loopFadeDur = max(0.2, fm.loopFade)
                        var ni = desired.index - 1
                        if desired.index > 0 {
                            if fm.loopNext == .next { ni = (ni + 1) % zoomTargets.count }
                            else if fm.loopNext == .random && zoomTargets.count > 1 { var r = ni; while r == ni { r = Int.random(in: 0..<zoomTargets.count) }; ni = r }
                        }
                        if desired.index > 0 && ni != desired.index - 1 {
                            desired = CentreSpec.target(ni); pendingReset = false; loopPhase = "wait"
                        } else { loopPhase = "fade"; loopT0 = t }
                        olog(String(format: "loop %d: dive & return at depth %.2f -> depth 0 on %@ (%.1f s crossfade from the frozen frame)",
                                    loopCount, loopEnd, desired.name, loopFadeDur))
                    }
                }
            }
            viewW = pow(10, log10W)
            let depth = log10WidthMax - log10W
            // zoom breathe: +-0.5 decade drawn around the depth (inside 0 ... cap); log10W itself never moves
            let lwR = min(log10WidthMax, max(log10WidthMax - cap, log10W - 0.5 * pm.zoom))
            let viewR = pow(10, lwR)
            let base = c.iterOverride > 0 ? c.iterOverride : min(direct ? 800 : maxIterLimit, autoIterations(depth: depth))   // direct: 800 is plenty to 1e4.5
            let fixed: Int? = c.resOverride > 0 ? min(Governor.levels.count, c.resOverride) - 1 : nil
            // jumps: guard the worst case of this first frame before it is drawn (governor)
            var why: [String] = []
            if let s = slot, s.centre.key != lastKey { if !lastKey.isEmpty { why.append("centre \(s.centre.name)") }; lastKey = s.centre.key }
            if depthJump { why.append(String(format: "depth jump to %.1f", depth)) }
            if c.iterOverride != lastIterOverride { why.append("iteration override"); lastIterOverride = c.iterOverride }
            if c.resOverride != lastResOverride { why.append("resolution override"); lastResOverride = c.resOverride }
            if !lastContentNormal { why.append("normal content") }
            if fixed == nil && !why.isEmpty, let line = gov.jump(iterations: base, why: why.joined(separator: ", ")) { olog(line) }
            let lvl = fixed ?? gov.level
            var scaleI = fixed == nil ? gov.iterScale : 1.0
            if fixed != nil {                          // fixed resolution: keep every frame's worst case bounded instead
                let wmax = Governor.fixedWork / (Governor.area(lvl) * Double(base))
                if wmax < 1 { scaleI = wmax }
            }
            let iters = max(min(100, base), min(maxIterLimit, Int((Double(base) * scaleI * pow(2, pm.iterations)).rounded())))   // Blob: 8...99 stays as set
            let (rw, rh) = Governor.levels[lvl]
            p.scale = Float(viewR / fracRefW(w, h))
            p.pal = UInt32(min(5, max(1, c.palette)))
            p.density = Float(0.03 * densMul)
            p.phase = Float((palOff + palAccum + 0.5 * pm.palette).truncatingRemainder(dividingBy: 1))
            pso = pMandel                              // only if there is no reference orbit (never after init)
            encodedFixed = fixed
            if let s = slot {
                // Minibrot loop: on the way in, turn toward the minibrot's own orientation, centre on c0 + lambda c0 and
                // (last 2 decades) spread the colour bands by 1/period around the minibrot's base escape count K, so the
                // frame at the end depth is the depth-0 view in shape, turn and colour
                var rotX = 0.0, offXc = 0.0, offYc = 0.0, densK = 1.0, phaseK = 0.0
                if let mi = mini {
                    rotX = -mi.argDeg * min(1, max(0, depth / mi.endDepth))
                    offXc = mi.offRe; offYc = mi.offIm
                    if mi.colourK.isFinite {
                        let r = min(1, max(0, (depth - (mi.endDepth - 2)) / 2))
                        densK = pow(Double(mi.period), -r)
                        phaseK = mi.colourK * 0.03 * (1 - densK)
                    }
                }
                // shape framing (2026-10-23): symmetric formations (Julia morph, Multibrot / a real power, kaleido) are centred on
                // 0, not on the place: at shallow depth the view slides from 0 to the place (gone by depth 1.5), so a shape
                // tile shows the whole formation at depth 0 and still dives into the place
                if mini == nil && s.centre.index > 0 {
                    // a Julia set has no "places": with the morph on it stays centred on 0 at every depth (x the morph)
                    let hj = fm.julia > 0.0005 ? min(1, fm.julia) : 0
                    let hs = fm.polarPower || fm.formula.power != 2 || foldN > 0 ? 1.0 : 0
                    let u = min(1, max(0, depth / 1.5)), fade = 1 - u * u * (3 - 2 * u)
                    let hw = max(hj, hs * fade)
                    if hw > 0 { offXc -= s.centre.re.hi * hw; offYc -= s.centre.im.hi * hw }
                }
                var pp = OatsPertParams()
                pp.scale = Float(viewR / fracRefW(rw, rh))
                pp.crisp = Float(crisp)
                pp.phase = Float((Double(p.phase) + loopPalPhase + phaseK).truncatingRemainder(dividingBy: 1))
                pp.density = Float(Double(p.density) * densK)
                pp.cx = Float(s.centre.re.hi)
                pp.cy = Float(s.centre.im.hi)
                pp.maxIter = UInt32(iters)
                pp.rw = UInt32(rw); pp.rh = UInt32(rh)
                pp.orbLen = UInt32(max(2, s.len))
                pp.pal = p.pal
                pp.cardioid = viewR > 1e-2 ? 1 : 0
                let rotP = rot + rotX + 45 * pm.rotation   // rotation wobble (phaser)
                let a = -rotP * .pi / 180                  // picture turns counter-clockwise: the plane turns back
                pp.rotC = Float(cos(a)); pp.rotS = Float(sin(a))
                pp.offX = Float(offX * viewR + offXc); pp.offY = Float(offY * viewR + offYc)
                // formula modifiers: the classic kernel when nothing is on (golden-checked), else pert2 / direct
                if fm.juliaBeat {
                    let pb = gPlayback.with { ($0.beat, $0.at, $0.rate, $0.frozen) }
                    juliaPh = (pb.0 + (freeze || pb.3 ? 0 : max(0, min(1, t - pb.1)) * pb.2 / 60)) * fm.juliaDrift
                } else {
                    juliaPh = (juliaPh + fm.juliaDrift * dt * c.effectSpeed).truncatingRemainder(dividingBy: 1)
                }
                let jr = fm.juliaRe + (fm.juliaDrift != 0 ? 0.04 * cos(2 * .pi * juliaPh) : 0) + 0.05 * pm.orbitX   // + Julia orbit (phaser)
                let ji = fm.juliaIm + (fm.juliaDrift != 0 ? 0.04 * sin(2 * .pi * juliaPh) : 0) + 0.05 * pm.orbitY
                let fo = direct ? fm.formula : s.formula
                if fz.n == 0 { wildSSN = 4 } else if wildSSN == 4 && gov.level >= 2 && fixed == nil {
                    wildSSN = 2; olog("wild twist: supersampling 2x2 -> 1x2 (the governor is at \(rw)x\(rh))")
                }
                let wildSS = fz.n > 0 ? wildSSN : 1
                let kind = direct ? 2 : (s.formula == .mandelbrot && fm.trap == .off && fcE.n == 0 && fm.bailout == 256 ? 0 : 1)
                let bail = min(1024, max(2, fm.bailout))
                var xp: [SIMD4<Float>] = [
                    SIMD4<Float>(Float(fo.rawValue), Float(log2(Double(fo.power))), Float(bail * bail), Float(TrapShape.allCases.firstIndex(of: fm.trap)!)),
                    SIMD4<Float>(Float(fm.trapMix), Float(fm.trapSize), Float(fcE.n), fcE.mirror ? 1 : 0),
                    SIMD4<Float>(Float(fz.n), fz.mirror ? 1 : 0, Float(fm.julia), Float(fm.warp)),
                    SIMD4<Float>(Float(jr), Float(ji), Float(cos(2 * .pi / Double(max(2, fm.fold)))), Float(sin(2 * .pi / Double(max(2, fm.fold)))))]
                    + (0..<6).map { j -> SIMD4<Float> in
                        let sct = 2 * Double.pi / Double(max(2, fm.fold)), a0 = -Double(2 * j) * sct, a1 = -Double(2 * j + 1) * sct
                        return SIMD4<Float>(Float(cos(a0)), Float(sin(a0)), Float(cos(a1)), Float(sin(a1)))
                    }
                    + [SIMD4<Float>(Float(cos(twist)), Float(sin(twist)), twist != 0 ? 1 : 0, 0),     // X[10]: kaleido twist
                       SIMD4<Float>(Float(fm.power), fm.polarPower ? 1 : 0, Float(wildSS), 0)]          // X[11]: Branches (real power), supersampling
                if fm.polarPower { xp[0].y = Float(log2(max(1.01, fm.power))) }                          // smooth colouring for z^p
                if kind == 2 { pp.cardioid = 0 }
                pert = (pp, s, kind, xp)
                let info = orbits.info()
                var f = FractalInfo()
                f.depth = depth
                f.target = s.centre.name; f.targetIndex = s.centre.index
                f.centerRe = s.centre.reText; f.centerIm = s.centre.imText
                f.pending = s.centre.key == desired.key ? "" : desired.name
                f.iterations = iters; f.iterBase = base; f.iterScale = scaleI
                f.refLen = s.len; f.refEscaped = s.escaped; f.refMs = s.ms; f.refComputed = info.computed
                f.refReady = s.centre.key == desired.key && (s.escaped || s.len >= min(OrbitWorker.capacity, base + 1))
                f.resW = rw; f.resH = rh; f.resAuto = fixed == nil
                f.gpuP95 = gov.p95; f.governorChanges = gov.changes
                f.offsetX = offX; f.offsetY = offY; f.rotation = rotP
                f.depthShown = log10WidthMax - lwR
                f.path = kind == 0 ? "perturbation" : (kind == 1 ? "perturbation+" : "direct")
                f.wildSS = wildSS
                f.formula = fo.name; f.depthCap = cap
                f.juliaShownRe = jr; f.juliaShownIm = ji
                f.loopPhase = loopPhase; f.loops = loopCount; f.loopEnd = loopEnd; f.loopKind = loopKind; f.loopNote = loopNote
                fi = f
            }
            fadeAlpha = fadeA; copyLoop = loopCopy; keepWarm = residencySet == nil && fm.loop != .off && fadeA == nil && !loopCopy
        case .deep:                                    // bench DEEP: log-space triangle 3.0 <-> 1e-5, 24 s period, by clock
            let animT = max(0, t - deepStart)
            let ph = animT / 24.0
            let tri = 1 - abs(1 - 2 * (ph - floor(ph)))
            viewW = exp(log(3.0) + (log(1e-5) - log(3.0)) * tri)
            p.scale = Float(viewW / fracRefW(w, h))
            p.pal = 0
            p.density = 0.03
            p.phase = Float((animT * 0.1).truncatingRemainder(dividingBy: 1))
            pso = pMandel
        case .noise:                                   // bench NOISE: full amplitude, new every frame
            p.scale = 1
            p.phase = Float(noiseFrame % 1000)
            if !freeze { noiseFrame += 1 }
            pso = pNoise
        case .testcard, .ndicard, .standby:            // testcard.swift: drawn into the canvas below (no fractal, no layers)
            pso = pMandel
        }
        let card = content.isCard
        // M2a clip layers: control changes, frames for this tick's display time, fades
        let fracOp = min(1, max(0, c.fractalOpacity))
        var lctl = c.layers
        for i in 0..<compCount { lctl[i].opacity = layerOpGlide[i].step(min(1, max(0, lctl[i].opacity)), t: t, start: tPrev, dur: gd, smooth: sm) }
        let tl0 = nowTicks()
        let linfo = layerEngine.step(lctl, t: t, host: ticksToSec(gStartTicks) + t, frozen: freeze)
        encodedLayersMs = ticksToSec(nowTicks() &- tl0) * 1000
        // layer sources (gen.swift): the one fractal draws on c.fractalLayer (normal content only; DEEP / NOISE stay on the base)
        let fl = content == .normal ? min(layerCount, max(0, c.fractalLayer)) : 0
        // BG = layer L0 (index bgIndex, drawn first over black). Its effective source: Fractal while the fractal is home
        // (fl == 0); Fractal chosen but the fractal is on L1-L4 = its own clip instead (none = black, status note);
        // DEEP / NOISE test content always on BG as before.
        var srcEff = lctl.map { $0.source }
        if content != .normal { srcEff[bgIndex] = .fractal }
        else if srcEff[bgIndex] == .fractal && fl != 0 { srcEff[bgIndex] = .clip }
        func fracHere(_ i: Int) -> Bool { i == bgIndex ? fl == 0 && srcEff[bgIndex] == .fractal : fl == i + 1 }
        // NDI sources (ndiin.swift): tell the supervisor which layers want which source; take this frame's textures
        gNDIIn.setWants((0..<compCount).map { srcEff[$0] == .ndi && !card ? (lctl[$0].ndiName, lctl[$0].ndiBandwidth) : nil })
        var ndiTex = [MTLTexture?](repeating: nil, count: compCount), ndiKeep: [AnyObject] = []
        for i in 0..<compCount where srcEff[i] == .ndi && !card {
            let f = gNDIIn.frame(i)
            ndiTex[i] = f.tex
            if let k = f.keep { ndiKeep.append(k) }
        }
        let soloWant = gPreview.soloWanted()            // GUI PREVIEW monitor: a generator layer it shows renders at 0 % too
        func soloBit(_ i: Int) -> Int { 1 << layerNum(i) }
        let drawFractal = !card && (fl == 0 ? srcEff[bgIndex] == .fractal && (lctl[bgIndex].opacity > 0 || soloWant & 1 != 0)
                                            : (lctl[fl - 1].source == .fractal && lctl[fl - 1].opacity > 0))
        if !drawFractal { pert = nil }
        let lw = log10W, vw = viewW, pal = c.palette, ph = Double(p.phase)
        encodedNormal = pert != nil
        lastContentNormal = content == .normal
        gStats.with { r in
            r.frozen = freeze; r.safeLook = safe; r.blackoutDMX = c.dmx.blackout
            r.content = content; r.viewWidth = vw; r.log10Width = lw; r.palette = pal; r.palettePhase = ph; r.dimmerOut = dim
            if let f = fi { r.fractal = f } else { r.fractal.depth = log10WidthMax - lw }
            r.layers = Array(linfo.prefix(layerCount)); r.bgLayer = linfo[bgIndex]; r.bgSource = srcEff[bgIndex]; r.fractalOpacity = fracOp
            r.fractalLayerShown = fl; r.fractalSpinAngle = remainder(fracSpin, 360)
            r.phaserShown = phShown; r.spreadShown = spreadShown; r.phaserNote = phNoteText; r.phaserPaused = phPausedOut
        }

        guard let cb = queue.makeCommandBuffer() else { return nil }
        if copyLoop, let blit = cb.makeBlitCommandEncoder() {      // loop: freeze the frame shown last (before this one draws)
            blit.copy(from: tex, to: loopTex)
            blit.endEncoding()
        } else if keepWarm, drawFractal, let blit = cb.makeBlitCommandEncoder() {   // no residency set: keep the loop textures paged in (64x64 touch)
            blit.copy(from: loopTex, sourceSlice: 0, sourceLevel: 0, sourceOrigin: MTLOrigin(x: 0, y: 0, z: 0), sourceSize: MTLSize(width: 64, height: 64, depth: 1),
                      to: fadeTex, destinationSlice: 0, destinationLevel: 0, destinationOrigin: MTLOrigin(x: 0, y: 0, z: 0))
            blit.endEncoding()
        }
        // one encoder per stage (GPUStages: timestamp counters at encoder boundaries); stage 0 = fractal
        let gst = gGPUStages.beginFrame()
        guard var enc = gGPUStages.compute(cb, gst, stage: 0) else { return nil }
        let tgM = MTLSize(width: pso.threadExecutionWidth, height: pso.maxTotalThreadsPerThreadgroup / pso.threadExecutionWidth, depth: 1)
        let tgC = MTLSize(width: pPack.threadExecutionWidth, height: pPack.maxTotalThreadsPerThreadgroup / pPack.threadExecutionWidth, depth: 1)
        if var pt = pert {
            // deep zoom: perturbation at the internal resolution; below 1080p into fracTex, then upscaled into tex
            let full = pt.pp.rw == UInt32(w) && pt.pp.rh == UInt32(h)
            let tgP = MTLSize(width: pPert.threadExecutionWidth, height: pPert.maxTotalThreadsPerThreadgroup / pPert.threadExecutionWidth, depth: 1)
            let pk = pt.kind == 0 ? pPert : (pt.kind == 1 ? pPert2 : pDirect)
            let tgK = MTLSize(width: pk.threadExecutionWidth, height: pk.maxTotalThreadsPerThreadgroup / pk.threadExecutionWidth, depth: 1)
            enc.setComputePipelineState(pk)
            enc.setTexture(full ? tex : fracTex, index: 0)
            enc.setBytes(&pt.pp, length: MemoryLayout<OatsPertParams>.size, index: 0)
            if pt.kind != 2 { enc.setBuffer(pt.slot.buf, offset: 0, index: 1) }
            if pt.kind != 0 { var xp = pt.x; enc.setBytes(&xp, length: MemoryLayout<SIMD4<Float>>.stride * xp.count, index: 2) }
            enc.dispatchThreads(MTLSize(width: Int(pt.pp.rw), height: Int(pt.pp.rh), depth: 1), threadsPerThreadgroup: pt.kind == 0 ? tgP : tgK)
            if !full {
                var q = SIMD4<UInt32>(pt.pp.rw, pt.pp.rh, UInt32(w), UInt32(h))
                let tgU = MTLSize(width: pUp.threadExecutionWidth, height: pUp.maxTotalThreadsPerThreadgroup / pUp.threadExecutionWidth, depth: 1)
                enc.setComputePipelineState(pUp)
                enc.setTexture(fracTex, index: 0)
                enc.setTexture(tex, index: 1)
                enc.setBytes(&q, length: MemoryLayout<SIMD4<UInt32>>.size, index: 0)
                enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tgU)
            }
        } else if drawFractal {
            enc.setComputePipelineState(pso)
            enc.setTexture(tex, index: 0)
            enc.setBytes(&p, length: MemoryLayout<OatsParams>.size, index: 0)
            enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tgM)
        }
        // loop crossfade: frozen last frame -> live fractal (the fractal layer reads fadeTex meanwhile)
        var fracOut: MTLTexture = tex
        if let fa = fadeAlpha, pert != nil {
            var a = Float(fa)
            let tgF = MTLSize(width: pFade.threadExecutionWidth, height: pFade.maxTotalThreadsPerThreadgroup / pFade.threadExecutionWidth, depth: 1)
            enc.setComputePipelineState(pFade)
            enc.setTexture(tex, index: 0)
            enc.setTexture(loopTex, index: 1)
            enc.setTexture(fadeTex, index: 2)
            enc.setBytes(&a, length: MemoryLayout<Float>.size, index: 0)
            enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tgF)
            fracOut = fadeTex
        }
        // M2a composite: fractal layer x opacity, then clip layers 1..4 bottom-up -> 16-bit float canvas
        // colour link: exponential smoothing, time constant 100 ms (modes and targets switch at once)
        let cl = c.color
        let goal = SIMD4<Double>(cl.r, cl.g, cl.b, cl.amount)
        let ka = colorT < 0 ? 1 : 1 - exp(-max(0, t - colorT) / 0.1)
        colorT = t
        colorSm += (goal - colorSm) * ka
        let csm = colorSm
        gColorShown.with { $0 = csm }
        // FX (fx.swift): transform, 2 slots and the beat mod per layer; the beat is extrapolated to this frame's time
        fxrt.beginFrame()
        let pb = gPlayback.with { ($0.beat, $0.at, $0.rate, $0.frozen) }
        let beatNow = pb.0 + (freeze || pb.3 ? 0 : max(0, min(1, t - pb.1)) * pb.2 / 60)
        let fxDt = dt * c.effectSpeed
        let linkOn = csm.w >= 0.002
        let linkRGB = SIMD3<Float>(Float(csm.x), Float(csm.y), Float(csm.z))
        var bctl = lctl
        var fxParams: [SIMD4<Float>] = [], histR: [MTLTexture] = [], histW: [MTLTexture] = []
        var allPlain = true, stages = 0
        var genX = [[SIMD4<Float>]](repeating: [], count: compCount)
        var visibleMask = 0
        var hasContent = [Bool](repeating: false, count: compCount)
        for i in 0..<compCount {
            // content: what the composite would draw for this layer (opacity 0 / empty layers skip FX and Trails work)
            let content: Bool
            switch srcEff[i] {
            case .clip: content = !card && layerEngine.hasContent(i)
            case .fractal: content = fracHere(i) && drawFractal
            case .gen: content = !card
            case .ndi: content = !card && ndiTex[i] != nil
            }
            hasContent[i] = content
            var lfx = c.layers[i].fx                   // audio react FX speed (fx1_speed / fx2_speed): on top, never stored
            if am.layers[i].fx1Speed != 0 || am.layers[i].fx2Speed != 0 { lfx.fx = audioFXSpeed(lfx.fx, am.layers[i]) }
            let r = fxrt.layer(i, lfx, dt: fxDt, beat: beatNow, t: t, start: tPrev, dur: gd, smooth: sm,
                               duo: linkOn ? linkRGB : layerAccent[i], aud: am.layers[i], source: srcEff[i],
                               baseOpacity: bctl[i].opacity, content: content)
            fxParams += r.params; histR.append(r.histR); histW.append(r.histW); genX[i] = r.gen
            bctl[i].opacity *= r.opacity
            if am.layers[i].opacity != 0 { bctl[i].opacity = min(1, max(0, bctl[i].opacity + am.layers[i].opacity)) }
            if r.visible { visibleMask |= 1 << i }
            if !r.plain && r.visible { allPlain = false; stages |= r.stages }
        }
        var mfxSlot = c.masterFX
        if am.masterFX != 0 { mfxSlot.amount = min(1, max(0, mfxSlot.amount + am.masterFX)) }
        if am.masterFXSpeed != 0 { mfxSlot.speed = min(1, max(0, mfxSlot.speed + am.masterFXSpeed)) }
        let mfx = card ? nil : fxrt.master(mfxSlot, dt: fxDt, t: t, start: tPrev, dur: gd, smooth: sm, duo: linkOn ? linkRGB : masterAccent)
        let (modShown, angShown, nHist, scShown, audShown) = (fxrt.modShown, fxrt.angleShown, fxrt.histAllocated, fxrt.scaleShown, audrt.shown)
        gStats.with { r in r.layerMod = modShown; r.layerAngle = angShown; r.layerScale = scShown; r.audioShown = audShown; r.masterFXOn = mfx != nil; r.fxHist = nHist; r.fxKernel = allPlain ? "composite" : "composite_fx/\(stages)"; r.layersDrawn = visibleMask }
        // stage 1 = layers: generators + composite (or the test card)
        enc.endEncoding()
        guard let encL = gGPUStages.compute(cb, gst, stage: 1) else { return nil }
        enc = encL
        // non-clip sources: the fractal texture on its layer, generators into their own textures (premultiplied)
        var src: [(kind: Int, tex: MTLTexture?)?] = []
        var tgG: MTLSize? = nil
        var ovTex = [MTLTexture?](repeating: nil, count: compCount)           // clip / fractal overlay textures (composite 21..25)
        var ovMode = [Float](repeating: 0, count: compCount)                  // overlay blend + 1 (0 = none)
        var ovOn = 0
        let identX: [SIMD4<Float>] = [SIMD4<Float>(0, 0, 1, 0), SIMD4<Float>(1, 0, 1, 0), SIMD4<Float>(0, 0, 0, 0)]
        for i in 0..<compCount {
            // layer overlay (gen.swift): skipped entirely when off, at opacity 0, on a card or a layer that draws nothing
            let ov = c.layers[i].overlay
            let ovOp = min(1, max(0, ov.opacity + am.layers[i].overlayOpacity))
            let ovActive = ov.on && ovOp > 0.0005 && !card && bctl[i].opacity > 0 && hasContent[i]
            let ovX = ov.follow && genX[i].count == 3 ? genX[i] : identX
            var ovP: [SIMD4<Float>]? = nil
            if ovActive {
                ovP = genrt.params(compCount + i, ov.gen, dt: fxDt, beat: beatNow, link: linkOn ? linkRGB : nil, accent: layerAccent[i])
                ovOn |= 1 << i
            }
            if tgG == nil { tgG = MTLSize(width: pGen.threadExecutionWidth, height: pGen.maxTotalThreadsPerThreadgroup / pGen.threadExecutionWidth, depth: 1) }
            switch srcEff[i] {
            case .clip, .fractal, .ndi:
                src.append(srcEff[i] == .clip ? nil : srcEff[i] == .ndi ? (3, ndiTex[i]) : (1, fracHere(i) && drawFractal ? fracOut : nil))
                guard let op = ovP, let gt = genrt.texture(i) else { continue }
                var gp = GenRuntime.pack(op, gain: Float(ovOp))                // overlay-only pass, opacity baked in
                enc.setComputePipelineState(pGen)
                enc.setTexture(gt, index: 0)
                enc.setBytes(&gp, length: MemoryLayout<SIMD4<Float>>.stride * gp.count, index: 0)
                var gx = ovX
                enc.setBytes(&gx, length: MemoryLayout<SIMD4<Float>>.stride * 3, index: 1)
                enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tgG!)
                ovTex[i] = gt; ovMode[i] = Float(ov.blend.mode.rawValue + 1)
            case .gen:
                guard !card, bctl[i].opacity > 0 || soloWant & soloBit(i) != 0, let gt = genrt.texture(i) else { src.append((2, nil)); continue }   // + the PREVIEW monitor at 0 %
                var gq = c.layers[i].gen
                let la = am.layers[i]
                if la.gen { gq.count = min(1, max(0, gq.count + la.genCount)); gq.thickness = min(1, max(0, gq.thickness + la.genThick)); gq.speed = min(1, max(-1, gq.speed + la.genSpeed)) }
                var gp = GenRuntime.pack(genrt.params(i, gq, dt: fxDt, beat: beatNow, link: linkOn ? linkRGB : nil, accent: layerAccent[i]),
                                         overlay: ovP, blend: ov.blend.mode, opacity: Float(ovOp), follow: ov.follow)   // overlay inline, same pass
                enc.setComputePipelineState(pGen)
                enc.setTexture(gt, index: 0)
                enc.setBytes(&gp, length: MemoryLayout<SIMD4<Float>>.stride * gp.count, index: 0)
                var gx = genX[i].count == 3 ? genX[i] : [SIMD4<Float>(0, 0, 1, 0), SIMD4<Float>(1, 0, 1, 0), SIMD4<Float>(0, 0, 0, 0)]
                enc.setBytes(&gx, length: MemoryLayout<SIMD4<Float>>.stride * 3, index: 1)
                enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tgG!)
                src.append((2, gt))
            }
        }
        let nGen = genrt.allocated
        gStats.with { $0.genAllocated = nGen; $0.overlaysDrawn = ovOn }
        let lb = layerEngine.bindings(bctl, dummy: dummy, src: src)
        var cp: [SIMD4<Float>] = [SIMD4<Float>(0, 0, 0, 0)] + lb.params          // p[0] unused (BG is layer slot 4, drawn first)
        for i in 0..<compCount where ovMode[i] > 0 && 2 + 2 * i < cp.count { cp[2 + 2 * i].w = ovMode[i] }
        // clip scaling per layer (mapping.swift layer_fit): fit = the whole clip with transparent bars instead of cover
        let fits = gMapping.layerFits()
        for i in 0..<min(layerCount, fits.count) where fits[i] && (srcEff[i] == .clip || srcEff[i] == .ndi) {
            if 2 + 2 * i < cp.count { cp[2 + 2 * i].z = 1 }
            if 6 * i + 1 < fxParams.count { fxParams[6 * i + 1].y += 16 }
        }
        cp.append(SIMD4<Float>(Float(csm.x), Float(csm.y), Float(csm.z), csm.w < 0.002 ? 0 : Float(csm.w)))
        cp.append(SIMD4<Float>(Float(ColorMode.allCases.firstIndex(of: cl.mode)!), Float(ColorTarget.allCases.firstIndex(of: cl.target)!), 0, 0))
        cp += fxParams
        fxPipeLock.lock(); let pV = allPlain ? nil : pCompFX[stages]; fxPipeLock.unlock()
        let pK = pV ?? pComp
        if pV == nil { allPlain = true }                 // variant still compiling: this frame without FX
        if card {                                        // test card / NDI card: one pass into the canvas instead of the composite
            let cf = cards.frameParams(kind: content, t: t)
            var cpp = [cf.p]
            let tgT = MTLSize(width: pCard.threadExecutionWidth, height: pCard.maxTotalThreadsPerThreadgroup / pCard.threadExecutionWidth, depth: 1)
            enc.setComputePipelineState(pCard)
            enc.setTexture(canvas, index: 0)
            enc.setTexture(cf.overlay ?? dummy, index: 1)
            enc.setBytes(&cpp, length: MemoryLayout<SIMD4<Float>>.stride, index: 0)
            enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tgT)
        } else {
            let tgK = MTLSize(width: pK.threadExecutionWidth, height: pK.maxTotalThreadsPerThreadgroup / pK.threadExecutionWidth, depth: 1)
            enc.setComputePipelineState(pK)
            enc.setTextures(lb.texs, range: 0..<lb.texs.count)                 // 2 per layer, L1..L4 then BG
            enc.setTexture(canvas, index: 10)
            if !allPlain { enc.setTextures(histR, range: 11..<16); enc.setTextures(histW, range: 16..<21) }
            enc.setTextures(ovTex.map { $0 ?? dummy }, range: 21..<26)
            enc.setBytes(&cp, length: MemoryLayout<SIMD4<Float>>.stride * cp.count, index: 0)
            enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tgK)
        }
        // master FX slot: one more full-frame pass, only while it is on; analysis and to_uyvy then read its output
        var outTex: MTLTexture = canvas
        enc.endEncoding()
        if let m = mfx, let encM = gGPUStages.compute(cb, gst, stage: 2) {
            enc = encM
            var mp = m.params
            let tgX = MTLSize(width: pMaster.threadExecutionWidth, height: pMaster.maxTotalThreadsPerThreadgroup / pMaster.threadExecutionWidth, depth: 1)
            enc.setComputePipelineState(pMaster)
            enc.setTexture(canvas, index: 0)
            enc.setTexture(m.out, index: 1)
            enc.setTexture(m.histR, index: 2)
            enc.setTexture(m.histW, index: 3)
            enc.setBytes(&mp, length: MemoryLayout<SIMD4<Float>>.stride * mp.count, index: 0)
            enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tgX)
            outTex = m.out
            enc.endEncoding()
        }
        // stage 3 = output: analysis, to_uyvy, preview, NDI copy
        guard let encO = gGPUStages.compute(cb, gst, stage: 3) else { return nil }
        enc = encO
        if !lb.keep.isEmpty || !ndiKeep.isEmpty { let keep = lb.keep + ndiKeep; cb.addCompletedHandler { _ in withExtendedLifetime(keep) {} } }
        // dominant colours: every 6th frame (10 Hz at 60), canvas x dimmer -> 64x36, k-means off the render thread
        anaFrame &+= 1
        if anaFrame % Int64(analysisEvery) == 0, let slot = analysis.begin() {
            var aq = SIMD4<UInt32>(UInt32(w), UInt32(h), UInt32(analysisW), UInt32(analysisH))
            var ad = Float(dim)
            let tgA = MTLSize(width: pAna.threadExecutionWidth, height: max(1, pAna.maxTotalThreadsPerThreadgroup / pAna.threadExecutionWidth), depth: 1)
            enc.setComputePipelineState(pAna)
            enc.setTexture(outTex, index: 0)
            enc.setBuffer(analysis.bufs[slot], offset: 0, index: 0)
            enc.setBytes(&aq, length: MemoryLayout<SIMD4<UInt32>>.size, index: 1)
            enc.setBytes(&ad, length: MemoryLayout<Float>.size, index: 2)
            enc.dispatchThreads(MTLSize(width: analysisW, height: analysisH, depth: 1), threadsPerThreadgroup: tgA)
            let an = analysis
            cb.addCompletedHandler { done in an.gpuDone(slot, ok: done.status == .completed) }
        }
        enc.setComputePipelineState(pPack)
        enc.setTexture(outTex, index: 0)
        enc.setBuffer(bufs[bi], offset: 0, index: 0)
        enc.setBytes(&p, length: MemoryLayout<OatsParams>.size, index: 1)
        enc.dispatchThreads(MTLSize(width: w / 2, height: h, depth: 1), threadsPerThreadgroup: tgC)
        // GUI preview: only while a client is connected (otherwise renderBegin is one atomic load), every Nth frame,
        // in this same command buffer; the completion handler hands the slot to the preview thread (no waits here).
        pvFrame &+= 1
        if let pv = gPreview.renderBegin(frame: pvFrame) {
            let tgP = MTLSize(width: pPreview.threadExecutionWidth, height: max(1, pPreview.maxTotalThreadsPerThreadgroup / pPreview.threadExecutionWidth), depth: 1)
            enc.setComputePipelineState(pPreview)
            enc.setBuffer(bufs[bi], offset: 0, index: 0)
            for (si, pw) in previewWidths.enumerated() where pv.mask & (1 << si) != 0 {
                var pq = SIMD4<UInt32>(UInt32(w), UInt32(h), UInt32(pw), UInt32(previewHeight(pw)))
                var lb = previewLetterbox(w, h, pw, previewHeight(pw))
                enc.setBuffer(pvBufs[si][pv.slot], offset: 0, index: 1)
                enc.setBytes(&pq, length: MemoryLayout<SIMD4<UInt32>>.size, index: 2)
                enc.setBytes(&lb, length: MemoryLayout<SIMD4<UInt32>>.size, index: 3)
                enc.dispatchThreads(MTLSize(width: pw, height: previewHeight(pw), depth: 1), threadsPerThreadgroup: tgP)
            }
            // PREVIEW monitor (?layer=n): that layer's own source texture(s) by itself, before opacity and blend (one dispatch)
            if pv.mask >> previewSoloBase != 0 && pv.layer >= 0 {
                let n = pv.layer
                var texA: MTLTexture = dummy, texB: MTLTexture = dummy, texO: MTLTexture = dummy
                var lp = [SIMD4<Float>](repeating: SIMD4<Float>(0, 0, 0, 0), count: 2)
                let li = layerIndex(min(layerCount, n))  // 0 = BG (a full layer: its source + overlay, like L1-L4)
                if 2 * li + 1 < lb.texs.count && 2 + 2 * li < cp.count {
                    texA = lb.texs[2 * li]; texB = lb.texs[2 * li + 1]
                    lp[0] = cp[1 + 2 * li]; lp[1] = cp[2 + 2 * li]
                    if let o = ovTex[li] { texO = o } else { lp[1].w = 0 }
                }
                let tgS = MTLSize(width: pSolo.threadExecutionWidth, height: max(1, pSolo.maxTotalThreadsPerThreadgroup / pSolo.threadExecutionWidth), depth: 1)
                enc.setComputePipelineState(pSolo)
                enc.setTexture(texA, index: 0); enc.setTexture(texB, index: 1); enc.setTexture(texO, index: 2)
                enc.setBytes(&lp, length: MemoryLayout<SIMD4<Float>>.stride * 2, index: 3)
                for (j, pw) in previewSoloWidths.enumerated() where pv.mask & (1 << (previewSoloBase + j)) != 0 {
                    var pq = SIMD4<UInt32>(UInt32(w), UInt32(h), UInt32(pw), UInt32(previewHeight(pw)))
                    var slb = previewLetterbox(w, h, pw, previewHeight(pw))
                    enc.setBuffer(pvBufs[previewSoloBase + j][pv.slot], offset: 0, index: 0)
                    enc.setBytes(&pq, length: MemoryLayout<SIMD4<UInt32>>.size, index: 1)
                    enc.setBytes(&slb, length: MemoryLayout<SIMD4<UInt32>>.size, index: 2)
                    enc.dispatchThreads(MTLSize(width: pw, height: previewHeight(pw), depth: 1), threadsPerThreadgroup: tgS)
                }
            }
            let slot = pv.slot, mask = pv.mask, player = pv.layer
            cb.addCompletedHandler { done in gPreview.gpuDone(slot: slot, mask: mask, layer: player, ok: done.status == .completed) }
        }
        // NDI copy (ndiout.swift): this frame into a free ring slot (the soft pass for native-soft, else a blit below);
        // the render loop publishes the slot once the GPU is done. No free slot = the sender is behind: no copy (counted).
        var ndiBlit: (slot: Int, buf: MTLBuffer, off: Int)? = nil
        if let ns = gNDIOut?.frameSlot() {
            if w != 1920 || h != 1080 {
                // another canvas: letterboxed into the 16:9 NDI frame (1920x1080 full, 960x540 previs / native-soft half)
                var nq = SIMD4<UInt32>(UInt32(w), UInt32(h), UInt32(ns.w), UInt32(ns.h))
                let tgN = MTLSize(width: pNdiFit.threadExecutionWidth, height: max(1, pNdiFit.maxTotalThreadsPerThreadgroup / pNdiFit.threadExecutionWidth), depth: 1)
                enc.setComputePipelineState(pNdiFit)
                enc.setBuffer(bufs[bi], offset: 0, index: 0)
                enc.setBuffer(ns.buf, offset: ns.offset, index: 1)
                enc.setBytes(&nq, length: MemoryLayout<SIMD4<UInt32>>.size, index: 2)
                enc.dispatchThreads(MTLSize(width: ns.w / 2, height: ns.h, depth: 1), threadsPerThreadgroup: tgN)
                encodedNDI = (ns.slot, ns.w, ns.h)
            } else if let sk = ns.soft {
                let pk = sk == .half ? pNdiHalf : pNdiBlur
                var nq = SIMD4<UInt32>(UInt32(w), UInt32(h), 0, 0)
                let tgN = MTLSize(width: pk.threadExecutionWidth, height: max(1, pk.maxTotalThreadsPerThreadgroup / pk.threadExecutionWidth), depth: 1)
                enc.setComputePipelineState(pk)
                enc.setBuffer(bufs[bi], offset: 0, index: 0)
                enc.setBuffer(ns.buf, offset: ns.offset, index: 1)
                enc.setBytes(&nq, length: MemoryLayout<SIMD4<UInt32>>.size, index: 2)
                enc.dispatchThreads(sk == .half ? MTLSize(width: w / 4, height: h / 2, depth: 1) : MTLSize(width: w / 2, height: h, depth: 1), threadsPerThreadgroup: tgN)
                encodedNDI = (ns.slot, ns.w, ns.h)
            } else { ndiBlit = (ns.slot, ns.buf, ns.offset) }
        }
        enc.endEncoding()
        if let nb = ndiBlit, let blit = gGPUStages.blit(cb, gst, stage: 3) {
            blit.copy(from: bufs[bi], sourceOffset: 0, to: nb.buf, destinationOffset: nb.off, size: w * 2 * h)
            blit.endEncoding()
            encodedNDI = (nb.slot, w, h)
        }
        let tr0 = nowTicks()
        gRecorder.encode(cb, uyvy: bi, at: t)            // recorder.swift: one blit into its staging ring while recording (else one lock)
        encodedRecMs = ticksToSec(nowTicks() &- tr0) * 1000
        if takeSnap, let blit = cb.makeBlitCommandEncoder() {
            snapLock.lock(); snapInFlight = true; snapLock.unlock()
            blit.copy(from: bufs[bi], sourceOffset: 0, to: snapBuf, destinationOffset: 0, size: w * 2 * h)
            blit.endEncoding()
            let tReq = nowTicks()
            cb.addCompletedHandler { [self] _ in self.snapQueue.async { self.writeSnapshot(requested: tReq) } }
        }
        gGPUStages.finish(cb, gst)
        let done = DispatchSemaphore(value: 0)              // run() waits on this with a bound, never on the GPU itself
        cb.addCompletedHandler { _ in done.signal() }
        encodedDone = done; encodedLoopTurn = copyLoop
        encodedCommit = nowTicks()
        cb.commit()
        return cb
    }

    private func run() {
        let period = secToTicks(Double(cfg.fpsD) / Double(cfg.fpsN))
        let t0 = gStartTicks
        var next = nowTicks() &+ period
        gStats.with { $0.running = true }
        var bi = 0
        simT = ticksToSec(next &- t0)
        deepStart = simT                                  // --content deep: the triangle starts at the first frame
        // autorelease pool per frame (2026-11-06): a Thread{} loop never drains its pool, so every autoreleased Metal /
        // AVFoundation object of encode() (compute encoders, command buffers, CV textures) piled up for the life of the player
        var pending = autoreleasepool { encode(index: bi, at: simT) }
        var pendingNormal = encodedNormal, pendingFixed = encodedFixed, pendingNDI = encodedNDI
        var pendingDone = encodedDone, pendingCommit = encodedCommit, pendingTurn = encodedLoopTurn
        var sent: Int64 = 0
        var lastSendStart: UInt64 = 0
        var lastEncodeMs = 0.0, lastLayersMs = 0.0, lastRecMs = 0.0
        var lastLateLog = 0.0, lateSinceLog = 0
        // Bounded GPU wait (2026-10-24): a tick waits at most holdLimit (2 periods) for its frame's command buffer. Past that
        // the last frame stays on the output ("held"), both heartbeats stay alive and the tick comes back next period to
        // wait again; no new frame is encoded meanwhile (the GPU is behind already). Before, waitUntilCompleted blocked the
        // thread for as long as the GPU took (978 ms at a loop turnaround on 2026-10-23) and the watchdog exited the player.
        let holdLimit = 2 * period
        var holdTicks = 0
        // loop turnaround measurable: max GPU / tick work over the 60 frames from the turnaround frame on (one log line)
        var turnLeft = 0, turnMaxGpu = 0.0, turnMaxTick = 0.0, turnHeld = 0
        olog(String(format: "render loop started: %dx%d UYVY %d/%d, 3 buffers, own pacing, frame budget %.1f ms, GPU wait bound %.1f ms (then the last frame is held); NDI via the frame ring (%@)",
                    w, h, cfg.fpsN, cfg.fpsD, gFrameBudgetMs, ticksToSec(holdLimit) * 1000, gNDIOut?.effectiveMode.rawValue ?? "off"))

        while !gFlags.stopping {
            mach_wait_until(next)
            let wake = nowTicks()
            gBeats.render = wake
            let lateMs = wake > next ? ticksToSec(wake &- next) * 1000 : 0
            let stall: Double = gControl.with { c in let s = c.stallRequest; c.stallRequest = 0; return s }
            if stall > 0 {
                olog(String(format: "DEBUG stall: render thread sleeping %.3f s", stall))
                usleep(useconds_t(stall * 1e6))
                gBeats.render = nowTicks()
            }
            var gpuMs = 0.0
            var gpuErr = false
            var startMs = 0.0, driverMs = 0.0              // commit -> GPU start; the driver's own scheduling time (LATE line)
            let tw0 = nowTicks()
            if let cb = pending {
                let finished: Bool
                if let d = pendingDone { finished = d.wait(timeout: .now() + ticksToSec(holdLimit)) == .success }
                else { cb.waitUntilCompleted(); finished = true }
                if !finished {
                    // the GPU is still on this frame: hold the last one, keep the heartbeats alive, come back next tick
                    holdTicks += 1
                    let now = nowTicks()
                    gBeats.render = now; gBeats.send = now
                    holdLimiter.log(String(format: "GPU busy: frame %lld not finished %.0f ms after commit (its encode %.1f ms): holding the last frame (tick %d)",
                                           sent + 1, ticksToSec(now &- pendingCommit) * 1000, lastEncodeMs, holdTicks))
                    if turnLeft > 0 { turnHeld += 1 }
                    next &+= period
                    var missed: UInt64 = 1                  // the held tick itself: no new frame went out
                    let n2 = nowTicks()
                    if n2 > next &+ period { let m = (n2 &- next) / period; missed += m; next &+= m * period }
                    gStats.with { r in
                        r.lateFrames += 1; r.wLate += 1; r.heldTicks += 1; r.wHeld += 1
                        r.droppedTotal += Int64(missed); r.wDropped += Int64(missed)
                    }
                    continue
                }
                gpuMs = (cb.gpuEndTime - cb.gpuStartTime) * 1000
                let commitSec = ticksToSec(pendingCommit)
                startMs = max(0, cb.gpuStartTime - commitSec) * 1000
                driverMs = max(0, cb.kernelEndTime - cb.kernelStartTime) * 1000
                if cb.status == .error {
                    gpuErr = true
                    errLimiter.log("Metal command buffer error: \(String(describing: cb.error))")
                }
            }
            let heldNow = holdTicks
            let heldMs = heldNow > 0 ? ticksToSec(nowTicks() &- pendingCommit) * 1000 : 0
            holdTicks = 0
            gBeats.render = nowTicks()
            if pending != nil && !gpuErr {
                gOutput.frameReady(bi)                    // output window (output.swift): lock + signal only
                if let nd = pendingNDI { gNDIOut?.publish(slot: nd.slot, w: nd.w, h: nd.h) }   // NDI ring: one atomic store + post
            }
            let waitMs = ticksToSec(nowTicks() &- tw0) * 1000
            if pendingNormal && !gpuErr, let line = gov.add(gpuMs, fixed: pendingFixed) { olog(line) }

            let t1 = nowTicks()
            gBeats.send = t1                              // "frame out" heartbeat (the watchdog's second beat)
            sent += 1
            let gapMs = lastSendStart != 0 ? ticksToSec(t1 &- lastSendStart) * 1000 : 0
            lastSendStart = t1
            // late frame (the budget): this frame's GPU time, or this tick's own work (wake-up delay + GPU wait + the
            // previous encode) over gFrameBudgetMs. Counted always, logged at most once a second.
            let tickWork = lateMs + waitMs + lastEncodeMs
            let late = (pending != nil && gpuMs > gFrameBudgetMs) || tickWork > gFrameBudgetMs || heldNow > 0
            var lateLine: String? = nil
            if late {
                lateSinceLog += 1
                let tn = ticksToSec(t1 &- t0)
                if tn - lastLateLog >= 1 {
                    lateLine = String(format: "LATE frame %lld over the %.1f ms budget: GPU %.1f ms (started %.1f ms after commit, driver %.1f ms), tick work %.1f ms (woke %.1f ms late, GPU wait %.1f ms, encode %.1f ms: layers %.1f, recorder %.2f)%@%@",
                                      sent, gFrameBudgetMs, gpuMs, startMs, driverMs, tickWork, lateMs, waitMs, lastEncodeMs, lastLayersMs, lastRecMs,
                                      heldNow > 0 ? String(format: " (held %d tick(s): %.0f ms from commit to finish)", heldNow, heldMs) : "",
                                      lateSinceLog > 1 ? " (\(lateSinceLog) late frames since the last line)" : "")
                    lastLateLog = tn; lateSinceLog = 0
                }
            }
            // loop turnaround measurable (2026-10-24): the first 60 frames from the dive-and-return / minibrot jump
            if pendingTurn { turnLeft = 60; turnMaxGpu = 0; turnMaxTick = 0; turnHeld = 0 }
            if turnLeft > 0 {
                turnMaxGpu = max(turnMaxGpu, gpuMs); turnMaxTick = max(turnMaxTick, tickWork)
                turnLeft -= 1
                if turnLeft == 0 {
                    olog(String(format: "loop turnaround: max GPU %.1f ms, max tick work %.1f ms, %d held tick(s) over its first 60 frames (budget %.1f ms)",
                                turnMaxGpu, turnMaxTick, turnHeld, gFrameBudgetMs))
                }
            }

            next &+= period
            var missed: UInt64 = 0
            let n = nowTicks()
            if n > next &+ period {                      // more than a full period late: skip ticks, count as dropped
                missed = (n &- next) / period
                next &+= missed * period
            }
            let frameNo = sent
            gStats.with { r in
                r.framesSent = frameNo
                r.wFrames += 1
                r.droppedTotal += Int64(missed); r.wDropped += Int64(missed)
                r.maxGapAll = max(r.maxGapAll, gapMs); r.wMaxGap = max(r.wMaxGap, gapMs)
                r.wMaxGpu = max(r.wMaxGpu, gpuMs); r.gpuMs = gpuMs
                if gpuErr { r.gpuErrors += 1 }
                if late { r.lateFrames += 1; r.wLate += 1 }
                if let l = lateLine { r.pendingAlarms.append(l) }
                if gapMs > 100 {
                    r.alarmsGap += 1
                    if gapMs > 200 { r.gapOver200 += 1 }
                    r.pendingAlarms.append(String(format: "ALARM%@ frame gap %.1f ms (frame %lld; woke %.1f ms late, GPU wait %.1f ms, previous encode %.1f ms)",
                                                  gapMs > 200 ? " GATE (frame gap > 200 ms)" : "", gapMs, frameNo, lateMs, waitMs, lastEncodeMs))
                }
                if missed > 0 && missed >= 3 {
                    r.pendingAlarms.append("dropped \(missed) ticks (frame \(frameNo))")
                }
            }

            bi = (bi + 1) % 3
            let te0 = nowTicks()
            pending = autoreleasepool { encode(index: bi, at: ticksToSec(next &- t0)) }   // see the first encode
            pendingNormal = encodedNormal; pendingFixed = encodedFixed; pendingNDI = encodedNDI
            pendingDone = encodedDone; pendingCommit = encodedCommit; pendingTurn = encodedLoopTurn
            lastEncodeMs = ticksToSec(nowTicks() &- te0) * 1000
            lastLayersMs = encodedLayersMs; lastRecMs = encodedRecMs
        }

        if let cb = pending { cb.waitUntilCompleted() }
        olog("render loop stopped after \(sent) frames")
        gStats.with { $0.running = false }
        renderDone.signal()
    }

    // MARK: snapshot

    private func writeSnapshot(requested: UInt64) {
        defer { snapLock.lock(); snapInFlight = false; snapLock.unlock() }
        let t0 = nowTicks()
        let src = snapBuf.contents().assumingMemoryBound(to: UInt8.self)
        let n = w * h
        var rgb = [UInt8](repeating: 0, count: n * 3)
        var ySum = 0
        @inline(__always) func c8(_ v: Double) -> UInt8 { UInt8(max(0, min(255, v.rounded()))) }
        rgb.withUnsafeMutableBufferPointer { out in
            for y in 0..<h {
                let row = src + y * w * 2
                for x2 in 0..<(w / 2) {
                    let q = row + x2 * 4
                    let u = Double(q[0]) - 128, y0 = Int(q[1]), v = Double(q[2]) - 128, y1 = Int(q[3])
                    ySum += y0 + y1
                    let rv = 1.792741 * v, gv = -0.213249 * u - 0.532909 * v, bv = 2.112402 * u   // BT.709 video range
                    let o = (y * w + x2 * 2) * 3
                    let ya = 1.164383 * (Double(y0) - 16), yb = 1.164383 * (Double(y1) - 16)
                    out[o] = c8(ya + rv); out[o + 1] = c8(ya + gv); out[o + 2] = c8(ya + bv)
                    out[o + 3] = c8(yb + rv); out[o + 4] = c8(yb + gv); out[o + 5] = c8(yb + bv)
                }
            }
        }
        let meanY = Double(ySum) / Double(n)
        let dir = cfg.logDir
        let final = (dir as NSString).appendingPathComponent("snapshot.png")
        let tmp = (dir as NSString).appendingPathComponent(".snapshot.tmp.png")
        var ok = false
        if let provider = CGDataProvider(data: Data(rgb) as CFData),
           let img = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 24, bytesPerRow: w * 3,
                             space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.none.rawValue),
                             provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent),
           let dst = CGImageDestinationCreateWithURL(URL(fileURLWithPath: tmp) as CFURL, "public.png" as CFString, 1, nil) {
            CGImageDestinationAddImage(dst, img, nil)
            ok = CGImageDestinationFinalize(dst) && rename(tmp, final) == 0
        }
        let ms = ticksToSec(nowTicks() &- t0) * 1000
        let since = ticksToSec(nowTicks() &- requested) * 1000
        if ok {
            gSnapshot.with { s in s.count += 1; s.lastUnix = Date().timeIntervalSince1970; s.meanLuma = meanY; s.path = final; s.ms = ms }
            olog(String(format: "snapshot written %@ (%dx%d, mean luma Y=%.2f, convert+PNG %.0f ms, %.0f ms after the frame was queued)", final, w, h, meanY, ms, since))
        } else {
            olog("snapshot FAILED writing \(final)")
        }
    }
}
