import Foundation
import AVFoundation
import CoreVideo
import CoreMedia
import Metal

// M2a: clip layers (PLAN 7.3/7.4/8). 4 clip layers over the fractal layer, Resolume-style:
//  - library: <media>/library.json (tools/make_library.swift), banks x slots of clip records;
//  - decode: AVQueuePlayer (+ AVPlayerLooper for loop: gapless, the queue preloads the next replica) with one
//    AVPlayerItemVideoOutput per item, BGRA through a CVMetalTextureCache (hardware decode, IOSurface, no copy);
//  - clock: the render loop asks each output for the item time at the host time the frame will be SHOWN
//    (itemTime(forHostTime:)) and takes a pixel buffer only if a new one is ready; otherwise the last one stays
//    (never waits on decode). Audio muted;
//  - transitions: a clip change on a layer opens a second decoder (B); once B has its first frame (preroll) the
//    layer crossfades A -> B over the layer's transition time, then A is released. Clear fades out the same way;
//  - scaling: cover (fill 1920x1080, keep aspect, crop the overflow). Portrait clips are covered too (cropped
//    top/bottom), the user's M2a choice; PLAN 8 item 6 had fit as the default;
//  - compositing (shaders.swift `composite`): the fractal x its opacity over black, then layers 1..4 bottom-up,
//    W3C blend formulas in display (gamma) space into a 16-bit float canvas; master dimmer / blackout / freeze after.
// All AVFoundation object creation and teardown runs on one serial queue ("clips"); the render thread only polls.

// MARK: - blend modes, playmodes

enum BlendMode: Int, CaseIterable {
    case alpha = 0, add, screen, multiply, difference, lighten, darken, overlay
    var name: String { ["Alpha", "Add", "Screen", "Multiply", "Difference", "Lighten", "Darken", "Overlay"][rawValue] }
    /// "screen" (any case) or 1..8 in this order (1 = Alpha).
    static func parse(_ a: OSCArg?) -> BlendMode? {
        guard let a = a else { return nil }
        if case .s(let s) = a { return allCases.first { $0.name.lowercased() == s.lowercased().trimmingCharacters(in: .whitespaces) } }
        if let v = a.number, v.isFinite, abs(v) < 1e6 { return BlendMode(rawValue: Int(v.rounded()) - 1) }
        return nil
    }
}

enum PlayMode: String {
    case loop, once                    // once = once + hold (the last frame stays)
    static func parse(_ a: OSCArg?) -> PlayMode? {
        guard let a = a else { return nil }
        if case .s(let s) = a {
            switch s.lowercased() { case "loop": return .loop; case "once", "once-hold", "oncehold", "hold", "once+hold": return .once; default: return nil }
        }
        if let v = a.number, v.isFinite { return v.rounded() == 0 ? .loop : (v.rounded() == 1 ? .once : nil) }
        return nil
    }
}

let layerCount = 4
/// BG as a full layer (2026-10-23): the base layer L0 is composite layer index 4 (after L1-L4 in the arrays, drawn first,
/// over black). layerCount stays 4 for everything that is only L1-L4 (DMX Layer fixtures, column go, the GUI's L rows).
let compCount = layerCount + 1
let bgIndex = layerCount
/// OSC / GUI layer number (0 = BG) -> index into Control.layers, and back.
func layerIndex(_ n: Int) -> Int { n == 0 ? bgIndex : n - 1 }
func layerNum(_ li: Int) -> Int { li == bgIndex ? 0 : li + 1 }
func layerLabel(_ li: Int) -> String { li == bgIndex ? "BG" : "layer \(li + 1)" }

/// Control side of one layer (OSC writes, render reads). playSeq changes on every play/clear command.
struct LayerCtl {
    var bank = 1
    var slot = 0                        // 0 = empty (cleared)
    var playSeq = 0
    var opacity = 1.0
    var blend: BlendMode = .alpha
    var speed = 1.0                     // 0..4, forward only
    var transition = 0.0                // seconds, 0..10
    var playmode: PlayMode = .loop
    var autopilot: Autopilot = .off     // playback.swift: change clips by itself within the current bank
    var apEvery = 0.0                   // seconds between changes; 0 = every apBeats beats
    var apBeats = 4.0
    var fx = LayerFX()                  // fx.swift: transform, 2 FX slots, beat mod
    var source: LayerSource = .clip     // gen.swift: what this layer shows (the clip decoders keep running under fractal/gen)
    var gen = GenParams()               // gen.swift: the generator, when source == .gen
    var genLook = ""                    // the gen look applied last (/gen/look s NAME, sent after its params); "" after a gen param is changed by hand
    var overlay = OverlayParams()       // gen.swift: a generator drawn over this layer's own source (any source)
    var ndiName = ""                    // ndiin.swift: the NDI source (full name or a part, e.g. "OBSBOT") when source == .ndi
    var ndiBandwidth: NDIBandwidth = .full   // full (highest) | proxy (lowest: 640x360-ish, less CPU)
}

enum Autopilot: String { case off, order, shuffle }

/// /oats/layers/{n}/seek f (0..1 of the duration) and .../seek/sec f: one pending request per layer (osc thread ->
/// render thread). Kept out of LayerCtl so scenes and state restores never replay a seek.
final class SeekRequests {
    private let lock = NSLock()
    private var req = [Double?](repeating: nil, count: compCount)   // >= 0 seconds, < 0 = -(fraction + 1)
    func set(_ li: Int, seconds: Double) { lock.lock(); req[li] = max(0, seconds); lock.unlock() }
    func set(_ li: Int, fraction: Double) { lock.lock(); req[li] = -(min(1, max(0, fraction)) + 1); lock.unlock() }
    func take(_ li: Int) -> Double? { lock.lock(); defer { lock.unlock() }; let r = req[li]; req[li] = nil; return r }
}
let gSeek = SeekRequests()

// MARK: - library

struct ClipRecord {
    let bank: Int, slot: Int
    let name: String
    let path: String
    let duration: Double, fps: Double
    let width: Int, height: Int
}

final class Library {
    let dir: String
    private(set) var banks: [(bank: Int, name: String, clips: [ClipRecord])] = []
    private(set) var error = ""

    init(dir: String, quiet: Bool = false) {
        self.dir = dir
        if dir.isEmpty { error = "not loaded"; return }           // the placeholder before main loads the real one
        let p = gLibraryFileOverride.isEmpty ? (dir as NSString).appendingPathComponent("library.json") : gLibraryFileOverride
        guard let d = FileManager.default.contents(atPath: p),
              let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
              let bs = j["banks"] as? [[String: Any]] else {
            error = "no readable \(p)"
            if !quiet { olog("library: WARNING: \(error): clip layers have nothing to play (build it with tools/make_library.swift)") }
            return
        }
        // A clip path must stay inside the media folder (a show pack's library.json is not trusted): relative, no
        // "..", and inside `dir` once symlinks are resolved. Others are skipped (logged).
        let root = ((dir as NSString).resolvingSymlinksInPath as NSString).standardizingPath
        var refused = 0
        for b in bs {
            guard let n = b["bank"] as? Int, let ss = b["slots"] as? [[String: Any]] else { continue }
            var clips: [ClipRecord] = []
            for s in ss {
                guard let sl = s["slot"] as? Int, let f = s["file"] as? String else { continue }
                let full = (((dir as NSString).appendingPathComponent(f) as NSString).resolvingSymlinksInPath as NSString).standardizingPath
                if f.hasPrefix("/") || f.hasPrefix("~") || f.split(separator: "/").contains("..") || !(full.hasPrefix(root + "/")) {
                    refused += 1
                    if !quiet && refused <= 5 { olog("library: WARNING: bank \(n) slot \(sl): clip path '\(f.prefix(120))' is outside the media folder: skipped") }
                    continue
                }
                clips.append(ClipRecord(bank: n, slot: sl, name: s["name"] as? String ?? f,
                                        path: (dir as NSString).appendingPathComponent(f),
                                        duration: s["duration_s"] as? Double ?? 0, fps: s["fps"] as? Double ?? 0,
                                        width: s["width"] as? Int ?? 0, height: s["height"] as? Int ?? 0))
            }
            banks.append((n, b["name"] as? String ?? "BANK \(n)", clips.sorted { $0.slot < $1.slot }))
        }
        if !quiet { olog("library: \(p): " + banks.map { "bank \($0.bank) \($0.name) \($0.clips.count) clips" }.joined(separator: ", ")) }
    }

    func clip(bank: Int, slot: Int) -> ClipRecord? { banks.first { $0.bank == bank }?.clips.first { $0.slot == slot } }
    func slots(bank: Int) -> Int { banks.first { $0.bank == bank }?.clips.count ?? 0 }
    /// The slot numbers that hold a clip in this bank, ascending (slots can have gaps after a GUI move).
    func slotNumbers(bank: Int) -> [Int] { banks.first { $0.bank == bank }?.clips.map { $0.slot } ?? [] }

    var summary: [String: Any] {
        ["dir": dir, "error": error, "clips": banks.reduce(0) { $0 + $1.clips.count },
         "banks": banks.map { ["bank": $0.bank, "name": $0.name, "slots": $0.clips.count] }]
    }
}

private let gLibLock = NSLock()
private var gLibStore = Library(dir: "")
/// The clip library (replaced in main before the engine starts, and by /oats/library/reload). Readers get the whole
/// object, so a reload never shows a half-built library.
var gLibrary: Library {
    get { gLibLock.lock(); defer { gLibLock.unlock() }; return gLibStore }
    set { gLibLock.lock(); gLibStore = newValue; gLibLock.unlock() }
}

// MARK: - decoder

// .workItem: an autorelease pool per block. Without it the AVFoundation objects autoreleased while making and tearing
// down players (FigPlayer, items, telemetry) were never drained: ~0.3 MB more footprint per clip change (2026-11-06).
let clipQueue = DispatchQueue(label: "clips", qos: .userInitiated, autoreleaseFrequency: .workItem)

/// One clip playing: an AVQueuePlayer (+ looper) and one video output per player item. Created and released on
/// clipQueue; pull() runs on the render thread.
final class ClipDecoder {
    let clip: ClipRecord
    let mode: PlayMode
    let player: AVQueuePlayer
    private var looper: AVPlayerLooper?
    // One output per player item. Made and attached on clipQueue only: AVPlayerLooper makes its replica items after
    // init, and attaching them from pull() (AVPlayerItem.add on the render thread) cost 6-22 ms per clip change and could
    // block longer while the item was being prepared (2026-11-06 watchdog restarts with a 2-beat autopilot). The render
    // thread only looks outputs up, under outLock.
    private var outputs: [ObjectIdentifier: AVPlayerItemVideoOutput] = [:]
    private var attaching = Set<ObjectIdentifier>()                          // render thread: attach asked of clipQueue
    private let outLock = NSLock()
    private let cache: CVMetalTextureCache
    private(set) var tex: CVMetalTexture? = nil                               // last frame (kept when none is new)
    private(set) var frames = 0
    private(set) var position = 0.0
    private(set) var ended = false
    private(set) var speed: Double
    let created = nowTicks()
    var firstFrameMs = -1.0
    // decoded fps over ~1 s windows
    private var winFrames = 0, winStart = nowTicks()
    private(set) var fpsDecoded = 0.0

    private static let outSettings: [String: Any] = [
        kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
        kCVPixelBufferMetalCompatibilityKey as String: true,
        kCVPixelBufferIOSurfacePropertiesKey as String: [String: Any](),
    ]

    init(clip: ClipRecord, mode: PlayMode, speed: Double, cache: CVMetalTextureCache) {
        self.clip = clip; self.mode = mode; self.cache = cache; self.speed = speed
        let asset = AVURLAsset(url: URL(fileURLWithPath: clip.path), options: [AVURLAssetPreferPreciseDurationAndTimingKey: false])
        let item = AVPlayerItem(asset: asset)
        player = AVQueuePlayer()
        player.isMuted = true
        player.volume = 0
        player.automaticallyWaitsToMinimizeStalling = false
        player.preventsDisplaySleepDuringVideoPlayback = false
        player.allowsExternalPlayback = false
        if mode == .loop {
            let lp = AVPlayerLooper(player: player, templateItem: item)
            looper = lp
            for it in lp.loopingPlayerItems { attach(it) }
        } else {
            player.actionAtItemEnd = .pause
            attach(item)
            player.insert(item, after: nil)
        }
        player.rate = Float(speed)
    }

    /// clipQueue only (init, or asked by pull for a looper replica made later).
    private func attach(_ it: AVPlayerItem) {
        let key = ObjectIdentifier(it)
        outLock.lock(); let have = outputs[key] != nil; outLock.unlock()
        if have { return }
        let o = AVPlayerItemVideoOutput(pixelBufferAttributes: ClipDecoder.outSettings)
        o.suppressesPlayerRendering = true
        it.add(o)
        outLock.lock(); outputs[key] = o; outLock.unlock()
    }

    /// Render thread: take the frame for host time `host` (mach seconds of the tick it will be shown at), if new.
    func pull(host: CFTimeInterval) {
        guard let item = player.currentItem else { return }
        let key = ObjectIdentifier(item)
        outLock.lock(); let o = outputs[key]; outLock.unlock()
        guard let out = o else {                         // a looper replica made after init: attach it on clipQueue
            if attaching.insert(key).inserted { clipQueue.async { [self, item] in self.attach(item) } }
            return                                       // the last frame stays meanwhile
        }
        let t = out.itemTime(forHostTime: host)
        if t.isValid { position = max(0, t.seconds) }
        if mode == .once, clip.duration > 0, position >= clip.duration - 1.5 / max(1, clip.fps) { ended = true }
        if out.hasNewPixelBuffer(forItemTime: t), let pb = out.copyPixelBuffer(forItemTime: t, itemTimeForDisplay: nil) {
            var cv: CVMetalTexture? = nil
            let w = CVPixelBufferGetWidth(pb), h = CVPixelBufferGetHeight(pb)
            if CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, cache, pb, nil, .bgra8Unorm, w, h, 0, &cv) == kCVReturnSuccess, cv != nil {
                tex = cv
                frames += 1; winFrames += 1
                if firstFrameMs < 0 { firstFrameMs = ticksToSec(nowTicks() &- created) * 1000 }
            }
        }
        let now = nowTicks()
        let ws = ticksToSec(now &- winStart)
        if ws >= 1 { fpsDecoded = Double(winFrames) / ws; winFrames = 0; winStart = now }
    }

    var texture: MTLTexture? { tex.flatMap { CVMetalTextureGetTexture($0) } }

    func setSpeed(_ s: Double) {
        guard s != speed else { return }
        speed = s
        clipQueue.async { [player] in player.rate = Float(s) }
    }

    func disableLooping() { clipQueue.async { [looper] in looper?.disableLooping() } }

    /// Render thread: jump to `sec` (0..duration). A small tolerance keeps it fast (nearest keyframe-ish, <= 0.1 s off);
    /// the next pulled frame comes from there. A finished "once" clip plays again from the new point.
    func seek(_ sec: Double) {
        let d = clip.duration > 0 ? clip.duration : sec
        let s = min(max(0, sec), max(0, d - 1.0 / max(1, clip.fps)))
        position = s; ended = false
        let tol = CMTime(seconds: 0.1, preferredTimescale: 600)
        clipQueue.async { [player, speed] in
            player.seek(to: CMTime(seconds: s, preferredTimescale: 600), toleranceBefore: tol, toleranceAfter: tol)
            if player.rate == 0 && speed > 0 { player.rate = Float(speed) }
        }
    }

    /// Stops playback on clipQueue; the last texture stays valid while command buffers still hold it. The block holds
    /// the decoder, so its whole teardown (outputs off their items, player, looper and items: AVFoundation deallocs)
    /// runs on clipQueue, never on the render thread that drops it. Before 2026-11-06 the decoder died on the render
    /// thread and its players / loopers outlived it: the footprint grew ~1.2 MB per clip change (now ~0.3).
    func release() {
        clipQueue.async { [self] in
            looper?.disableLooping()
            player.pause()
            outLock.lock(); let outs = outputs; outputs = [:]; outLock.unlock()
            for it in player.items() { if let o = outs[ObjectIdentifier(it)] { it.remove(o) } }
            player.removeAllItems()
            looper = nil
        }
    }
}

// MARK: - per-layer runtime (render thread)

struct LayerInfo {
    var n = 0, bank = 1, slot = 0
    var name = ""
    var opacity = 1.0
    var blend = "Alpha"
    var playing = false
    var position = 0.0
    var duration = 0.0
    var fpsDecoded = 0.0
    var clipFps = 0.0
    var transition = 0.0
    var fade = -1.0                 // crossfade progress 0..1, -1 = none
    var speed = 1.0
    var playmode = "loop"
    var decoders = 0
    var prerollMs = -1.0            // first frame of the newest clip, ms after its trigger
    var fadesDone = 0
}

final class LayerRT {
    let n: Int
    var a: ClipDecoder? = nil        // showing
    var b: ClipDecoder? = nil        // incoming (preroll until its first frame, then the crossfade)
    var fadeStart: Double? = nil
    var fadeDur = 0.0
    var fadeOut: Double? = nil       // clear with a transition: start time of the fade to empty
    var fadeOutDur = 0.0
    var seenSeq = 0
    var waitingSeq = -1              // a decoder for this seq is being made on clipQueue
    var lastPrerollMs = -1.0
    var fadesDone = 0
    var lastMode: PlayMode = .loop
    var k = 0.0                      // this frame's mix A -> B
    var alphaA = 0.0, alphaB = 0.0
    init(n: Int) { self.n = n }
}

final class LayerEngine {
    let dev: MTLDevice
    let cache: CVMetalTextureCache
    var rts: [LayerRT] = (0..<compCount).map { LayerRT(n: layerNum($0)) }   // index 4 = BG (n 0)
    private let lock = NSLock()
    private var made: [Int: (seq: Int, dec: ClipDecoder?)] = [:]    // clipQueue -> render thread
    private var flushCount = 0

    init?(dev: MTLDevice) {
        self.dev = dev
        var c: CVMetalTextureCache? = nil
        guard CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, dev, nil, &c) == kCVReturnSuccess, let cc = c else { return nil }
        cache = cc
    }

    private func request(_ li: Int, seq: Int, clip: ClipRecord, mode: PlayMode, speed: Double) {
        let cache = self.cache
        clipQueue.async { [weak self] in
            let d = ClipDecoder(clip: clip, mode: mode, speed: speed, cache: cache)
            guard let self = self else { return }
            self.lock.lock()
            if let old = self.made[li]?.dec { old.release() }
            self.made[li] = (seq, d)
            self.lock.unlock()
        }
    }

    /// Render thread, once per frame: apply control changes, pull frames, advance fades.
    /// t = render time (s) of the tick the frame is shown at, host = the same in mach seconds. frozen: no new frames.
    func step(_ ctl: [LayerCtl], t: Double, host: CFTimeInterval, frozen: Bool) -> [LayerInfo] {
        var out: [LayerInfo] = []
        for (i, rt) in rts.enumerated() {
            let c = ctl[i]
            if !frozen && c.playSeq != rt.seenSeq {
                rt.seenSeq = c.playSeq
                if c.slot == 0 {                                   // clear
                    rt.b?.release(); rt.b = nil; rt.fadeStart = nil; rt.waitingSeq = -1
                    if rt.a != nil && c.transition > 0 { rt.fadeOut = t; rt.fadeOutDur = c.transition }
                    else { rt.a?.release(); rt.a = nil; rt.fadeOut = nil }
                    olog("\(rt.n == 0 ? "BG" : "layer \(rt.n)"): clear" + (rt.fadeOut != nil ? String(format: " (fade out %.2f s)", c.transition) : ""))
                } else if let clip = gLibrary.clip(bank: c.bank, slot: c.slot) {
                    rt.waitingSeq = c.playSeq
                    rt.lastMode = c.playmode
                    request(i, seq: c.playSeq, clip: clip, mode: c.playmode, speed: c.speed)
                    olog("\(rt.n == 0 ? "BG" : "layer \(rt.n)"): play bank \(c.bank) slot \(c.slot) '\(clip.name)' (\(c.playmode.rawValue), speed \(c.speed), transition \(c.transition) s): preroll")
                } else {
                    olog("\(rt.n == 0 ? "BG" : "layer \(rt.n)"): bank \(c.bank) slot \(c.slot): no such clip in the library (ignored)")
                }
            }
            // a decoder made on clipQueue
            lock.lock(); let m = made[i]; if m != nil { made[i] = nil }; lock.unlock()
            if let m = m {
                if m.seq == rt.waitingSeq, let d = m.dec {
                    if let old = rt.b {                            // a change during preroll/fade: drop the incoming one,
                        if rt.fadeStart != nil && rt.k >= 0.5 { rt.a?.release(); rt.a = old } else { old.release() }   // keep the more visible
                    }
                    if rt.fadeOut != nil { rt.a?.release(); rt.a = nil; rt.fadeOut = nil }   // was fading out: fade in from empty
                    rt.b = d; rt.fadeStart = nil; rt.waitingSeq = -1
                } else { m.dec?.release() }
            }
            if let r = gSeek.take(i), let d = rt.b ?? rt.a {       // seek the clip that is showing (the incoming one while fading)
                let sec = r >= 0 ? r : (-r - 1) * d.clip.duration
                d.seek(sec)
                olog(String(format: "%@: seek '%@' to %.2f s of %.2f s", rt.n == 0 ? "BG" : "layer \(rt.n)", d.clip.name, sec, d.clip.duration))
            }
            if !frozen {
                rt.a?.pull(host: host)
                rt.b?.pull(host: host)
                rt.a?.setSpeed(c.speed); rt.b?.setSpeed(c.speed)
                if c.playmode != rt.lastMode {                     // playmode change on a running clip
                    rt.lastMode = c.playmode
                    if c.playmode == .once { rt.a?.disableLooping() }
                    else if let a = rt.a, a.mode == .once, c.slot > 0 {   // once -> loop: restart it looping (cut)
                        rt.waitingSeq = c.playSeq
                        request(i, seq: c.playSeq, clip: a.clip, mode: .loop, speed: c.speed)
                    }
                }
            }
            // fades
            if let b = rt.b, b.tex != nil {
                if rt.fadeStart == nil {
                    rt.fadeStart = t; rt.fadeDur = rt.a == nil && c.transition <= 0 ? 0 : c.transition
                    rt.lastPrerollMs = b.firstFrameMs
                    olog(String(format: "%@: '%@' first frame after %.0f ms; %@", rt.n == 0 ? "BG" : "layer \(rt.n)", b.clip.name, b.firstFrameMs,
                                rt.fadeDur > 0 ? String(format: "crossfade %.2f s", rt.fadeDur) : "cut"))
                }
                let k = rt.fadeDur > 0 ? min(1, max(0, (t - rt.fadeStart!) / rt.fadeDur)) : 1
                if k >= 1 {
                    rt.a?.release(); rt.a = b; rt.b = nil; rt.fadeStart = nil
                    if rt.fadeDur > 0 { rt.fadesDone += 1; olog("\(rt.n == 0 ? "BG" : "layer \(rt.n)"): crossfade to '\(b.clip.name)' done") }
                }
            }
            var aA = rt.a?.tex != nil ? 1.0 : 0.0, aB = 0.0, k = 0.0
            if let fs = rt.fadeStart, rt.b != nil {
                k = rt.fadeDur > 0 ? min(1, max(0, (t - fs) / rt.fadeDur)) : 1
                aB = 1
            }
            if let fo = rt.fadeOut {
                let ko = rt.fadeOutDur > 0 ? min(1, (t - fo) / rt.fadeOutDur) : 1
                aA *= 1 - ko
                if ko >= 1 { rt.a?.release(); rt.a = nil; rt.fadeOut = nil; aA = 0 }
            }
            rt.k = k; rt.alphaA = aA; rt.alphaB = aB
            let shown = (rt.b != nil && k >= 0.5) ? rt.b : (rt.a ?? rt.b)
            var li = LayerInfo()
            li.n = rt.n; li.bank = c.bank; li.slot = c.slot; li.opacity = c.opacity; li.blend = c.blend.name
            li.transition = c.transition; li.speed = c.speed; li.playmode = c.playmode.rawValue
            li.fade = rt.fadeStart != nil && rt.b != nil ? k : (rt.fadeOut != nil ? 1 - aA : -1)
            li.decoders = (rt.a != nil ? 1 : 0) + (rt.b != nil ? 1 : 0)
            li.prerollMs = rt.lastPrerollMs; li.fadesDone = rt.fadesDone
            if let s = shown {
                li.name = s.clip.name; li.position = s.position; li.duration = s.clip.duration
                li.fpsDecoded = s.fpsDecoded; li.clipFps = s.clip.fps
                li.playing = s.tex != nil && !s.ended && s.speed > 0 && !frozen
            }
            out.append(li)
        }
        flushCount += 1
        if flushCount % 600 == 0 { CVMetalTextureCacheFlush(cache, 0) }
        return out
    }

    /// The textures and mix values for the composite kernel. keep: CVMetalTextures the command buffer must hold.
    /// src[i]: a non-clip source for layer i (kind 1 fractal, 2 generator; tex nil = shows nothing), nil = the clip.
    /// Whether clip layer i draws anything this frame (a decoder texture with alpha after the A -> B mix), exactly the
    /// composite kernel's `a > 0` test: a layer without it skips its FX variant bits and Trails history (engine.swift).
    func hasContent(_ i: Int) -> Bool {
        guard i >= 0 && i < rts.count else { return false }
        let rt = rts[i]
        return (rt.a?.texture != nil && rt.alphaA * (1 - rt.k) > 0) || (rt.b?.texture != nil && rt.alphaB * rt.k > 0)
    }

    func bindings(_ ctl: [LayerCtl], dummy: MTLTexture, src: [(kind: Int, tex: MTLTexture?)?]) -> (texs: [MTLTexture], params: [SIMD4<Float>], keep: [AnyObject]) {
        var texs: [MTLTexture] = [], ps: [SIMD4<Float>] = [], keep: [AnyObject] = []
        for (i, rt) in rts.enumerated() {
            if i < src.count, let o = src[i] {
                texs.append(o.tex ?? dummy); texs.append(dummy)
                ps.append(SIMD4<Float>(Float(min(1, max(0, ctl[i].opacity))), 0, o.tex != nil ? 1 : 0, 0))
                ps.append(SIMD4<Float>(Float(ctl[i].blend.rawValue), Float(o.kind), 0, 0))
                continue
            }
            let ta = rt.a?.texture, tb = rt.b?.texture
            if let x = rt.a?.tex { keep.append(x) }
            if let x = rt.b?.tex { keep.append(x) }
            texs.append(ta ?? dummy); texs.append(tb ?? dummy)
            let aA = ta != nil ? Float(rt.alphaA) : 0, aB = tb != nil ? Float(rt.alphaB) : 0
            ps.append(SIMD4<Float>(Float(min(1, max(0, ctl[i].opacity))), Float(rt.k), aA, aB))
            ps.append(SIMD4<Float>(Float(ctl[i].blend.rawValue), 0, 0, 0))
        }
        return (texs, ps, keep)
    }
}
