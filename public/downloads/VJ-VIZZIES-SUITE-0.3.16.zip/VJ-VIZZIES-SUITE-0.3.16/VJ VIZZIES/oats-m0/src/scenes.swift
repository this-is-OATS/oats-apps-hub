import Foundation

// Scenes (player-side looks, 2026-10-22). A scene is a full snapshot of the visual state: per layer (source, clip bank/slot
// + playmode/speed/transition, generator, transform/FX/beat mod, blend, opacity, autopilot), the fractal (target / centre,
// depth, zoom speed, formula modifiers, palette / cycle / offset, rotation / spin, loop, which layer, opacity), master FX,
// colour link and effect speed. 8 banks x 16 slots, stored in <m0>/scenes.json; a 160x90 JPEG thumbnail of the output
// (the preview server's /preview.jpg) in <media>/.scenes/<bank>-<slot>.jpg.
// Recall with a fade: numeric values crossfade (smoothstep) over the fade time on the "scenes" thread (50 Hz); discrete
// values (clip, source, generator type, formula, FX type, blend, ...) switch at the fade start; a layer whose clip changes
// crossfades through the layer's own clip transition (set to the fade time for that change, then back). 0 = cut.
// Flags per scene: keep depth (default on: a recall never jumps the zoom) and per-layer include.
// Numbering: scene n = (bank - 1) * 16 + slot, 1..128 (the same as DMX Master 16 ch 9).

let sceneBanks = 8, sceneSlots = 16, sceneMax = sceneBanks * sceneSlots

func m0Dir() -> String {
    URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath().deletingLastPathComponent()
        .deletingLastPathComponent().standardizedFileURL.path
}
func sceneLabel(_ n: Int) -> String { n < 1 ? "–" : "\((n - 1) / sceneSlots + 1).\((n - 1) % sceneSlots + 1)" }
@inline(__always) private func clk() -> Double { ticksToSec(nowTicks() &- gStartTicks) }

private func dnum(_ d: [String: Any], _ k: String) -> Double? { (d[k] as? NSNumber).map { $0.doubleValue }.flatMap { $0.isFinite ? $0 : nil } }
private func dint(_ d: [String: Any], _ k: String) -> Int? { (d[k] as? NSNumber)?.intValue }
private func dbool(_ d: [String: Any], _ k: String) -> Bool? { (d[k] as? NSNumber)?.boolValue }
private func dstr(_ d: [String: Any], _ k: String) -> String? { d[k] as? String }
private func dsub(_ d: [String: Any], _ k: String) -> [String: Any] { d[k] as? [String: Any] ?? [:] }
private func d3(_ d: [String: Any], _ k: String) -> SIMD3<Double>? {
    guard let a = d[k] as? [Any], a.count == 3, let x = (a[0] as? NSNumber)?.doubleValue, let y = (a[1] as? NSNumber)?.doubleValue,
          let z = (a[2] as? NSNumber)?.doubleValue else { return nil }
    return SIMD3<Double>(min(1, max(0, x)), min(1, max(0, y)), min(1, max(0, z)))
}
private func a3(_ v: SIMD3<Double>) -> [Double] { [v.x, v.y, v.z] }

// MARK: - capture / apply

/// The current look as a JSON-able dict.
func sceneCapture() -> [String: Any] {
    let c = gControl.snapshot
    let fi = gStats.with { $0.fractal }
    let layers: [[String: Any]] = c.layers.map { l in
        let g = l.gen, f = l.fx
        return ["source": l.source.rawValue, "bank": l.bank, "slot": l.slot, "playmode": l.playmode.rawValue, "speed": l.speed,
                "transition": l.transition, "opacity": l.opacity, "blend": l.blend.rawValue, "autopilot": l.autopilot.rawValue,
                "ap_every": l.apEvery, "ap_beats": l.apBeats, "gen_look": l.genLook, "ndi": l.ndiName, "ndi_bandwidth": l.ndiBandwidth.rawValue,
                "gen": ["type": g.type.rawValue, "count": g.count, "thickness": g.thickness, "softness": g.softness, "speed": g.speed,
                        "angle": g.angle, "variation": g.variation, "beatsync": g.beatSync, "colorA": a3(g.colorA), "colorB": a3(g.colorB),
                        "colormode": g.colorMode.rawValue] as [String: Any],
                "overlay": l.overlay.sceneDict,
                "fx": ["x": f.x, "y": f.y, "scale": f.scale, "rotation": f.rotation, "spin": f.spin, "flipx": f.flipX, "flipy": f.flipY,
                       "tile": f.tile, "mirror": f.mirror, "look": f.look, "slots": f.fx.map { ["type": $0.type.rawValue, "amount": $0.amount, "speed": $0.speed] },
                       "mod_target": f.modTarget.rawValue, "mod_shape": f.modShape.rawValue, "mod_beats": f.modBeats, "mod_depth": f.modDepth,
                       "spinfill": f.spinFill.rawValue, "edge_feather": f.edgeFeather, "edge_shape": f.edgeShape.rawValue] as [String: Any]]
    }
    let m = c.frac
    let mods: [String: Any] = ["formula": m.formula.rawValue, "fold": m.fold, "fold_mirror": m.foldMirror, "foldc": m.foldC,
                               "foldc_mirror": m.foldCMirror, "julia": m.julia, "julia_re": m.juliaRe, "julia_im": m.juliaIm,
                               "julia_drift": m.juliaDrift, "julia_beat": m.juliaBeat, "warp": m.warp, "bailout": m.bailout,
                               "trap": m.trap.rawValue, "trap_mix": m.trapMix, "trap_size": m.trapSize, "loop": m.loop.rawValue,
                               "loop_next": m.loopNext.rawValue, "loop_depth": m.loopDepth, "loop_fade": m.loopFade, "preset": m.preset,
                               "spread": m.spread, "phasers": m.phasers.map { $0.dict }, "phaser_preset": m.phaserPreset, "power": m.power, "fold_mode": m.foldMode.rawValue, "phaser_free": m.phaserFree]
    let fractal: [String: Any] = ["target": fi.targetIndex, "target_name": fi.target, "center": [fi.centerRe, fi.centerIm], "depth": fi.depth,
                                  "zoomspeed": c.zoomSpeed, "palette": c.palette, "palette_speed": c.paletteSpeed, "palette_offset": c.paletteOffset,
                                  "rotation": c.rotation, "spin": c.fractalSpin, "layer": c.fractalLayer, "opacity": c.fractalOpacity, "mods": mods,
                                  "iterations": c.iterOverride, "shape_memory": c.shapeMemoryDict, "shape_memory_on": c.shapeMemoryOn]
    let master: [String: Any] = ["fx": ["type": c.masterFX.type.rawValue, "amount": c.masterFX.amount, "speed": c.masterFX.speed],
                                 "effect_speed": c.effectSpeed,
                                 "color": ["r": c.color.r, "g": c.color.g, "b": c.color.b, "amount": c.color.amount,
                                           "mode": c.color.mode.rawValue, "target": c.color.target.rawValue] as [String: Any]]
    return ["layers": layers, "fractal": fractal, "master": master,
            "audio": ["routes": c.audioRoutes.map { $0.dict }, "preset": c.audioPreset] as [String: Any]]
}

/// Writes the look into a Control copy (included layers only; the fractal target / depth are handled by the recall).
private func sceneApply(_ d: [String: Any], into c: inout Control, inc inc0: [Bool]) {
    let inc = inc0 + [true]                                 // BG (L0, index 4) is always part of a scene, like the fractal
    if var ls = d["layers"] as? [[String: Any]] {
        // a scene stored before BG was a full layer (4 rows): BG back to a plain fractal base (its opacity comes from "fractal")
        if ls.count == layerCount { ls.append(["source": "fractal", "slot": 0, "blend": 0, "autopilot": "off", "overlay": ["on": false] as [String: Any],
                                               "fx": ["x": 0, "y": 0, "scale": 1, "rotation": 0, "spin": 0, "flipx": false, "flipy": false, "tile": 1,
                                                      "mirror": false, "slots": [["type": 0, "amount": 0], ["type": 0, "amount": 0]], "mod_target": 0,
                                                      "spinfill": "auto", "edge_feather": 0, "edge_shape": "rect"] as [String: Any]]) }
        for (li, l) in ls.prefix(compCount).enumerated() where inc[li] {
            var L = c.layers[li]
            if let s = dstr(l, "source"), let v = LayerSource(rawValue: s) { L.source = v }
            if let v = dint(l, "bank") { L.bank = v }
            if let v = dint(l, "slot") { L.slot = max(0, v) }
            if let s = dstr(l, "playmode"), let v = PlayMode(rawValue: s) { L.playmode = v }
            if let v = dnum(l, "speed") { L.speed = min(4, max(0, v)) }
            if let v = dnum(l, "transition") { L.transition = min(10, max(0, v)) }
            if let v = dnum(l, "opacity") { L.opacity = min(1, max(0, v)) }
            if let v = dint(l, "blend"), let b = BlendMode(rawValue: v) { L.blend = b }
            if let s = dstr(l, "autopilot"), let v = Autopilot(rawValue: s) { L.autopilot = v }
            if let v = dnum(l, "ap_every") { L.apEvery = v }
            if let v = dnum(l, "ap_beats") { L.apBeats = v }
            if let s = dstr(l, "ndi") { L.ndiName = String(s.prefix(200)) }
            if let s = dstr(l, "ndi_bandwidth"), let v = NDIBandwidth(rawValue: s) { L.ndiBandwidth = v }
            let g = dsub(l, "gen")
            if let v = dint(g, "type"), let t = GenType(rawValue: v) { L.gen.type = t }
            if let v = dnum(g, "count") { L.gen.count = v }
            if let v = dnum(g, "thickness") { L.gen.thickness = v }
            if let v = dnum(g, "softness") { L.gen.softness = v }
            if let v = dnum(g, "speed") { L.gen.speed = v }
            if let v = dnum(g, "angle") { L.gen.angle = v }
            if let v = dnum(g, "variation") { L.gen.variation = v }
            if let v = dbool(g, "beatsync") { L.gen.beatSync = v }
            if let v = d3(g, "colorA") { L.gen.colorA = v }
            if let v = d3(g, "colorB") { L.gen.colorB = v }
            if let s = dstr(g, "colormode"), let v = GenColorMode(rawValue: s) { L.gen.colorMode = v }
            // overlay (2026-10-23): scenes stored before it switch the overlay off (a scene is the whole look)
            if let o = l["overlay"] as? [String: Any] { L.overlay.apply(o) } else { L.overlay.on = false }
            let f = dsub(l, "fx")
            if let v = dnum(f, "x") { L.fx.x = v }
            if let v = dnum(f, "y") { L.fx.y = v }
            if let v = dnum(f, "scale") { L.fx.scale = v }
            if let v = dnum(f, "rotation") { L.fx.rotation = v }
            if let v = dnum(f, "spin") { L.fx.spin = v }
            if let v = dbool(f, "flipx") { L.fx.flipX = v }
            if let v = dbool(f, "flipy") { L.fx.flipY = v }
            if let v = dint(f, "tile") { L.fx.tile = min(8, max(1, v)) }
            if let v = dbool(f, "mirror") { L.fx.mirror = v }
            if let ss = f["slots"] as? [[String: Any]] {
                for (k, s) in ss.prefix(2).enumerated() {
                    if let v = dint(s, "type"), let t = FXType(rawValue: v) { L.fx.fx[k].type = t }
                    if let v = dnum(s, "amount") { L.fx.fx[k].amount = v }
                    if let v = dnum(s, "speed") { L.fx.fx[k].speed = v }
                }
            }
            if let v = dint(f, "mod_target"), let t = ModTarget(rawValue: v) { L.fx.modTarget = t }
            if let v = dint(f, "mod_shape"), let t = ModShape(rawValue: v) { L.fx.modShape = t }
            if let v = dnum(f, "mod_beats") { L.fx.modBeats = snapModBeats(v) }
            if let v = dnum(f, "mod_depth") { L.fx.modDepth = v }
            // spin fill + edge (2026-10-23): scenes stored before them leave the current values as they are
            if let s = dstr(f, "spinfill"), let v = SpinFill(rawValue: s) { L.fx.spinFill = v }
            if let v = dnum(f, "edge_feather") { L.fx.edgeFeather = min(1, max(0, v)) }
            if let s = dstr(f, "edge_shape"), let v = EdgeShape(rawValue: s) { L.fx.edgeShape = v }
            // look names (2026-10-24): a recalled scene lights the looks it holds; a scene stored before them lights none
            L.fx.look = dstr(f, "look") ?? ""
            L.genLook = dstr(l, "gen_look") ?? ""
            c.layers[li] = L
        }
    }
    let fr = dsub(d, "fractal")
    if let v = dnum(fr, "zoomspeed") { c.zoomSpeed = min(5, max(-5, v)) }
    if let v = dint(fr, "palette") { c.palette = min(5, max(1, v)) }
    if let v = dnum(fr, "palette_speed") { c.paletteSpeed = v }
    if let v = dnum(fr, "palette_offset") { c.paletteOffset = v }
    if let v = dnum(fr, "rotation") { c.rotation = v }
    if let v = dnum(fr, "spin") { c.fractalSpin = v }
    if let v = dint(fr, "layer") { c.fractalLayer = min(layerCount, max(0, v)) }
    if let v = dnum(fr, "opacity") { c.fractalOpacity = v }
    let m = dsub(fr, "mods")
    if let v = dint(m, "formula"), let f = Formula(rawValue: v) { c.frac.formula = f }
    if let v = dnum(m, "power") { c.frac.power = clampPower(v) }   // after the formula (which resets it)
    if let v = dint(m, "fold") { c.frac.fold = v }
    if let v = dbool(m, "fold_mirror") { c.frac.foldMirror = v }
    if let s = dstr(m, "fold_mode"), let t = FoldMode(rawValue: s) { c.frac.foldMode = t } else if c.frac.fold >= 2 { c.frac.foldMode = .wild }   // older scenes: z fold
    if let v = dint(m, "foldc") { c.frac.foldC = v }
    if let v = dbool(m, "foldc_mirror") { c.frac.foldCMirror = v }
    if let v = dnum(m, "julia") { c.frac.julia = v }
    if let v = dnum(m, "julia_re") { c.frac.juliaRe = v }
    if let v = dnum(m, "julia_im") { c.frac.juliaIm = v }
    if let v = dnum(m, "julia_drift") { c.frac.juliaDrift = v }
    if let v = dbool(m, "julia_beat") { c.frac.juliaBeat = v }
    if let v = dnum(m, "warp") { c.frac.warp = v }
    if let v = dnum(m, "bailout") { c.frac.bailout = v }
    if let s = dstr(m, "trap"), let t = TrapShape(rawValue: s) { c.frac.trap = t }
    if let v = dnum(m, "trap_mix") { c.frac.trapMix = v }
    if let v = dnum(m, "trap_size") { c.frac.trapSize = v }
    if let s = dstr(m, "loop"), let t = LoopMode(rawValue: s) { c.frac.loop = t }
    if let s = dstr(m, "loop_next"), let t = LoopNext(rawValue: s) { c.frac.loopNext = t }
    if let v = dnum(m, "loop_depth") { c.frac.loopDepth = v }
    if let v = dnum(m, "loop_fade") { c.frac.loopFade = v }
    if let s = dstr(m, "preset") { c.frac.preset = s }
    // phasers + spread (2026-10-23): scenes stored before them leave the current ones as they are
    if let v = dnum(m, "spread") { c.frac.spread = min(1, max(-1, v)) }
    if let rows = m["phasers"] as? [[String: Any]] {
        for k in 0..<phaserCount { c.frac.phasers[k] = k < rows.count ? Phaser.from(rows[k], base: c.frac.phasers[k]) : c.frac.phasers[k] }
        c.frac.phaserPreset = dstr(m, "phaser_preset") ?? ""
    }
    if let v = dbool(m, "phaser_free") { c.frac.phaserFree = v }
    let ma = dsub(d, "master"), mf = dsub(ma, "fx"), co = dsub(ma, "color")
    if let v = dint(mf, "type"), let t = FXType(rawValue: v) { c.masterFX.type = t }
    if let v = dnum(mf, "amount") { c.masterFX.amount = v }
    if let v = dnum(mf, "speed") { c.masterFX.speed = v }
    if let v = dnum(ma, "effect_speed") { c.effectSpeed = min(2, max(0, v)) }
    if let v = dnum(co, "r") { c.color.r = v }
    if let v = dnum(co, "g") { c.color.g = v }
    if let v = dnum(co, "b") { c.color.b = v }
    if let v = dnum(co, "amount") { c.color.amount = v }
    if let s = dstr(co, "mode"), let t = ColorMode(rawValue: s) { c.color.mode = t }
    if let s = dstr(co, "target"), let t = ColorTarget(rawValue: s) { c.color.target = t }
    // audio react routes (2026-10-23): scenes stored before them leave the current routes as they are
    let au = dsub(d, "audio")
    if let rows = au["routes"] as? [[String: Any]] {
        for k in 0..<audioRouteCount { c.audioRoutes[k] = k < rows.count ? AudioRoute.from(rows[k], base: AudioRoute()) : AudioRoute() }
        c.audioPreset = dstr(au, "preset") ?? ""
    }
}

/// Discrete values switch at the fade start. Returns the layers whose clip changes (their transition is set to the fade).
private func sceneDiscrete(_ c: inout Control, _ t: Control, inc inc0: [Bool], fade: Double) -> [Int] {
    let inc = inc0 + [true]
    var changed: [Int] = []
    for li in 0..<compCount where inc[li] {
        let T = t.layers[li]
        if c.layers[li].bank != T.bank || c.layers[li].slot != T.slot {
            c.layers[li].bank = T.bank; c.layers[li].slot = T.slot; c.layers[li].playSeq += 1
            c.layers[li].transition = fade
            changed.append(li)
        } else { c.layers[li].transition = T.transition }
        c.layers[li].source = T.source
        c.layers[li].blend = T.blend; c.layers[li].playmode = T.playmode
        c.layers[li].autopilot = T.autopilot; c.layers[li].apEvery = T.apEvery; c.layers[li].apBeats = T.apBeats
        c.layers[li].gen.type = T.gen.type; c.layers[li].gen.beatSync = T.gen.beatSync; c.layers[li].gen.colorMode = T.gen.colorMode
        let O = T.overlay
        if O.on || !c.layers[li].overlay.on {                       // on / type / modes switch at the start; off at the end (fades out)
            c.layers[li].overlay.on = O.on; c.layers[li].overlay.gen.type = O.gen.type
            c.layers[li].overlay.blend = O.blend; c.layers[li].overlay.follow = O.follow
        }
        c.layers[li].overlay.look = O.look
        c.layers[li].overlay.gen.beatSync = O.gen.beatSync; c.layers[li].overlay.gen.colorMode = O.gen.colorMode
        c.layers[li].fx.flipX = T.fx.flipX; c.layers[li].fx.flipY = T.fx.flipY; c.layers[li].fx.tile = T.fx.tile; c.layers[li].fx.mirror = T.fx.mirror
        c.layers[li].fx.spinFill = T.fx.spinFill; c.layers[li].fx.edgeShape = T.fx.edgeShape
        for k in 0..<2 { c.layers[li].fx.fx[k].type = T.fx.fx[k].type }
        c.layers[li].fx.modTarget = T.fx.modTarget; c.layers[li].fx.modShape = T.fx.modShape; c.layers[li].fx.modBeats = T.fx.modBeats
        c.layers[li].fx.look = T.fx.look; c.layers[li].genLook = T.genLook      // the scene's look names (lit indicators) from the fade start
    }
    // the one fractal: on the scene's layer if that layer is included (or the base); never left on an included layer that is no longer Fractal
    let fl = t.fractalLayer
    if fl == 0 || inc[fl - 1] { c.fractalLayer = fl }
    else if c.fractalLayer >= 1, inc[c.fractalLayer - 1], c.layers[c.fractalLayer - 1].source != .fractal { c.fractalLayer = 0 }
    c.frac.formula = t.frac.formula; c.frac.fold = t.frac.fold; c.frac.foldMirror = t.frac.foldMirror; c.frac.foldMode = t.frac.foldMode
    c.frac.foldC = t.frac.foldC; c.frac.foldCMirror = t.frac.foldCMirror; c.frac.juliaBeat = t.frac.juliaBeat
    c.frac.trap = t.frac.trap; c.frac.loop = t.frac.loop; c.frac.loopNext = t.frac.loopNext; c.frac.preset = t.frac.preset
    // phasers switch at the fade start (each fades in / out over 0.25 s by itself); the spread crossfades
    c.frac.phasers = t.frac.phasers; c.frac.phaserPreset = t.frac.phaserPreset
    c.palette = t.palette
    c.masterFX.type = t.masterFX.type; c.color.mode = t.color.mode; c.color.target = t.color.target
    return changed
}

/// Numeric values: a + (b - a) k (angles the short way round).
private func sceneLerp(_ c: inout Control, _ a: Control, _ b: Control, _ k: Double, inc inc0: [Bool]) {
    let inc = inc0 + [true]
    func l(_ x: Double, _ y: Double) -> Double { x + (y - x) * k }
    func ang(_ x: Double, _ y: Double) -> Double { x + remainder(y - x, 360) * k }
    func l3(_ x: SIMD3<Double>, _ y: SIMD3<Double>) -> SIMD3<Double> { x + (y - x) * k }
    for li in 0..<compCount where inc[li] {
        let A = a.layers[li], B = b.layers[li]
        c.layers[li].opacity = l(A.opacity, B.opacity); c.layers[li].speed = l(A.speed, B.speed)
        c.layers[li].gen.count = l(A.gen.count, B.gen.count); c.layers[li].gen.thickness = l(A.gen.thickness, B.gen.thickness)
        c.layers[li].gen.softness = l(A.gen.softness, B.gen.softness); c.layers[li].gen.speed = l(A.gen.speed, B.gen.speed)
        c.layers[li].gen.angle = ang(A.gen.angle, B.gen.angle); c.layers[li].gen.variation = l(A.gen.variation, B.gen.variation)
        c.layers[li].gen.colorA = l3(A.gen.colorA, B.gen.colorA); c.layers[li].gen.colorB = l3(A.gen.colorB, B.gen.colorB)
        let OA = A.overlay, OB = B.overlay
        // overlay opacity: from / to 0 when it switches on / off, so it fades in and out
        c.layers[li].overlay.opacity = l(OA.on ? OA.opacity : 0, OB.on ? OB.opacity : 0)
        if k >= 1 { c.layers[li].overlay = OB }
        else {
            c.layers[li].overlay.gen.count = l(OA.gen.count, OB.gen.count); c.layers[li].overlay.gen.thickness = l(OA.gen.thickness, OB.gen.thickness)
            c.layers[li].overlay.gen.softness = l(OA.gen.softness, OB.gen.softness); c.layers[li].overlay.gen.speed = l(OA.gen.speed, OB.gen.speed)
            c.layers[li].overlay.gen.angle = ang(OA.gen.angle, OB.gen.angle); c.layers[li].overlay.gen.variation = l(OA.gen.variation, OB.gen.variation)
            c.layers[li].overlay.gen.colorA = l3(OA.gen.colorA, OB.gen.colorA); c.layers[li].overlay.gen.colorB = l3(OA.gen.colorB, OB.gen.colorB)
            if !OB.on && OA.on { c.layers[li].overlay.on = true }
        }
        c.layers[li].fx.x = l(A.fx.x, B.fx.x); c.layers[li].fx.y = l(A.fx.y, B.fx.y); c.layers[li].fx.scale = l(A.fx.scale, B.fx.scale)
        c.layers[li].fx.rotation = remainder(ang(A.fx.rotation, B.fx.rotation), 360); c.layers[li].fx.spin = l(A.fx.spin, B.fx.spin)
        for s in 0..<2 {
            c.layers[li].fx.fx[s].amount = l(A.fx.fx[s].amount, B.fx.fx[s].amount)
            c.layers[li].fx.fx[s].speed = l(A.fx.fx[s].speed, B.fx.fx[s].speed)
        }
        c.layers[li].fx.modDepth = l(A.fx.modDepth, B.fx.modDepth)
        c.layers[li].fx.edgeFeather = l(A.fx.edgeFeather, B.fx.edgeFeather)
    }
    let fa = a.frac, fb = b.frac
    c.frac.julia = l(fa.julia, fb.julia); c.frac.juliaRe = l(fa.juliaRe, fb.juliaRe); c.frac.juliaIm = l(fa.juliaIm, fb.juliaIm)
    c.frac.juliaDrift = l(fa.juliaDrift, fb.juliaDrift); c.frac.warp = l(fa.warp, fb.warp); c.frac.bailout = l(fa.bailout, fb.bailout)
    c.frac.trapMix = l(fa.trapMix, fb.trapMix); c.frac.trapSize = l(fa.trapSize, fb.trapSize)
    c.frac.loopDepth = l(fa.loopDepth, fb.loopDepth); c.frac.loopFade = l(fa.loopFade, fb.loopFade)
    c.frac.spread = l(fa.spread, fb.spread)
    c.paletteSpeed = l(a.paletteSpeed, b.paletteSpeed); c.paletteOffset = l(a.paletteOffset, b.paletteOffset)
    var r = ang(a.rotation, b.rotation).truncatingRemainder(dividingBy: 360); if r < 0 { r += 360 }
    c.rotation = r
    c.fractalSpin = l(a.fractalSpin, b.fractalSpin); c.zoomSpeed = l(a.zoomSpeed, b.zoomSpeed)
    c.fractalOpacity = l(a.fractalOpacity, b.fractalOpacity)
    c.frac.power = l(a.frac.power, b.frac.power)            // Branches morph (after the formula switched at the fade start)
    c.masterFX.amount = l(a.masterFX.amount, b.masterFX.amount); c.masterFX.speed = l(a.masterFX.speed, b.masterFX.speed)
    c.color.r = l(a.color.r, b.color.r); c.color.g = l(a.color.g, b.color.g); c.color.b = l(a.color.b, b.color.b)
    c.color.amount = l(a.color.amount, b.color.amount); c.effectSpeed = l(a.effectSpeed, b.effectSpeed)
}

// MARK: - store + recall

final class Scenes {
    struct Rec {
        var name: String, color: String, fade: Double, keepDepth: Bool, include: [Bool], stored: Double, look: [String: Any]
    }
    private struct Fade {
        var n: Int, from: Control, to: Control, start: Double, dur: Double, inc: [Bool]
        var depth: (Double, Double)?, restore: [Int], restoreAt: Double, done = false
    }
    static let colors = ["#7c5cff", "#22d3ee", "#e879f9", "#fbbf24", "#a3e635", "#fb7185", "#60a5fa", "#f97316"]
    private let lock = NSLock()
    private var recs: [Int: Rec] = [:]
    private var bankNames: [Int: String] = [:]
    private var bank = 1, current = 0, rev = 0, goes = 0, lastGo = ""
    private var fade: Fade? = nil
    private var progress = 1.0
    let path = gScenesFileOverride.isEmpty ? (m0Dir() as NSString).appendingPathComponent("scenes.json") : gScenesFileOverride
    var thumbDir: String { (gLibrary.dir as NSString).appendingPathComponent(".scenes") }
    func thumbName(_ n: Int) -> String { String(format: "%d-%02d.jpg", (n - 1) / sceneSlots + 1, (n - 1) % sceneSlots + 1) }

    func load() {
        guard let d = FileManager.default.contents(atPath: path) else { olog("scenes: no \(path) yet (store one to create it)"); return }
        guard let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { olog("scenes: WARNING: \(path) is not readable JSON: ignored"); return }
        lock.lock(); defer { lock.unlock() }
        bank = min(sceneBanks, max(1, dint(j, "bank") ?? 1))
        for b in j["banks"] as? [[String: Any]] ?? [] {
            guard let bn = dint(b, "bank"), (1...sceneBanks).contains(bn) else { continue }
            if let nm = dstr(b, "name") { bankNames[bn] = nm }
            for s in b["scenes"] as? [[String: Any]] ?? [] {
                guard let sl = dint(s, "slot"), (1...sceneSlots).contains(sl), let look = s["look"] as? [String: Any] else { continue }
                let inc = (s["include"] as? [Bool]) ?? [Bool](repeating: true, count: layerCount)
                recs[(bn - 1) * sceneSlots + sl] = Rec(name: dstr(s, "name") ?? "Scene \(bn).\(sl)", color: dstr(s, "color") ?? Scenes.colors[(sl - 1) % 8],
                                                       fade: min(60, max(0, dnum(s, "fade") ?? 2)), keepDepth: dbool(s, "keep_depth") ?? true,
                                                       include: inc.count == layerCount ? inc : [Bool](repeating: true, count: layerCount),
                                                       stored: dnum(s, "stored") ?? 0, look: look)
            }
        }
        olog("scenes: \(path): \(recs.count) scenes, bank \(bank)")
    }

    /// Call under `lock`.
    private func save() {
        var banks: [[String: Any]] = []
        for bn in 1...sceneBanks {
            let ss = (1...sceneSlots).compactMap { sl -> [String: Any]? in
                let n = (bn - 1) * sceneSlots + sl
                guard let r = recs[n] else { return nil }
                return ["slot": sl, "n": n, "name": r.name, "color": r.color, "fade": r.fade, "keep_depth": r.keepDepth, "include": r.include,
                        "stored": r.stored, "thumb": thumbName(n), "look": r.look]
            }
            if ss.isEmpty && bankNames[bn] == nil { continue }
            banks.append(["bank": bn, "name": bankNames[bn] ?? "Bank \(bn)", "scenes": ss])
        }
        let j: [String: Any] = ["version": 1, "about": "OATS VIZ scenes (src/scenes.swift); scene n = (bank-1)*16 + slot", "bank": bank, "banks": banks]
        rev += 1
        guard let data = try? JSONSerialization.data(withJSONObject: j, options: [.prettyPrinted, .sortedKeys]) else { olog("scenes: WARNING: could not encode"); return }
        do { try data.write(to: URL(fileURLWithPath: path), options: .atomic) } catch { olog("scenes: WARNING: write \(path) failed: \(error)") }
    }

    func store(_ n: Int, name: String?) -> String {
        let look = sceneCapture()
        lock.lock()
        let old = recs[n], sl = (n - 1) % sceneSlots + 1
        recs[n] = Rec(name: name ?? old?.name ?? "Scene \(sceneLabel(n))", color: old?.color ?? Scenes.colors[(sl - 1) % 8], fade: old?.fade ?? 2,
                      keepDepth: old?.keepDepth ?? true, include: old?.include ?? [Bool](repeating: true, count: layerCount),
                      stored: Date().timeIntervalSince1970, look: look)
        let nm = recs[n]!.name
        save()
        lock.unlock()
        grabThumb(n)
        return "scene \(sceneLabel(n)) (\(n)) stored '\(nm)'" + (old == nil ? "" : " (replaced)")
    }

    /// 160x90 JPEG of the output, from the preview server (waits for the next frame; async).
    private func grabThumb(_ n: Int) {
        let dir = thumbDir, file = (dir as NSString).appendingPathComponent(thumbName(n))
        guard let url = URL(string: "http://127.0.0.1:\(previewPort)/preview.jpg?w=160") else { return }
        var rq = URLRequest(url: url); rq.timeoutInterval = 3
        URLSession.shared.dataTask(with: rq) { [self] data, resp, err in
            guard let d = data, (resp as? HTTPURLResponse)?.statusCode == 200, d.count > 100 else {
                olog("scenes: thumbnail for \(sceneLabel(n)) failed (\(err.map { "\($0)" } ?? "no JPEG from the preview server"))"); return
            }
            try? FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true)
            if FileManager.default.createFile(atPath: file, contents: d) { lock.lock(); rev += 1; lock.unlock() }
        }.resume()
    }

    func edit(_ n: Int, _ body: (inout Rec) -> Void) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard var r = recs[n] else { return false }
        body(&r); recs[n] = r; save(); return true
    }

    func delete(_ n: Int) -> String {
        lock.lock()
        guard recs.removeValue(forKey: n) != nil else { lock.unlock(); return "scene \(sceneLabel(n)) is empty (nothing to delete)" }
        if current == n { current = 0 }
        save(); lock.unlock()
        try? FileManager.default.removeItem(atPath: (thumbDir as NSString).appendingPathComponent(thumbName(n)))
        return "scene \(sceneLabel(n)) deleted"
    }

    func setBank(_ b: Int) -> String {
        lock.lock(); bank = min(sceneBanks, max(1, b)); save(); let x = bank; lock.unlock()
        return "scene bank \(x)"
    }

    /// next / previous stored scene in the current bank (wrapping), from the current one.
    func step(_ dir: Int) -> Int? {
        lock.lock(); defer { lock.unlock() }
        let base = (bank - 1) * sceneSlots
        let ns = (1...sceneSlots).map { base + $0 }.filter { recs[$0] != nil }
        guard !ns.isEmpty else { return nil }
        if current > base && current <= base + sceneSlots {
            return dir > 0 ? (ns.first { $0 > current } ?? ns[0]) : (ns.last { $0 < current } ?? ns[ns.count - 1])
        }
        return dir > 0 ? ns[0] : ns[ns.count - 1]
    }

    func go(_ n: Int, fade fo: Double?, from src: String) -> String {
        lock.lock()
        guard let r = recs[n] else { lock.unlock(); return "scene \(sceneLabel(n)) is empty (nothing recalled)" }
        lock.unlock()
        gStartup.input("scene go \(sceneLabel(n)) (\(src))")
        let dur = min(60, max(0, fo ?? r.fade))
        let fi = gStats.with { $0.fractal }
        let now = clk()
        var f = Fade(n: n, from: Control(), to: Control(), start: now, dur: dur, inc: r.include, depth: nil, restore: [], restoreAt: now + dur + 1.5)
        var note = ""
        gControl.with { c in
            let from = c
            var to = c
            sceneApply(r.look, into: &to, inc: r.include)
            let fr = dsub(r.look, "fractal")
            let ti = dint(fr, "target") ?? 0, sd = min(zoomDepthMax, max(0, dnum(fr, "depth") ?? fi.depth))
            var targetMove = false
            if ti >= 1 && ti <= zoomTargets.count {
                if ti != fi.targetIndex {
                    c.targetRequest = ti - 1; c.centerRequest = nil; c.targetDepth = r.keepDepth ? fi.depth : sd; targetMove = true
                    note += " target \(zoomTargets[ti - 1].name)"
                }
            } else if let ce = fr["center"] as? [String], ce.count == 2, ce[0] != fi.centerRe || ce[1] != fi.centerIm,
                      let spec = CentreSpec.custom(re: ce[0], im: ce[1]) {
                c.centerRequest = spec; c.targetRequest = nil; targetMove = true; note += " custom centre"
                if !r.keepDepth { c.zoomSet = log10WidthMax - sd }
            }
            // shape memory (2026-10-23): the scene's saved shapes come back; the live shape is the scene's own
            if ti >= 1 && ti <= zoomTargets.count && ti - 1 != c.shapeTarget && c.shapeMemoryOn {
                c.shapeMemory[zoomTargets[min(zoomTargets.count - 1, max(0, c.shapeTarget))].name] = c.shape
            }
            if let sm = fr["shape_memory"] as? [String: Any] { c.setShapeMemory(sm) }
            if let v = dbool(fr, "shape_memory_on") { c.shapeMemoryOn = v }
            if ti >= 1 && ti <= zoomTargets.count { c.shapeTarget = ti - 1 }
            if let v = dint(fr, "iterations") { c.iterOverride = v <= 0 ? 0 : min(maxIterLimit, max(minIterOverride, v)) }
            f.restore = sceneDiscrete(&c, to, inc: r.include, fade: dur)
            if r.look["audio"] != nil { c.audioRoutes = to.audioRoutes; c.audioPreset = to.audioPreset; c.layerOwners["audio"] = .osc }   // routes switch at the fade start
            var ps: [Param] = [.zoomspeed, .target, .palette, .palette_speed, .palette_offset, .rotation, .spin, .effect_speed]
            if !r.keepDepth { ps.append(.depth) }
            c.ltpOSC(ps, depthMove: !r.keepDepth)
            for li in 0..<compCount where li == bgIndex || r.include[li] {
                for k in ["clip", "opacity", "blend", "speed", "transition", "playmode", "source", "autopilot", "pos", "scale", "rotation", "spin", "tile",
                          "fx1", "fx2", "mod", "gen.type", "gen.count", "gen.thickness", "gen.softness", "gen.speed", "gen.angle", "gen.variation",
                          "gen.beatsync", "gen.colormode", "gen.colorA", "gen.colorB", "overlay"] { c.layerOwners["layer\(layerNum(li)).\(k)"] = .osc }
            }
            for k in ["fractal.formula", "fractal.fold", "fractal.julia", "fractal.juliac", "fractal.trap", "fractal.loop", "fractal.layer",
                      "fractal.opacity", "color.rgb", "color.amount", "color.mode", "color.target", "master.fx"] { c.layerOwners[k] = .osc }
            if !r.keepDepth && !targetMove && abs(sd - fi.depth) > 1e-6 { f.depth = (fi.depth, sd) }
            f.from = from; f.to = to
            if dur <= 0 {
                sceneLerp(&c, from, to, 1, inc: r.include)
                if let d = f.depth { c.zoomSet = log10WidthMax - d.1 }
            }
        }
        lock.lock()
        // a running fade's restore of clip transitions: done now (the new fade sets its own)
        if let old = fade, !old.restore.isEmpty {
            gControl.with { c in for li in old.restore where !f.restore.contains(li) { c.layers[li].transition = old.to.layers[li].transition } }
        }
        fade = f; current = n; goes += 1; progress = dur <= 0 ? 1 : 0
        lastGo = "\(sceneLabel(n)) '\(r.name)' from \(src)"
        rev += 1
        lock.unlock()
        let inc = r.include.allSatisfy { $0 } ? "" : " layers " + (0..<layerCount).filter { r.include[$0] }.map { "\($0 + 1)" }.joined(separator: ",")
        return "scene \(sceneLabel(n)) (\(n)) '\(r.name)' go" + (dur > 0 ? String(format: ", fade %.2f s", dur) : ", cut")
            + (f.restore.isEmpty ? "" : ", clip change on layer " + f.restore.map { "\($0 + 1)" }.joined(separator: ","))
            + note + (r.keepDepth ? " (keep depth)" : "") + inc + " [\(src)]"
    }

    func start() {
        let t = Thread { [self] in while !gFlags.stopping { autoreleasepool { self.tick() }; usleep(20_000) } }   // pool per tick (playback.swift)
        t.name = "scenes"; t.qualityOfService = .userInitiated; t.start()
    }

    private func tick() {
        lock.lock(); guard var f = fade else { lock.unlock(); return }; lock.unlock()
        let now = clk()
        let k = f.dur > 0 ? min(1, max(0, (now - f.start) / f.dur)) : 1
        let e = k * k * (3 - 2 * k)
        var finished = false
        gControl.with { c in
            if !f.done {
                if f.dur > 0 {
                    sceneLerp(&c, f.from, f.to, e, inc: f.inc)
                    if let d = f.depth { c.zoomSet = log10WidthMax - (d.0 + (d.1 - d.0) * e) }
                }
                if k >= 1 { f.done = true }
            }
            if f.done && now >= f.restoreAt {
                for li in f.restore { c.layers[li].transition = f.to.layers[li].transition }
                finished = true
            }
        }
        lock.lock()
        if fade?.start == f.start && fade?.n == f.n {
            progress = k
            if finished { fade = nil; rev += 1 } else { fade = f }
            if k >= 1 && f.done && !finished { /* fade done; waiting for the clip transition restore */ }
        }
        lock.unlock()
    }

    func status() -> [String: Any] {
        lock.lock(); defer { lock.unlock() }
        let fading = fade.map { !$0.done } ?? false
        return ["current": current, "current_label": sceneLabel(current), "current_name": recs[current]?.name ?? "",
                "bank": bank, "fading": fading, "progress": (progress * 1000).rounded() / 1000,
                "fade_s": fade?.dur ?? 0, "count": recs.count, "rev": rev, "goes": goes, "last_go": lastGo, "path": path,
                "thumbs": thumbDir]
    }

    // MARK: OSC  /oats/scene/{store,go,next,prev,bank,delete,rename,color,fade,keepdepth,include}, /oats/scene/{n}/go

    /// One scene reference from args: s "b.s", i b i s (two ints), or i n (1..128). Returns (n, index of the next arg).
    static func ref(_ args: [OSCArg]) -> (Int, Int)? {
        guard let a0 = args.first else { return nil }
        if case .s(let s) = a0 { return parse(s).map { ($0, 1) } }
        func isInt(_ a: OSCArg) -> Bool { if case .i = a { return true }; if case .h = a { return true }; return false }
        guard let v = a0.number, v.isFinite, abs(v) < 1e6 else { return nil }
        if args.count >= 2, isInt(a0), isInt(args[1]), let s = args[1].number {
            let b = Int(v), sl = Int(s)
            guard (1...sceneBanks).contains(b), (1...sceneSlots).contains(sl) else { return nil }
            return ((b - 1) * sceneSlots + sl, 2)
        }
        let n = Int(v.rounded())
        return (1...sceneMax).contains(n) ? (n, 1) : nil
    }
    static func parse(_ s: String) -> Int? {
        let t = s.trimmingCharacters(in: .whitespaces)
        let p = t.split(separator: ".").map { Int($0) }
        if p.count == 2, let b = p[0], let sl = p[1], (1...sceneBanks).contains(b), (1...sceneSlots).contains(sl) { return (b - 1) * sceneSlots + sl }
        if p.count == 1, let n = p[0], (1...sceneMax).contains(n) { return n }
        return nil
    }

    /// Returns the log text, or nil = bad args / unknown (the caller logs it rate-limited).
    func osc(_ m: OSCMessage) -> String? {
        let parts = m.address.split(separator: "/").map(String.init)      // oats scene ...
        guard parts.count >= 3 else { return nil }
        let rest = Array(parts[2...])
        func str(_ i: Int) -> String? { if i < m.args.count, case .s(let v) = m.args[i] { return v }; return nil }
        func num(_ i: Int) -> Double? { i < m.args.count ? m.args[i].number.flatMap { $0.isFinite ? $0 : nil } : nil }
        if rest.count == 2, rest[1] == "go", let n = Scenes.parse(rest[0]) {
            if let v = num(0), v.rounded() == 0, m.args.count == 1, m.types == ",i" { return "scene \(rest[0]) go: release ignored" }
            return go(n, fade: num(0), from: "OSC")
        }
        guard rest.count == 1 else { return nil }
        switch rest[0] {
        case "store":
            guard let (n, i) = Scenes.ref(m.args) else { return nil }
            let nm = str(i).map { String($0.prefix(48)) }
            return store(n, name: nm?.isEmpty == true ? nil : nm)
        case "go":
            guard let (n, i) = Scenes.ref(m.args) else { return nil }
            return go(n, fade: num(i), from: "OSC")
        case "next", "prev":
            if let v = num(0), v.rounded() == 0 { return "scene \(rest[0]): release ignored" }
            guard let n = step(rest[0] == "next" ? 1 : -1) else { return "scene \(rest[0]): no stored scene in this bank" }
            return go(n, fade: nil, from: "OSC \(rest[0])")
        case "bank":
            guard let v = num(0), v >= 1, v <= Double(sceneBanks) else { return nil }
            return setBank(Int(v.rounded()))
        case "delete":
            guard let (n, _) = Scenes.ref(m.args) else { return nil }
            return delete(n)
        case "rename":
            guard let (n, i) = Scenes.ref(m.args), let s = str(i), !s.trimmingCharacters(in: .whitespaces).isEmpty else { return nil }
            let nm = String(s.trimmingCharacters(in: .whitespaces).prefix(48))
            return edit(n) { $0.name = nm } ? "scene \(sceneLabel(n)) renamed '\(nm)'" : "scene \(sceneLabel(n)) is empty"
        case "color":
            guard let (n, i) = Scenes.ref(m.args), let s = str(i), s.range(of: "^#[0-9a-fA-F]{6}$", options: .regularExpression) != nil else { return nil }
            return edit(n) { $0.color = s.lowercased() } ? "scene \(sceneLabel(n)) colour \(s)" : "scene \(sceneLabel(n)) is empty"
        case "fade":
            guard let (n, i) = Scenes.ref(m.args), let v = num(i) else { return nil }
            let c = min(60, max(0, v))
            return edit(n) { $0.fade = c } ? String(format: "scene %@ fade %.2f s", sceneLabel(n), c) : "scene \(sceneLabel(n)) is empty"
        case "keepdepth":
            guard let (n, i) = Scenes.ref(m.args), let v = num(i) else { return nil }
            return edit(n) { $0.keepDepth = v != 0 } ? "scene \(sceneLabel(n)) keep depth \(v != 0 ? "on" : "off")" : "scene \(sceneLabel(n)) is empty"
        case "include":
            guard let (n, i) = Scenes.ref(m.args), let v = num(i), v >= 0, v < 16 else { return nil }
            let mask = Int(v)
            return edit(n) { r in r.include = (0..<layerCount).map { mask & (1 << $0) != 0 } }
                ? "scene \(sceneLabel(n)) layers " + ((0..<layerCount).filter { mask & (1 << $0) != 0 }.map { "\($0 + 1)" }.joined(separator: ",")) : "scene \(sceneLabel(n)) is empty"
        default: return nil
        }
    }
}

let gScenes = Scenes()
