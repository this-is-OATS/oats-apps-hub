# oats-hub: NDI multiview + PTZ control in the browser

Finds every NDI source on the LAN, receives each at proxy bandwidth, and serves a web page with a
multiview grid, a big program view, and PTZ controls (joystick, zoom, 8 presets, autofocus) that call the
NDI receiver PTZ functions directly. Free PTZ for any NDI camera that advertises it (oats-cam does).
Selecting a camera lights its NDI tally (program).

    http://<this mac>:7080/          control page: program view + controls + tile strip (phone / tablet / laptop on the LAN)
    http://<this mac>:7080/multiview full-screen multiview for a wall monitor or Display 2: auto grid, names, PTZ/MIC/LIVE tags,
                                     clock. F = fullscreen, 1-9 columns, 0 auto. Click = select + tally, double-click = open the
                                     control page on that camera. Filters: ?only=link,viz  ?hide=vectorworks
    hub.sh start | stop | restart | status | log [N] | build

Settings (`hub.env` or env): HUB_PORT 7080, HUB_PREVIEW_FPS 12, HUB_QUALITY 0.6, HUB_ARCH arm64,
HUB_EXTRA e.g. `--no-tally` or `--full` (full-bandwidth receive instead of the 640x360 proxy).
NDI_CONFIG_DIR defaults to ../oats-m0/ndi-config. Started at login by oats-m0/autostart.sh.

## Controls

- Click a tile to select. Joystick pad: drag = pan/tilt speed, release = stop. Speed slider scales it.
- Zoom: slider = absolute, hold −/+ = zoom speed.
- Presets 1-8: tap recalls, hold 0.7 s stores. Keyboard: arrows, +/−, 1-8 (shift stores), space stops.
- Home = pan 0 tilt 0 zoom out.
- Voice button / key V: speech-only mode on the selected camera's mic (oats-cam voice gate). FEEDBACK badge + toast when
  the sender auto-muted on a howl (last 60 s), with the frequency and event count.
- Audio button / key A: toggles the selected camera's mic into its NDI feed (oats-cam senders; HUB_AUDIO_CTL maps
  source short name -> the sender's UDP control port, default "Link Cam=127.0.0.1:7001"). Tiles show MIC when on.

## API

    GET  /api/sources                       -> {sources:[{id,name,url,connected,ptz,frames,width,height,age_ms,tally}], selected}
    POST /api/select/<id>|none              tally follows the selection (unless --no-tally)
    POST /api/ptz/<id>/speed      {pan,tilt}      -1..1      POST /api/ptz/<id>/abs    {pan,tilt}
    POST /api/ptz/<id>/zoom_speed {zoom}          -1..1      POST /api/ptz/<id>/zoom   {zoom}  0..1
    POST /api/ptz/<id>/store {index}   /recall {index,speed}   /af   /focus {distance}   /wb_auto   /exposure_auto   /stop
    POST /api/audio/<id>/on|off|toggle|status|voice-on|voice-off|voice-toggle -> {ok, audio, voice}   (sources with a control port)
                       source status carries voice, gate_open, feedback_hz, feedback_age_s, feedback_events
    GET  /ws           WebSocket: every source's preview pushed as encoded, binary frames [id len][id utf8][jpeg]
                       (both pages use this; one connection for all tiles, since browsers cap ~6 connections per host)
    GET  /mjpeg/<id>   multipart MJPEG preview        GET /jpeg/<id>   one frame (polling fallback)
    GET  /<file>       static from www/

ids are the NDI name lower-cased with runs of non-alphanumerics as "-": "OBS.HOST (Link Cam)" -> obs-host-link-cam.

## Code

`src/hub.swift` Source (one libndi receiver per NDI name, BGRA proxy frames -> JPEG via ImageIO at
HUB_PREVIEW_FPS, condition-variable fan-out to MJPEG clients, PTZ passthrough, tally) and Hub (finder
thread, drop after 60 s unseen). `src/http.swift` small threaded HTTP/1.1 server. `src/app.swift` routes.
`www/index.html` the page (vanilla JS, pointer events, works on phones).

## Next (phase 2, the public web viewer)

Keep this hub as the control surface and add per-camera H.264 (VideoToolbox) pushed to mediamtx for
WebRTC/HLS to viewers off the LAN. MJPEG previews are LAN-only by design (bandwidth, no audio).

## Tally

- **What "on air" means.** `HUB_TALLY` (hub.env) = `program` (default: selecting a source in the hub puts it ON AIR, red),
  `preview` (selecting only cues it, green; program comes from the real switcher: OBS/DistroAV, vMix or the GoStream set NDI
  program tally themselves and NDI merges every receiver's tally at the sender) or `off`. Use `preview` whenever another
  program switcher is in the show, or the hub's steering would falsely light cameras red.
- **The truth comes from the senders.** Every 300 ms the hub asks each oats-cam (control port) for its merged NDI tally, so
  `/api/sources` `live` / `cued` / `program` / `preview` / `led` reflect what the camera actually sees, from every receiver.
  Other NDI sources fall back to the hub's own selection.
- **On the camera:** oats-cam drives the OBSBOT's status LED (off / full / blink) from the same tally (`CAM_TALLY_LED`).
- **On a phone:** `http://<hub>:7080/tally?id=<source id>` (no id = a picker) is a full-screen red / green / dark page with
  wake lock; tap = fullscreen. Put an old phone or iPad on the camera mount. Ids as in `/api/sources`
  (e.g. `obs-host-link-cam`).
- **To a lighting console (a real red light next to the camera):** `HUB_TALLY_OSC=192.168.1.141:8000` plus
  `HUB_TALLY_ON_CMD='Go+ Sequence "TALLY %s"'` and `HUB_TALLY_OFF_CMD='Off Sequence "TALLY %s"'` (%s = the camera's short name,
  e.g. `Link Cam`) send grandMA3 `/cmd` OSC on every on-air change (MA3: In & Out > OSC, Receive Command on). `/tally/<id>,i,0|1`
  is always sent too for anything else (Companion, a WLED lamp bridge). The MA3 side needs a sequence per camera with a fixture
  pointed at the talent.

## AI tracking (OBSBOT and Insta360 Link)

OBSBOT and Insta360 Link / Link 2 senders start with AI face tracking **on** (`CAM_TRACKING=on` in the profile; `off` / `keep` otherwise), the
"Find a face" button on the hub toggles it, `cam.sh [-p PROFILE] track on|off [framing]` from a shell (OBSBOT framing 0-4, Link 1 head / 2 half / 3 full body; `track recenter` re-centres a Link), `POST /api/track/<id>/on|off|toggle`
over HTTP and `/track/<cam>/on|off|toggle` over OSC. The camera itself drops back to manual whenever the host moves the
gimbal (any pan/tilt from the hub, a preset recall), and the sender does the same for the Link, so press "Find a face" again after framing a shot by hand.
Insta360 Link: extension unit GUID faf1672d-…, selector 2 mode (1 = tracking), selector 19 framing, selector 14 recentre (`src/linktrack.swift`).

## OSC input (consoles and automation)

The hub listens for OSC on UDP `HUB_OSC_PORT` (7081). Same actions as the HTTP API; `<cam>` = a source id, any unique
part of it (`obsbot`, `link`) or `selected`. Numbers may be ints or floats; bundles are unpacked; nothing is replied.

    /ptz/<cam>/recall i [f speed]   /ptz/<cam>/store i      /ptz/<cam>/home          /ptz/<cam>/af
    /ptz/<cam>/abs f pan f tilt     /ptz/<cam>/zoom f       /ptz/<cam>/focus f       (pan/tilt -1..1, zoom 0..1)
    /ptz/<cam>/speed f pan f tilt   /ptz/<cam>/zoom_speed f /ptz/<cam>/stop
    /select <cam> | /select none    /audio/<cam>/on|off|toggle|voice-on|voice-off

- **grandMA3:** an OSC output line to the Mac (192.168.1.148) port 7081, then in a cue `SendOSC 3 "/ptz/obsbot/recall,i,2"`
  (or `"/ptz/obsbot/abs,ff,0.2,0.1"`), so camera framing lives in the lighting cue list and follows its timecode.
- **OBS (Advanced Scene Switcher):** a macro per scene, condition "Scene = Wide", action "Run" with
  `python3 -I ~/Developer/oats-viz/oats-m0/tests/osc_send.py --to 127.0.0.1:7081 /ptz/obsbot/recall i:1`
  (or curl the HTTP API: `curl -s -X POST http://127.0.0.1:7080/api/ptz/obs-host-obsbot-cam/recall -d '{"index":1}'`).
- **Inside OBS:** Docks > Custom Browser Docks, URL `http://127.0.0.1:7080/` (joystick, zoom, presets) and `/multiview`.
- The port is LAN-open like the HTTP API: the lighting network is the trust boundary.
