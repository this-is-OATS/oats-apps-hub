#!/bin/zsh
# VJ VIZZIES installer (the player as a folder, like the OATS NDI HUB): copies this folder to ~/Applications/VJ VIZZIES,
# checks the NDI runtime, writes this Mac's NDI machine name + lighting interface (oats-m0/m0.env), installs the login
# item (com.fooknoats.oatsviz -> autostart.sh) with THIS install's path, puts "VJ VIZZIES.app" (the control window, when
# shipped) in /Applications pointed at this folder, and starts the player + controls.
# Re-running updates in place: scenes.json, mapping.json, mapping/, m0.env, media/ and logs are kept.
#   install.sh [--dry-run] [--yes] [--machine-name NAME] [--lighting-nic en0] [--dest DIR] [--no-start] [--no-app] [--build]
#     --lighting-nic   the interface on the lighting network (sACN / OSC are accepted from it, NDI is pinned to it;
#                      the player refuses to start while it has no address). Default en0.
#     --build          Intel Mac: compile the player for x86_64 here (needs the Xcode Command Line Tools, ~3-5 min)
#                      when the shipped bin/oats-m0 has no x86_64 slice. Asked interactively otherwise.
emulate -L zsh; setopt err_exit pipe_fail null_glob
SRC=${0:A:h}
DEST="$HOME/Applications/VJ VIZZIES"
PLIST="$HOME/Library/LaunchAgents/com.fooknoats.oatsviz.plist"
DRY=0 YES=0 START=1 APP=1 BUILD=0 MNAME="" NIC=""
while (( $# )); do
  case $1 in
    --dry-run) DRY=1 ;;
    --yes|-y) YES=1 ;;
    --machine-name) MNAME=${2:?}; shift ;;
    --lighting-nic|--nic) NIC=${2:?}; shift ;;
    --dest) DEST=${2:?}; shift ;;
    --no-start) START=0 ;;
    --no-app) APP=0 ;;
    --build) BUILD=1 ;;
    -h|--help) sed -n '2,11p' $0; exit 0 ;;
    *) echo "unknown option $1 (see --help)"; exit 64 ;;
  esac; shift
done
export OATS_VIZ_DEST=$DEST
say() { print -r -- "• $*"; }
ARCH=$(uname -m)
echo "VJ VIZZIES $(head -1 $SRC/VERSION) installer ($ARCH, macOS $(sw_vers -productVersion))$( (( DRY )) && echo '   DRY RUN: nothing is changed')"
echo
if [[ -f /usr/local/lib/libndi.dylib ]]; then say "NDI runtime: $( (strings /usr/local/lib/libndi.dylib 2>/dev/null; true) | grep -m1 -oE 'NDI SDK APPLE [^"]*' || echo found)"
else echo "!! NDI runtime not found (/usr/local/lib/libndi.dylib): NDI previs will be off. Install NDI Tools from https://ndi.video/tools/ (shows over HDMI work without it)."; fi
if [[ $ARCH == arm64 ]]; then
  [[ -e /Library/Apple/usr/libexec/oah/libRosettaRuntime ]] && say "Rosetta 2: installed (NDI helper mode)" || echo "!! Rosetta 2 missing: NDI previs falls back to native-soft.  softwareupdate --install-rosetta --agree-to-license"
fi
PARCH=$(/usr/bin/file -b $SRC/oats-m0/bin/oats-m0 | head -1)
say "player binary: ${PARCH#Mach-O 64-bit executable } ($(stat -f '%Sm' -t '%Y-%m-%d %H:%M' $SRC/oats-m0/bin/oats-m0))"
NEEDBUILD=0
if [[ $ARCH == x86_64 && $PARCH != *x86_64* ]]; then
  NEEDBUILD=1
  echo "!! the shipped player has no Intel (x86_64) slice. It must be compiled on this Mac from the included sources:"
  echo "   needs the Xcode Command Line Tools (xcode-select --install), ~600 MB free, 3-5 minutes."
  if (( ! BUILD )) && (( ! YES )) && [[ -t 0 ]]; then read "a?Compile it now? [Y/n] "; [[ ${a:-y} == [Yy]* ]] && BUILD=1; fi
  command -v swiftc >/dev/null || { echo "!! no swiftc: install the Command Line Tools (xcode-select --install) and run install.sh again."; (( DRY )) || exit 1; }
fi

# NDI identity + lighting interface (oats-m0/m0.env, sourced by the shipped m0.sh and autostart.sh)
[[ -f $DEST/oats-m0/m0.env ]] && source $DEST/oats-m0/m0.env
def_name=${OATS_NDI_MACHINE:-$(hostname -s | tr '[:lower:]' '[:upper:]' | tr -c 'A-Z0-9.\n' '-')}
if [[ -z $MNAME ]]; then
  if (( YES )) || [[ ! -t 0 ]]; then MNAME=$def_name
  else read "MNAME?NDI machine name for THIS Mac [$def_name] (must differ from every other Mac on the network): "; MNAME=${MNAME:-$def_name}; fi
fi
MNAME=$(print -r -- "$MNAME" | tr '[:lower:]' '[:upper:]' | tr -c 'A-Z0-9.\n' '-')
if [[ -z $NIC ]]; then
  def_nic=${OATS_NDI_IF:-en0}
  if (( YES )) || [[ ! -t 0 ]]; then NIC=$def_nic
  else
    echo "Network interfaces with an address:"
    for i in $(ifconfig -l); do ip=$(ipconfig getifaddr $i 2>/dev/null) || continue; [[ $ip == 169.254.* ]] && continue
      port=$(networksetup -listallhardwareports 2>/dev/null | grep -B1 "Device: $i$" | head -1 | sed 's/Hardware Port: //'); echo "  $i  $ip  ${port:-}"; done
    read "NIC?Lighting network interface (sACN / OSC accepted from it, NDI pinned to it) [$def_nic]: "; NIC=${NIC:-$def_nic}
  fi
fi
[[ $NIC == none ]] && NIC=en0
ip=$(ipconfig getifaddr $NIC 2>/dev/null || true)
say "NDI machine name: $MNAME  (receivers see \"$MNAME (OATS VIZ Program)\")    lighting interface: $NIC${ip:+ ($ip)}"
[[ -n $ip ]] || echo "!! $NIC has no address right now: the player waits for one at start (plug in the cable / join the network)"

# copy
if [[ -d $DEST ]]; then
  say "updating existing install in $DEST (scenes, mapping, media, m0.env kept)"
  if (( ! DRY )); then "$DEST/oats-m0/gui/run.sh" stop >/dev/null 2>&1 || true; "$DEST/oats-m0/m0.sh" stop >/dev/null 2>&1 || true; "$DEST/oats-m0/m0.sh" ndi stop >/dev/null 2>&1 || true; "$DEST/oats-m0/m0.sh" link stop >/dev/null 2>&1 || true
  else say "[dry-run] would stop the running player / controls in $DEST first"; fi
else say "new install in $DEST"; fi
RSYNC=(rsync -a --delete --exclude 'oats-m0/logs/*' --exclude 'oats-m0/run/*' --exclude 'oats-m0/gui/run/*' --exclude 'oats-m0/ndi-config/*'
       --exclude 'oats-m0/scenes.json' --exclude 'oats-m0/mapping.json' --exclude 'oats-m0/mapping/' --exclude 'oats-m0/m0.env' --exclude 'oats-m0/ndi_order.json' --exclude 'oats-m0/mc/'
       --exclude 'media/' --exclude 'VJ VIZZIES.app' --exclude '.DS_Store')
if (( DRY )); then
  say "[dry-run] would run: ${RSYNC[*]} \"$SRC/\" \"$DEST/\""
  n=$("${RSYNC[@]}" --dry-run --itemize-changes "$SRC/" "$DEST/" 2>/dev/null | grep -c '^[<>c]' || true); say "[dry-run] $n files would be copied"
  [[ -d $SRC/media ]] && say "[dry-run] would copy media/ (clip library) only where $DEST/media has no library.json yet"
  [[ -f $DEST/oats-m0/scenes.json ]] || say "[dry-run] would seed oats-m0/scenes.json from the shipped example"
else
  mkdir -p "$DEST"; "${RSYNC[@]}" "$SRC/" "$DEST/"
  if [[ -d $SRC/media && ! -f $DEST/media/library.json ]]; then rsync -a "$SRC/media/" "$DEST/media/"; say "media/ copied (the shipped example clip library)"; fi
  [[ -f $DEST/oats-m0/scenes.json ]] || cp "$SRC/oats-m0/scenes.json" "$DEST/oats-m0/scenes.json"
  mkdir -p "$DEST/oats-m0/logs" "$DEST/oats-m0/run" "$DEST/oats-m0/ndi-config" "$DEST/media"
  find "$DEST" -exec xattr -d com.apple.quarantine {} + 2>/dev/null || true
  printf '# written by install.sh; sourced by m0.sh and autostart.sh\nOATS_NDI_MACHINE=%s\nOATS_NDI_IF=%s\n' "$MNAME" "$NIC" > "$DEST/oats-m0/m0.env"
fi
say "installed to $DEST"

if (( NEEDBUILD )); then
  if (( BUILD )); then
    if (( DRY )); then say "[dry-run] would compile: cd \"$DEST/oats-m0\" && OATS_BUILD_ONLY=player ./m0.sh build --x86"
    else say "compiling the player for Intel (x86_64) ..."; ( cd "$DEST/oats-m0" && OATS_BUILD_ONLY=player ./m0.sh build --x86 ); fi
  else echo "!! not compiled: the player will not start on this Mac until you run   cd \"$DEST/oats-m0\" && OATS_BUILD_ONLY=player ./m0.sh build --x86"; START=0; fi
fi

# the control window app (universal), pointed at this folder
if (( APP )) && [[ -d "$SRC/VJ VIZZIES.app" ]]; then
  APPDIR=/Applications; [[ -w /Applications ]] || APPDIR="$HOME/Applications"
  if (( DRY )); then say "[dry-run] would copy VJ VIZZIES.app to $APPDIR (quarantine removed) and set its player folder to $DEST/oats-m0"
  else
    mkdir -p "$APPDIR"; rm -rf "$APPDIR/VJ VIZZIES.app"; ditto "$SRC/VJ VIZZIES.app" "$APPDIR/VJ VIZZIES.app"
    find "$APPDIR/VJ VIZZIES.app" -exec xattr -d com.apple.quarantine {} + 2>/dev/null || true
    defaults write com.fooknoats.oatsviz.app M0Dir "$DEST/oats-m0"
    say "VJ VIZZIES.app in $APPDIR (the controls window + menu-bar health dot; it starts the player from $DEST)"
  fi
fi

# login item with THIS install's path (mirrors the show Mac's com.fooknoats.oatsviz.plist)
plist_body() { cat <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.fooknoats.oatsviz</string>
  <key>ProgramArguments</key><array><string>/bin/zsh</string><string>$DEST/autostart.sh</string></array>
  <key>WorkingDirectory</key><string>$DEST/oats-m0</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string></dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><false/>
  <key>AbandonProcessGroup</key><true/>
  <key>ProcessType</key><string>Interactive</string>
  <key>StandardOutPath</key><string>$DEST/oats-m0/logs/autostart.log</string>
  <key>StandardErrorPath</key><string>$DEST/oats-m0/logs/autostart.log</string>
</dict></plist>
PL
}
if (( DRY )); then say "[dry-run] would write $PLIST (runs $DEST/autostart.sh at login) and launchctl load it"
else mkdir -p ${PLIST:h}; plist_body > "$PLIST"; launchctl unload "$PLIST" 2>/dev/null || true; launchctl load "$PLIST"; fi
say "login item (com.fooknoats.oatsviz): starts the player and the controls at login"
if (( START )); then
  if (( DRY )); then say "[dry-run] would start now: $DEST/autostart.sh now"; else "$DEST/autostart.sh" now; fi
fi
echo
ip=${ip:-localhost}
cat <<TXT
Done. Controls:  http://$ip:8090   (this Mac and the lighting network)   NDI previs: "$MNAME (OATS VIZ Program)"
Player: "$DEST/oats-m0/m0.sh" status | stop | start --no-ndi-meta --universe 5 | log     Controls: oats-m0/gui/run.sh status
Output: full screen on the HDMI display from the controls (Output) or  --output-display N  in autostart.sh.
Clips: $DEST/media (library.json + bank folders; the controls' clip grid uploads into it). Scenes: oats-m0/scenes.json.
Allow when macOS asks for the local network (sACN, OSC, NDI) and, with Audio react > Device, the microphone.
TXT
