#!/bin/zsh
# OATS NDI HUB login item: waits for the network, then starts the hub, the camera sender for the default "link" profile
# (if the camera is present; it keeps retrying until it is), every extra camera profile (one per oats-cam/cam.<name>.env)
# and the display sender (if oats-screen/ENABLED exists). "autostart.sh now" skips the login wait.
D=${0:A:h}
[[ ${1:-} == now ]] || sleep 15
for i in {1..60}; do ipconfig getifaddr en0 >/dev/null 2>&1 || ipconfig getifaddr en1 >/dev/null 2>&1 && break; sleep 2; done
echo "$(date '+%F %T') autostart"
$D/ndi-config.sh            # machine name + adapter pin for this install (suite.env), re-derived at every start
$D/oats-hub/hub.sh start
$D/oats-cam/cam.sh start
for e in $D/oats-cam/cam.*.env(N); do   # extra cameras: one profile per cam.<name>.env (e.g. cam.obsbot.env)
  p=${${e:t}#cam.}; p=${p%.env}
  $D/oats-cam/cam.sh -p $p start
done
[[ -f $D/oats-screen/ENABLED ]] && $D/oats-screen/screen.sh start
exit 0
