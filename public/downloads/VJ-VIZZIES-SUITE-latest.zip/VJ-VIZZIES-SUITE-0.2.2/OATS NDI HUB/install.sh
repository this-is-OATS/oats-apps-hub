#!/bin/zsh
# OATS NDI HUB installer: copies this folder to ~/Applications/OATS NDI HUB, checks the NDI runtime (and Rosetta on Apple
# Silicon), writes this install's NDI machine name + adapter pin, installs the login item (autostart) and starts everything.
# Re-running updates an existing install in place: cam.env, cam.*.env, presets*.json, audio.json, hub.env, screen.env,
# ndi-config/ and suite.env are kept.
#   install.sh [--dry-run] [--yes] [--machine-name NAME] [--lighting-nic en0|none] [--dest DIR] [--no-start]
#     --dry-run        print what would be done, change nothing
#     --yes            no questions (defaults: machine name = this Mac's hostname upper-cased, no adapter pin)
#     --machine-name   the NDI machine name of THIS Mac ("LAPTOP (Link Cam)"); every Mac on the network needs its own
#     --lighting-nic   pin NDI to that interface's address (en0, en1 ...; `none` = all adapters). Also the interface the
#                      player (VJ VIZZIES) should use for sACN / OSC: its own setup asks the same question.
emulate -L zsh; setopt err_exit pipe_fail null_glob
SRC=${0:A:h}
DEST="$HOME/Applications/OATS NDI HUB"
PLIST="$HOME/Library/LaunchAgents/com.fooknoats.oatsndihub.plist"
DRY=0 YES=0 START=1 MNAME="" NIC=""
while (( $# )); do
  case $1 in
    --dry-run) DRY=1 ;;
    --yes|-y) YES=1 ;;
    --machine-name) MNAME=${2:?}; shift ;;
    --lighting-nic|--nic) NIC=${2:?}; shift ;;
    --dest) DEST=${2:?}; shift ;;
    --no-start) START=0 ;;
    -h|--help) sed -n '2,11p' $0; exit 0 ;;
    *) echo "unknown option $1 (see --help)"; exit 64 ;;
  esac; shift
done
export OATS_HUB_DEST=$DEST
say() { print -r -- "• $*"; }
do_() { if (( DRY )); then print -r -- "  [dry-run] $*"; else "$@"; fi }
ARCH=$(uname -m)
echo "OATS NDI HUB $(head -1 $SRC/VERSION) installer ($ARCH, macOS $(sw_vers -productVersion))$( (( DRY )) && echo '   DRY RUN: nothing is changed')"
echo
# requirements
if [[ -f /usr/local/lib/libndi.dylib ]]; then
  say "NDI runtime: $( (strings /usr/local/lib/libndi.dylib 2>/dev/null; true) | grep -m1 -oE 'NDI SDK APPLE [^"]*' || echo found)"
else
  echo "!! NDI runtime not found (/usr/local/lib/libndi.dylib). Install NDI Tools from https://ndi.video/tools/ then run this again."
  (( DRY )) || exit 1
fi
if [[ $ARCH == arm64 ]]; then
  if [[ -e /Library/Apple/usr/libexec/oah/libRosettaRuntime ]]; then say "Rosetta 2: installed"
  else echo "!! Rosetta 2 is needed by the camera and display senders on Apple Silicon:  softwareupdate --install-rosetta --agree-to-license"; echo "   (the hub itself runs without it). Continuing."; fi
else
  say "Intel Mac: everything runs natively (no Rosetta needed; the hub binary is universal, the senders are x86_64)"
fi
for b in oats-hub/bin/oats-hub oats-cam/bin/oats-cam oats-screen/bin/oats-screen; do
  a=$(/usr/bin/file -b $SRC/$b | head -1)
  case $ARCH in
    arm64) [[ $a == *arm64* || $a == *x86_64* ]] || echo "!! $b: $a" ;;
    *)     [[ $a == *x86_64* ]] || echo "!! $b has no x86_64 slice ($a): it will not run on this Mac" ;;
  esac
done

# this install's NDI identity (suite.env -> ndi-config.sh -> ndi-config/ndi-config.v1.json, read via NDI_CONFIG_DIR)
if [[ -f $DEST/suite.env ]]; then source $DEST/suite.env; fi
def_name=${NDI_MACHINE:-$(hostname -s | tr '[:lower:]' '[:upper:]' | tr -c 'A-Z0-9.\n' '-')}
if [[ -z $MNAME ]]; then
  if (( YES )) || [[ ! -t 0 ]]; then MNAME=$def_name
  else read "MNAME?NDI machine name for THIS Mac [$def_name] (must differ from every other Mac on the network): "; MNAME=${MNAME:-$def_name}; fi
fi
MNAME=$(print -r -- "$MNAME" | tr '[:lower:]' '[:upper:]' | tr -c 'A-Z0-9.\n' '-')
if [[ -z $NIC ]]; then
  def_nic=${NDI_IF:-none}
  if (( YES )) || [[ ! -t 0 ]]; then NIC=$def_nic
  else
    echo "Network interfaces with an address:"
    for i in $(ifconfig -l); do ip=$(ipconfig getifaddr $i 2>/dev/null) || continue; [[ $ip == 169.254.* ]] && continue
      port=$(networksetup -listallhardwareports 2>/dev/null | grep -B1 "Device: $i$" | head -1 | sed 's/Hardware Port: //'); echo "  $i  $ip  ${port:-}"; done
    read "NIC?Pin NDI to one interface (the lighting / NDI network; 'none' = all adapters) [$def_nic]: "; NIC=${NIC:-$def_nic}
  fi
fi
[[ $NIC == none ]] && NIC=""
ip=""
if [[ -n $NIC ]]; then ip=$(ipconfig getifaddr $NIC 2>/dev/null || true); [[ -n $ip && $ip != 169.254.* ]] || { echo "!! $NIC has no usable IPv4 address right now; NDI would be pinned to nothing. Continuing (the pin is re-derived at every start)."; ip=""; }; fi
say "NDI machine name: $MNAME    adapter pin: ${NIC:-none (all adapters)}${ip:+ ($ip)}"

# copy (an update keeps the user's settings: excluded from the transfer AND from --delete)
if [[ -d $DEST ]]; then
  say "updating existing install in $DEST (settings, presets, profiles kept)"
  if (( ! DRY )); then
    for e in "$DEST"/oats-cam/cam.*.env; do p=${${e:t}#cam.}; p=${p%.env}; "$DEST/oats-cam/cam.sh" -p $p stop >/dev/null 2>&1 || true; done
    for m in oats-hub oats-cam oats-screen; do "$DEST/$m/"*.sh stop >/dev/null 2>&1 || true; done
  else say "[dry-run] would stop the running hub / senders in $DEST first"; fi
else
  say "new install in $DEST"
fi
RSYNC=(rsync -a --delete --exclude 'logs/*' --exclude 'run/*' --exclude 'oats-cam/cam.env' --exclude 'oats-cam/cam.*.env'
       --exclude 'oats-cam/presets*.json' --exclude 'oats-cam/audio.json' --exclude 'oats-hub/hub.env' --exclude 'oats-screen/screen.env'
       --exclude 'oats-screen/ENABLED' --exclude 'ndi-config/' --exclude 'suite.env' --exclude '.DS_Store')
if (( DRY )); then
  say "[dry-run] would run: ${RSYNC[*]} \"$SRC/\" \"$DEST/\""
  n=$("${RSYNC[@]}" --dry-run --itemize-changes "$SRC/" "$DEST/" 2>/dev/null | grep -c '^[<>c]' || true); say "[dry-run] $n files would be copied"
else
  mkdir -p "$DEST"; "${RSYNC[@]}" "$SRC/" "$DEST/"
  find "$DEST" -exec xattr -d com.apple.quarantine {} + 2>/dev/null || true
fi
[[ -f $DEST/oats-hub/hub.env ]] || { say "seeding oats-hub/hub.env from oats-hub/examples/hub.env (HUB_AUDIO_CTL for Link Cam + OBSBOT Cam, HUB_TALLY=program)"; do_ cp "$SRC/oats-hub/examples/hub.env" "$DEST/oats-hub/hub.env"; }
# suite.env + NDI config
if (( DRY )); then say "[dry-run] would write $DEST/suite.env: NDI_MACHINE=$MNAME NDI_IF=$NIC, then ndi-config/ndi-config.v1.json via ndi-config.sh"
else
  printf '# written by install.sh; read by ndi-config.sh at every start\nNDI_MACHINE=%s\nNDI_IF=%s\n' "$MNAME" "$NIC" > "$DEST/suite.env"
  "$DEST/ndi-config.sh"
fi
say "installed to $DEST"

# login item
plist_body() { cat <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.fooknoats.oatsndihub</string>
  <key>ProgramArguments</key><array><string>/bin/zsh</string><string>$DEST/autostart.sh</string></array>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string></dict>
  <key>RunAtLoad</key><true/>
  <key>StandardOutPath</key><string>$DEST/oats-hub/logs/autostart.log</string>
  <key>StandardErrorPath</key><string>$DEST/oats-hub/logs/autostart.log</string>
</dict></plist>
PL
}
if (( DRY )); then say "[dry-run] would write $PLIST (runs $DEST/autostart.sh at login) and launchctl load it"
else
  mkdir -p ${PLIST:h}; plist_body > "$PLIST"
  launchctl unload "$PLIST" 2>/dev/null || true
  launchctl load "$PLIST"
fi
say "login item (com.fooknoats.oatsndihub): starts the hub, the Link Cam sender, every oats-cam/cam.<name>.env profile and the display sender (if enabled) at login"
if (( START )); then
  if (( DRY )); then say "[dry-run] would start now: $DEST/autostart.sh now"
  else "$DEST/autostart.sh" now; fi
fi
echo
ip=$(ipconfig getifaddr ${NIC:-en0} 2>/dev/null || ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo localhost)
cat <<TXT
Done. Hub:  http://$ip:7080/    multiview:  http://$ip:7080/multiview    tally page:  http://$ip:7080/tally    OSC in: udp $ip:7081
NDI sources from this Mac appear as "$MNAME (Link Cam)", "$MNAME (OBSBOT Cam)" ...

CAMERA PERMISSION, FIRST TIME ON THIS MAC: macOS grants the camera and the microphone to the app that STARTS the sender.
  Start it once from Terminal and click Allow:     "$DEST/oats-cam/cam.sh" restart
  (the login item then inherits that; a sender started from another tool's shell gets no camera and exits 77)
Extra camera (OBSBOT ...): cp "$DEST/oats-cam/examples/cam.obsbot.env" "$DEST/oats-cam/";  "$DEST/oats-cam/cam.sh" -p obsbot start
  One camera per USB port (a hub shares bandwidth). Close OBSBOT Center / Insta360 Link Controller: their tracking fights remote PTZ.
Camera sender: "$DEST/oats-cam/cam.sh" status     Hub: "$DEST/oats-hub/hub.sh" status     Settings: oats-cam/cam.env, oats-hub/hub.env
Display sender: off by default; enable with  touch "$DEST/oats-screen/ENABLED"  then  "$DEST/oats-screen/screen.sh" start
TXT
