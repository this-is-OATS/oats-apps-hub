import Foundation

/// AI face tracking on the camera itself ("Find a face" on the hub). One interface, two cameras:
/// TallyLED (OBSBOT, vendor channel tag 0x16) and LinkTracking (Insta360 Link / Link 2, extension unit below).
protocol AITracker: AnyObject {
    var tracking: Bool? { get }            // last known state (nil = never set / unknown)
    var framing: UInt8 { get set }
    var framingRange: ClosedRange<UInt8> { get }
    var kind: String { get }
    @discardableResult func setTracking(_ on: Bool, _ via: String) -> Bool
    var trackingText: String { get }
}
extension TallyLED: AITracker {
    var framingRange: ClosedRange<UInt8> { 0...4 }
    var kind: String { "obsbot" }
}

/// Insta360 Link / Link 2: extension unit GUID faf1672d-b71b-4793-8c91-7b1c9b7f95f8 (unit 9 on our Link 2).
/// Selector 2 is the mode control (GET_LEN bytes, 61 on the Link 2): write a zeroed buffer with byte[0] = mode,
/// byte[1] = flag; mode 1/0 = AI tracking on, 0/0 = normal. Read-back byte[0] is 0xff while tracking is on, 0 when off
/// (verified on our Link 2 2026-11-02: the camera levelled itself the moment tracking went on). Selector 19 (1 byte) is the
/// framing: 1 head, 2 half body, 3 full body. Selector 14 (1 byte, write 1) re-centres the gimbal.
/// Map from vrwallace/Insta360-Link-1-and-2-Controller-for-Linux (confirmed there by watching the official app on Windows).
final class LinkTracking: AITracker {
    static let guid: [UInt8] = [0x2d, 0x67, 0xf1, 0xfa, 0x1b, 0xb7, 0x93, 0x47, 0x8c, 0x91, 0x7b, 0x1c, 0x9b, 0x7f, 0x95, 0xf8]
    let dev: OpaquePointer
    let q: DispatchQueue
    let unit: UInt8
    /// The firmware swings the gimbal to its centre view the moment tracking goes on (seen on our Link 2 2026-11-05). With a
    /// PTZ object we read the position just before and hold it there for a moment, so the search starts where the camera was.
    weak var ptz: PTZ?
    var holdPosition = true
    /// Lost-target scan (--scan): the firmware tells us nothing about the gimbal (UVC GET_CUR echoes what the host last set,
    /// no extension-unit selector changes with the pose: checked 2026-11-05), so we watch the picture instead (FaceWatch).
    /// Tracking on and no face for scanLostAfter s = lost: we tilt up to scanTilt and pan limit to limit (scanPeriod s per cycle)
    /// starting the way the face left, until a face is back in the picture (the firmware takes it from there) or tracking is off.
    var scan = true
    var scanTilt: Double = 0, scanLostAfter: Double = 3, scanPeriod: Double = 16, scanRange: Double = 90   // scanTilt: degrees up, negative = down (this camera sits above the people); pan ±range° (the limits stare at walls)
    var faces: FaceWatch? = nil
    private var scanGen: UInt64 = 0
    private(set) var scanning = false, scans: UInt64 = 0, steps: UInt64 = 0
    private(set) var tracking: Bool? = nil
    var framing: UInt8 = 0                 // 0 = leave the camera's own setting
    var framingRange: ClosedRange<UInt8> { 1...3 }
    var kind: String { "link" }
    private(set) var writes: UInt64 = 0, errors: UInt64 = 0
    private var modeLen: UInt16 = 61

    init?(dev: OpaquePointer, queue: DispatchQueue) {
        var found: Int? = nil
        for i in 0..<Int(uvc_xu_count(dev)) {
            var id: Int32 = 0, nc: Int32 = 0, csz: Int32 = 0, bm: UInt32 = 0; var g = [UInt8](repeating: 0, count: 16)
            guard uvc_xu_info(dev, Int32(i), &id, &g, &nc, &csz, &bm) == 0 else { continue }
            if g == LinkTracking.guid { found = Int(id); break }
        }
        guard let u = found else { return nil }
        self.dev = dev; self.q = queue; self.unit = UInt8(u)
        var len: UInt16 = 0; var kr: Int32 = 0
        if uvc_get(dev, unit, 2, UInt8(UVC_GET_LEN), &len, 2, &kr) == 2, len > 2, len <= 512 { modeLen = UInt16(littleEndian: len) }
        tracking = nil   // ours, not the firmware's
        olog("tracking: Insta360 Link AI tracking on extension unit \(u) (mode selector 2, \(modeLen) bytes), camera reports \(tracking.map { $0 ? "ON" : "off" } ?? "unknown")")
    }

    /// Ask the camera (selector 2 byte 0: 0xff / 1 = tracking on).
    func readTracking() -> Bool? {
        var buf = [UInt8](repeating: 0, count: Int(modeLen)); var kr: Int32 = 0
        var r: Int32 = -1
        q.sync { r = uvc_get(dev, unit, 2, UInt8(UVC_GET_CUR), &buf, modeLen, &kr) }
        guard r > 0 else { return nil }
        return buf[0] != 0
    }

    /// "Find a face": the sender's own tracker (FaceWatch + absolute pan/tilt), not the firmware's. The firmware's AI tracking
    /// recentres the gimbal on every enable, drops it on loss and dies on any host pan/tilt write (checked 2026-11-05), so we
    /// write its mode OFF and steer ourselves: keep the face centred, scan when it is gone, never recentre.
    @discardableResult func setTracking(_ on: Bool, _ via: String) -> Bool {
        var buf = [UInt8](repeating: 0, count: Int(modeLen)); buf[0] = 0x00; buf[1] = 0x00
        var kr: Int32 = 0; var ok = false
        q.sync { ok = uvc_set(dev, unit, 2, buf, modeLen, &kr) >= 0 }   // firmware tracking off (we drive)
        if !ok { errors &+= 1; olog("tracking: mode write failed IOKit 0x\(String(UInt32(bitPattern: kr), radix: 16)) (\(via))") }
        writes &+= 1
        let was = tracking; tracking = on
        scanGen &+= 1; scanning = false
        if on, ptz != nil, faces != nil { let gen = scanGen; Thread { self.monitor(gen, settle: 0) }.start() }
        if was != on || via == "start" { olog("tracking: \(on ? "ON (find a face: own tracker, scan \(scan ? "on" : "off"))" : "off") (\(via))") }
        return true
    }

    /// The tracker loop (one per "tracking on"; a newer generation or tracking off ends it), 10 Hz. It drives the gimbal the way
    /// the joystick does (speed, integrated at 20 Hz by PTZ: smooth, and PTZ.pan/tilt stay true): speed proportional to how far
    /// the face is from the centre; no face for scanLostAfter s -> scan (if enabled), a face ends the scan.
    var gain = 3.0, deadband = 0.05
    var tiltMaxDown: Double = 22   // the tracker never tilts further down than this (degrees; the room's floor line)
    var parkZone = 0.18          // parked (centred once): no moves until the person is this far from centre
    private(set) var parked = false
    private var lastTrackTilt: Int32? = nil   // where the person was, vertically: the search goes back there
    private func monitor(_ gen: UInt64, settle: Double) {
        guard let z = ptz, let fw = faces else { return }
        fw.intervalMs = 150
        var armed = Date(), lastLog = Date(timeIntervalSince1970: 0)
        defer { z.drive(0, 0) }
        while tracking == true, scanGen == gen {
            usleep(100_000)
            let since = fw.lastSeen.map { Date().timeIntervalSince($0) } ?? .infinity
            if since < 0.5 {
                // Link 2 axes (measured 2026-11-05): +pan turns the camera LEFT, +tilt points it DOWN
                let ex = fw.lastX - 0.5, ey = fw.lastY - 0.5
                // park once centred: a person who stands still gets a still camera; move again only when they leave the zone
                if parked, abs(ex) < parkZone, abs(ey) < parkZone { z.drive(0, 0); continue }
                if abs(ex) <= deadband, abs(ey) <= deadband { if !parked { olog("tracking: centred, parked at \(z.pan / 3600)°/\(z.tilt / 3600)°") }; parked = true; lastTrackTilt = z.tilt; z.drive(0, 0); continue }
                parked = false
                let ps = abs(ex) > deadband ? max(-1, min(1, -ex * gain)) : 0
                var ts = abs(ey) > deadband ? max(-1, min(1, -ey * gain)) : 0
                if ts > 0, Double(z.tilt) / 3600 >= tiltMaxDown { ts = 0 }   // +tilt is down: stop at the floor line
                z.drive(ps, ts); steps &+= 1
                if Date().timeIntervalSince(lastLog) > 2 { lastLog = Date(); olog("tracking: face x \(String(format: "%.2f", fw.lastX)) y \(String(format: "%.2f", fw.lastY)) -> speed \(String(format: "%+.2f/%+.2f", ps, ts)) at \(z.pan / 3600)°/\(z.tilt / 3600)°") }
            } else if scan, since >= scanLostAfter, Date().timeIntervalSince(armed) >= scanLostAfter {
                parked = false; runScan(gen, dir: fw.exitDir); armed = Date().addingTimeInterval(4)
            } else { z.drive(0, 0) }
        }
    }
    /// Pan across ±scanRange at the joystick's speed (scanSpeed of full rate), the way the face left first, tilted scanTilt° up.
    /// Ends when a face is in the picture.
    var scanSpeed = 0.35
    /// Pan ranges (degrees, +pan is left) the search jumps across instead of sweeping: walls, a shelf of posters, a doorway.
    var skipZones: [(Double, Double)] = []
    private func runScan(_ gen: UInt64, dir: Double) {
        guard let z = ptz, let fw = faces else { return }
        scanning = true; scans &+= 1
        let lim = Int32(scanRange * 3600), hi = min(lim, z.panMax), lo = max(-lim, z.panMin)
        // scanTilt 0 = keep the tilt the person was last tracked at (15° down until someone has been tracked: at a cold start the
        // camera's reported tilt is meaningless); else scanTilt° up, absolute (+tilt is down on the Link). Never below the floor line.
        var tilt = scanTilt == 0 ? (lastTrackTilt ?? 15 * 3600) : Int32(-scanTilt * 3600)
        tilt = min(tilt, Int32(tiltMaxDown * 3600))
        if tilt != z.tilt { z.holdPanTilt(z.pan, tilt) }
        var d = dir, wasInZone = false
        olog("tracking: no face for \(Int(scanLostAfter)) s: scanning \(d < 0 ? "left" : "right") first, pan ±\(Int(scanRange))°, tilt \(tilt / 3600)°, \(Int(scanSpeed * z.panRateDeg))°/s")
        while tracking == true, scanGen == gen {
            if let s = fw.lastSeen, Date().timeIntervalSince(s) < 1 { z.drive(0, 0); olog("tracking: scan ended, a face is back (x \(String(format: "%.2f", fw.lastX)) at pan \(z.pan / 3600)°): tracking it"); break }
            if z.pan >= hi - 1800 { d = 1 } else if z.pan <= lo + 1800 { d = -1 }   // +pan is the left end
            let deg = Double(z.pan) / 3600
            let inZone = skipZones.contains { deg > $0.0 && deg < $0.1 }   // inside a skip zone: no stop, no jump, just cross it at full speed
            if inZone != wasInZone { wasInZone = inZone; if inZone { olog("tracking: scan crossing a skip zone at full speed") } }
            let sp = inZone ? 1.0 : scanSpeed
            z.drive(d > 0 ? -sp : sp, 0)   // +speed turns the camera left: "right" (d > 0) is negative
            usleep(100_000)
        }
        z.drive(0, 0); scanning = false
    }

    /// Raw GET_CUR of an extension-unit selector: hex bytes and, when the length allows, little-endian floats (diagnosis).
    func dumpSelector(_ sel: UInt8) -> String {
        var len: UInt16 = 0; var kr: Int32 = 0
        var r: Int32 = -1
        q.sync { r = uvc_get(dev, unit, sel, UInt8(UVC_GET_LEN), &len, 2, &kr) }
        guard r == 2, len > 0, len <= 512 else { return "xu \(sel): no length (r=\(r) kr=0x\(String(UInt32(bitPattern: kr), radix: 16)))" }
        var buf = [UInt8](repeating: 0, count: Int(len))
        q.sync { r = uvc_get(dev, unit, sel, UInt8(UVC_GET_CUR), &buf, len, &kr) }
        guard r > 0 else { return "xu \(sel) len \(len): read failed kr=0x\(String(UInt32(bitPattern: kr), radix: 16))" }
        let hex = buf.map { String(format: "%02x", $0) }.joined(separator: " ")
        var floats = ""
        if len % 4 == 0 { floats = " floats " + stride(from: 0, to: Int(len), by: 4).map { i in String(format: "%.3g", buf[i..<i+4].withUnsafeBytes { $0.loadUnaligned(as: Float.self) }) }.joined(separator: " ") }
        return "xu \(sel) len \(len): \(hex)\(floats)"
    }

    /// Gimbal re-centre (selector 14).
    func recenter() { var one: UInt8 = 1; var kr: Int32 = 0; q.sync { _ = uvc_set(dev, unit, 14, &one, 1, &kr) } }

    /// off | searching | tracking | parked
    var state: String { tracking != true ? "off" : scanning ? "searching" : parked ? "parked" : "tracking" }
    var trackingText: String { "tracking=\(tracking.map { $0 ? "on" : "off" } ?? "unknown") framing=\(framing) kind=link state=\(state)\(tracking == true ? (faces?.boxText ?? "") : "")" }
    func statusDict() -> [String: Any] { ["kind": "link", "on": (tracking as Any?) ?? NSNull(), "framing": Int(framing), "unit": Int(unit), "writes": Int(writes), "errors": Int(errors), "scanning": scanning, "scans": Int(scans), "faces": faces?.text ?? "off"] }
}
