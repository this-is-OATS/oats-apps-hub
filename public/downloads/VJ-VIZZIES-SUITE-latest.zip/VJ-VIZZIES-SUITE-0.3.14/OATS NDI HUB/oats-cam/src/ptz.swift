import Foundation

/// NDI PTZ commands (metadata XML from receivers) -> UVC camera-terminal controls.
/// The Link 2 has absolute pan/tilt/zoom only, so speed ("joystick") moves are emulated by stepping the absolute position.
final class PTZ {
    struct Preset: Codable { var pan: Int32; var tilt: Int32; var zoom: Int16 }
    let dev: OpaquePointer
    let ct: UInt8
    let q = DispatchQueue(label: "oats-cam.ptz", qos: .userInitiated)
    // ranges (arcseconds for pan/tilt; device units for zoom/focus)
    var panMin: Int32 = -1, panMax: Int32 = 1, tiltMin: Int32 = -1, tiltMax: Int32 = 1
    var zoomMin: Int16 = 0, zoomMax: Int16 = 1, focusMin: Int16 = 0, focusMax: Int16 = 1
    var hasPanTilt = false, hasZoom = false, hasFocus = false, hasAutoFocus = false
    // tracked target position and joystick speeds
    var pan: Int32 = 0, tilt: Int32 = 0, zoom: Int16 = 0
    var panSpeed = 0.0, tiltSpeed = 0.0, zoomSpeed = 0.0
    var panRate: Double, tiltRate: Double, zoomRate: Double   // full-speed rates: deg/s, deg/s, fraction of zoom range per s
    private var moving = false
    private var lastSentPan: Int32 = .min, lastSentTilt: Int32 = .min, lastSentZoom: Int16 = .min
    private var lastTickNs: UInt64 = 0
    private var timer: DispatchSourceTimer?
    private(set) var commands: UInt64 = 0, unknown: UInt64 = 0, uvcErrors: UInt64 = 0
    private(set) var lastCommand = ""
    var presetsPath: String
    private var presets: [Int: Preset] = [:]

    init?(vid: Int, pid: Int, presetsPath: String, panRate: Double, tiltRate: Double, zoomRate: Double) {
        var err = [CChar](repeating: 0, count: 256)
        guard let d = uvc_open(UInt16(vid), UInt16(pid), &err, err.count) else { olog("ptz: uvc_open failed: \(String(cString: err))"); return nil }
        dev = d
        ct = UInt8(uvc_camera_terminal(d))
        self.presetsPath = presetsPath
        self.panRate = panRate; self.tiltRate = tiltRate; self.zoomRate = zoomRate
        let note = String(cString: uvc_last_error(d))
        olog("ptz: uvc device \(String(format: "%04x:%04x", vid, pid)) VC interface \(uvc_interface_number(d)) camera terminal \(ct) controls 0x\(String(uvc_ct_controls(d), radix: 16))\(note.isEmpty ? "" : " (\(note))")")
        readRanges()
        loadPresets()
    }

    private func get32x2(_ cs: UInt8, _ req: UInt8) -> (Int32, Int32)? {
        var b = [UInt8](repeating: 0, count: 8); var kr: Int32 = 0
        guard uvc_get(dev, ct, cs, req, &b, 8, &kr) == 8 else { return nil }
        let a = b.withUnsafeBytes { $0.load(fromByteOffset: 0, as: Int32.self) }, c = b.withUnsafeBytes { $0.load(fromByteOffset: 4, as: Int32.self) }
        return (Int32(littleEndian: a), Int32(littleEndian: c))
    }
    private func get16(_ cs: UInt8, _ req: UInt8) -> Int16? {
        var v: Int16 = 0; var kr: Int32 = 0
        guard uvc_get(dev, ct, cs, req, &v, 2, &kr) == 2 else { return nil }
        return Int16(littleEndian: v)
    }
    private func readRanges() {
        if let mn = get32x2(UInt8(UVC_CT_PANTILT_ABSOLUTE), UInt8(UVC_GET_MIN)), let mx = get32x2(UInt8(UVC_CT_PANTILT_ABSOLUTE), UInt8(UVC_GET_MAX)) {
            panMin = mn.0; tiltMin = mn.1; panMax = mx.0; tiltMax = mx.1; hasPanTilt = panMax > panMin
            if let cur = get32x2(UInt8(UVC_CT_PANTILT_ABSOLUTE), UInt8(UVC_GET_CUR)) { pan = cur.0; tilt = cur.1 }
        }
        if let mn = get16(UInt8(UVC_CT_ZOOM_ABSOLUTE), UInt8(UVC_GET_MIN)), let mx = get16(UInt8(UVC_CT_ZOOM_ABSOLUTE), UInt8(UVC_GET_MAX)) {
            zoomMin = mn; zoomMax = mx; hasZoom = mx > mn
            if let cur = get16(UInt8(UVC_CT_ZOOM_ABSOLUTE), UInt8(UVC_GET_CUR)) { zoom = cur }
        }
        if let mn = get16(UInt8(UVC_CT_FOCUS_ABSOLUTE), UInt8(UVC_GET_MIN)), let mx = get16(UInt8(UVC_CT_FOCUS_ABSOLUTE), UInt8(UVC_GET_MAX)) { focusMin = mn; focusMax = mx; hasFocus = mx > mn }
        var b: UInt8 = 0; var kr: Int32 = 0
        hasAutoFocus = uvc_get(dev, ct, UInt8(UVC_CT_FOCUS_AUTO), UInt8(UVC_GET_INFO), &b, 1, &kr) == 1
        olog("ptz: pan \(panMin)..\(panMax) tilt \(tiltMin)..\(tiltMax) arcsec (\(panMin / 3600)°..\(panMax / 3600)° / \(tiltMin / 3600)°..\(tiltMax / 3600)°) zoom \(zoomMin)..\(zoomMax) focus \(focusMin)..\(focusMax) autofocus=\(hasAutoFocus) now pan \(pan) tilt \(tilt) zoom \(zoom)")
    }

    func start() {
        let t = DispatchSource.makeTimerSource(queue: q)
        t.schedule(deadline: .now(), repeating: .milliseconds(50))   // 20 Hz integration
        t.setEventHandler { [weak self] in self?.tick() }
        t.resume(); timer = t
    }

    /// The camera's real pan/tilt (arcseconds), read on the PTZ queue. nil without pan/tilt.
    func readPanTilt() -> (Int32, Int32)? {
        guard hasPanTilt else { return nil }
        var r: (Int32, Int32)? = nil
        q.sync { r = get32x2(UInt8(UVC_CT_PANTILT_ABSOLUTE), UInt8(UVC_GET_CUR)) }
        return r
    }
    /// Drive like the joystick does (speeds -1..1 of panRate/tiltRate): the tick integrates them at 20 Hz, so `pan`/`tilt`
    /// stay a true record of where the gimbal is. Not a "manual" move.
    func drive(_ ps: Double, _ ts: Double) { q.sync { panSpeed = ps; tiltSpeed = ts } }
    var panRateDeg: Double { panRate }
    /// Put the gimbal back at p/t (arcseconds), forcing the write even if it is what we last sent. Not a "manual" move.
    func holdPanTilt(_ p: Int32, _ t: Int32) {
        q.sync { pan = p; tilt = t; clampAll(); lastSentPan = .min; sendPanTilt() }
    }

    private func sendPanTilt() {
        guard hasPanTilt, pan != lastSentPan || tilt != lastSentTilt else { return }
        var b = [UInt8](repeating: 0, count: 8)
        b.withUnsafeMutableBytes { $0.storeBytes(of: pan.littleEndian, toByteOffset: 0, as: Int32.self); $0.storeBytes(of: tilt.littleEndian, toByteOffset: 4, as: Int32.self) }
        var kr: Int32 = 0
        if uvc_set(dev, ct, UInt8(UVC_CT_PANTILT_ABSOLUTE), b, 8, &kr) < 0 { uvcErrors &+= 1; if uvcErrors < 5 || uvcErrors % 100 == 0 { olog("ptz: pan/tilt set failed IOKit 0x\(String(UInt32(bitPattern: kr), radix: 16)) (\(uvcErrors))") } }
        else { lastSentPan = pan; lastSentTilt = tilt }
    }
    private func sendZoom() {
        guard hasZoom, zoom != lastSentZoom else { return }
        var z = zoom.littleEndian; var kr: Int32 = 0
        if uvc_set(dev, ct, UInt8(UVC_CT_ZOOM_ABSOLUTE), &z, 2, &kr) < 0 { uvcErrors &+= 1; if uvcErrors < 5 || uvcErrors % 100 == 0 { olog("ptz: zoom set failed IOKit 0x\(String(UInt32(bitPattern: kr), radix: 16)) (\(uvcErrors))") } }
        else { lastSentZoom = zoom }
    }
    private func clampAll() {
        pan = min(max(pan, panMin), panMax); tilt = min(max(tilt, tiltMin), tiltMax); zoom = min(max(zoom, zoomMin), zoomMax)
    }
    private func tick() {
        let now = monoNs()
        let dt = lastTickNs == 0 ? 0.05 : min(Double(now - lastTickNs) / 1e9, 0.25)
        lastTickNs = now
        let anySpeed = panSpeed != 0 || tiltSpeed != 0 || zoomSpeed != 0
        if anySpeed {
            if !moving {   // starting a move: seed from the camera's real position (it may have been moved by hand or another app)
                if let cur = get32x2(UInt8(UVC_CT_PANTILT_ABSOLUTE), UInt8(UVC_GET_CUR)) { pan = cur.0; tilt = cur.1 }
                if let z = get16(UInt8(UVC_CT_ZOOM_ABSOLUTE), UInt8(UVC_GET_CUR)) { zoom = z }
                moving = true
            }
            pan = Int32((Double(pan) + panSpeed * panRate * 3600 * dt).rounded())
            tilt = Int32((Double(tilt) + tiltSpeed * tiltRate * 3600 * dt).rounded())
            zoom = Int16((Double(zoom) + zoomSpeed * zoomRate * Double(zoomMax - zoomMin) * dt).rounded())
            clampAll()
            sendPanTilt(); sendZoom()
        } else {
            moving = false
            sendPanTilt(); sendZoom()   // flush any pending absolute target
        }
    }

    // MARK: presets
    private func loadPresets() {
        guard let d = FileManager.default.contents(atPath: presetsPath), let m = try? JSONDecoder().decode([String: Preset].self, from: d) else { return }
        presets = Dictionary(uniqueKeysWithValues: m.compactMap { k, v in Int(k).map { ($0, v) } })
        olog("ptz: \(presets.count) presets from \(presetsPath)")
    }
    private func savePresets() {
        let m = Dictionary(uniqueKeysWithValues: presets.map { (String($0.key), $0.value) })
        let enc = JSONEncoder(); enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        if let d = try? enc.encode(m) { try? d.write(to: URL(fileURLWithPath: presetsPath), options: .atomic) }
    }

    // MARK: NDI metadata
    /// Parse `<name attr="v" .../>` -> (name, attrs). Returns nil if it is not an element.
    static func parse(_ xml: String) -> (String, [String: String])? {
        guard let lt = xml.firstIndex(of: "<") else { return nil }
        var i = xml.index(after: lt); var name = ""
        while i < xml.endIndex, !xml[i].isWhitespace, xml[i] != "/", xml[i] != ">" { name.append(xml[i]); i = xml.index(after: i) }
        var attrs: [String: String] = [:]
        while i < xml.endIndex, xml[i] != ">" {
            while i < xml.endIndex, xml[i].isWhitespace { i = xml.index(after: i) }
            var k = ""
            while i < xml.endIndex, xml[i] != "=", !xml[i].isWhitespace, xml[i] != "/", xml[i] != ">" { k.append(xml[i]); i = xml.index(after: i) }
            guard i < xml.endIndex, xml[i] == "=" else { break }
            i = xml.index(after: i)
            guard i < xml.endIndex, xml[i] == "\"" || xml[i] == "'" else { break }
            let qch = xml[i]; i = xml.index(after: i); var v = ""
            while i < xml.endIndex, xml[i] != qch { v.append(xml[i]); i = xml.index(after: i) }
            if i < xml.endIndex { i = xml.index(after: i) }
            attrs[k] = v
        }
        return name.isEmpty ? nil : (name, attrs)
    }
    private func lerp32(_ u: Double, _ lo: Int32, _ hi: Int32) -> Int32 { Int32((Double(lo) + (min(max(u, -1), 1) + 1) / 2 * Double(hi - lo)).rounded()) }
    private func lerp16(_ u: Double, _ lo: Int16, _ hi: Int16) -> Int16 { Int16((Double(lo) + min(max(u, 0), 1) * Double(hi - lo)).rounded()) }

    /// Called (outside the PTZ queue) when a receiver moves the camera by hand: joystick, absolute position, preset recall.
    var onManual: (() -> Void)?

    /// Handle one metadata frame from a receiver. Returns true if it was a PTZ command we understand.
    func handle(_ xml: String) -> Bool {
        guard let (name, a) = PTZ.parse(xml), name.hasPrefix("ntk_ptz") else { return false }
        func f(_ k: String) -> Double? { a[k].flatMap(Double.init) }
        var known = true
        let manual: Bool = {
            switch name {
            case "ntk_ptz_pan_tilt_speed": return (f("pan_speed") ?? 0) != 0 || (f("tilt_speed") ?? 0) != 0
            case "ntk_ptz_pan_tilt", "ntk_ptz_recall_preset": return true
            default: return false
            }
        }()
        defer { if known && manual { onManual?() } }
        q.sync {
            switch name {
            case "ntk_ptz_pan_tilt_speed":
                panSpeed = f("pan_speed") ?? 0; tiltSpeed = f("tilt_speed") ?? 0
            case "ntk_ptz_pan_tilt":
                panSpeed = 0; tiltSpeed = 0
                if let p = f("pan") { pan = lerp32(p, panMin, panMax) }
                if let t = f("tilt") { tilt = lerp32(t, tiltMin, tiltMax) }
            case "ntk_ptz_zoom_speed":
                zoomSpeed = f("zoom_speed") ?? 0
            case "ntk_ptz_zoom":
                zoomSpeed = 0
                if let z = f("zoom") { zoom = lerp16(z, zoomMin, zoomMax) }
            case "ntk_ptz_store_preset":
                if let i = a["index"].flatMap(Int.init) { presets[i] = Preset(pan: pan, tilt: tilt, zoom: zoom); savePresets(); olog("ptz: stored preset \(i) pan \(pan) tilt \(tilt) zoom \(zoom)") }
            case "ntk_ptz_recall_preset":
                if let i = a["index"].flatMap(Int.init) {
                    if let p = presets[i] { panSpeed = 0; tiltSpeed = 0; zoomSpeed = 0; pan = p.pan; tilt = p.tilt; zoom = p.zoom; olog("ptz: recall preset \(i)") }
                    else { olog("ptz: recall preset \(i): not stored") }
                }
            case "ntk_ptz_focus":
                var kr: Int32 = 0
                if a["mode"] == "auto" { var on: UInt8 = 1; _ = uvc_set(dev, ct, UInt8(UVC_CT_FOCUS_AUTO), &on, 1, &kr) }
                else if let d = f("distance") { var off: UInt8 = 0; _ = uvc_set(dev, ct, UInt8(UVC_CT_FOCUS_AUTO), &off, 1, &kr); var v = lerp16(d, focusMin, focusMax).littleEndian; _ = uvc_set(dev, ct, UInt8(UVC_CT_FOCUS_ABSOLUTE), &v, 2, &kr) }
            default:
                known = false
            }
            clampAll()
            if known { commands &+= 1; lastCommand = name } else { unknown &+= 1 }
        }
        return known
    }
    var statusText: String { "pan \(pan) tilt \(tilt) zoom \(zoom) speeds \(String(format: "%.2f/%.2f/%.2f", panSpeed, tiltSpeed, zoomSpeed)) cmds \(commands) unknown \(unknown) uvc_err \(uvcErrors)" }
    func statusDict() -> [String: Any] {
        ["pan_arcsec": Int(pan), "tilt_arcsec": Int(tilt), "pan_deg": Double(pan) / 3600, "tilt_deg": Double(tilt) / 3600, "zoom": Int(zoom), "zoom_min": Int(zoomMin), "zoom_max": Int(zoomMax),
         "pan_speed": panSpeed, "tilt_speed": tiltSpeed, "zoom_speed": zoomSpeed, "commands": Int(commands), "unknown_commands": Int(unknown), "uvc_errors": Int(uvcErrors), "last_command": lastCommand, "presets": presets.keys.sorted()]
    }
}
