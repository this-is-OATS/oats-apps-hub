import Foundation
import Vision
import CoreVideo

/// Looks at the camera's own frames a few times a second (Vision: human (body) rectangles, faces as the fallback) so the
/// sender knows where the person is and which way they left. The body is steadier than a face that turns away.
final class FaceWatch {
    private let q = DispatchQueue(label: "oats-cam.face", qos: .utility)
    private var busy = false
    private var lastRunNs: UInt64 = 0
    var intervalMs: UInt64 = 500
    private(set) var lastSeen: Date? = nil        // when a CONFIRMED face was last in frame (big enough; one hit counts, the camera moves during a scan)
    var minWidth = 0.025                          // a face narrower than 2.5% of the picture is noise (posters, letters, far clutter)
    private var streak = 0
    private(set) var lastX: Double = 0.5          // its centre, 0 = left edge of the picture, 1 = right
    private(set) var lastY: Double = 0.5          // 0 = bottom, 1 = top (Vision's coordinates)
    private(set) var lastW: Double = 0
    private(set) var lastBox: CGRect = .zero      // the hit, Vision coordinates (0..1, y up)
    private(set) var lastKind = ""                // "body" | "face"
    private(set) var exitDir: Double = 1          // +1: it was last heading / seen right of centre, -1: left
    private(set) var frames: UInt64 = 0, faces: UInt64 = 0, bodies: UInt64 = 0, errors: UInt64 = 0
    private var prevX: Double? = nil

    func consider(_ pb: CVPixelBuffer) {
        let now = monoNs()
        guard !busy, now - lastRunNs > intervalMs * 1_000_000 else { return }
        busy = true; lastRunNs = now
        q.async { [self] in
            defer { busy = false }
            let body = VNDetectHumanRectanglesRequest(); body.upperBodyOnly = true
            let face = VNDetectFaceRectanglesRequest()
            do { try VNImageRequestHandler(cvPixelBuffer: pb, orientation: .up, options: [:]).perform([body, face]) }
            catch { errors &+= 1; if errors <= 3 { olog("face: detector failed: \(error.localizedDescription)") }; return }
            frames &+= 1
            // the biggest upper body (head + shoulders; aim a little above its centre), else the biggest face
            var box: CGRect? = nil, yAim = 0.5
            if let b = (body.results ?? []).filter({ Double($0.boundingBox.width) >= minWidth * 2 }).max(by: { $0.boundingBox.width < $1.boundingBox.width }) { box = b.boundingBox; yAim = 0.65; bodies &+= 1; lastKind = "body" }
            else if let f = (face.results ?? []).filter({ Double($0.boundingBox.width) >= minWidth }).max(by: { $0.boundingBox.width < $1.boundingBox.width }) { box = f.boundingBox; faces &+= 1; lastKind = "face" }
            if let r = box {
                streak += 1
                let x = Double(r.midX)
                if let p = prevX, abs(x - p) > 0.02 { exitDir = x > p ? 1 : -1 } else { exitDir = x >= 0.5 ? 1 : -1 }
                prevX = x; lastX = x; lastY = Double(r.minY) + Double(r.height) * yAim; lastW = Double(r.width); lastBox = r
                if streak >= 1 { lastSeen = Date() }
            } else { prevX = nil; streak = 0 }
        }
    }
    /// "box=x,y,w,h,kind" in picture fractions with y down (for an overlay), only while a hit is fresh.
    var boxText: String {
        guard let s = lastSeen, Date().timeIntervalSince(s) < 1 else { return "" }
        let r = lastBox
        return String(format: " box=%.3f,%.3f,%.3f,%.3f,%@", r.minX, 1 - r.maxY, r.width, r.height, lastKind)
    }
    var text: String { "face=\(lastSeen.map { String(format: "%.1fs ago", Date().timeIntervalSince($0)) } ?? "never") x=\(String(format: "%.2f", lastX)) dir=\(exitDir > 0 ? "right" : "left") frames=\(frames) bodies=\(bodies) faces=\(faces)" }
}
