#!/bin/zsh
# oats-hub supervisor: NDI multiview + PTZ control in the browser (http://<this mac>:7080/).
#   hub.sh build | start | stop | restart | status | log [N]
# Settings via env or hub.env: HUB_PORT (7080), HUB_PREVIEW_FPS (25), HUB_QUALITY (0.6), HUB_ARCH (arm64), HUB_EXTRA (e.g. --no-tally --full)
setopt no_unset pipefail 2>/dev/null
C=${0:A:h}
BIN=$C/bin/oats-hub
LOGS=$C/logs
RUN=$C/run
PID=$RUN/oats-hub.pid
LOOPPID=$RUN/oats-hub-loop.pid
LOOPLOG=$LOGS/oats-hub-loop.log
[[ -f $C/hub.env ]] && source $C/hub.env
: ${HUB_PORT:=7080} ${HUB_PREVIEW_FPS:=25} ${HUB_QUALITY:=0.6} ${HUB_ARCH:=arm64} ${HUB_EXTRA:=}
: ${HUB_TALLY:=program} ${HUB_TALLY_OSC:=} ${HUB_TALLY_ON_CMD:=} ${HUB_TALLY_OFF_CMD:=} ${HUB_OSC_PORT:=7081}   # tally: program|preview|off; out: host:port + /cmd templates (%s = cam name)
[[ -d $C/../ndi-config ]] && : ${NDI_CONFIG_DIR:=$C/../ndi-config}   # this install's machine name + adapter pin (install.sh)
[[ -d $C/../oats-m0/ndi-config ]] && : ${NDI_CONFIG_DIR:=$C/../oats-m0/ndi-config}   # share the vizzies' NDI pin when installed next to them
: ${NDI_CONFIG_DIR:=$HOME/.ndi}
: ${HUB_AUDIO_CTL:="Link Cam=127.0.0.1:7001"}   # source short name -> oats-cam UDP control port, for the Audio button / "a" key
export NDI_CONFIG_DIR HUB_AUDIO_CTL HUB_TALLY HUB_TALLY_OSC HUB_TALLY_ON_CMD HUB_TALLY_OFF_CMD HUB_OSC_PORT
mkdir -p $LOGS $RUN
ts() { date '+%Y-%m-%d %H:%M:%S' }
readpid() { [[ -f $1 ]] && cat $1 2>/dev/null || true }
alive() { [[ -n ${1:-} ]] && kill -0 $1 2>/dev/null }

build() {
  local mc=$C/.modcache arch=$HUB_ARCH target
  [[ $arch == arm64 ]] && target=arm64-apple-macos14 || target=x86_64-apple-macos14
  mkdir -p $mc
  echo "$(ts) building bin/oats-hub ($arch)"
  swiftc -O -swift-version 5 -parse-as-library -target $target -module-cache-path $mc \
    -import-objc-header $C/src/bridge.h $C/src/log.swift $C/src/ndi.swift $C/src/http.swift $C/src/hub.swift $C/src/osc.swift $C/src/app.swift \
    -framework Foundation -framework ImageIO -framework CoreGraphics \
    -o $BIN.tmp && mv $BIN.tmp $BIN || { rm -f $BIN.tmp; echo "$(ts) BUILD FAILED (oats-hub)" >&2; return 1 }
  echo "$(ts) built $BIN ($(/usr/bin/file -b $BIN | sed 's/Mach-O 64-bit executable //'))"
}
runner() { [[ $(/usr/bin/file -b $BIN) == *arm64* ]] && print -r -- "" || print -r -- "arch -x86_64" }

loop() {
  echo "$(ts) hub loop started pid=$$ port=$HUB_PORT" >> $LOOPLOG
  while true; do
    ${=$(runner)} $BIN --port $HUB_PORT --www $C/www --log-dir $LOGS --preview-fps $HUB_PREVIEW_FPS --quality $HUB_QUALITY ${=HUB_EXTRA} > /dev/null 2>> $LOGS/oats-hub.err < /dev/null &
    local child=$!
    echo $child > $PID
    echo "$(ts) started oats-hub pid=$child" >> $LOOPLOG
    wait $child; local code=$?
    rm -f $PID
    (( code == 0 )) && { echo "$(ts) oats-hub exited 0: hub loop ends" >> $LOOPLOG; break; }
    (( code == 64 || code == 78 )) && { echo "$(ts) oats-hub exited $code (arguments / libndi): hub loop ends" >> $LOOPLOG; break; }
    echo "$(ts) oats-hub exited $code$( (( code > 128 )) && echo " (signal $((code - 128)))"): restarting in 2 s" >> $LOOPLOG
    sleep 2
  done
  rm -f $LOOPPID
  echo "$(ts) hub loop exit" >> $LOOPLOG
}
start() {
  local lp=$(readpid $LOOPPID)
  alive $lp && { echo "oats-hub already running (loop pid $lp, oats-hub pid $(readpid $PID))"; return 0 }
  [[ -x $BIN ]] || build || return 1
  # own session (setsid) so the loop survives whatever shell or tool started it (m0.sh does the same)
  nohup python3 -I -c 'import os, sys; os.setsid(); os.execvp(sys.argv[1], sys.argv[1:])' zsh $C/hub.sh _loop > /dev/null 2>&1 < /dev/null &
  echo $! > $LOOPPID
  disown 2>/dev/null || true
  echo "$(ts) oats-hub loop pid $! -> http://$(ipconfig getifaddr en0 2>/dev/null || echo localhost):$HUB_PORT/  (logs $LOGS/oats-hub-*.log)"
}
stop() {
  local lp=$(readpid $LOOPPID) p=$(readpid $PID)
  alive $lp && kill -TERM $lp 2>/dev/null
  if alive $p; then kill -TERM $p 2>/dev/null; for i in {1..30}; do alive $p || break; sleep 0.1; done; alive $p && kill -KILL $p 2>/dev/null; fi
  rm -f $LOOPPID $PID
  echo "$(ts) oats-hub stopped"
}
status() {
  local lp=$(readpid $LOOPPID) p=$(readpid $PID)
  echo "loop: $( alive $lp && echo "running pid $lp" || echo "not running" )   oats-hub: $( alive $p && echo "running pid $p" || echo "not running" )   http://$(ipconfig getifaddr en0 2>/dev/null || echo localhost):$HUB_PORT/"
  curl -s --max-time 2 http://127.0.0.1:$HUB_PORT/api/sources | python3 -I -c "
import json,sys; d=json.load(sys.stdin)
for s in d['sources']: print(f\"  {s['name']:<42} {'on ' if s['connected'] else 'off'} {'PTZ' if s['ptz'] else '   '} {s['width']}x{s['height']} frames={s['frames']} age={s['age_ms']}ms{' LIVE' if s['tally'] else ''}\")
print('  selected:', d['selected'])" 2>/dev/null || echo "  (no answer from the hub API)"
}
case ${1:-status} in
  _loop) loop ;;
  build) build ;;
  start) start ;;
  stop) stop ;;
  restart) stop; start ;;
  status) status ;;
  log) tail -n ${2:-30} $(ls -t $LOGS/oats-hub-2*.log | head -1) ;;
  *) echo "usage: hub.sh build|start|stop|restart|status|log [N]"; exit 64 ;;
esac
