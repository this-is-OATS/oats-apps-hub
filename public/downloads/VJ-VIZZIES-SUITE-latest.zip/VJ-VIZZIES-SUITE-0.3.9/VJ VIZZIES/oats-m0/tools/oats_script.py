#!/usr/bin/env python3
"""OATS VIZ generator looks and beat scripts (tools/gen_presets.json). Stdlib only; run with python3 -I.

usage:
  python3 -I tools/oats_script.py list
  python3 -I tools/oats_script.py look "Ring Pulse" --layer 2
  python3 -I tools/oats_script.py run "Geometry Tour" --layer 2 [--bpm 128] [--once]
  python3 -I tools/oats_script.py stop --layer 2          (stops a running script on that layer)

A look switches the layer to source gen, sends its generator params, then the optional FX preset, blend and
opacity. A script steps through looks, holding each for N beats at the player's BPM (status.json tempo.bpm,
re-read every step, so MA3 / tap tempo changes follow), and starts each step on a beat boundary.
Sends OSC to 127.0.0.1:7000 (--to host:port to change). Ctrl-C stops a script and leaves the last look up.
"""
import argparse
import json
import os
import signal
import subprocess
import socket
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PRESETS = os.path.join(HERE, "gen_presets.json")
STATUS = os.path.join(HERE, "..", "logs", "status.json")
RUN_DIR = os.path.join(HERE, "..", "logs")
BLENDS = {b.lower(): b for b in ("Alpha", "Add", "Screen", "Multiply", "Difference", "Lighten", "Darken", "Overlay")}


def _pad(b):
    return b + b"\0" * (4 - len(b) % 4)


def osc(addr, *args):
    tags, data = ",", b""
    for a in args:
        if isinstance(a, bool) or isinstance(a, int):
            tags += "i"; data += struct.pack(">i", int(a))
        elif isinstance(a, float):
            tags += "f"; data += struct.pack(">f", a)
        else:
            tags += "s"; data += _pad(str(a).encode())
    return _pad(addr.encode()) + _pad(tags.encode()) + data


class Sender:
    def __init__(self, to):
        host, port = to.rsplit(":", 1)
        self.dst = (host, int(port))
        self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def send(self, addr, *args):
        self.s.sendto(osc(addr, *args), self.dst)


def load():
    with open(PRESETS) as f:
        return json.load(f)


def status():
    try:
        with open(STATUS) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def apply_look(tx, layer, name, look):
    p = f"/oats/layers/{layer}"
    g = look.get("gen", {})
    tx.send(f"{p}/source", "gen")
    if "type" in g:
        tx.send(f"{p}/gen/type", g["type"])
    for k in ("count", "thickness", "softness", "speed", "angle", "variation"):
        if k in g:
            tx.send(f"{p}/gen/{k}", float(g[k]))
    if "beatsync" in g:
        tx.send(f"{p}/gen/beatsync", int(g["beatsync"]))
    for k in ("colorA", "colorB"):
        if k in g:
            tx.send(f"{p}/gen/{k}", *[float(v) for v in g[k]])
    if "colormode" in g:
        tx.send(f"{p}/gen/colormode", g["colormode"])
    if look.get("fx"):
        tx.send(f"{p}/fx/preset", look["fx"])
    else:
        tx.send(f"{p}/fx/reset")
    if "blend" in look:
        tx.send(f"{p}/blend", BLENDS.get(str(look["blend"]).lower(), look["blend"]))
    if "opacity" in look:
        tx.send(f"{p}/opacity", float(look["opacity"]))
    print(f"{time.strftime('%H:%M:%S')} layer {layer}: {name}", flush=True)


def pidfile(layer):
    return os.path.join(RUN_DIR, f"script-layer{layer}.pid")


def run_script(tx, layer, name, data, bpm_override, once):
    sc = data["scripts"][name]
    looks = data["looks"]
    pf = pidfile(layer)
    old = _read_pid(pf)
    if old and old != os.getpid():
        _stop_pid(old, pf)                        # one script per layer: the new one replaces the old
    with open(pf, "w") as f:
        f.write(str(os.getpid()))
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    try:
        loop = sc.get("loop", True) and not once
        while True:
            for step in sc["steps"]:
                if step.get("look"):
                    apply_look(tx, layer, step["look"], looks[step["look"]])
                for addr, *args in step.get("set", []):
                    tx.send(addr, *args)
                st = status().get("tempo", {})
                bpm = bpm_override or st.get("bpm") or 120
                beats = float(step.get("beats", 8))
                # hold N beats, ending on a beat boundary of the player's clock when it is known
                beat_now = st.get("beat")
                hold = beats * 60.0 / bpm
                if isinstance(beat_now, (int, float)) and not bpm_override:
                    hold -= (beat_now % 1.0) * 60.0 / bpm
                time.sleep(max(0.05, hold))
            if not loop:
                break
    finally:
        if _read_pid(pf) == os.getpid():
            os.remove(pf)


def _is_our_script(pid):
    """A pidfile survives SIGKILL and power cuts, and its pid can belong to anything after a reboot (oats-m0, the
    GUI server): only a process whose command line runs this oats_script.py may be signalled."""
    try:
        out = subprocess.run(["/bin/ps", "-o", "command=", "-p", str(int(pid))], capture_output=True, text=True, timeout=3).stdout
    except (OSError, subprocess.SubprocessError, ValueError):
        return False
    return "oats_script.py" in out and " run " in f" {out} "


def _stop_pid(pid, pf):
    """SIGTERM pid if it is one of our scripts; a stale pidfile is removed. Returns True when signalled."""
    if not _is_our_script(pid):
        try:
            os.remove(pf)
        except OSError:
            pass
        return False
    try:
        os.kill(pid, signal.SIGTERM)
        return True
    except OSError:
        return False


def _read_pid(pf):
    try:
        with open(pf) as f:
            return int(f.read().strip())
    except (OSError, ValueError):
        return None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["list", "look", "run", "stop"])
    ap.add_argument("name", nargs="?")
    ap.add_argument("--layer", type=int, default=2, help="layer 0 (BG) - 4 (default 2)")
    ap.add_argument("--to", default="127.0.0.1:7000")
    ap.add_argument("--bpm", type=float, default=0, help="fixed BPM instead of the player's")
    ap.add_argument("--once", action="store_true", help="play a looping script once")
    a = ap.parse_args()
    data = load()
    if a.cmd == "list":
        print("Looks:");   [print("  " + n) for n in data["looks"]]
        print("Scripts:"); [print(f"  {n}  ({s.get('about', '')})") for n, s in data["scripts"].items()]
        return
    if not 0 <= a.layer <= 4:
        sys.exit("--layer must be 0 (BG) - 4")
    if a.cmd == "stop":
        pid = _read_pid(pidfile(a.layer))
        if pid and _stop_pid(pid, pidfile(a.layer)):
            print(f"stopped script on layer {a.layer}")
        elif pid:
            print(f"no running script (stale pidfile: pid {pid} is not oats_script.py; removed)")
        else:
            print("no running script")
        return
    tx = Sender(a.to)
    if a.cmd == "look":
        if a.name not in data["looks"]:
            sys.exit(f"unknown look '{a.name}' (see: list)")
        apply_look(tx, a.layer, a.name, data["looks"][a.name])
    else:
        if a.name not in data["scripts"]:
            sys.exit(f"unknown script '{a.name}' (see: list)")
        try:
            run_script(tx, a.layer, a.name, data, a.bpm, a.once)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
