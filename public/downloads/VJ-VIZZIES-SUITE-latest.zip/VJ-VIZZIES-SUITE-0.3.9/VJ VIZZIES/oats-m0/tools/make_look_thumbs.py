#!/usr/bin/env python3
"""Render a small thumbnail for every look (generator, FX, fractal, master FX) with a throw-away player instance.

usage:
  python3 -I tools/make_look_thumbs.py                 # all looks (re-run after adding / editing looks)
  python3 -I tools/make_look_thumbs.py --only gen,fx   # some kinds: gen | fx | fractal | master | shape | place
  python3 -I tools/make_look_thumbs.py --missing       # only looks that have no thumbnail yet

Writes gui/thumbs/<kind>/<slug>.jpg (128x72, JPEG q 70; slug = lowercase name, non-alnum -> "-") and
gui/thumbs/index.json ({kind: {name: "kind/slug.jpg"}}). Rebuild the app (apps/mac/bundle/build.sh) to ship them.

The test player is a SEPARATE process: bin/oats-m0 under nice -n 10 at --fps 20, OSC 7190, preview 8199, NDI off,
sACN off, startup card off, its own log dir and scenes file. It never sends to (or touches) the live player on 7000 /
8091; it only reads the live logs/status.json to watch its fps, and waits longer between looks if the live fps dips.
Stdlib + macOS sips only.
"""
import argparse
import json
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
M0 = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import oats_script  # noqa: E402  (apply_look / Sender, pointed at the test port)

BIN = os.environ.get("OATS_THUMBS_BIN") or os.path.join(M0, "bin", "oats-m0")   # OATS_THUMBS_BIN: a new build before install
THUMBS = os.path.join(M0, "gui", "thumbs")
LIVE_STATUS = os.path.join(M0, "logs", "status.json")
OSC_PORT, PREVIEW_PORT = 7190, 8199
LIVE_PORTS = (7000, 8091)
W, H, QUALITY = 128, 72, 70
KINDS = ("gen", "fx", "fractal", "master", "shape", "place")
# Deep zoom step 1 shape tiles (= src/state.swift shapePresets, OSC /oats/fractal/1/shape s NAME): drawn at depth 0, default palette
SHAPES = ["Mandelbrot", "Burning Ship", "Tricorn", "Celtic", "Flower 3", "Flower 4", "Flower 5", "Julia Dendrite", "Julia Rabbit",
          "Julia Spiral", "Julia Dust", "Kaleido 6", "Kaleido 8"]
# step 2 places (= src/deep.swift zoomTargets) with the default shape, ZOOMED IN at a depth that shows what each one is
PLACES = [("SEAHORSE", 7.0), ("SPIRAL", 7.0), ("JULIA", 6.0), ("VOID", 8.0), ("ELEPHANT", 7.0), ("STAR", 6.5), ("SEAMINI", 9.0), ("STARMINI", 9.0)]
# reference source for FX / master looks: gen Grid, medium density, two colours
GRID = {"type": "Grid", "count": 0.5, "thickness": 0.18, "softness": 0.08, "speed": 0.25, "angle": 0, "variation": 0.5,
        "beatsync": 0, "colorA": [0.25, 0.8, 1.0], "colorB": [1.0, 0.35, 0.75], "colormode": "custom"}
BLACK_BYTES = 1000                   # a 128x72 q70 JPEG this small is (near) black
TRAIL_TYPES = ("trails",)           # StarTrails, WarpTrails, SpiralTrails, Trails: settle longer


def slug(name):
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "look"


def load(fn):
    with open(os.path.join(HERE, fn)) as f:
        return json.load(f)


def looks():
    """[(kind, name, payload)] in GUI order."""
    g, fx, fr = load("gen_presets.json"), load("fx_presets.json"), load("fractal_presets.json")
    out = [("gen", k, v) for k, v in g.get("looks", {}).items()]
    out += [("fx", p["name"], p) for p in fx.get("presets", [])]
    out += [("fractal", p["name"], p) for p in fr.get("presets", [])]
    out += [("master", p["name"], p) for p in fx.get("master", []) if not re.fullmatch(r"(?i)\s*(off|none)\s*", p["name"])]
    out += [("shape", n, {}) for n in SHAPES]
    out += [("place", n, {"depth": d}) for n, d in PLACES]
    return out


def has_trails(kind, name, payload):
    if kind == "gen":
        ref = payload.get("fx")
        fxp = {p["name"]: p for p in load("fx_presets.json").get("presets", [])}
        payload = fxp.get(ref, {}) if ref else {}
    blob = json.dumps(payload).lower()
    return any(t in blob for t in TRAIL_TYPES)


def port_busy(port, udp):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM if udp else socket.SOCK_STREAM)
    try:
        if udp:
            s.bind(("0.0.0.0", port)); return False
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0     # TCP: a listener answers (TIME_WAIT from the last run is fine)
    except OSError:
        return True
    finally:
        s.close()


def live_fps():
    try:
        with open(LIVE_STATUS) as f:
            v = json.load(f).get("fps")
        return float(v) if isinstance(v, (int, float)) else None
    except (OSError, ValueError):
        return None


def grab(path):
    """One fresh preview frame of the test instance (320x180 JPEG), scaled to 128x72 q 70 with sips."""
    with urllib.request.urlopen(f"http://127.0.0.1:{PREVIEW_PORT}/preview.jpg?w=320", timeout=5) as r:
        data = r.read()
    tmp = path + ".src.jpg"
    with open(tmp, "wb") as f:
        f.write(data)
    try:
        subprocess.run(["sips", "-z", str(H), str(W), "-s", "format", "jpeg", "-s", "formatOptions", str(QUALITY), tmp, "--out", path],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    finally:
        os.remove(tmp)


class Player:
    def __init__(self, log_dir):
        self.log_dir = log_dir
        self.p = None

    def start(self):
        for port, udp in ((OSC_PORT, True), (PREVIEW_PORT, False)):
            if port_busy(port, udp):
                sys.exit(f"port {port} is in use: is another thumbnail run still going? (pgrep -fl 'oats-m0.*--osc-port {OSC_PORT}')")
        scenes = os.path.join(self.log_dir, "scenes.json")
        cmd = ["nice", "-n", "10", BIN, "--name", "OATS VIZ Thumbs", "--osc-port", str(OSC_PORT), "--preview-port", str(PREVIEW_PORT),
               "--ndi", "off", "--no-sacn", "--no-ndi-meta", "--startup-card", "off", "--fps", "20", "--log-dir", self.log_dir,
               "--scenes", scenes, "--output-display", "0"]
        self.p = subprocess.Popen(cmd, cwd=M0, stdout=subprocess.DEVNULL, stderr=open(os.path.join(self.log_dir, "stderr.txt"), "wb"),
                                  start_new_session=True)
        st = os.path.join(self.log_dir, "status.json")
        t0 = time.time()
        while time.time() - t0 < 20:
            if self.p.poll() is not None:
                sys.exit(f"test player exited with {self.p.returncode} (log in {self.log_dir})")
            if os.path.exists(st):
                try:
                    with urllib.request.urlopen(f"http://127.0.0.1:{PREVIEW_PORT}/preview.jpg?w=160", timeout=3):
                        return
                except OSError:
                    pass
            time.sleep(0.3)
        self.stop(); sys.exit("test player did not come up in 20 s")

    def stop(self):
        if not self.p or self.p.poll() is not None:
            return
        self.p.send_signal(signal.SIGTERM)
        try:
            self.p.wait(6)
        except subprocess.TimeoutExpired:
            self.p.kill(); self.p.wait(3)


def neutral(tx):
    """Layers cleared, fractal base off, master FX off: black background."""
    tx.send("/oats/master/fx/reset")
    tx.send("/oats/fractal/layer", 0)
    tx.send("/oats/fractal/opacity", 0.0)
    for n in (1, 2, 3, 4):
        p = f"/oats/layers/{n}"
        tx.send(f"{p}/fx/reset"); tx.send(f"{p}/opacity", 0.0); tx.send(f"{p}/source", "clip"); tx.send(f"{p}/clear")
        tx.send(f"{p}/blend", "Alpha")


def grid(tx):
    oats_script.apply_look(tx, 1, "Grid (reference)", {"gen": GRID, "blend": "Alpha", "opacity": 1.0})


def apply(tx, kind, name, payload):
    neutral(tx)
    if kind == "gen":
        oats_script.apply_look(tx, 1, name, payload)
        tx.send("/oats/layers/1/opacity", 1.0)
        tx.send("/oats/layers/1/blend", "Alpha")   # over black: Multiply / Darken / Overlay would show nothing
    elif kind == "fx":
        grid(tx); tx.send("/oats/layers/1/fx/preset", name)
    elif kind == "master":
        grid(tx); tx.send("/oats/master/fx/preset", name)
    elif kind == "fractal":
        tx.send("/oats/fractal/1/preset", name)
        tx.send("/oats/fractal/opacity", 1.0)
    elif kind in ("shape", "place"):
        fr = "/oats/fractal/1/"
        tx.send("/oats/fractal/1/preset", "none")       # classic look, loop off (palette stays the default)
        tx.send(fr + "target/dive", 0); tx.send(fr + "shape/memory", 0); tx.send(fr + "zoomspeed", 0.0)
        tx.send(fr + "rotation", 0.0); tx.send(fr + "iter", 0)
        tx.send("/oats/fractal/opacity", 1.0)
        if kind == "shape":
            tx.send(fr + "target", "SEAHORSE"); time.sleep(0.4)
            tx.send(fr + "shape", name); tx.send(fr + "depth", 0.0)
        else:
            tx.send(fr + "shape", "Mandelbrot"); tx.send(fr + "target", name)
            time.sleep(0.8)                               # its orbit, then the depth (a target change lands at depth 0)
            tx.send(fr + "depth", float(payload["depth"]))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", default="", help="comma list of kinds: gen,fx,fractal,master,shape,place")
    ap.add_argument("--missing", action="store_true", help="skip looks that already have a thumbnail")
    ap.add_argument("--log-dir", default="", help="test player's log dir (default: a temp dir, removed after)")
    ap.add_argument("--gap", type=float, default=0.15, help="extra seconds between looks (grows when the live fps dips)")
    a = ap.parse_args()
    kinds = [k for k in a.only.split(",") if k] or list(KINDS)
    bad = set(kinds) - set(KINDS)
    if bad:
        sys.exit(f"unknown kind(s) {', '.join(bad)} ({', '.join(KINDS)})")
    assert OSC_PORT not in LIVE_PORTS and PREVIEW_PORT not in LIVE_PORTS
    allx = looks()
    todo = [x for x in allx if x[0] in kinds and not (a.missing and os.path.exists(os.path.join(THUMBS, x[0], slug(x[1]) + ".jpg")))]
    tmpdir = None
    log_dir = a.log_dir or (tmpdir := tempfile.mkdtemp(prefix="oats-thumbs-"))
    os.makedirs(log_dir, exist_ok=True)
    for k in KINDS:
        os.makedirs(os.path.join(THUMBS, k), exist_ok=True)

    pl = Player(log_dir)
    t0 = time.time()
    fps_seen, gap, made, failed = [], a.gap, 0, []
    if todo:
        pl.start()
        tx = oats_script.Sender(f"127.0.0.1:{OSC_PORT}")
        tx.send("/oats/fractal/1/res", 4)          # 540p fractal: plenty for 128x72, less GPU next to the show
        tx.send("/oats/fractal/1/zoomspeed", 0.0)
        try:
            for i, (kind, name, payload) in enumerate(todo):
                apply(tx, kind, name, payload)
                settle = 2.0 if kind == "place" else (1.5 if (kind in ("fractal", "shape") or has_trails(kind, name, payload)) else 0.8)
                time.sleep(settle)
                out = os.path.join(THUMBS, kind, slug(name) + ".jpg")
                try:
                    grab(out)
                    for _ in range(8):             # strobe / flash looks: a black frame says nothing, catch an "on" one
                        if os.path.getsize(out) > BLACK_BYTES:
                            break
                        time.sleep(0.11); grab(out)
                    made += 1
                except (OSError, subprocess.CalledProcessError) as e:
                    failed.append(f"{kind}/{name}: {e}")
                f = live_fps()
                if f is not None:
                    fps_seen.append(f)
                    if f < 57:                     # the show comes first: slow down, never speed up
                        gap = min(2.0, gap + 0.5)
                        print(f"  live fps {f:.1f}: gap now {gap:.2f} s", flush=True)
                time.sleep(gap)
        finally:
            pl.stop()

    # index.json: every current look that has a file (deleted looks drop out)
    idx = {k: {} for k in KINDS}
    for kind, name, _ in allx:
        fn = f"{kind}/{slug(name)}.jpg"
        if os.path.exists(os.path.join(THUMBS, fn)):
            idx[kind][name] = fn
    tmp = os.path.join(THUMBS, ".index.json.tmp")
    with open(tmp, "w") as f:
        json.dump(idx, f, indent=1, ensure_ascii=False)
    os.replace(tmp, os.path.join(THUMBS, "index.json"))
    if tmpdir:
        shutil.rmtree(tmpdir, ignore_errors=True)

    stray = subprocess.run(["pgrep", "-f", f"oats-m0.*--osc-port {OSC_PORT}"], capture_output=True, text=True).stdout.split()
    total = sum(len(v) for v in idx.values())
    print(f"made {made} thumbnails in {time.time() - t0:.0f} s; index has {total} ({', '.join(f'{k} {len(v)}' for k, v in idx.items())})")
    if fps_seen:
        print(f"live player fps during the run: min {min(fps_seen):.1f}, avg {sum(fps_seen) / len(fps_seen):.1f} ({len(fps_seen)} samples)")
    for x in failed:
        print("FAILED " + x)
    if stray:
        print(f"WARNING: test player still running: pid {' '.join(stray)}"); sys.exit(1)
    print("test player stopped (no stray process)")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
