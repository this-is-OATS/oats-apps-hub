// Builds media/library.json from media/.catalog-rows.json (rows copied from the read-only catalog):
// every file is opened with AVFoundation; files it can't open (no playable video track) are skipped.
// Slots are numbered 1..n per bank in file-name order.
// Build + run: swiftc -O -target x86_64-apple-macos14 tools/make_library.swift -o /tmp/mklib && /tmp/mklib ../media
import Foundation
import AVFoundation

let dir = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "../media"
let rowsURL = URL(fileURLWithPath: dir).appendingPathComponent(".catalog-rows.json")
guard let data = try? Data(contentsOf: rowsURL),
      let rows = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { print("no \(rowsURL.path)"); exit(1) }
let bankNames = [1: "MIXKIT", 2: "TUNNEL"]
var banks: [Int: [[String: Any]]] = [:]
var skipped: [String] = []
let sem = DispatchSemaphore(value: 0)
Task {
    for r in rows.sorted(by: { ($0["file"] as! String) < ($1["file"] as! String) }) {
        let b = r["bank"] as! Int, f = r["file"] as! String
        let url = URL(fileURLWithPath: dir).appendingPathComponent(f)
        let a = AVURLAsset(url: url)
        do {
            let (playable, dur) = try await a.load(.isPlayable, .duration)
            let vt = try await a.loadTracks(withMediaType: .video)
            guard playable, let t = vt.first else { skipped.append(f); continue }
            let (sz, fps, tf) = try await t.load(.naturalSize, .nominalFrameRate, .preferredTransform)
            let r2 = sz.applying(tf)
            var name = (f as NSString).lastPathComponent
            name = (name as NSString).deletingPathExtension
            name = name.replacingOccurrences(of: "mixkit-", with: "").replacingOccurrences(of: "-hd-ready", with: "")
            if let rg = name.range(of: "-[0-9]+$", options: .regularExpression) { name.removeSubrange(rg) }
            name = name.replacingOccurrences(of: "-", with: " ")
            var arr = banks[b] ?? []
            arr.append(["slot": arr.count + 1, "name": name, "file": f, "duration_s": (dur.seconds * 1000).rounded() / 1000,
                        "fps": (Double(fps) * 1000).rounded() / 1000, "width": Int(abs(r2.width)), "height": Int(abs(r2.height)),
                        "vcodec": r["vcodec"] as? String ?? ""])
            banks[b] = arr
        } catch { skipped.append(f) }
    }
    sem.signal()
}
sem.wait()
let out: [String: Any] = [
    "version": 1,
    "root": "~/Developer/oats-viz/media",
    "note": "bank 1 = VJ CLIPS/MIXKIT, bank 2 = RESOLUME VISUALS/TUNNEL (copies; the NAS is never played from)",
    "banks": banks.keys.sorted().map { ["bank": $0, "name": bankNames[$0] ?? "BANK \($0)", "slots": banks[$0]!] },
    "skipped": skipped,
]
let j = try! JSONSerialization.data(withJSONObject: out, options: [.prettyPrinted, .sortedKeys])
try! j.write(to: URL(fileURLWithPath: dir).appendingPathComponent("library.json"))
print("library.json: " + banks.keys.sorted().map { "bank \($0) \(banks[$0]!.count) slots" }.joined(separator: ", ") + ", skipped \(skipped.count)")
