#!/usr/bin/env python3
"""Writes the OATS VIZ GDTF fixture file (DMX personality v0) and checks it. Stdlib only; run with python3 -I.

usage:
  python3 -I tools/make_gdtf.py                       # write ~/Developer/oats-viz/gdtf/OATS_VIZ.gdtf and validate it
  python3 -I tools/make_gdtf.py --check bin/oats-m0   # also compare it with the player's own decoder table
  python3 -I tools/make_gdtf.py --markdown            # print the channel tables (README)
  python3 -I tools/make_gdtf.py --validate FILE.gdtf  # validate an existing file only
  python3 -I tools/make_gdtf.py --presets             # DMX values of tools/fx_presets.json for a Layer FX 24 fixture (README)

One fixture type "OATS VIZ" (manufacturer OATS, short name OATSVIZ) with five DMX modes, patched as eleven fixtures
on one universe: "Master 16" at address 1, "Fractal 24" at address 17 and four "Layer 16" (one per clip layer)
at 41, 57, 73, 89, "Color 8" at 105, four "Layer FX 24" (one per clip layer) at 113, 137, 161, 185. Layer 16 bank / slot channel sets are named from media/library.json (banks by name, slots by
the clip names of bank 1): --media must point at the same library the player uses. GDTF DataVersion 1.2 (DIN SPEC
15800:2022-02): grandMA3 2.1+ imports GDTF 1.2, and MA3 2.3.2's own GDTF library (libMaGdtfMvrExchange)
writes DataVersion 1.2. The FixtureTypeID below is fixed: keep it, so MA3 sees later files as revisions of the
same type. The output is byte-stable (fixed zip timestamps): bump REVISION when the table changes.

The table here must match the player's decoder (src/dmx.swift dmxTableV0): --check runs `bin/oats-m0 --dmx-table`
and compares offsets, attributes, defaults, snap and the named values channel by channel.
"""
import argparse
import json
import os
import re
import subprocess
import sys
import zipfile
import xml.etree.ElementTree as ET
from xml.sax.saxutils import quoteattr

FIXTURE_TYPE_ID = "1D726D7B-C558-4602-84E0-3B3F2DCC3CE3"      # generated once (2026-10-21); never change it
DATA_VERSION = "1.2"
REVISION = ("2026-11-01T15:00:00", "v0.10: Layer 16 ch 14 Source band appended: 30 NDI (Reserved from 40); with Source = NDI, ch 3 Slot picks the n-th discovered NDI source (status.json ndi_sources, A-Z by NDI name, ndi_order.json pins); older values unchanged")
# earlier: ("2026-10-23T06:00:00", "v0.9: Layer 16 ch 15 generator type band appended: 120 Stars (Reserved from 130); Master 16 ch 15 test content bands appended: 30 Test card, 40 NDI card (Reserved from 50); older values unchanged")
# earlier: ("2026-10-23T04:00:00", "v0.8: Layer FX 24 ch 10 / 13 / 20 FX type bands appended: 180 StarTrails, 190 WarpTrails, 200 SpiralTrails (Reserved from 210); older values unchanged")
# earlier: ("2026-10-23T01:00:00", "v0.7: Master 16 ch 9 Scene (0 none, 1-128 = scene bank.slot, fires on change), ch 10 Scene fade (0 = the scene's own, 1-255 = 0.1-25.5 s)")
# earlier: ("2026-10-22T23:00:00", "v0.6: Fractal 24 formula modifiers + endless zoom: ch 1 formula (Mandelbrot, Burning Ship, Tricorn, "
#                                    "Multibrot 3/4/5, Celtic), ch 12-15 Julia c (0/32768 keep), ch 16 kaleido fold, ch 20 orbit trap, ch 23 Julia morph, "
#                                    "ch 24 loop bands 30-69; targets 7 SEAMINI, 8 STARMINI")
# earlier: ("2026-10-22T21:00:00", "v0.5: layer sources (Layer 16 ch 14 Source Clip/Fractal/Generator, ch 15 Generator type, ch 16 count); Layer FX 24 ch 23 generator speed, ch 24 thickness; Fractal 24 ch 22 Spin")
# earlier: ("2026-10-22T19:00:00", "v0.4: mode Layer FX 24 (per-layer transform, 2 FX slots, beat mod; master FX on Layer FX 1) at 113/137/161/185")
# earlier: ("2026-10-22T17:00:00", "v0.3: mode Color 8 (lights -> VJ colour link, at 105); Layer 16 ch 10-13 clip command + autopilot; Master ch 8 column go")
# earlier: ("2026-10-21T22:30:00", "v0.2: mode Layer 16 (one fixture per clip layer at 41/57/73/89); Master 16 and Fractal 24 unchanged")
# earlier: ("2026-10-21T20:45:00", "v0.1: Master ch 14 Effect speed (0 stop, 128 1.0x, 255 2.0x); Master dimmer default 0")
# earlier: ("2026-10-21T19:00:00", "v0: Master 16 + Fractal 24 (OATS VIZ player, DMX personality v0)")
DEFAULT_OUT = os.path.expanduser("~/Developer/oats-viz/gdtf/OATS@OATS VIZ.gdtf")  # MA3's Manufacturer@Name convention
TARGETS = ["SEAHORSE", "SPIRAL", "JULIA", "VOID", "ELEPHANT", "STAR", "SEAMINI", "STARMINI"]   # src/deep.swift zoomTargets
FORMULAS = ["Mandelbrot", "Burning Ship", "Tricorn", "Multibrot 3", "Multibrot 4", "Multibrot 5", "Celtic"]   # src/deep.swift Formula
TRAPS = ["Off (palette)", "Point", "Circle", "Line", "Cross", "Star"]                                      # src/dmx.swift trapSetNames
FRACTAL_CONTROL = ["Idle", "Reset to target", "Freeze zoom", "Loop minibrot", "Dive & return", "Dive next target", "Dive random target"]
FOLD_SETS = [(0, "Off")] + [(10 * (n - 1), "Fold %d" % n) for n in range(2, 13)] + [(120 + 10 * (n - 2), "Fold %d mirror" % n) for n in range(2, 13)] + [(230, "Reserved")]
JULIA_C_SETS = [(0, "Keep (0)", 0.0, 0.0), (1, "Negative", -2.0, -2 / 32768), (32768, "Keep (OSC/GUI)", 0.0, 0.0), (32769, "Positive", 2 / 32768, 2.0)]
PALETTES = ["OATS Navy", "Viridis", "Magma", "Inferno", "Plasma"]             # src/shaders.swift paletteNames
BLENDS = ["Alpha", "Add", "Screen", "Multiply", "Difference", "Lighten", "Darken", "Overlay"]   # src/layers.swift BlendMode
DEFAULT_MEDIA = os.path.expanduser("~/Developer/oats-viz/media")
LAYER_STARTS = [41, 57, 73, 89]
FX_STARTS = [113, 137, 161, 185]
FX_TYPES = ["None", "Kaleido", "Mirror", "Warp", "Twist", "Ripple", "ZoomBlur", "HueSpin", "Posterize", "Invert",
            "Duotone", "RGBSplit", "Pixelate", "SliceShift", "Strobe", "Blur", "EdgeGlow", "Trails",
            "StarTrails", "WarpTrails", "SpiralTrails"]                                                # src/fx.swift FXType (v0.8: appended)
MOD_TARGETS = ["None", "Rotation", "Scale", "Position X", "Position Y", "FX 1 amount", "FX 2 amount", "Opacity"]
MOD_SHAPES = ["Sine", "Saw", "Square", "Random step"]
MOD_BEATS = [0.25, 0.5, 1, 2, 4, 8, 16]
GEN_TYPES = ["Lines", "Angles", "Prisms", "Circles", "Dots", "Grid", "Polygons", "Rays", "Spiral", "Waves", "Tunnel", "Shapes Burst", "Stars"]  # src/gen.swift GenType (v0.9: Stars appended)
# 0 = keep (no DMX value: an older patch with the channel at 0 changes nothing), 1-124 one way, 125-131 stop, 132-255 the other
SPIN_SETS = [(0, "Keep (OSC/GUI)", 0.0, 0.0), (1, "Spin clockwise", -720.0, -720 / 124), (125, "Stop", 0.0, 0.0), (132, "Spin counter-clockwise", 720 / 124, 720.0)]
GEN_SPEED_SETS = [(0, "Keep (OSC/GUI)", 0.0, 0.0), (1, "Reverse", -1.0, -1 / 124), (125, "Stop", 0.0, 0.0), (132, "Forward", 1 / 124, 1.0)]
UNIT_KEEP_SETS = lambda lo, hi: [(0, "Keep (OSC/GUI)", 0.0, 0.0), (1, lo + " to " + hi, 0.0, 1.0)]

# Feature groups, as grandMA3 names them (shared/resource/attribute_definitions.xml).
FEATURE_GROUPS = [
    ("Dimmer", "Dimmer", ["Dimmer"]),
    ("Position", "Position", ["XYZ", "Rotation"]),
    ("Gobo", "Gobo", ["Media"]),
    ("Color", "Color", ["RGB", "Color"]),
    ("Focus", "Focus", ["Focus"]),
    ("Control", "Control", ["Control"]),
]


def bands(names, width=10):
    """Choice channel: bands of `width` values, then Reserved."""
    return [(i * width, n) for i, n in enumerate(names)] + [(len(names) * width, "Reserved")]


def ch(c, nbytes, attr, pretty, feature, function, default, snap=False, unit="None", phys=(0.0, 1.0), sets=(), master="None", ag=None):
    """One DMX channel. sets: (dmx_from, name) or (dmx_from, name, phys_from, phys_to). ag: GDTF ActivationGroup."""
    return dict(ch=c, bytes=nbytes, attr=attr, pretty=pretty, feature=feature, function=function, default=default,
                snap=snap, unit=unit, phys=phys, sets=list(sets), master=master, ag=ag)


def reserved(c, nbytes, attr, pretty, feature, what, default=0, snap=False, unit="None", phys=(0.0, 1.0)):
    return ch(c, nbytes, attr, pretty, feature, what + " (reserved)", default, snap=snap, unit=unit, phys=phys)


CTL, MEDIA, COLOR, FOCUS, XYZ, ROT = "Control.Control", "Gobo.Media", "Color.Color", "Focus.Focus", "Position.XYZ", "Position.Rotation"

MODES = [
    dict(name="Master 16", start=1, footprint=16,
         description="OATS VIZ master: dimmer, tempo, column, scene recall, effect speed, test content, master control. Patch at universe address 1.",
         channels=[
             ch(1, 1, "Dimmer", "Dim", "Dimmer.Dimmer", "Dimmer", 0, unit="LuminousIntensity", master="Grand"),
             ch(2, 2, "OatsBPM", "BPM", CTL, "BPM", 0, phys=(0.0, 300.0),
                sets=[(0, "No override", 0.0, 0.0), (1, "BPM 20-300", 20.0, 300.0)]),
             ch(4, 1, "OatsTap", "Tap", CTL, "Tap", 0, snap=True, sets=[(0, "Off"), (128, "Tap")]),
             ch(5, 1, "OatsResync", "Resync", CTL, "Resync", 0, snap=True, sets=[(0, "Off"), (128, "Resync")]),
             reserved(6, 2, "OatsCrossfade", "XFade", CTL, "Crossfader"),
             ch(8, 1, "OatsColumn", "Column", CTL, "Column", 0, snap=True,
                sets=[(0, "None")] + [(i, "Column %d" % i) for i in range(1, 9)] + [(9, "Column 9+")]),
             ch(9, 1, "OatsScene", "Scene", CTL, "Scene", 0, snap=True,
                sets=[(0, "None")] + [(n, "Scene %d.%d" % ((n - 1) // 16 + 1, (n - 1) % 16 + 1)) for n in range(1, 129)] + [(129, "Reserved")]),
             ch(10, 1, "OatsSceneFade", "Scene Fade", CTL, "Scene fade", 0, phys=(0.0, 25.5),
                sets=[(0, "Scene's own", 0.0, 0.0), (1, "Fade 0.1-25.5 s", 0.1, 25.5)]),
             reserved(11, 1, "OatsMasterFX2", "MFX2", CTL, "Master FX 2"),
             reserved(12, 1, "OatsMasterFX3", "MFX3", CTL, "Master FX 3"),
             reserved(13, 1, "OatsMasterFX4", "MFX4", CTL, "Master FX 4"),
             ch(14, 1, "OatsEffectSpeed", "FX Speed", CTL, "Effect speed", 128, phys=(0.0, 2.0),
                sets=[(0, "Stopped", 0.0, 0.0), (1, "Slower", 1 / 128, 127 / 128), (128, "Normal", 1.0, 1.0), (129, "Faster", 1 + 1 / 127, 2.0)]),
             ch(15, 1, "OatsTestContent", "Test", CTL, "Test content", 0, snap=True, sets=bands(["Normal", "DEEP test", "NOISE test", "Test card", "NDI card"])),
             ch(16, 1, "OatsMasterControl", "Master Ctrl", CTL, "Master control", 0, snap=True,
                sets=bands(["Idle", "Blackout", "Freeze", "Safe look"])),
         ]),
    dict(name="Fractal 24", start=17, footprint=24,
         description="OATS VIZ fractal: deep zoom (7 formulas), target, depth, auto-zoom, endless loop, kaleido fold, Julia morph, orbit trap, palette. Patch right after the Master (address 17).",
         channels=[
             ch(1, 1, "OatsFractalType", "Type", MEDIA, "Fractal type", 0, snap=True, sets=bands(FORMULAS)),
             ch(2, 1, "OatsTarget", "Target", MEDIA, "Target", 0, snap=True,
                sets=[(0, "Free (keep)")] + [(i + 1, n) for i, n in enumerate(TARGETS)] + [(len(TARGETS) + 1, "Reserved")]),
             ch(3, 2, "OatsOffsetX", "Offset X", XYZ, "Offset X", 32768, phys=(-1.0, 1.0),
                sets=[(0, "Left", -1.0, -1 / 32768), (32768, "On target", 0.0, 0.0), (32769, "Right", 1 / 32768, 32767 / 32768)]),
             ch(5, 2, "OatsOffsetY", "Offset Y", XYZ, "Offset Y", 32768, phys=(-1.0, 1.0),
                sets=[(0, "Down", -1.0, -1 / 32768), (32768, "On target", 0.0, 0.0), (32769, "Up", 1 / 32768, 32767 / 32768)]),
             ch(7, 2, "OatsDepth", "Depth", FOCUS, "Zoom depth", 0, phys=(0.0, 28.0)),
             ch(9, 1, "OatsAutoZoom", "Auto Zoom", FOCUS, "Auto-zoom speed", 128, phys=(-0.5, 0.5),
                sets=[(0, "Zoom out", -0.5, -0.004), (125, "Stop", 0.0, 0.0), (132, "Zoom in", 0.5 / 124, 0.5)]),
             ch(10, 2, "OatsIterations", "Iterations", MEDIA, "Max iterations", 0, phys=(0.0, 65535.0),
                sets=[(0, "Auto", 0.0, 0.0), (1, "Fixed", 1.0, 65535.0)]),
             ch(12, 2, "OatsJuliaRe", "Julia Re", MEDIA, "Julia c real", 32768, phys=(-2.0, 2.0), sets=JULIA_C_SETS),
             ch(14, 2, "OatsJuliaIm", "Julia Im", MEDIA, "Julia c imaginary", 32768, phys=(-2.0, 2.0), sets=JULIA_C_SETS),
             ch(16, 1, "OatsKaleidoFold", "Kaleido", MEDIA, "Kaleido fold", 0, snap=True, sets=FOLD_SETS),
             ch(17, 1, "OatsPalette", "Palette", COLOR, "Palette", 0, snap=True, sets=bands(PALETTES)),
             ch(18, 1, "OatsPaletteOffset", "Pal Offset", COLOR, "Palette offset", 0, phys=(0.0, 1.0)),
             ch(19, 1, "OatsPaletteCycle", "Pal Cycle", COLOR, "Palette cycle speed", 0, unit="Frequency", phys=(0.0, 0.5),
                sets=[(0, "Stop", 0.0, 0.0), (1, "Cycle", 0.5 / 255, 0.5)]),
             ch(20, 1, "OatsColouring", "Trap", COLOR, "Orbit trap", 0, snap=True, sets=bands(TRAPS)),
             ch(21, 1, "OatsRotation", "Rotation", ROT, "Rotation", 0, unit="Angle", phys=(0.0, 360.0)),
             ch(22, 1, "OatsFractalSpin", "Spin", ROT, "Spin", 0, unit="AngularSpeed", phys=(-720.0, 720.0), sets=SPIN_SETS),
             ch(23, 1, "OatsJuliaAmount", "Julia", MEDIA, "Julia morph", 0, phys=(0.0, 1.0),
                sets=[(0, "Off", 0.0, 0.0), (1, "Mandelbrot to Julia", 1 / 255, 1.0)]),
             ch(24, 1, "OatsFractalControl", "Fractal Ctrl", CTL, "Fractal control", 0, snap=True,
                sets=bands(FRACTAL_CONTROL)),
         ]),
]


COLOR_MODE = dict(name="Color 8", start=105, footprint=8,
    description="OATS VIZ colour link (lights -> VJ): RGB like a wash, match amount, target, mode. Patch after Layer 4 (address 105).",
    channels=[
        ch(1, 1, "ColorAdd_R", "R", "Color.RGB", "Red", 255, unit="ColorComponent", ag="ColorRGB"),
        ch(2, 1, "ColorAdd_G", "G", "Color.RGB", "Green", 255, unit="ColorComponent", ag="ColorRGB"),
        ch(3, 1, "ColorAdd_B", "B", "Color.RGB", "Blue", 255, unit="ColorComponent", ag="ColorRGB"),
        ch(4, 1, "OatsColorAmount", "Match", CTL, "Match amount", 0, sets=[(0, "Off", 0.0, 0.0), (1, "Match", 1 / 255, 1.0)]),
        ch(5, 1, "OatsColorTarget", "Col Target", CTL, "Colour target", 0, snap=True, sets=bands(["All layers + fractal", "Clips only", "Fractal only"])),
        ch(6, 1, "OatsColorMode", "Col Mode", CTL, "Colour mode", 0, snap=True, sets=bands(["Tint", "Hue shift", "Replace"])),
        reserved(7, 1, "OatsColorCh7", "Color 7", CTL, "Color ch 7"),
        reserved(8, 1, "OatsColorCh8", "Color 8", CTL, "Color ch 8"),
    ])


def tile_set_name(idx):
    """src/dmx.swift fxTileSetName: flip (4) x tile (Normal, Tile 2-8, Mirror 2-8) in bands of 4."""
    fl, ts = idx // 15, idx % 15
    base = "" if ts == 0 else ("Tile %d" % (ts + 1) if ts <= 7 else "Mirror %d" % (ts - 6))
    f = ["", "Flip H", "Flip V", "Flip HV"][fl]
    return (f or "Normal") if not base else (base + " " + f if f else base)


def beat_name(b):
    n = {0.25: "1/4", 0.5: "1/2"}.get(b, "%d" % b)
    return n + (" beat" if b <= 1 else " beats")


FX_SPEED_SETS = [(0, "Stopped", 0.0, 0.0), (1, "Slower", 1 / 256, 127 / 256), (128, "Normal", 0.5, 0.5), (129, "Faster", 0.5 + 0.5 / 127, 1.0)]
FX_AMOUNT_SETS = [(0, "Off", 0.0, 0.0), (1, "Amount", 1 / 255, 1.0)]
FXC = "Gobo.Media"
LAYER_FX_MODE = dict(name="Layer FX 24", start=113, footprint=24,
    description="OATS VIZ layer motion + FX: position, scale, rotation, spin, flip/tile, 2 FX slots, beat mod; ch 20-22 master FX; ch 23-24 generator speed/thickness "
                "(Layer FX 1 only). One fixture per layer: patch at 113, 137, 161, 185 (layers 1-4).",
    channels=[
        ch(1, 2, "OatsLayerX", "Pos X", XYZ, "Position X", 32768, phys=(-1.0, 1.0),
           sets=[(0, "Left", -1.0, -1 / 32768), (32768, "Centre", 0.0, 0.0), (32769, "Right", 1 / 32768, 32767 / 32768)]),
        ch(3, 2, "OatsLayerY", "Pos Y", XYZ, "Position Y", 32768, phys=(-1.0, 1.0),
           sets=[(0, "Up", -1.0, -1 / 32768), (32768, "Centre", 0.0, 0.0), (32769, "Down", 1 / 32768, 32767 / 32768)]),
        ch(5, 1, "OatsLayerScale", "Scale", XYZ, "Scale", 128, phys=(0.1, 4.0),
           sets=[(0, "Smaller", 0.1, 0.1 * 10 ** (127 / 128)), (128, "1x (cover)", 1.0, 1.0), (129, "Larger", 4 ** (1 / 127), 4.0)]),
        ch(6, 2, "OatsLayerRot", "Rotation", ROT, "Rotation", 32768, unit="Angle", phys=(-180.0, 180.0),
           sets=[(0, "Clockwise", -180.0, -180 / 32768), (32768, "Upright", 0.0, 0.0), (32769, "Counter-clockwise", 180 / 32768, 180 * 32767 / 32768)]),
        ch(8, 1, "OatsLayerSpin", "Spin", ROT, "Spin", 128, unit="AngularSpeed", phys=(-720.0, 720.0),
           sets=[(0, "Spin clockwise", -720.0, -720 / 125), (125, "Stop", 0.0, 0.0), (132, "Spin counter-clockwise", 720 / 124, 720.0)]),
        ch(9, 1, "OatsLayerTile", "Flip/Tile", FXC, "Flip / tile", 0, snap=True,
           sets=[(i * 4, tile_set_name(i)) for i in range(60)] + [(240, "Reserved")]),
        ch(10, 1, "OatsFX1Type", "FX1", FXC, "FX 1 type", 0, snap=True, sets=bands(FX_TYPES)),
        ch(11, 1, "OatsFX1Amount", "FX1 Amt", FXC, "FX 1 amount", 0, sets=FX_AMOUNT_SETS),
        ch(12, 1, "OatsFX1Speed", "FX1 Spd", FXC, "FX 1 speed", 128, sets=FX_SPEED_SETS),
        ch(13, 1, "OatsFX2Type", "FX2", FXC, "FX 2 type", 0, snap=True, sets=bands(FX_TYPES)),
        ch(14, 1, "OatsFX2Amount", "FX2 Amt", FXC, "FX 2 amount", 0, sets=FX_AMOUNT_SETS),
        ch(15, 1, "OatsFX2Speed", "FX2 Spd", FXC, "FX 2 speed", 128, sets=FX_SPEED_SETS),
        ch(16, 1, "OatsModTarget", "Mod Target", CTL, "Beat mod target", 0, snap=True, sets=bands(MOD_TARGETS)),
        ch(17, 1, "OatsModShape", "Mod Shape", CTL, "Beat mod shape", 0, snap=True, sets=bands(MOD_SHAPES)),
        ch(18, 1, "OatsModRate", "Mod Rate", CTL, "Beat mod rate", 0, snap=True, sets=bands([beat_name(b) for b in MOD_BEATS])),
        ch(19, 1, "OatsModDepth", "Mod Depth", CTL, "Beat mod depth", 0),
        ch(20, 1, "OatsMstFXType", "Master FX", FXC, "Master FX type (Layer FX 1 only)", 0, snap=True, sets=bands(FX_TYPES)),
        ch(21, 1, "OatsMstFXAmount", "MFX Amt", FXC, "Master FX amount", 0, sets=FX_AMOUNT_SETS),
        ch(22, 1, "OatsMstFXSpeed", "MFX Spd", FXC, "Master FX speed", 128, sets=FX_SPEED_SETS),
        ch(23, 1, "OatsGenSpeed", "Gen Speed", FXC, "Generator speed", 0, phys=(-1.0, 1.0), sets=GEN_SPEED_SETS),
        ch(24, 1, "OatsGenThickness", "Gen Thick", FXC, "Generator thickness", 0, sets=UNIT_KEEP_SETS("Thin", "thick")),
    ])


def preset_dmx(p):
    """DMX values (Layer FX 24 channel -> value) for one tools/fx_presets.json preset: the inverse of src/dmx.swift."""
    import math
    t, fx, m = p.get("transform", {}), (p.get("fx", []) + [{}, {}])[:2], p.get("mod", {})
    def b16(v):
        return max(0, min(65535, int(round(v))))
    def speed(s):
        return int(round(s / 0.5 * 128)) if s <= 0.5 else int(round(128 + (s - 0.5) / 0.5 * 127))
    sc = t.get("scale", 1.0)
    out = {"1-2 pos X": b16(32768 + t.get("x", 0) * 32768), "3-4 pos Y": b16(32768 + t.get("y", 0) * 32768),
           "5 scale": int(round(128 * math.log10(sc * 10))) if sc <= 1 else int(round(128 + 127 * math.log(sc) / math.log(4))),
           "6-7 rotation": b16(32768 + t.get("rotation", 0) / 180 * 32768)}
    sp = t.get("spin", 0)
    out["8 spin"] = 128 if sp == 0 else (int(round(131 + sp / 2 * 124)) if sp > 0 else int(round(125 + sp / 2 * 125)))
    tile, mir = int(t.get("tile", 1)), bool(t.get("mirror", False))
    ts = 0 if tile <= 1 else (tile - 1 if not mir else tile + 6)
    out["9 flip/tile"] = 4 * ((1 if t.get("flipx") else 0) + (2 if t.get("flipy") else 0)) * 15 + 4 * ts
    for i, f in enumerate(fx):
        b = 10 + 3 * i
        ty = f.get("type", "None")
        out["%d FX%d type" % (b, i + 1)] = 10 * [x.lower() for x in FX_TYPES].index(ty.lower())
        out["%d FX%d amount" % (b + 1, i + 1)] = int(round(f.get("amount", 0.0 if ty == "None" else 0.5) * 255)) if ty != "None" else 0
        out["%d FX%d speed" % (b + 2, i + 1)] = speed(f.get("speed", 0.5))
    tg = {"none": 0, "rotation": 1, "scale": 2, "posx": 3, "posy": 4, "fx1": 5, "fx2": 6, "opacity": 7}[m.get("target", "none")]
    out["16 mod target"] = 10 * tg
    out["17 mod shape"] = 10 * {"sine": 0, "saw": 1, "square": 2, "random": 3}[m.get("shape", "sine")] if tg else 0
    beats = m.get("beats", 1)
    out["18 mod rate"] = 10 * min(range(len(MOD_BEATS)), key=lambda k: abs(math.log2(MOD_BEATS[k]) - math.log2(beats))) if tg else 0
    out["19 mod depth"] = int(round(m.get("depth", 0.5) * 255)) if tg else 0
    return out


DEFAULTS = {"1-2 pos X": 32768, "3-4 pos Y": 32768, "5 scale": 128, "6-7 rotation": 32768, "8 spin": 128, "12 FX1 speed": 128, "15 FX2 speed": 128}


def presets_markdown(path):
    with open(path) as f:
        ps = json.load(f)["presets"]
    print("| Preset | Layer FX 24 channels (others at the neutral defaults: ch 1-2/3-4/6-7 32768, ch 5 128, ch 8 128, ch 12/15 128, rest 0) |")
    print("|---|---|")
    for p in ps:
        d = preset_dmx(p)
        diff = ["ch %s = %d" % (k, v) for k, v in d.items() if v != DEFAULTS.get(k, 0)]
        print("| %s | %s |" % (p["name"], ", ".join(diff) or "neutral"))


def load_library(media):
    """[(bank, name, [(slot, clip name)])] from <media>/library.json, like src/layers.swift Library ([] if unreadable)."""
    try:
        with open(os.path.join(media, "library.json")) as f:
            j = json.load(f)
        out = []
        for b in j["banks"]:
            if not isinstance(b.get("bank"), int) or not isinstance(b.get("slots"), list):
                continue
            clips = [(c["slot"], c.get("name", c["file"])) for c in b["slots"] if isinstance(c.get("slot"), int) and isinstance(c.get("file"), str)]
            out.append((b["bank"], b.get("name", "BANK %d" % b["bank"]), sorted(clips)))
        return out
    except Exception as e:
        print("warning: no readable library in %s (%s): bank/slot channel sets get no names" % (media, e), file=sys.stderr)
        return []


def clip_set_name(slot, name):
    """src/dmx.swift dmxClipSetName: "<slot> <name>", at most 32 characters, no trailing spaces."""
    return ("%d %s" % (slot, name))[:32].rstrip(" ")


def layer_mode(lib):
    """Layer 16, as src/dmx.swift layerModeDef."""
    bank_sets = [(0, "Empty")]
    bs = sorted(b for b, _, _ in lib if 1 <= b <= 255)
    names = {b: n for b, n, _ in lib}
    for i, b in enumerate(bs):
        bank_sets.append((b, names[b]))
        nxt = bs[i + 1] if i + 1 < len(bs) else 256
        if nxt != b + 1 and b < 255:
            bank_sets.append((b + 1, "Unused"))
    if not bs:
        bank_sets.append((1, "Unused"))
    slot_sets = [(0, "Clear")]
    clips = sorted(c for b, _, cs in lib if b == 1 for c in cs if 1 <= c[0] <= 255)
    for i, (sl, nm) in enumerate(clips):
        slot_sets.append((sl, clip_set_name(sl, nm)))
        nxt = clips[i + 1][0] if i + 1 < len(clips) else 256
        if nxt != sl + 1 and sl < 255:
            slot_sets.append((sl + 1, "Slot %d+" % (sl + 1)))
    if not clips:
        slot_sets.append((1, "Slot 1+"))
    chans = [
        ch(1, 1, "Dimmer", "Opacity", "Dimmer.Dimmer", "Opacity", 0, unit="LuminousIntensity"),
        ch(2, 1, "MediaFolder1", "Bank", MEDIA, "Bank", 0, snap=True, sets=bank_sets),
        ch(3, 1, "MediaContent1", "Slot", MEDIA, "Slot", 0, snap=True, sets=slot_sets),
        ch(4, 1, "OatsBlend", "Blend", CTL, "Blend mode", 0, snap=True, sets=bands(BLENDS)),
        ch(5, 1, "OatsPlayMode", "Playmode", CTL, "Playmode", 0, snap=True, sets=bands(["Loop", "Once + hold"])),
        ch(6, 2, "OatsPlaySpeed", "Speed", CTL, "Play speed", 16384, phys=(0.0, 4.0),
           sets=[(0, "Stopped", 0.0, 0.0), (1, "Slower", 1 / 16384, 16383 / 16384), (16384, "Normal", 1.0, 1.0),
                 (16385, "Faster", 16385 / 16384, 65535 / 16384)]),
        ch(8, 1, "OatsTransition", "Transition", CTL, "Transition time", 0, unit="Time", phys=(0.0, 10.0)),
        ch(9, 1, "OatsRestart", "Restart", CTL, "Restart", 0, snap=True, sets=[(0, "Off"), (128, "Restart")]),
        ch(10, 1, "OatsClipCommand", "Clip Cmd", CTL, "Clip command", 0, snap=True, sets=bands(["Idle", "Next", "Previous", "Random"])),
        ch(11, 1, "OatsAutopilot", "Autopilot", CTL, "Autopilot", 0, snap=True, sets=bands(["Off", "Order", "Shuffle"])),
        ch(12, 1, "OatsAutopilotTime", "AP Time", CTL, "Autopilot interval", 0, unit="Time", phys=(0.0, 255.0),
           sets=[(0, "Per beats (ch 13)", 0.0, 0.0), (1, "1-255 s", 1.0, 255.0)]),
        ch(13, 1, "OatsAutopilotBeats", "AP Beats", CTL, "Autopilot beats", 0, snap=True,
           sets=bands(["1 beat", "2 beats", "4 beats", "8 beats", "16 beats", "32 beats"])),
        ch(14, 1, "OatsLayerSource", "Source", MEDIA, "Source", 0, snap=True, sets=bands(["Clip", "Fractal", "Generator", "NDI"])),
        ch(15, 1, "OatsGenType", "Gen Type", MEDIA, "Generator type", 0, snap=True, sets=bands(GEN_TYPES)),
        ch(16, 1, "OatsGenCount", "Gen Count", MEDIA, "Generator count", 0, sets=UNIT_KEEP_SETS("Sparse", "dense")),
    ]
    return dict(name="Layer 16", start=LAYER_STARTS[0], footprint=16,
                description="OATS VIZ layer: opacity, bank, slot, blend, playmode, speed, transition, restart, clip command, autopilot, "
                            "source (clip / fractal / generator), generator type + count. "
                            "One fixture per layer: patch at 41, 57, 73, 89 (layers 1-4).",
                channels=chans)


def fmt(v):
    return "%.6f" % v


def dmxv(v, nbytes):
    return "%d/%d" % (v, nbytes)


def build_xml():
    attrs = {}                                                    # name -> (pretty, feature, unit, ag), in first-use order
    for m in MODES:
        for c in m["channels"]:
            attrs.setdefault(c["attr"], (c["pretty"], c["feature"], c["unit"], c["ag"]))
    ags = sorted({v[3] for v in attrs.values() if v[3]})
    L = ['<GDTF DataVersion="%s">' % DATA_VERSION,  # no XML declaration, like the GDTF files MA3 ships
         '  <FixtureType Name="OATS VIZ" ShortName="OATSVIZ" LongName="OATS VIZ media server" Manufacturer="OATS"'
         ' Description=%s FixtureTypeID="%s" Thumbnail="" ThumbnailOffsetX="0" ThumbnailOffsetY="0" CanHaveChildren="No" RefFT="">'
         % (quoteattr("OATS VIZ player (Metal deep-zoom fractal + 4 clip layers, NDI out). Eleven fixtures per player on one universe: "
                      "mode Master 16 at address 1, mode Fractal 24 at 17, mode Layer 16 at 41, 57, 73, 89 (layers 1-4), mode Color 8 at 105, "
                      "mode Layer FX 24 at 113, 137, 161, 185 (layers 1-4)."), FIXTURE_TYPE_ID),
         '    <AttributeDefinitions>']
    if ags:
        L += ['      <ActivationGroups>'] + ['        <ActivationGroup Name="%s"/>' % g for g in ags] + ['      </ActivationGroups>']
    L += ['      <FeatureGroups>']
    for g, pretty, feats in FEATURE_GROUPS:
        L.append('        <FeatureGroup Name="%s" Pretty="%s">' % (g, pretty))
        L += ['          <Feature Name="%s"/>' % f for f in feats]
        L.append('        </FeatureGroup>')
    L += ['      </FeatureGroups>', '      <Attributes>']
    for name, (pretty, feature, unit, ag) in attrs.items():
        L.append('        <Attribute Name="%s" Pretty=%s%s Feature="%s" PhysicalUnit="%s"/>'
                 % (name, quoteattr(pretty), ' ActivationGroup="%s"' % ag if ag else "", feature, unit))
    L += ['      </Attributes>', '    </AttributeDefinitions>',
          '    <Wheels/>', '    <PhysicalDescriptions/>',
          '    <Models>', '      <Model Name="Body" Length="0.300000" Width="0.300000" Height="0.200000" PrimitiveType="Cube" File="" SVGOffsetX="0.000000" SVGOffsetY="0.000000" SVGSideOffsetX="0.000000" SVGSideOffsetY="0.000000" SVGFrontOffsetX="0.000000" SVGFrontOffsetY="0.000000"/>', '    </Models>',
          '    <Geometries>',
          '      <Geometry Name="Base" Model="Body" Position="{1.000000,0.000000,0.000000,0.000000}{0.000000,1.000000,0.000000,0.000000}'
          '{0.000000,0.000000,1.000000,0.000000}{0,0,0,1}"/>',
          '    </Geometries>',
          '    <DMXModes>']
    for m in MODES:
        L.append('      <DMXMode Name="%s" Description=%s Geometry="Base">' % (m["name"], quoteattr(m["description"])))
        L.append('        <DMXChannels>')
        for c in m["channels"]:
            n = c["bytes"]
            top = (1 << (8 * n)) - 1
            off = ",".join(str(c["ch"] + i) for i in range(n))
            pf, pt = c["phys"]
            fname = c["function"]
            L.append('          <DMXChannel DMXBreak="1" Offset="%s" InitialFunction=%s Highlight="None" Geometry="Base">'
                     % (off, quoteattr("Base_%s.%s.%s" % (c["attr"], c["attr"], fname))))
            L.append('            <LogicalChannel Attribute="%s" Snap="%s" Master="%s" MibFade="0.000000" DMXChangeTimeLimit="0.000000">'
                     % (c["attr"], "Yes" if c["snap"] else "No", c["master"]))
            L.append('              <ChannelFunction Name=%s Attribute="%s" OriginalAttribute="" DMXFrom="%s" Default="%s" '
                     'PhysicalFrom="%s" PhysicalTo="%s" RealFade="0.000000" RealAcceleration="0.000000" Min="%s" Max="%s" CustomName=""%s>'
                     % (quoteattr(fname), c["attr"], dmxv(0, n), dmxv(c["default"], n), fmt(pf), fmt(pt), fmt(pf), fmt(pt), "" if c["sets"] else "/"))
            if c["sets"]:
                froms = [s[0] for s in c["sets"]]
                for i, s in enumerate(c["sets"]):
                    lo, hi = s[0], (froms[i + 1] - 1 if i + 1 < len(froms) else top)
                    spf, spt = (s[2], s[3]) if len(s) == 4 else (pf + (pt - pf) * lo / top, pf + (pt - pf) * hi / top)
                    L.append('                <ChannelSet Name=%s DMXFrom="%s" PhysicalFrom="%s" PhysicalTo="%s"/>'
                             % (quoteattr(s[1]), dmxv(lo, n), fmt(spf), fmt(spt)))
                L.append('              </ChannelFunction>')
            L += ['            </LogicalChannel>', '          </DMXChannel>']
        L += ['        </DMXChannels>', '        <Relations/>', '        <FTMacros/>', '      </DMXMode>']
    L += ['    </DMXModes>',
          '    <Revisions>',
          '      <Revision Text=%s Date="%s" UserID="0" ModifiedBy="oats-m0 tools/make_gdtf.py"/>' % (quoteattr(REVISION[1]), REVISION[0]),
          '    </Revisions>',
          '    <FTPresets/>', '    <Protocols/>',
          '  </FixtureType>', '</GDTF>', '']
    return "\n".join(L)


def write(path):
    xml = build_xml().encode("utf-8")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    y, mo, d = (int(x) for x in REVISION[0][:10].split("-"))
    zi = zipfile.ZipInfo("description.xml", date_time=(y, mo, d, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_STORED  # MA3's own GDTF files are all stored, not deflated
    zi.create_system = 0  # MS-DOS-style entry, like most GDTF files (some zip readers dislike Unix attrs)
    zi.external_attr = 0
    with zipfile.ZipFile(tmp, "w") as z:
        z.writestr(zi, xml)
    os.replace(tmp, path)
    return len(xml)


def parse_dmx(v):
    m = re.fullmatch(r"(\d+)/(\d)", v or "")
    if not m:
        raise ValueError("bad DMX value %r" % v)
    return int(m.group(1)), int(m.group(2))


def decode(path):
    """Opens the .gdtf, checks it and returns {mode name: {footprint, channels: [...]}} in the --dmx-table shape."""
    errs = []
    with zipfile.ZipFile(path) as z:
        bad = z.testzip()
        if bad:
            errs.append("zip CRC error in %s" % bad)
        if "description.xml" not in z.namelist():
            raise SystemExit("FAIL: no description.xml in %s" % path)
        root = ET.fromstring(z.read("description.xml"))          # raises on malformed XML
    if root.tag != "GDTF" or root.get("DataVersion") != DATA_VERSION:
        errs.append("root %s DataVersion %s" % (root.tag, root.get("DataVersion")))
    ft = root.find("FixtureType")
    if not re.fullmatch(r"[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}", ft.get("FixtureTypeID", "")):
        errs.append("FixtureTypeID %r is not an upper-case UUID" % ft.get("FixtureTypeID"))
    feats = {"%s.%s" % (g.get("Name"), f.get("Name")) for g in ft.iter("FeatureGroup") for f in g.iter("Feature")}
    attrs = {}
    for a in ft.find("AttributeDefinitions/Attributes"):
        if a.get("Name") in attrs:
            errs.append("attribute %s defined twice" % a.get("Name"))
        attrs[a.get("Name")] = a
        if a.get("Feature") not in feats:
            errs.append("attribute %s: feature %s not defined" % (a.get("Name"), a.get("Feature")))
    geoms = {g.get("Name") for g in ft.iter("Geometry")}
    models = {m.get("Name") for m in ft.iter("Model")}
    for g in ft.iter("Geometry"):
        if g.get("Model") and g.get("Model") not in models:
            errs.append("geometry %s: model %s missing" % (g.get("Name"), g.get("Model")))
    out = {}
    for mode in ft.iter("DMXMode"):
        mname = mode.get("Name")
        if mode.get("Geometry") not in geoms:
            errs.append("%s: geometry %s missing" % (mname, mode.get("Geometry")))
        used, names, chans = {}, set(), []
        for dc in mode.iter("DMXChannel"):
            offs = [int(x) for x in dc.get("Offset").split(",")]
            lc = dc.find("LogicalChannel")
            attr = lc.get("Attribute")
            cname = "%s_%s" % (dc.get("Geometry"), attr)
            where = "%s %s" % (mname, cname)
            if dc.get("Geometry") not in geoms:
                errs.append("%s: geometry missing" % where)
            if cname in names:
                errs.append("%s: duplicate DMX channel name" % where)
            names.add(cname)
            if attr not in attrs:
                errs.append("%s: attribute not defined" % where)
            if offs != list(range(offs[0], offs[0] + len(offs))):
                errs.append("%s: offsets %s are not consecutive (coarse, fine)" % (where, offs))
            for o in offs:
                if o in used:
                    errs.append("%s: offset %d overlaps %s" % (where, o, used[o]))
                used[o] = cname
            n = len(offs)
            top = (1 << (8 * n)) - 1
            fns = lc.findall("ChannelFunction")
            init = dc.get("InitialFunction", "").split(".")
            if len(init) != 3 or init[0] != cname or init[1] != attr or init[2] not in [f.get("Name") for f in fns]:
                errs.append("%s: InitialFunction %r does not resolve" % (where, dc.get("InitialFunction")))
            sets, default, prev = [], None, -1
            for fi, fn in enumerate(fns):
                lo, res = parse_dmx(fn.get("DMXFrom"))
                hi = parse_dmx(fns[fi + 1].get("DMXFrom"))[0] - 1 if fi + 1 < len(fns) else top
                if res != n or lo <= prev or lo > top:
                    errs.append("%s: function %s DMXFrom %s (resolution %d, previous %d)" % (where, fn.get("Name"), fn.get("DMXFrom"), n, prev))
                prev = lo
                if fn.get("Attribute") not in attrs:
                    errs.append("%s: function attribute %s not defined" % (where, fn.get("Attribute")))
                if fn.get("Name") == init[-1]:
                    dv, dres = parse_dmx(fn.get("Default"))
                    if dres != n or not lo <= dv <= hi:
                        errs.append("%s: Default %s outside the initial function %d..%d/%d" % (where, fn.get("Default"), lo, hi, n))
                    default = dv
                sp = lo - 1
                for cs in fn.findall("ChannelSet"):
                    v, r = parse_dmx(cs.get("DMXFrom"))
                    if r != n or v <= sp or not lo <= v <= hi:
                        errs.append("%s: channel set %s DMXFrom %s" % (where, cs.get("Name"), cs.get("DMXFrom")))
                    sp = v
                    sets.append({"from": v, "name": cs.get("Name")})
            chans.append({"offset": offs, "attribute": attr, "default": default, "snap": lc.get("Snap") == "Yes", "sets": sets,
                          "function": fns[0].get("Name") if fns else ""})
        fp = max(used) if used else 0
        missing = sorted(set(range(1, fp + 1)) - set(used))
        if missing:
            errs.append("%s: offsets %s not used (gaps)" % (mname, missing))
        out[mname] = {"footprint": fp, "channels": chans}
    return out, errs


def compare(gdtf, table):
    errs = []
    tm = {m["name"]: m for m in table["modes"]}
    if set(tm) != set(gdtf):
        errs.append("modes: GDTF %s, player %s" % (sorted(gdtf), sorted(tm)))
    for name in sorted(set(tm) & set(gdtf)):
        g, p = gdtf[name], tm[name]
        if g["footprint"] != p["footprint"]:
            errs.append("%s: footprint GDTF %d, player %d" % (name, g["footprint"], p["footprint"]))
        gc = {tuple(c["offset"]): c for c in g["channels"]}
        pc = {tuple(c["offset"]): c for c in p["channels"]}
        if set(gc) != set(pc):
            errs.append("%s: channel offsets differ: only GDTF %s, only player %s" % (name, sorted(set(gc) - set(pc)), sorted(set(pc) - set(gc))))
        for off in sorted(set(gc) & set(pc)):
            a, b = gc[off], pc[off]
            for k in ("attribute", "default", "snap", "sets", "function"):
                if a[k] != b[k]:
                    errs.append("%s ch %s %s: GDTF %r, player %r" % (name, ",".join(map(str, off)), k, a[k], b[k]))
    return errs


def markdown():
    for m in MODES:
        at = ", ".join(map(str, LAYER_STARTS)) if m["name"] == "Layer 16" else ", ".join(map(str, FX_STARTS)) if m["name"] == "Layer FX 24" else str(m["start"])
        print("**%s** (%d ch, patch at address %s)\n" % (m["name"], m["footprint"], at))
        print("| Ch | Attribute | Function | Default | Values |")
        print("|---|---|---|---|---|")
        for c in m["channels"]:
            chs = "%d" % c["ch"] if c["bytes"] == 1 else "%d–%d" % (c["ch"], c["ch"] + 1)
            vals = ", ".join("%d %s" % (s[0], s[1]) for s in c["sets"])
            print("| %s | %s%s | %s | %d | %s |" % (chs, c["attr"], " (snap)" if c["snap"] else "", c["function"], c["default"], vals))
        print()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default=DEFAULT_OUT)
    ap.add_argument("--check", metavar="BIN", help="compare with `BIN --dmx-table` (native arm64; an x86_64 build runs under Rosetta)")
    ap.add_argument("--validate", metavar="GDTF", help="only validate this file")
    ap.add_argument("--markdown", action="store_true")
    ap.add_argument("--presets", nargs="?", const=os.path.join(os.path.dirname(os.path.abspath(__file__)), "fx_presets.json"), metavar="JSON")
    ap.add_argument("--media", default=DEFAULT_MEDIA, help="clip library folder (library.json) for the Layer 16 names")
    a = ap.parse_args()
    MODES.append(layer_mode(load_library(a.media)))
    MODES.append(COLOR_MODE)
    MODES.append(LAYER_FX_MODE)
    if a.presets:
        presets_markdown(a.presets)
        return 0
    if a.markdown:
        markdown()
        return 0
    path = a.validate or a.out
    if not a.validate:
        n = write(path)
        print("wrote %s (%d bytes; description.xml %d bytes; DataVersion %s; FixtureTypeID %s)" % (path, os.path.getsize(path), n, DATA_VERSION, FIXTURE_TYPE_ID))
    gdtf, errs = decode(path)
    for name, m in gdtf.items():
        print("  mode %-11s footprint %2d, %2d channels: %s" % (name, m["footprint"], len(m["channels"]),
              " ".join("%s=%s" % (c["attribute"], ",".join(map(str, c["offset"]))) for c in m["channels"])))
    if a.check:
        r = subprocess.run([a.check, "--media", a.media, "--dmx-table"], capture_output=True, text=True, timeout=60)
        if r.returncode != 0:
            errs.append("%s --dmx-table failed: %s" % (a.check, r.stderr.strip()[:300]))
        else:
            errs += compare(gdtf, json.loads(r.stdout))
            print("  compared with %s --dmx-table: %d modes" % (a.check, len(json.loads(r.stdout)["modes"])))
    if errs:
        print("FAIL:\n  " + "\n  ".join(errs))
        return 1
    print("PASS: zip + well-formed description.xml, offsets inside each footprint with no gaps or overlaps, references resolve"
          + (", matches the player's decoder table" if a.check else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
