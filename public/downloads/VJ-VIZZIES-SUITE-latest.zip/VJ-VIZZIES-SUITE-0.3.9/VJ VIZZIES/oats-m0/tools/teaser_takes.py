#!/usr/bin/env python3
"""Teaser takes: records the four takes Grok asked for, each in 1080p (16:9) and vertical (9:16), with the player's
recorder (/oats/record/start|stop, src/recorder.swift), and writes a shot list. Stdlib only; run with python3 -I.

usage:
  python3 -I tools/teaser_takes.py                 # all 4 takes x 2 sizes = 8 files, ~150 s each
  python3 -I tools/teaser_takes.py --dry-run       # print the plan, send nothing, record nothing
  python3 -I tools/teaser_takes.py --secs 120 --takes deep-dive,looks --sizes 1080p
  python3 -I tools/teaser_takes.py --to 127.0.0.1:7000 --out "~/Movies/OATS VIZ/teaser-takes"

Takes (driven over OSC, timed in beats from status.json tempo.bpm like oats_script.py):
  deep-dive  BG fractal: a Seahorse dive from depth 0 to about 1e20, palette cycling, a rotation phaser, no clips
  looks      generator looks on L2 / L3 changing every 8 bars (gen_presets.json, apply_look), BG fractal under them, 2 master FX changes
  audio      a Stars generator on L1 with Star Trails in FX slot 1, audio preset "Star trails · kick", the audio source as set
  scenes     scene 1.1, a fade to 1.2 with the master dimmer dipping on the change, back again

Before anything the player's look is saved with tools/oats_state.py (logs/teaser-state.json) and put back at the end,
also on Ctrl-C. Every run then starts from a clean look (clean_look): audio routes cleared, autopilots off, layer
transforms / FX / beat mod reset on L0-L4 (scale 1, no spin), master FX off, blackout off, dimmer 1; the restore puts
the user's look back as it was. Files: <out>/<yyyymmdd-HHMMSS>-<take>-<size>.mp4; the shot list <out>/SHOT-LIST.md says what each
file shows, with timestamps from the recording start.
"""
import argparse
import json
import os
import signal
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
M0 = os.path.dirname(HERE)
sys.path.insert(0, HERE)                     # python3 -I does not add the script folder: oats_script.py lives next to this file
from oats_script import Sender, apply_look, load as load_looks, status  # noqa: E402

STATE_FILE = os.path.join(M0, "logs", "teaser-state.json")
STATE_TOOL = os.path.join(HERE, "oats_state.py")
SCENES = os.path.join(M0, "scenes.json")
DEFAULT_OUT = os.path.expanduser("~/Movies/OATS VIZ/teaser-takes")
SIZES = {"1080p": "16:9 1920x1080", "vertical": "9:16 1080x1920 (centre crop of the 16:9 program)"}
TAKES = ["deep-dive", "looks", "audio", "scenes"]
LOOK_CYCLE = ["Prism Kaleido", "Ring Pulse", "Hex Nest", "Twist Rays", "Hypno Spiral", "Diamond Tunnel", "Star Burst", "Ocean Waves"]
AUDIO_LOOK = "Star Field Trails"             # Stars generator + the Star Trails FX preset (slot 1), blend screen
AUDIO_PRESET = "Star trails · kick"
MASTER_FX = [("Star Trails", "master FX Star Trails on"), ("Vortex", "master FX Vortex (turn + zoom)")]


class Take:
    """One recording: sends OSC through `tx` (or prints, in a dry run) and keeps the shot list events."""

    def __init__(self, tx, name, size, secs, dry, log):
        self.tx, self.name, self.size, self.secs, self.dry, self.log = tx, name, size, secs, dry, log
        self.t0 = time.monotonic()
        self.vt = 0.0                             # dry run: a virtual clock (holds advance it, nothing sleeps)
        self.events = []
        self.notes = []
        self.path = ""

    def send(self, addr, *args):
        if self.dry:
            self.log(f"      (dry) {addr} {' '.join(repr(a) for a in args)}")
        else:
            self.tx.send(addr, *args)
            time.sleep(0.004)

    def elapsed(self):
        return self.vt if self.dry else time.monotonic() - self.t0

    def mark(self, what):
        t = self.elapsed()
        self.events.append((t, what))
        self.log(f"  {self.stamp(t)}  {what}")

    @staticmethod
    def stamp(t):
        return f"{int(t) // 60:02d}:{int(t) % 60:02d}"

    def left(self):
        return self.secs - self.elapsed()

    def bpm(self):
        b = status().get("tempo", {}).get("bpm") or 120
        return float(b) if 20 <= float(b) <= 999 else 120.0

    def hold_beats(self, beats, cap=None):
        """Holds N beats of the player's tempo, ending on a beat boundary when the clock is known; never past the take."""
        st = status().get("tempo", {})
        bpm = self.bpm()
        hold = beats * 60.0 / bpm
        beat_now = st.get("beat")
        if isinstance(beat_now, (int, float)):
            hold -= (beat_now % 1.0) * 60.0 / bpm
        if cap is not None:
            hold = min(hold, cap)
        return self.hold_secs(hold)

    def hold_secs(self, s):
        s = min(s, max(0.0, self.left()))
        if self.dry:
            self.vt += s
        elif s > 0:
            time.sleep(s)
        return s

    def layers_off(self):
        for n in (1, 2, 3, 4):
            self.send(f"/oats/layers/{n}/opacity", 0.0)

    def bg_fractal(self):
        self.send("/oats/layers/0/source", "fractal")
        self.send("/oats/fractal/layer", 0)
        self.send("/oats/fractal/opacity", 1.0)
        self.send("/oats/layers/0/opacity", 1.0)

    # ---- the four takes --------------------------------------------------------------------------------------

    def deep_dive(self):
        target_depth = 20.0
        speed = round(target_depth / max(30.0, self.secs - 15.0), 3)     # decades/s: depth 20 about 15 s before the end
        self.layers_off()
        self.bg_fractal()
        self.send("/oats/master/fx/reset")
        self.send("/oats/fractal/1/target/dive", 0)
        self.send("/oats/fractal/1/preset", "none")
        self.send("/oats/fractal/1/target", "SEAHORSE")
        self.send("/oats/fractal/1/depth", 0.0)
        self.send("/oats/fractal/1/zoomspeed", 0.0)
        self.send("/oats/fractal/1/palette", 3)
        self.send("/oats/fractal/1/palette/speed", 0.08)
        self.send("/oats/fractal/1/phaser/1/target", "rotation")
        self.send("/oats/fractal/1/phaser/1/shape", "sine")
        self.send("/oats/fractal/1/phaser/1/beats", 32.0)
        self.send("/oats/fractal/1/phaser/1/depth", 0.6)
        self.send("/oats/fractal/1/phaser/1/on", 1)
        self.send("/oats/fractal/1/phaser/2/on", 0)
        self.send("/oats/fractal/1/phaser/3/on", 0)
        self.mark("Seahorse valley at depth 0 (full set), Magma palette cycling, rotation wobble over 32 beats; clips off")
        self.hold_secs(4.0)
        self.send("/oats/fractal/1/zoomspeed", speed)
        self.mark(f"dive starts: {speed} decades/s toward depth 1e{target_depth:.0f}")
        for d in (5, 10, 15):
            self.hold_secs(max(0.0, 4.0 + d / speed - self.elapsed()))
            self.mark(f"about depth 1e{d}")
        self.hold_secs(max(0.0, self.left() - 8.0))
        self.send("/oats/fractal/1/zoomspeed", 0.0)
        self.mark("hold at the deep end")
        self.hold_secs(self.left())
        self.notes.append(f"zoom speed {speed} decades/s; Magma palette at 0.08 cycles/s; phaser 1 = rotation wobble, sine, 32 beats, depth 0.6")

    def looks(self):
        looks = load_looks()["looks"]
        self.layers_off()
        self.bg_fractal()
        self.send("/oats/master/fx/reset")
        self.send("/oats/fractal/1/zoomspeed", 0.15)
        self.send("/oats/fractal/1/palette/speed", 0.05)
        self.mark("BG fractal zooming slowly underneath (0.15 decades/s)")
        cycle = [n for n in LOOK_CYCLE if n in looks] or list(looks)[:8]
        step, fx_i, i = 0, 0, 0
        while self.left() > 2.0:
            layer = 2 if step % 2 == 0 else 3
            name = cycle[i % len(cycle)]
            apply_look(self.tx if not self.dry else _DryTx(self.log), layer, name, looks[name])
            self.send(f"/oats/layers/{layer}/opacity", 0.85)
            self.mark(f"L{layer}: look '{name}' ({looks[name].get('gen', {}).get('type', '?')}, FX {looks[name].get('fx') or 'none'}, blend {looks[name].get('blend', 'alpha')})")
            if step in (2, 5) and fx_i < len(MASTER_FX):
                pre, what = MASTER_FX[fx_i]
                self.send("/oats/master/fx/preset", pre)
                self.mark(what)
                fx_i += 1
            held = self.hold_beats(32)
            step += 1
            i += 1
            if self.dry:
                self.log(f"      (dry) hold 8 bars = 32 beats ({held:.1f} s at {self.bpm():.0f} BPM)")
        self.send("/oats/master/fx/reset")
        self.mark("master FX off")
        self.notes.append("looks alternate L2 / L3 every 8 bars (32 beats at the player's tempo); master FX changes after the 3rd and 6th look")

    def audio(self):
        looks = load_looks()["looks"]
        st = status()
        au = st.get("audio", {})
        src = au.get("source", "off")
        self.layers_off()
        self.bg_fractal()
        self.send("/oats/master/fx/reset")
        self.send("/oats/fractal/1/zoomspeed", 0.0)
        self.send("/oats/fractal/opacity", 0.35)
        look = looks.get(AUDIO_LOOK)
        if look:
            apply_look(self.tx if not self.dry else _DryTx(self.log), 1, AUDIO_LOOK, look)
        else:
            self.send("/oats/layers/1/source", "gen")
            self.send("/oats/layers/1/gen/type", "Stars")
            self.send("/oats/layers/1/fx/preset", "Star Trails")
        self.send("/oats/layers/1/opacity", 1.0)
        self.send("/oats/audio/preset", AUDIO_PRESET, 1)
        self.mark(f"L1: Stars generator with Star Trails in FX slot 1; audio preset '{AUDIO_PRESET}' on L1; fractal dimmed to 35 % behind")
        if src == "off":
            self.notes.append("AUDIO WAS OFF in status.json when this take was recorded: the trails do not react; re-take with music (audio source NDI or Device)")
            self.mark("note: audio source is off (no reaction) - re-take with music")
        else:
            self.notes.append(f"audio source {src}: {au.get('name') or ''}{' (connected)' if au.get('connected') else ' (NOT connected)'}")
        quarter = self.secs / 4.0
        self.hold_secs(quarter)
        self.send("/oats/layers/1/fx/1/speed", 0.65)
        self.mark("trails spin a little faster (FX 1 speed 0.65)")
        self.hold_secs(quarter)
        self.send("/oats/layers/1/gen/count", 0.9)
        self.mark("denser stars (count 0.9)")
        self.hold_secs(quarter)
        self.send("/oats/fractal/opacity", 0.6)
        self.mark("fractal up to 60 % behind the stars")
        self.hold_secs(self.left())

    def scenes(self):
        names = scene_names()
        n1, n2 = names.get(1, "scene 1.1"), names.get(2, "scene 1.2")
        fade = max(2.0, min(6.0, self.secs / 25.0))
        self.send("/oats/master/dimmer", 1.0)
        self.send("/oats/scene/go", 1, 0.0)
        self.mark(f"scene 1.1 '{n1}' (cut)")
        third = (self.secs - 2 * fade) / 3.0
        self.hold_beats(999, cap=third)
        self.send("/oats/master/dimmer", 0.25)
        self.send("/oats/scene/go", 2, fade)
        self.mark(f"dimmer dips to 25 % and scene 1.2 '{n2}' fades in over {fade:.0f} s")
        self.hold_secs(fade * 0.5)
        self.send("/oats/master/dimmer", 1.0)
        self.mark("dimmer back to 100 %")
        self.hold_secs(fade * 0.5)
        self.hold_beats(999, cap=third)
        self.send("/oats/master/dimmer", 0.25)
        self.send("/oats/scene/go", 1, fade)
        self.mark(f"dimmer dips and scene 1.1 '{n1}' fades back over {fade:.0f} s")
        self.hold_secs(fade * 0.5)
        self.send("/oats/master/dimmer", 1.0)
        self.mark("dimmer back to 100 %")
        self.hold_secs(self.left())
        self.notes.append(f"scenes from bank 1: 1 = '{n1}', 2 = '{n2}'; fades {fade:.0f} s; the master dimmer dips to 25 % at each change and comes back over the first half of the fade")

    def run(self):
        {"deep-dive": self.deep_dive, "looks": self.looks, "audio": self.audio, "scenes": self.scenes}[self.name]()


class _DryTx:
    def __init__(self, log):
        self.log = log

    def send(self, addr, *args):
        self.log(f"      (dry) {addr} {' '.join(repr(a) for a in args)}")


def clean_look(tx, dry, log):
    """A known starting point for the takes (after the state save; the restore brings the user's look back):
    audio routes cleared, autopilots off, layer transforms / FX / beat mod neutral (scale 1, no spin), master FX off,
    blackout off, dimmer 1. Sends in a dry run are printed only."""
    msgs = [("/oats/audio/routes/clear",)]
    for n in (1, 2, 3, 4):
        msgs.append((f"/oats/layers/{n}/autopilot", "off"))
    for n in (0, 1, 2, 3, 4):
        msgs.append((f"/oats/layers/{n}/fx/reset",))
    msgs += [("/oats/master/fx/reset",), ("/oats/master/blackout", 0), ("/oats/master/dimmer", 1.0)]
    log("clean look: audio routes cleared, autopilots off, layer transforms / FX reset (L0-L4), master FX off, blackout off, dimmer 1")
    for m in msgs:
        if dry:
            log(f"      (dry) {m[0]} {' '.join(repr(a) for a in m[1:])}")
        else:
            tx.send(*m)
            time.sleep(0.004)


def scene_names():
    try:
        with open(SCENES) as f:
            d = json.load(f)
        for b in d.get("banks", []):
            if b.get("bank") == 1:
                return {s.get("slot"): s.get("name", "") for s in b.get("scenes", []) if isinstance(s, dict)}
    except (OSError, ValueError):
        pass
    return {}


def log(s):
    print(f"{time.strftime('%H:%M:%S')} {s}", flush=True)


def state(cmd):
    r = subprocess.run([sys.executable, "-I", STATE_TOOL, cmd, STATE_FILE], capture_output=True, text=True, timeout=120)
    out = (r.stdout + r.stderr).strip().splitlines()
    log(f"state {cmd}: " + (out[-1] if out else f"exit {r.returncode}"))
    return r.returncode == 0


def wait_record(want_on, timeout=10.0):
    """Waits for status.json record.on to be `want_on`; returns the record dict (or {})."""
    t_end = time.monotonic() + timeout
    rc = {}
    while time.monotonic() < t_end:
        rc = status().get("record") or {}
        if bool(rc.get("on")) == want_on and (want_on or rc.get("note") in ("done", "failed", "off")):
            return rc
        time.sleep(0.25)
    return rc


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dry-run", action="store_true", help="print the plan and the OSC it would send; no recording, nothing sent")
    ap.add_argument("--secs", type=float, default=150.0, help="seconds per take (2-3 minutes; default 150)")
    ap.add_argument("--takes", default=",".join(TAKES), help="comma list of " + ", ".join(TAKES))
    ap.add_argument("--sizes", default="1080p,vertical", help="comma list of 1080p, vertical")
    ap.add_argument("--out", default=DEFAULT_OUT, help="folder for the files and SHOT-LIST.md")
    ap.add_argument("--to", default="127.0.0.1:7000")
    a = ap.parse_args()
    takes = [t.strip() for t in a.takes.split(",") if t.strip()]
    sizes = [s.strip() for s in a.sizes.split(",") if s.strip()]
    bad = [t for t in takes if t not in TAKES] + [s for s in sizes if s not in SIZES]
    if bad:
        sys.exit(f"unknown take / size: {bad} (takes: {', '.join(TAKES)}; sizes: {', '.join(SIZES)})")
    if not 30 <= a.secs <= 600:
        sys.exit("--secs must be 30..600 (the recorder stops itself at 10 minutes)")
    out = os.path.expanduser(a.out)
    dry = a.dry_run
    st = status()
    if not st and not dry:
        sys.exit("no logs/status.json: is the player running?")
    rc0 = st.get("record") or {}
    if not dry and "on" not in rc0:
        sys.exit("status.json has no 'record': this player has no recorder (build with src/recorder.swift and restart)")
    if rc0.get("on") and not dry:
        sys.exit(f"a recording is already running ({rc0.get('path')}): stop it first")
    free = rc0.get("free_gb")
    need = len(takes) * len(sizes) * a.secs * 24e6 / 8 / 1e9 + 2.0
    log(f"plan: {len(takes)} take(s) x {len(sizes)} size(s) = {len(takes) * len(sizes)} files, {a.secs:.0f} s each "
        f"(about {len(takes) * len(sizes) * a.secs / 60:.0f} min of recording, ~{need - 2:.1f} GB at 24 Mbit/s; "
        f"{free if free is not None else '?'} GB free now; the recorder needs 3 GB to start and stops at 2 GB)")
    log(f"out: {out}")
    log(f"tempo now: {st.get('tempo', {}).get('bpm', '?')} BPM ({st.get('tempo', {}).get('source', '?')}); audio: {st.get('audio', {}).get('source', '?')}")
    if free is not None and not dry and free < need:
        log(f"WARNING: {free} GB free is less than the ~{need:.1f} GB these takes may need; the disk guard will stop a take at 2 GB")
    if dry:
        log("DRY RUN: nothing is sent or recorded")
    tx = Sender(a.to)
    results = []
    stamp = time.strftime("%Y%m%d-%H%M%S")
    restored = False

    def restore():
        nonlocal restored
        if restored or dry:
            return
        restored = True
        tx.send("/oats/record/stop")
        tx.send("/oats/master/dimmer", 1.0)
        state("restore")

    def on_sig(*_):
        log("stopped (signal): restoring the look")
        restore()
        write_shot_list(out, results, takes, sizes, a.secs, st, stamp, partial=True)
        sys.exit(130)

    if not dry:
        if not state("save"):
            sys.exit("state save failed")
        signal.signal(signal.SIGINT, on_sig)
        signal.signal(signal.SIGTERM, on_sig)
    clean_look(tx, dry, log)
    try:
        for tk in takes:
            for sz in sizes:
                path = os.path.join(out, f"{stamp}-{tk}-{sz}.mp4")
                log(f"=== take '{tk}' {SIZES[sz]} -> {path}")
                t = Take(tx, tk, sz, a.secs, dry, log)
                t.path = path
                if not dry:
                    tx.send("/oats/record/start", path, sz)
                    rc = wait_record(True, 6.0)
                    if not rc.get("on"):
                        log(f"recorder did not start ({rc.get('note', '?')}): see the player log; skipping this file")
                        results.append((t, {"error": "did not start"}))
                        continue
                    t.t0 = time.monotonic()
                t.run()
                rc = {}
                if not dry:
                    tx.send("/oats/record/stop")
                    rc = wait_record(False, 15.0)
                    log(f"    stopped: {rc.get('frames', '?')} frames, {rc.get('dropped', '?')} dropped, {(rc.get('bytes') or 0) / 1e6:.0f} MB, {rc.get('seconds', '?')} s, note {rc.get('note', '?')}")
                    time.sleep(1.0)
                results.append((t, rc))
    finally:
        restore()
    write_shot_list(out, results, takes, sizes, a.secs, st, stamp, partial=False, dry=dry)


def write_shot_list(out, results, takes, sizes, secs, st, stamp, partial=False, dry=False):
    lines = [f"# Teaser takes · {time.strftime('%Y-%m-%d %H:%M')}" + (" (DRY RUN: no files were recorded)" if dry else "") + (" (INTERRUPTED)" if partial else ""), ""]
    lines.append(f"Player: {st.get('resolution', '?')} @ {st.get('frame_rate', '?')} fps, tempo {st.get('tempo', {}).get('bpm', '?')} BPM "
                 f"({st.get('tempo', {}).get('source', '?')}), audio source {st.get('audio', {}).get('source', '?')}. "
                 f"Recorder: H.264 ~24 Mbit/s, BT.709, program output after master FX / dimmer / blackout. "
                 f"Takes: {', '.join(takes)}; sizes: {', '.join(f'{s} = {SIZES[s]}' for s in sizes)}; {secs:.0f} s each.")
    lines.append("")
    for t, rc in results:
        lines.append(f"## {os.path.basename(t.path)}")
        lines.append(f"- take **{t.name}**, {SIZES[t.size]}")
        if rc.get("error"):
            lines.append(f"- NOT RECORDED: {rc['error']}")
        elif rc:
            lines.append(f"- {rc.get('frames', '?')} frames, {rc.get('dropped', '?')} dropped, {(rc.get('bytes') or 0) / 1e6:.0f} MB, {rc.get('seconds', '?')} s ({rc.get('note', '?')})")
        for n in t.notes:
            lines.append(f"- {n}")
        lines.append("")
        lines.append("| time | what |")
        lines.append("|---|---|")
        for ts, what in t.events:
            lines.append(f"| {Take.stamp(ts)} | {what} |")
        lines.append("")
    if dry:
        lines.append("Files would be: " + ", ".join(f"{stamp}-{tk}-{sz}.mp4" for tk in takes for sz in sizes))
        lines.append("")
    text = "\n".join(lines)
    if dry:
        print("\n----- SHOT-LIST.md (not written in a dry run) -----\n" + text)
        return
    os.makedirs(out, exist_ok=True)
    p = os.path.join(out, "SHOT-LIST.md")
    with open(p, "w") as f:
        f.write(text)
    log(f"shot list: {p}")


if __name__ == "__main__":
    main()
