#!/usr/bin/env python3
"""Save the player's look from logs/status.json and put it back over OSC (after a restart, which starts from defaults).

usage:
  python3 -I tools/oats_state.py save FILE      # copy of status.json (owners included)
  python3 -I tools/oats_state.py restore FILE [--to 127.0.0.1:7000] [--all]

restore sends only what OSC / the GUI owned when it was saved (owners "osc"): what MA3 owned comes back by itself
from the console's next packets (latest move wins), and defaults stay defaults. --all also sends the DMX-owned and
default values. Blackout and test content are never touched; the output window display and fit are put back. Stdlib only.
"""
import json
import os
import socket
import struct
import sys
import time

M0 = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATUS = os.path.join(M0, "logs", "status.json")


def enc(addr, args):
    def pad(b):
        return b + b"\0" * (4 - len(b) % 4)
    tags, data = ",", b""
    for a in args:
        if isinstance(a, bool):
            tags += "i"; data += struct.pack(">i", int(a))
        elif isinstance(a, int):
            tags += "i"; data += struct.pack(">i", a)
        elif isinstance(a, float):
            tags += "f"; data += struct.pack(">f", a)
        else:
            tags += "s"; data += pad(str(a).encode())
    return pad(addr.encode()) + pad(tags.encode()) + data


def restore(st, to, every):
    host, port = to.rsplit(":", 1)
    sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    own = st.get("owners", {})
    sent = 0

    def mine(k):
        return every or own.get(k) == "osc"

    def send(addr, *args):
        nonlocal sent
        sk.sendto(enc(addr, list(args)), (host, int(port)))
        sent += 1
        time.sleep(0.004)

    f = st["fractal"]
    fm = f.get("formula", {})
    # BG (L0, status.json "bg", 2026-10-23) first: a BG source Fractal takes the fractal home, a layer's Fractal after it moves it on
    for L in ([st["bg"]] if isinstance(st.get("bg"), dict) else []) + st["layers"]:
        n, k = L["n"], "layer%d." % L["n"]
        b = "/oats/layers/%d/" % n
        if mine(k + "clip") and L.get("slot", 0) > 0:
            send(b + "play", int(L["bank"]), int(L["slot"]))
        if mine(k + "ndi") and isinstance(L.get("ndi"), dict):      # NDI source (ndiin.swift): name + bandwidth, before the source
            if L["ndi"].get("name"): send(b + "ndi", L["ndi"]["name"])
            send(b + "ndi/bandwidth", L["ndi"].get("bandwidth", "full"))
        if mine(k + "source"):
            send(b + "source", L["source"])
        if mine(k + "opacity"): send(b + "opacity", float(L["opacity"]))
        if mine(k + "blend"): send(b + "blend", L["blend"])
        if mine(k + "speed"): send(b + "speed", float(L["speed"]))
        if mine(k + "transition"): send(b + "transition", float(L["transition"]))
        if mine(k + "playmode"): send(b + "playmode", "once" if L["playmode"] == "once" else "loop")
        if mine(k + "autopilot"):
            if L.get("autopilot_every_s", 0) > 0:
                send(b + "autopilot/every", float(L["autopilot_every_s"]))
            else:
                send(b + "autopilot/beats", float(L.get("autopilot_beats", 4)))
            send(b + "autopilot", L["autopilot"])
        g = L["gen"]
        for p in ("count", "thickness", "softness", "speed", "angle", "variation"):
            if mine(k + "gen." + p): send(b + "gen/" + p, float(g[p]))
        if mine(k + "gen.type"): send(b + "gen/type", int(g["type_index"]))
        if mine(k + "gen.beatsync"): send(b + "gen/beatsync", 1 if g["beatsync"] else 0)
        if mine(k + "gen.colormode"): send(b + "gen/colormode", g["colormode"])
        if mine(k + "gen.colorA"): send(b + "gen/colorA", *[float(x) for x in g["colorA"]])
        if mine(k + "gen.colorB"): send(b + "gen/colorB", *[float(x) for x in g["colorB"]])
        o = L.get("overlay")                             # layer overlay (2026-10-23): one owner key for all of it
        if o and mine(k + "overlay"):
            ob = b + "overlay/"
            send(ob + "type", int(o["type_index"]))
            for p in ("count", "thickness", "softness", "speed", "angle", "variation", "opacity"):
                send(ob + p, float(o[p]))
            send(ob + "beatsync", 1 if o["beatsync"] else 0); send(ob + "colormode", o["colormode"])
            send(ob + "colorA", *[float(x) for x in o["colorA"]]); send(ob + "colorB", *[float(x) for x in o["colorB"]])
            send(ob + "blend", o["blend"]); send(ob + "follow", 1 if o["follow"] else 0)
            send(ob + "on", 1 if o["on"] else 0)
        t = L["transform"]
        if mine(k + "pos"): send(b + "transform/x", float(t["x"])); send(b + "transform/y", float(t["y"]))
        if mine(k + "scale"): send(b + "transform/scale", float(t["scale"]))
        if mine(k + "rotation"): send(b + "transform/rotation", float(t["rotation"]))
        if mine(k + "spin"): send(b + "transform/spin", float(t["spin"]))
        if mine(k + "tile"):
            send(b + "transform/tile", float(t["tile"]))
            for q in ("flipx", "flipy", "mirror"):
                send(b + "transform/" + q, 1 if t[q] else 0)
        if mine(k + "spinfill") and "spinfill" in t: send(b + "transform/spinfill", t["spinfill"])
        if mine(k + "edge") and isinstance(t.get("edge"), dict):
            send(b + "edge/feather", float(t["edge"].get("feather", 0))); send(b + "edge/shape", t["edge"].get("shape", "rect"))
        for s, fx in enumerate(L["fx"][:2], 1):
            if mine(k + "fx%d" % s):
                send(b + "fx/%d/type" % s, fx["type"]); send(b + "fx/%d/amount" % s, float(fx["amount"])); send(b + "fx/%d/speed" % s, float(fx["speed"]))
        md = L["mod"]
        if mine(k + "mod"):
            send(b + "mod/target", md["target"]); send(b + "mod/shape", md["shape"])
            send(b + "mod/beats", float(md["beats"])); send(b + "mod/depth", float(md["depth"]))
    fr = "/oats/fractal/1/"
    # target first (2026-10-23): with the per-target shape memory a target change loads that target's shape, so the
    # target goes before the shape values; then the saved shapes of the other targets (fractal.shape_memory)
    send(fr + "shape/memory", 1 if f.get("shape_memory_on", True) else 0)
    send(fr + "target/dive", 0)                          # no dive burst while restoring (set back below)
    if mine("target"):
        if f.get("target_index", 0) >= 1:
            send(fr + "target", int(f["target_index"]))
        else:
            send(fr + "center", f["center_re"], f["center_im"])
    sm = f.get("shape_memory") if isinstance(f.get("shape_memory"), dict) else {}   # a file from before the memory: none saved
    send(fr + "shape/memory/data", json.dumps(sm, separators=(",", ":")))
    if mine("iterations"): send(fr + "iter", int(f.get("iterations_override", f.get("iterations_base", 0) if f.get("iterations_mode") == "override" else 0)))
    if mine("fractal.formula"):
        send(fr + "formula", fm.get("key", "mandelbrot"))
        if "power" in fm: send(fr + "power", float(fm["power"]))      # Branches (after the formula, which resets it)
    if mine("fractal.fold"):
        send(fr + "fold/mode", fm.get("fold_mode", "wild" if int(fm.get("fold", 0)) >= 2 else "clean"))   # Twist mode (2026-10-23)
        send(fr + "fold", int(fm.get("fold", 0))); send(fr + "fold/mirror", 1 if fm.get("fold_mirror") else 0)
    send(fr + "foldc", int(fm.get("foldc", 0))); send(fr + "foldc/mirror", 1 if fm.get("foldc_mirror") else 0)
    if mine("fractal.julia"): send(fr + "julia", float(fm.get("julia", 0)))
    if mine("fractal.juliac"): send(fr + "julia/c", *[float(x) for x in fm.get("julia_c", [-0.8, 0.156])])
    send(fr + "julia/drift", float(fm.get("julia_drift", 0))); send(fr + "julia/beat", 1 if fm.get("julia_beat") else 0)
    send(fr + "warp", float(fm.get("warp", 0))); send(fr + "bailout", float(fm.get("bailout", 256)))
    if mine("fractal.trap"): send(fr + "trap", fm.get("trap", "off"))
    send(fr + "trap/mix", float(fm.get("trap_mix", 0.6))); send(fr + "trap/size", float(fm.get("trap_size", 0.5)))
    lp = f.get("loop", {})
    send(fr + "loop/next", lp.get("next", "same")); send(fr + "loop/depth", float(lp.get("depth", 26))); send(fr + "loop/fade", float(lp.get("fade", 2)))
    if mine("fractal.loop"): send(fr + "loop", lp.get("mode", "off"))
    if mine("palette"): send(fr + "palette", int(st["palette"]))
    if mine("palette_speed"): send(fr + "palette/speed", float(st["palette_speed"]))
    if mine("palette_offset"): send(fr + "palette/offset", float(st["palette_offset"]))
    # spread + phasers (2026-10-23; status.json fractal.spread / fractal.phasers): only what OSC / the GUI set
    if mine("fractal.spread") and "spread" in f: send(fr + "spread", float(f["spread"]))
    if "phaser_free" in f: send(fr + "phaser/free", 1 if f["phaser_free"] else 0)
    if mine("fractal.phasers"):
        for p in f.get("phasers", [])[:3]:
            b = fr + "phaser/%d/" % int(p["n"])
            send(b + "target", p["target"]); send(b + "shape", p["shape"])
            if float(p.get("seconds", 0)) > 0: send(b + "seconds", float(p["seconds"]))
            else: send(b + "beats", float(p.get("beats", 4)))
            send(b + "depth", float(p.get("depth", 0.5))); send(b + "phase", float(p.get("phase", 0))); send(b + "on", 1 if p.get("on") else 0)
    if mine("rotation"): send(fr + "rotation", float(f.get("rotation_set_deg", 0)))
    if mine("spin"): send(fr + "spin", float(f.get("spin", 0)))
    if mine("fractal.opacity"): send("/oats/fractal/opacity", float(st["fractal_layer"]["opacity"]))
    send(fr + "target/keepdepth", 1 if f.get("keepdepth") else 0)

    if mine("target"):
        time.sleep(0.8)                                  # the new target's orbit (sent above); then the depth
    if mine("depth"): send(fr + "depth", float(f["depth_log10"]))
    send(fr + "target/dive", 1 if f.get("dive_on_select", True) else 0)
    if mine("zoomspeed"): send(fr + "zoomspeed", float(st["zoomspeed"]))
    fl = int(f.get("layer_requested", f.get("layer", 0)))
    bg_src = (st.get("bg") or {}).get("source", "fractal")
    if mine("fractal.layer") and (fl != 0 or bg_src == "fractal"):   # layer 0 would also set BG's source back to Fractal
        send("/oats/fractal/layer", fl)
    if mine("dimmer"): send("/oats/master/dimmer", float(st["dimmer"]))
    if mine("effect_speed"): send("/oats/master/speed", float(st["effect_speed"]))
    if mine("bpm") and st.get("bpm", 0) > 0: send("/oats/tempo/bpm", float(st["bpm"]))
    mf = st.get("master_fx", {})
    if mine("master.fx"): send("/oats/master/fx/type", mf.get("type", "None")); send("/oats/master/fx/amount", float(mf.get("amount", 0.5))); send("/oats/master/fx/speed", float(mf.get("speed", 0.5)))
    cl = st.get("color_link", {})
    if mine("color.rgb"): send("/oats/color/link", float(cl["r"]), float(cl["g"]), float(cl["b"]))
    if mine("color.amount"): send("/oats/color/amount", float(cl["amount"]))
    if mine("color.mode"): send("/oats/color/mode", cl["mode"])
    if mine("color.target"): send("/oats/color/target", cl["target"])
    # audio react (2026-10-23; status.json audio): input settings + the 8 routes, when OSC / the GUI set them
    au = st.get("audio")
    if au and mine("audio"):
        if au.get("ndi_name"): send("/oats/audio/ndi", au["ndi_name"])
        if au.get("device"): send("/oats/audio/device", au["device"])
        send("/oats/audio/channel", int(au.get("channel", 0))); send("/oats/audio/gain", float(au.get("gain_db", 0)))
        send("/oats/audio/agc", 1 if au.get("agc", True) else 0); send("/oats/audio/quantize", float(au.get("quantize", 0)))
        for r in au.get("routes", [])[:8]:
            b = "/oats/audio/route/%d/" % int(r["n"])
            send(b + "source", r["source"]); send(b + "target", r["target"]); send(b + "layer", r["layer"] if isinstance(r.get("layer"), str) else int(r.get("layer", 1)))
            send(b + "scene", int(r.get("scene", 0))); send(b + "amount", float(r.get("amount", 0.5))); send(b + "curve", r.get("curve", "linear"))
            send(b + "smooth", float(r.get("smooth", 0.05))); send(b + "on", 1 if r.get("on") else 0)
        send("/oats/audio/source", au.get("source", "off"))
    # output window (2026-10-23): fit + the display it was on (the slices and canvas live in mapping.json already)
    out = st.get("output") or {}
    if out.get("fit"): send("/oats/output/fit", out["fit"])
    if int(out.get("requested", 0) or 0) > 0: send("/oats/output/display", int(out["requested"]))
    return sent


def main(argv):
    if len(argv) < 2 or argv[0] not in ("save", "restore"):
        print(__doc__); return 64
    if argv[0] == "save":
        with open(STATUS) as f:
            st = json.load(f)
        with open(argv[1], "w") as f:
            json.dump(st, f, indent=1, sort_keys=True)
        print("saved %s (pid %s, %d owners)" % (argv[1], st.get("pid"), len(st.get("owners", {}))))
        return 0
    with open(argv[1]) as f:
        st = json.load(f)
    to = argv[argv.index("--to") + 1] if "--to" in argv else "127.0.0.1:7000"
    n = restore(st, to, "--all" in argv)
    print("restored %d OSC messages to %s from %s" % (n, to, argv[1]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
