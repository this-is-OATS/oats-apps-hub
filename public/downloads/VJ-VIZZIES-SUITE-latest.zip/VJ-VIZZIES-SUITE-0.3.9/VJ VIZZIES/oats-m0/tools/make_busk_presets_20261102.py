"""Adds new generator looks, layer FX presets, master FX presets and busk stacks (2026-11-02). Append-only: an existing
name is never changed. Validates every type, range and cross-reference, then writes the three files in TOOLS (argv[1])."""
import json, sys, os
T = sys.argv[1]; DRY = "--dry" in sys.argv
GP, FP, SP = (os.path.join(T, f) for f in ("gen_presets.json", "fx_presets.json", "stacks.json"))
g = json.load(open(GP)); f = json.load(open(FP))
TYPES = ["Lines", "Angles", "Prisms", "Circles", "Dots", "Grid", "Polygons", "Rays", "Spiral", "Waves", "Tunnel", "Shapes Burst", "Stars"]
FXT = ["Kaleido", "Mirror", "Warp", "Twist", "Ripple", "ZoomBlur", "HueSpin", "Posterize", "Invert", "Duotone", "RGBSplit", "Pixelate",
       "SliceShift", "Strobe", "Blur", "EdgeGlow", "Trails", "StarTrails", "WarpTrails", "SpiralTrails"]
BL = ["alpha", "add", "screen", "multiply", "difference", "lighten", "darken", "overlay"]
MODT = ["rotation", "scale", "posx", "posy", "fx1", "fx2", "opacity"]; MODS = ["sine", "saw", "square", "random"]; MODB = [0.25, 0.5, 1, 2, 4, 8, 16]
FRAC = ['Kaleido Bloom 6', 'Burning Cathedral', 'Tricorn Mirror', 'Julia Breath', 'Star Trap', 'Celtic Knot', 'Power 3 Flower', 'Endless Seahorse loop']
FSH = ['Mandelbrot', 'Burning Ship', 'Tricorn', 'Celtic', 'Flower 3', 'Flower 4', 'Flower 5', 'Julia Dendrite', 'Julia Rabbit', 'Julia Spiral', 'Julia Dust', 'Kaleido 6', 'Kaleido 8']
PINK, CYAN, ORANGE, VIOLET, LIME, RED, BLUE, GOLD = [1, .1, .6], [0, .9, 1], [1, .45, 0], [.55, .2, 1], [.6, 1, .1], [1, .05, .1], [.1, .3, 1], [1, .8, .2]

def L(t, c, th, so, sp, an, va, bs, cm, blend, op=None, fx=None, a=None, b=None):
    d = {"gen": {"type": t, "count": c, "thickness": th, "softness": so, "speed": sp, "angle": an, "variation": va, "beatsync": bs, "colormode": cm}, "blend": blend}
    if cm == "custom": d["gen"]["colorA"], d["gen"]["colorB"] = a, b
    if op is not None: d["opacity"] = op
    if fx: d["fx"] = fx
    return d
NEW_LOOKS = {
 # Lines
 "Barcode Scan":     L("Lines", .70, .05, .02, .50, 0, .90, 1, "white", "add"),
 "Diagonal Rain":    L("Lines", .50, .08, .20, .35, 60, .80, 0, "link", "screen"),
 "Horizon Bars":     L("Lines", .12, .50, .40, .10, 90, .30, 0, "accent", "screen", .8),
 "Neon Slash":       L("Lines", .25, .10, .10, .50, 135, .60, 1, "custom", "add", a=PINK, b=CYAN),
 # Angles
 "Arrow Drop":       L("Angles", .40, .15, .05, .50, 270, .50, 1, "accent", "add"),
 "Zigzag Neon":      L("Angles", .30, .12, .10, .30, 0, .70, 0, "custom", "screen", a=PINK, b=CYAN),
 "Chevron Flood":    L("Angles", .60, .30, .15, .25, 90, .40, 0, "link", "screen", .75),
 # Prisms
 "Crystal Floor":    L("Prisms", .50, .10, .10, .15, 0, .60, 0, "link", "screen"),
 "Shard Flash":      L("Prisms", .30, .20, .05, .50, 0, .95, 1, "white", "add", fx="Glitch Hit"),
 "Prism Sunset":     L("Prisms", .25, .25, .30, .10, 30, .50, 0, "custom", "screen", a=ORANGE, b=VIOLET),
 # Circles
 "Sonar":            L("Circles", .20, .05, .30, .25, 0, .40, 1, "link", "screen"),
 "Bullseye Beat":    L("Circles", .45, .25, .05, .50, 0, .50, 1, "accent", "add"),
 "Halo Soft":        L("Circles", .10, .60, .90, .05, 0, .30, 0, "white", "screen", .6),
 "Ring Kaleido":     L("Circles", .35, .12, .15, .30, 0, .60, 1, "custom", "add", fx="Kaleido Bloom", a=CYAN, b=VIOLET),
 # Dots
 "LED Wall":         L("Dots", .80, .50, .05, .10, 0, .20, 0, "link", "screen"),
 "Confetti":         L("Dots", .55, .20, .05, .40, 0, 1.0, 1, "accent", "add"),
 "Polka Pulse":      L("Dots", .30, .40, .20, .50, 0, .50, 1, "custom", "screen", a=PINK, b=GOLD),
 # Grid
 "Laser Grid":       L("Grid", .30, .04, .10, .20, 45, .50, 0, "link", "add"),
 "Tron Floor":       L("Grid", .50, .06, .05, .35, 0, .40, 0, "custom", "add", a=CYAN, b=BLUE),
 "Checker Strobe":   L("Grid", .60, .55, .02, .50, 0, .90, 1, "white", "difference"),
 # Polygons
 "Triangle Stack":   L("Polygons", .30, .10, .05, .30, 0, .30, 1, "accent", "add"),
 "Hex Bloom":        L("Polygons", .50, .15, .30, .20, 0, .60, 0, "link", "screen"),
 "Square Pulse":     L("Polygons", .40, .20, .05, .50, 45, .50, 1, "white", "add", fx="Beat Zoom"),
 # Rays
 "Lighthouse":       L("Rays", .10, .30, .50, .10, 0, .30, 0, "white", "screen", .8),
 "Disco Rays":       L("Rays", .60, .10, .05, .50, 0, .70, 1, "accent", "add"),
 "Sunburst Soft":    L("Rays", .35, .40, .60, .08, 0, .40, 0, "custom", "screen", a=ORANGE, b=GOLD),
 # Spiral
 "Vortex Arms":      L("Spiral", .50, .20, .10, .60, 0, .50, 0, "link", "add"),
 "Slow Galaxy":      L("Spiral", .20, .40, .70, .08, 0, .60, 0, "accent", "screen", .8),
 "Spiral Beat":      L("Spiral", .35, .15, .05, .50, 0, .40, 1, "custom", "add", a=LIME, b=CYAN),
 # Waves
 "Sine Ribbons":     L("Waves", .30, .10, .20, .30, 0, .50, 0, "link", "screen"),
 "Ocean Floor":      L("Waves", .60, .05, .10, .15, 0, .40, 0, "custom", "screen", a=BLUE, b=CYAN),
 "Bass Wobble":      L("Waves", .20, .30, .10, .50, 90, .70, 1, "accent", "add"),
 # Tunnel
 "Hyper Tunnel":     L("Tunnel", .60, .10, .05, .80, 0, .50, 0, "link", "add", fx="Hyperspace Jump"),
 "Slow Descent":     L("Tunnel", .30, .30, .50, .12, 0, .40, 0, "white", "screen", .8),
 "Beat Tunnel":      L("Tunnel", .40, .20, .05, .50, 0, .50, 1, "custom", "add", a=RED, b=VIOLET),
 # Shapes Burst
 "Shape Rain":       L("Shapes Burst", .60, .10, .05, .40, 0, .90, 0, "link", "screen"),
 "Drop Bomb":        L("Shapes Burst", .20, .25, .05, .50, 0, .80, 1, "accent", "add", fx="Beat Zoom"),
 # Stars
 "Deep Space":       L("Stars", .80, .05, .30, .20, 0, .60, 0, "white", "screen"),
 "Star Rush":        L("Stars", .60, .08, .10, .90, 0, .50, 0, "link", "add", fx="Warp Speed"),
 "Twinkle":          L("Stars", .50, .06, .40, .05, 0, 1.0, 0, "accent", "screen", .9),
}
def FX(name, fx=None, mod=None, transform=None, edge=None):
    d = {"name": name}
    if transform: d["transform"] = transform
    if fx: d["fx"] = [{"type": t, "amount": a, "speed": s} for t, a, s in fx]
    if mod: d["mod"] = dict(zip(("target", "shape", "beats", "depth"), mod))
    if edge: d["edge"] = edge
    return d
NEW_FX = [
 # strobes: one flash per beat at most (2 /s at 120 BPM): under the 3-4 flashes/s photosensitivity guidance
 FX("Strobe Beat", mod=("opacity", "square", 1, 1.0)),
 FX("Pulse Beat", mod=("scale", "saw", 1, .15)),
 FX("Pulse Bar", mod=("scale", "saw", 4, .3)),
 FX("Bounce", mod=("posy", "sine", 1, .12)),
 FX("Sway", mod=("posx", "sine", 4, .2)),
 FX("Spin Beat", mod=("rotation", "saw", 1, .25)),
 FX("Breathe", mod=("opacity", "sine", 4, .5)),
 FX("Fade Bar", mod=("opacity", "saw", 4, 1.0)),
 FX("Kaleido Spin", fx=[("Kaleido", .7, .5)], transform={"spin": .08}),
 FX("Mirror Pulse", fx=[("Mirror", 1.0, .5)], mod=("scale", "sine", 2, .2)),
 FX("RGB Shake", fx=[("RGBSplit", .4, .6)], mod=("fx1", "random", .25, 1.0)),
 FX("Posterize Pop", fx=[("Posterize", .7, .5)], mod=("fx1", "square", 1, 1.0)),
 FX("Invert Beat", fx=[("Invert", 1.0, .5)], mod=("fx1", "square", 2, 1.0)),
 FX("Hue Cycle", fx=[("HueSpin", .5, .3)]),
 FX("Edge Neon", fx=[("EdgeGlow", .7, .5)]),
 FX("Blur Dream", fx=[("Blur", .5, .5)], mod=("scale", "sine", 8, .15)),
 FX("Zoom Punch", fx=[("ZoomBlur", .6, .5)], mod=("fx1", "saw", 1, 1.0)),
 FX("Ripple Beat", fx=[("Ripple", .6, .5)], mod=("fx1", "saw", 1, 1.0)),
 FX("Twist Sway", fx=[("Twist", .6, .5)], mod=("fx1", "sine", 4, .8)),
 FX("Pixel Beat", fx=[("Pixelate", .7, .5)], mod=("fx1", "square", .5, 1.0)),
 FX("Glitch Storm", fx=[("SliceShift", .8, .8), ("RGBSplit", .7, .8)], mod=("fx1", "random", .25, 1.0)),
 FX("Duotone Breathe", fx=[("Duotone", 1.0, .5)], mod=("fx1", "sine", 4, .6)),
 FX("Spiral Trails Slow", fx=[("SpiralTrails", .6, .62)]),
]
NEW_MASTER = [
 {"name": "Strobe Beat", "type": "Strobe", "amount": 1.0, "speed": 0.1},
 {"name": "Strobe 1/2", "type": "Strobe", "amount": 1.0, "speed": 0.4},   # the player caps Strobe at 4 /s: 1 beat at 128+ BPM
 {"name": "Hue Spin", "type": "HueSpin", "amount": 0.5, "speed": 0.3},
 {"name": "Kaleido", "type": "Kaleido", "amount": 0.6, "speed": 0.4},
 {"name": "Mirror", "type": "Mirror", "amount": 1.0, "speed": 0.5},
 {"name": "Invert", "type": "Invert", "amount": 1.0, "speed": 0.5},
 {"name": "RGB Split", "type": "RGBSplit", "amount": 0.5, "speed": 0.6},
]
def S(name, about, bg=None, l1=None, l2=None, l3=None, l4=None, master=None):
    d = {"name": name, "about": about}
    if bg: d["bg"] = bg
    lay = {k: v for k, v in (("1", l1), ("2", l2), ("3", l3), ("4", l4)) if v}
    if lay: d["layers"] = lay
    if master: d["master"] = master
    return d
fr = lambda p, **k: dict(fractal=p, **k)
lk = lambda name, **k: dict(look=name, **k)
STACKS = [
 # fractal BG + one or two generator layers on top: the house style
 S("Cathedral Lasers", "fractal + laser grid + sonar", fr("Burning Cathedral"), lk("Laser Grid", opacity=.8), lk("Sonar", blend="screen", opacity=.6)),
 S("Seahorse Dive", "slow fractal dive + soft halo", fr("Endless Seahorse loop"), lk("Halo Soft", opacity=.5)),
 S("Kaleido Garden", "kaleido fractal + ring kaleido", fr("Kaleido Bloom 6"), lk("Ring Kaleido", opacity=.7)),
 S("Julia Waves", "julia breath + ocean floor", fr("Julia Breath"), lk("Ocean Floor", opacity=.7)),
 S("Star Trap Tunnel", "fractal + beat tunnel", fr("Star Trap"), lk("Beat Tunnel", opacity=.8)),
 S("Celtic Grid", "celtic knot + tron floor", fr("Celtic Knot"), lk("Tron Floor", opacity=.7)),
 S("Flower Rays", "flower fractal + sunburst", fr("Power 3 Flower"), lk("Sunburst Soft", opacity=.6)),
 S("Tricorn Mirror Hex", "tricorn mirror + hex bloom", fr("Tricorn Mirror"), lk("Hex Bloom", opacity=.6)),
 # pure generator stacks: no fractal, high contrast
 S("Laser Show", "barcode + disco rays + lighthouse", lk("Lighthouse", opacity=.6), lk("Barcode Scan", opacity=.9), lk("Disco Rays", opacity=.7)),
 S("Tron City", "tron floor + laser grid", lk("Tron Floor"), lk("Laser Grid", blend="add", opacity=.7)),
 S("Deep Space Rush", "stars + star rush", lk("Deep Space"), lk("Star Rush", opacity=.8)),
 S("Hyperdrive", "hyper tunnel + star rush + warp master", lk("Hyper Tunnel"), lk("Star Rush", opacity=.6), master="Warp"),
 S("Galaxy Drift", "slow galaxy + twinkle", lk("Slow Galaxy"), lk("Twinkle", opacity=.7)),
 S("Neon Arcade", "zigzag neon + polka pulse", lk("Zigzag Neon"), lk("Polka Pulse", opacity=.6)),
 S("Sunset Prisms", "prism sunset + sine ribbons", lk("Prism Sunset"), lk("Sine Ribbons", opacity=.6)),
 S("Bass Room", "bass wobble + bullseye beat", lk("Bass Wobble"), lk("Bullseye Beat", opacity=.7)),
 # overlay stacks: a base with a shape drawn over it
 S("Fractal + Rain", "fractal with diagonal rain overlay", fr("Burning Cathedral", overlay="Diagonal Rain")),
 S("Fractal + Sonar", "fractal with sonar overlay", fr("Julia Breath", overlay="Sonar")),
 S("Fractal + Grid", "fractal with laser grid overlay", fr("Kaleido Bloom 6", overlay="Laser Grid")),
 S("Galaxy + Arms", "slow galaxy with vortex overlay", lk("Slow Galaxy", overlay="Vortex Arms")),
 # build-up / drop moves: more energy, beat FX
 S("Build: Pulse", "build-up: pulsing tunnel + rays", lk("Beat Tunnel", fx="Pulse Bar"), lk("Disco Rays", opacity=.6)),
 S("Build: Riser", "build-up: hyper tunnel + zoom punch", lk("Hyper Tunnel", fx="Zoom Punch"), lk("Sonar", opacity=.5)),
 S("Drop: Strobe Grid", "drop: checker + beat strobe", lk("Checker Strobe"), lk("Laser Grid", opacity=.7), master="Strobe 1/2"),
 S("Drop: Glitch", "drop: shard flash + glitch storm", lk("Shard Flash", fx="Glitch Storm"), lk("Barcode Scan", opacity=.8)),
 S("Drop: Bomb", "drop: drop bomb + bullseye", lk("Drop Bomb"), lk("Bullseye Beat", opacity=.8), lk("Confetti", opacity=.6)),
 S("Drop: Kaleido", "drop: fractal + kaleido master", fr("Kaleido Bloom 6"), lk("Disco Rays", opacity=.7), master="Kaleido"),
 # breakdown / chill: low energy, black space
 S("Breakdown: Halo", "breakdown: soft halo only", lk("Halo Soft", opacity=.7)),
 S("Breakdown: Lighthouse", "breakdown: lighthouse sweep", lk("Lighthouse", opacity=.8)),
 S("Breakdown: Waves", "breakdown: ocean floor + breathe", lk("Ocean Floor", fx="Breathe")),
 S("Breakdown: Space", "breakdown: deep space + twinkle", lk("Deep Space", opacity=.7), lk("Twinkle", opacity=.5)),
 # four-layer stacks
 S("Full Stack: Neon", "4 layers: neon slash, hex, confetti, rays", fr("Celtic Knot", opacity=.7), lk("Neon Slash"), lk("Hex Bloom", opacity=.6), lk("Confetti", opacity=.5), lk("Disco Rays", opacity=.5)),
 S("Full Stack: Space", "4 layers: space, galaxy, star rush, sonar", lk("Deep Space"), lk("Slow Galaxy", opacity=.7), lk("Star Rush", opacity=.5), lk("Sonar", opacity=.4)),
 S("Full Stack: Geometry", "4 layers: triangles, grid, circles, lines", lk("Tron Floor", opacity=.6), lk("Triangle Stack"), lk("Bullseye Beat", opacity=.6), lk("Horizon Bars", opacity=.5)),
 S("Full Stack: Fire", "4 layers: sunset fractal and warm shapes", fr("Power 3 Flower"), lk("Sunburst Soft", opacity=.6), lk("Prism Sunset", opacity=.5), lk("Bass Wobble", opacity=.5)),
 # FX-led stacks
 S("Mirror Room", "mirror pulse over tunnel", lk("Slow Descent", fx="Mirror Pulse"), lk("Sine Ribbons", opacity=.5)),
 S("Edge Neon City", "edge glow on the fractal + grid", fr("Tricorn Mirror", fx="Edge Neon"), lk("Laser Grid", opacity=.6)),
 S("Invert Hits", "beat invert on dots", lk("LED Wall", fx="Invert Beat"), lk("Arrow Drop", opacity=.6)),
 S("Hue Trip", "hue cycle on the fractal + spiral", fr("Julia Breath", fx="Hue Cycle"), lk("Spiral Beat", opacity=.6)),
 S("Spiral Trails", "spiral trails on stars", lk("Deep Space", fx="Spiral Trails Slow"), lk("Vortex Arms", opacity=.5)),
 S("Blackout Pulse", "only a beat pulse on black: room to breathe", None, lk("Square Pulse", opacity=.8)),
]
# ---------- validate ----------
err = []
looks = dict(g["looks"]); fxn = {p["name"] for p in f["presets"]}; mn = {p["name"] for p in f["master"]}
for k, v in NEW_LOOKS.items():
    if k in looks: err.append("look exists: " + k); continue
    q = v["gen"]
    if q["type"] not in TYPES: err.append(k + ": type " + q["type"])
    for p in ("count", "thickness", "softness", "variation"):
        if not 0 <= q[p] <= 1: err.append(f"{k}: {p}")
    if not -1 <= q["speed"] <= 1: err.append(k + ": speed")
    if v["blend"] not in BL: err.append(k + ": blend")
    if q["colormode"] not in ("white", "link", "accent", "custom"): err.append(k + ": colormode")
for p in NEW_FX:
    if p["name"] in fxn: err.append("fx exists: " + p["name"])
    for s in p.get("fx", []):
        if s["type"] not in FXT: err.append(p["name"] + ": fx " + s["type"])
    m = p.get("mod")
    if m and (m["target"] not in MODT or m["shape"] not in MODS or m["beats"] not in MODB): err.append(p["name"] + ": mod")
for p in NEW_MASTER:
    if p["name"] in mn: err.append("master exists: " + p["name"])
    if p["type"] not in FXT: err.append(p["name"] + ": master type")
allfx = fxn | {p["name"] for p in NEW_FX}; alllooks = set(looks) | set(NEW_LOOKS); allm = mn | {p["name"] for p in NEW_MASTER}
for k, v in NEW_LOOKS.items():
    if v.get("fx") and v["fx"] not in allfx: err.append(k + ": look fx " + v["fx"])
names = set()
for s in STACKS:
    if s["name"] in names: err.append("dup stack " + s["name"])
    names.add(s["name"])
    for c in [s.get("bg")] + list(s.get("layers", {}).values()):
        if not c: continue
        if c.get("look") and c["look"] not in alllooks: err.append(s["name"] + ": look " + c["look"])
        if c.get("overlay") and c["overlay"] not in alllooks: err.append(s["name"] + ": overlay " + c["overlay"])
        if c.get("fx") and c["fx"] not in allfx: err.append(s["name"] + ": fx " + c["fx"])
        if c.get("fractal") and c["fractal"] not in FRAC: err.append(s["name"] + ": fractal " + c["fractal"])
        if c.get("shape") and c["shape"] not in FSH: err.append(s["name"] + ": shape")
        if c.get("blend") and c["blend"] not in BL: err.append(s["name"] + ": blend")
    if s.get("bg", {}) and s.get("bg", {}).get("fractal") is None and s.get("bg", {}).get("look") is None and s.get("bg"): err.append(s["name"] + ": bg empty")
    if s.get("master") and s["master"] not in allm: err.append(s["name"] + ": master " + s["master"])
    for n, c in s.get("layers", {}).items():
        if c.get("fractal"): err.append(s["name"] + ": fractal only on BG")
if err: print("ERRORS:\n  " + "\n  ".join(err)); sys.exit(1)
print(f"valid: +{len(NEW_LOOKS)} looks ({len(looks)} -> {len(looks)+len(NEW_LOOKS)}), +{len(NEW_FX)} layer FX ({len(fxn)} -> {len(allfx)}), "
      f"+{len(NEW_MASTER)} master ({len(mn)} -> {len(allm)}), {len(STACKS)} stacks")
if DRY: sys.exit(0)
g["looks"].update(NEW_LOOKS)
off = [p for p in f["master"] if p["name"] == "Off"]; rest = [p for p in f["master"] if p["name"] != "Off"]
f["presets"] += NEW_FX; f["master"] = rest + NEW_MASTER + off               # "Off" stays last
stk = {"about": "VJ VIZZIES busk stacks (2026-11-02): one APC mini pad (pad mode STACKS) recalls a whole multi-layer look. "
        "Per layer (bg, layers 1..4): fractal (BG only) / shape (fractal shape) / look (gen look) / clip [bank, slot], plus optional "
        "overlay (a gen look drawn over the layer), fx (layer FX preset), blend, opacity (default 1). A layer a stack leaves out goes "
        "to opacity 0; master = a master FX preset (default Off). Served by GET /api/stacks, re-read on every request: edit freely.",
       "stacks": STACKS}
for path, obj in ((GP, g), (FP, f), (SP, stk)):
    tmp = path + ".tmp"; json.dump(obj, open(tmp, "w"), indent=2, ensure_ascii=False); open(tmp, "a").write("\n"); os.replace(tmp, path)
print("written")
