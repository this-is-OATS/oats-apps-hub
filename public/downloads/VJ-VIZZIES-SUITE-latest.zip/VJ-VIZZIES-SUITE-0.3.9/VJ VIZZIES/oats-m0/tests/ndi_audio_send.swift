import Foundation
import Darwin

// NDI audio test sender for the audio react smoke test (no djay source needed): a 120 BPM kick-like click
// (a 150 -> 50 Hz pitch drop, ~120 ms decay) plus a quiet 440 Hz sine, 48 kHz stereo FLTP, 10 ms frames, audio only.
// Build (x86_64 like the NDI helper; runs under Rosetta):
//   swiftc -O -parse-as-library -target x86_64-apple-macos14 -import-objc-header src/ndi_min.h tests/ndi_audio_send.swift -o bin/ndi-audio-send
// Run:  NDI_CONFIG_DIR=ndi-config arch -x86_64 bin/ndi-audio-send [--name "OATS AUDIO TEST"] [--secs 20] [--bpm 120]
// The source is in group Public. Stdlib + libndi (dlopen) only.

@main
struct NDIAudioSend {
    static func main() {
        signal(SIGPIPE, SIG_IGN)
        setvbuf(stdout, nil, _IOLBF, 0)
        var name = "OATS AUDIO TEST", secs = 20.0, bpm = 120.0
        var it = CommandLine.arguments.dropFirst().makeIterator()
        while let a = it.next() {
            switch a {
            case "--name": name = it.next() ?? name
            case "--secs": secs = Double(it.next() ?? "") ?? secs
            case "--bpm": bpm = Double(it.next() ?? "") ?? bpm
            default: print("usage: ndi-audio-send [--name N] [--secs S] [--bpm B]"); exit(64)
            }
        }
        let path = ProcessInfo.processInfo.environment["NDI_LIB"] ?? "/usr/local/lib/libndi.dylib"
        guard let h = dlopen(path, RTLD_NOW | RTLD_LOCAL) else { print("dlopen failed: \(String(cString: dlerror()))"); exit(3) }
        func sym<T>(_ n: String) -> T {
            guard let p = dlsym(h, n) else { print("dlsym failed: \(n)"); exit(3) }
            return unsafeBitCast(p, to: T.self)
        }
        let initialize: fn_initialize = sym("NDIlib_initialize")
        let sendCreate: fn_send_create = sym("NDIlib_send_create")
        let sendDestroy: fn_send_destroy = sym("NDIlib_send_destroy")
        let sendAudio: fn_send_audio_v2 = sym("NDIlib_send_send_audio_v2")
        let conns: fn_send_get_no_connections = sym("NDIlib_send_get_no_connections")
        guard initialize() else { print("NDIlib_initialize failed"); exit(3) }
        let cname = strdup(name)!
        var sc = NDIlib_send_create_t(p_ndi_name: UnsafePointer(cname), p_groups: nil, clock_video: false, clock_audio: true)
        guard let snd = sendCreate(&sc) else { print("NDIlib_send_create failed"); exit(4) }
        let rate = 48000, ns = 480, nc = 2
        var buf = [Float](repeating: 0, count: ns * nc)
        let beatSamples = Int(Double(rate) * 60 / bpm)
        var n = 0, kickPhase = 0.0, sinePhase = 0.0, frames = 0, lastPrint = -1
        let total = Int(secs * Double(rate))
        print("sending '\(name)' (Public): \(rate) Hz, \(nc) ch FLTP, \(ns) samples/frame, kick at \(bpm) BPM + 440 Hz sine, \(secs) s")
        while n < total {
            for i in 0..<ns {
                let s = n + i
                let tk = Double(s % beatSamples) / Double(rate)          // seconds since the last kick
                let f = 50 + 100 * exp(-tk / 0.03)                       // pitch drop 150 -> 50 Hz
                kickPhase += 2 * .pi * f / Double(rate)
                let kick = tk < 0.4 ? 0.8 * exp(-tk / 0.12) * sin(kickPhase) : 0
                if tk >= 0.4 { kickPhase = 0 }
                sinePhase += 2 * .pi * 440 / Double(rate)
                let v = Float(kick + 0.1 * sin(sinePhase))
                buf[i] = v; buf[ns + i] = v
            }
            buf.withUnsafeMutableBufferPointer { b in
                var af = NDIlib_audio_frame_v2_t(sample_rate: Int32(rate), no_channels: Int32(nc), no_samples: Int32(ns), timecode: Int64.max,
                                                 p_data: b.baseAddress, channel_stride_in_bytes: Int32(ns * MemoryLayout<Float>.size),
                                                 p_metadata: nil, timestamp: 0)
                sendAudio(snd, &af)                                      // clock_audio: paces to real time
            }
            n += ns; frames += 1
            let sec = n / rate
            if sec != lastPrint && sec % 5 == 0 { lastPrint = sec; print("t=\(sec) s frames=\(frames) connections=\(conns(snd, 0))") }
        }
        sendDestroy(snd)
        print("done: \(frames) frames")
    }
}
