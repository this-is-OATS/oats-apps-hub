#!/usr/bin/env python3
"""oats-m0 performance runs with the freeze-test PASS rule (PLAN 4.1 / 13.1). Stdlib only; run with python3 -I.

Runs against a running instance (`./m0.sh start --test --gate`). For each phase it switches the content over
OSC, connects the ndi-bench receiver to "OATS VIZ Test" (group oatsbench) for the phase length, and judges:
  sender fps >= 59.5, dropped ticks <= 0.5 %, no send call > 100 ms, no sender frame gap > 200 ms,
  receiver: no gap > 200 ms, 0 timecode gaps.
Sender numbers come from status.json counters (frames, dropped, gate counters) at the start and end of the
receiver's window, and from the STATUS / ALARM lines of the program log inside that window.

usage:  python3 -I tests/perf.py [--phases normal:75,deep:75,noise:60,deep:75:0] [--tag NAME]
        python3 -I tests/perf.py --observe --match "OATS VIZ Program" --groups public --phases watch:300
            observe mode (M0 Parts D/E next to Vision): sends no OSC, measures whatever is on air; the
            phase name is only a label, and the content actually measured is read from status.json
        a phase is content:seconds[:receiver bandwidth] (100 = full stream, 0 = lowest / proxy, as Vision's Low)
        normal content zooms in from width 3.0 at 0.04 decades/s with a 0.1 cycles/s palette cycle.
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import osc_send as O                            # noqa: E402

M = os.path.dirname(HERE)
STATUS = os.path.join(M, "logs", "status.json")
BENCH_RECV = os.path.join(os.path.dirname(M), "ndi-bench", "bin", "receiver")
OSC_TO = ("127.0.0.1", 7000)


def status():
    for _ in range(40):
        try:
            with open(STATUS) as f:
                return json.load(f)
        except (OSError, ValueError):
            time.sleep(0.05)
    raise RuntimeError("cannot read " + STATUS)


def fresh_status(after):
    """First status.json written after `after` (unix time)."""
    t0 = time.monotonic()
    while time.monotonic() - t0 < 5:
        st = status()
        if st["updated_unix"] > after:
            return st
        time.sleep(0.05)
    return status()


MATCH, GROUPS, OBSERVE = "OATS VIZ Test", "oatsbench", False


def osc(address, *args):
    if OBSERVE:
        return
    O.send(O.encode_message(address, list(args)), OSC_TO)


def machine():
    load = subprocess.run(["sysctl", "-n", "vm.loadavg"], capture_output=True, text=True).stdout.split()
    swap = subprocess.run(["sysctl", "-n", "vm.swapusage"], capture_output=True, text=True).stdout.strip()
    top = subprocess.run(["ps", "-Ao", "pcpu=,rss=,comm=", "-r"], capture_output=True, text=True).stdout.splitlines()[:6]
    return {"load1": float(load[1]), "load5": float(load[2]), "swap": swap,
            "top_cpu": [" ".join(x.split()[:2]) + " " + os.path.basename(" ".join(x.split()[2:])) for x in top]}


STAMP = re.compile(r"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d{3}) (.*)$")


def log_lines_between(path, t_from, t_to):
    out = []
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f:
                m = STAMP.match(line.rstrip("\n"))
                if not m:
                    continue
                t = time.mktime(time.strptime(m.group(1)[:19], "%Y-%m-%d %H:%M:%S")) + int(m.group(1)[20:]) / 1000
                if t_from <= t <= t_to:
                    out.append((t, m.group(2)))
    except OSError:
        pass
    return out


def run_phase(content, secs, bw, tag):
    print(f"--- phase {content} {secs} s, receiver bandwidth {bw} ({'full' if bw == 100 else 'lowest/proxy'})", flush=True)
    mach = machine()
    print(f"  load {mach['load1']:.2f} (5-min {mach['load5']:.2f}), swap {mach['swap']}", flush=True)
    print("  top CPU: " + "; ".join(mach["top_cpu"]), flush=True)
    osc("/oats/master/blackout", ("i", 0))
    osc("/oats/master/dimmer", ("f", 1.0))
    if content == "normal":
        osc("/oats/fractal/1/palette", ("i", 1))
        osc("/oats/fractal/1/zoom", ("d", 0.47712125))
        osc("/oats/fractal/1/zoomspeed", ("f", 0.04))
        osc("/oats/fractal/1/palette/speed", ("f", 0.1))
    else:
        osc("/oats/fractal/1/zoomspeed", ("f", 0.0))
        osc("/oats/fractal/1/palette/speed", ("f", 0.0))
    osc("/oats/test/content", ("s", content))
    out = os.path.join(M, "logs", f"perf-{tag}-{content}-bw{bw}.recv.txt")
    env = {k: v for k, v in os.environ.items() if k != "NDI_CONFIG_DIR"}
    with open(out, "w") as f:
        p = subprocess.Popen([BENCH_RECV, "--match", MATCH, "--groups", GROUPS, "--findwait", "15",
                              "--warm", "3", "--secs", str(secs), "--bw", str(bw)], stdout=f, stderr=subprocess.STDOUT, env=env)
        st0 = None
        t_win0 = None
        t_start = time.monotonic()
        while True:
            time.sleep(0.05)
            txt = open(out, encoding="utf-8", errors="replace").read()
            if st0 is None and "FIRST FRAME" in txt:
                time.sleep(3.0)                       # receiver warm-up; its window starts now
                t_win0 = time.time()
                st0 = fresh_status(t_win0 - 0.5)
            if "R: mem" in txt or p.poll() is not None or time.monotonic() - t_start > secs + 60:
                break
        t_win1 = time.time()
        st1 = fresh_status(t_win1 - 0.2)
        if p.poll() is None:
            p.terminate()
            try:
                p.wait(3)
            except subprocess.TimeoutExpired:
                p.kill()
    txt = open(out, encoding="utf-8", errors="replace").read()
    res = {"content": content, "content_on_air": (status() or {}).get("content"), "secs": secs, "bw": bw, "machine": mach, "recv_file": out}
    if st0 is None:
        res["error"] = "receiver got no frames"
        print("  ERROR: receiver got no frames: " + txt.strip().splitlines()[-1] if txt.strip() else "", flush=True)
        return res
    dt = st1["updated_unix"] - st0["updated_unix"]
    dfr = st1["frames_sent"] - st0["frames_sent"]
    ddr = st1["dropped_ticks_total"] - st0["dropped_ticks_total"]
    res.update({
        "pid": st1["pid"], "pid_changed": st1["pid"] != st0["pid"],
        "sender_fps": dfr / dt if dt > 0 else 0, "frames": dfr, "dropped": ddr,
        "dropped_pct": 100.0 * ddr / max(1, dfr + ddr),
        "gate_send_over_100": st1["gate_send_over_100ms"] - st0["gate_send_over_100ms"],
        "gate_gap_over_200": st1["gate_gap_over_200ms"] - st0["gate_gap_over_200ms"],
        "alarms_send": st1["alarms_send"] - st0["alarms_send"], "alarms_gap": st1["alarms_gap"] - st0["alarms_gap"],
        "ndi_connections_end": st1["ndi_connections"],
    })
    lines = log_lines_between(st1["log_file"], t_win0, t_win1)
    stl = [l for t, l in lines if l.startswith("STATUS ") and t >= t_win0 + 5.1]   # 5 s windows fully inside the phase
    def grab(key):
        return [float(m.group(1)) for l in stl for m in [re.search(key + r"=([0-9.]+)", l)] if m]
    ms, mg, cpu, fps = grab("max_send"), grab("max_gap"), grab("cpu"), grab("fps")
    res.update({"status_windows": len(stl), "max_send_ms": max(ms, default=0), "max_gap_ms": max(mg, default=0),
                "cpu_pct_mean": sum(cpu) / len(cpu) if cpu else 0, "cpu_pct_max": max(cpu, default=0),
                "status_fps_min": min(fps, default=0),
                "alarm_lines": [f"{time.strftime('%H:%M:%S', time.localtime(t))}.{int(t * 1000) % 1000:03d} {l}"
                                for t, l in lines if l.startswith("ALARM") or "dropped" in l and "ticks" in l]})
    def rx(pat, cast=float, default=None):
        m = re.search(pat, txt)
        return cast(m.group(1)) if m else default
    res.update({
        "recv_url": rx(r"found source '[^']*" + re.escape(MATCH) + r"[^']*' url=(\S+)", str, ""),
        "recv_res": rx(r"FIRST FRAME .*?xres=(\d+ yres=\d+)", str, ""),
        "recv_fps": rx(r"WINDOW .* fps=([0-9.]+)"), "recv_frames": rx(r"WINDOW .* frames=(\d+)", int),
        "timecode_gaps": rx(r"timecode_gaps=(\d+)", int), "recv_backwards": rx(r"backwards=(\d+)", int),
        "recv_interval_max_ms": rx(r"capture_interval_ms .* max=([0-9.]+)"),
        "recv_interval_p99_ms": rx(r"capture_interval_ms .* p99=([0-9.]+)"),
        "recv_stalls": [float(g) for g in re.findall(r"STALL at t=[0-9.]+ s gap=([0-9.]+) ms", txt)],
        "recv_sdk_dropped": rx(r"video_dropped=(\d+)", int), "recv_cpu_pct": rx(r"proc_cpu=([0-9.]+)%"),
    })
    fails = []
    if res["sender_fps"] < 59.5: fails.append(f"sender fps {res['sender_fps']:.2f} < 59.5")
    if res["dropped_pct"] > 0.5: fails.append(f"dropped {res['dropped_pct']:.2f}% > 0.5%")
    if res["gate_send_over_100"] > 0: fails.append(f"{res['gate_send_over_100']} send call(s) > 100 ms")
    if res["gate_gap_over_200"] > 0: fails.append(f"{res['gate_gap_over_200']} sender frame gap(s) > 200 ms")
    if res["recv_fps"] is None: fails.append("no receiver WINDOW line")
    elif res["recv_fps"] < 59.5: fails.append(f"receiver fps {res['recv_fps']:.2f} < 59.5")
    if res["recv_stalls"] or (res["recv_interval_max_ms"] or 0) > 200:
        fails.append(f"receiver gap > 200 ms ({res['recv_stalls']}, max interval {res['recv_interval_max_ms']} ms)")
    if res["timecode_gaps"] is None or res["timecode_gaps"] > 0: fails.append(f"timecode gaps {res['timecode_gaps']}")
    if res["pid_changed"]: fails.append("oats-m0 restarted during the phase")
    res["pass"] = not fails
    res["fails"] = fails
    print(f"  sender: {res['sender_fps']:.2f} fps over {dt:.1f} s, {dfr} frames, dropped {ddr} ({res['dropped_pct']:.3f}%), "
          f"longest send {res['max_send_ms']:.1f} ms, longest gap {res['max_gap_ms']:.1f} ms, alarms send {res['alarms_send']} gap {res['alarms_gap']}, "
          f"gate send>100 {res['gate_send_over_100']} gap>200 {res['gate_gap_over_200']}, CPU {res['cpu_pct_mean']:.1f}% of one core "
          f"(max window {res['cpu_pct_max']:.1f}%)", flush=True)
    print(f"  receiver: {res['recv_res']} url {res['recv_url']}, {res['recv_fps']} fps, {res['recv_frames']} frames, timecode gaps "
          f"{res['timecode_gaps']}, interval p99 {res['recv_interval_p99_ms']} max {res['recv_interval_max_ms']} ms, stalls {res['recv_stalls']}, "
          f"sdk dropped {res['recv_sdk_dropped']}, receiver CPU {res['recv_cpu_pct']}%", flush=True)
    for a in res["alarm_lines"]:
        print("  " + a, flush=True)
    print(f"  => {'PASS' if res['pass'] else 'FAIL: ' + '; '.join(fails)}", flush=True)
    return res


def main():
    ap = argparse.ArgumentParser(description="oats-m0 perf runs", epilog=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--phases", default="normal:75,deep:75,noise:60,deep:75:0")
    ap.add_argument("--tag", default=time.strftime("%Y%m%d-%H%M%S"))
    ap.add_argument("--match", default="OATS VIZ Test", help="NDI source name to receive (M0 sheet: 'OATS VIZ Program')")
    ap.add_argument("--groups", default="oatsbench", help="NDI group (M0 sheet: 'public')")
    ap.add_argument("--observe", action="store_true", help="send no OSC; just measure what is on air")
    a = ap.parse_args()
    global MATCH, GROUPS, OBSERVE
    MATCH, GROUPS, OBSERVE = a.match, a.groups, a.observe
    st = status()
    if time.time() - st["updated_unix"] > 3:
        print("start the program first: ./m0.sh start ... (status.json is stale)")
        return 2
    if not OBSERVE and st["ndi_name"] != "OATS VIZ Test":
        print("perf.py drives the content over OSC, so it only runs against the test instance (./m0.sh start --test --gate);"
              " use --observe --match 'OATS VIZ Program' --groups public next to Vision")
        return 2
    print(f"oats-m0 pid {st['pid']} '{st['ndi_name']}' group {st['ndi_groups']} pinned {st['ndi_adapters_allowed']} "
          f"meta thread {st.get('ndi_meta_thread')} libndi {st['libndi_version']}", flush=True)
    phases = []
    for ph in a.phases.split(","):
        f = ph.split(":")
        phases.append((f[0], int(f[1]), int(f[2]) if len(f) > 2 else 100))
    results = [run_phase(c, s, bw, a.tag) for c, s, bw in phases]
    for c in ("/oats/test/content", ):
        osc(c, ("s", "normal"))
    osc("/oats/fractal/1/zoomspeed", ("f", 0.0))
    osc("/oats/fractal/1/palette/speed", ("f", 0.0))
    out = os.path.join(M, "logs", f"perf-{a.tag}.json")
    with open(out, "w") as f:
        json.dump(results, f, indent=1)
    print("--- summary")
    for r in results:
        if "error" in r:
            print(f"  {r['content']:6} bw{r['bw']:<3} ERROR {r['error']}")
            continue
        print(f"  {r['content']:6} bw{r['bw']:<3} {'PASS' if r['pass'] else 'FAIL'}  sender {r['sender_fps']:.2f} fps, dropped {r['dropped_pct']:.3f}%, "
              f"send max {r['max_send_ms']:.1f} ms, gap max {r['max_gap_ms']:.1f} ms; receiver {r['recv_fps']} fps, tc gaps {r['timecode_gaps']}, "
              f"max interval {r['recv_interval_max_ms']} ms; CPU {r['cpu_pct_mean']:.1f}%; load {r['machine']['load1']:.2f}"
              + ("" if r["pass"] else "  (" + "; ".join(r["fails"]) + ")"))
    print(f"results: {out}")
    return 0 if all(r.get("pass") for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
