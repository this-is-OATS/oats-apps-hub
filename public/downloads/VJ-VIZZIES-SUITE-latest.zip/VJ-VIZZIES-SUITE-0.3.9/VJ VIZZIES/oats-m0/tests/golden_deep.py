#!/usr/bin/env python3
"""Golden check for deep zoom: the player's perturbation output against a plain-iteration CPU render.

For each target and depth it sets the player (zoom hold, Viridis, no colour cycle, internal resolution 640x360,
auto iterations), takes /oats/system/snapshot, and renders a small tile of the same view on the CPU with Python
decimal (z = z^2 + c, about depth + 15 digits, same bailout R = 256, same iteration count and smooth colouring).
The tile pixels sit exactly on the player's internal texel centres (1080p pixel 3*t + 1). It compares luma
(Pearson correlation) and the interior (black) mask. PASS: correlation >= 0.90 and mask agreement >= 0.95.

  python3 -I tests/golden_deep.py --to 127.0.0.1:7001 --logs DIR            (a --test instance)
  python3 -I tests/golden_deep.py --targets VOID --depths 26 --tile 64x36     (minibrot: interior is CPU-heavy)

The player's state (target, depth, zoom speed, palette, cycle, offset, keepdepth, iterations, resolution) is
put back at the end. Stdlib only; macOS `sips` converts the PNG snapshot to BMP.
"""
import argparse
import json
import math
import os
import struct
import subprocess
import sys
import tempfile
import time
from decimal import Decimal, getcontext

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.append(HERE)
from osc_send import encode_message, parse_hostport  # noqa: E402

import socket  # noqa: E402

VIRIDIS = ["440154", "482878", "3e4989", "31688e", "26828e", "1f9e89", "35b779", "6ece58", "b5de2b", "fde725"]
LEVELS = {1080: 1, 900: 2, 720: 3, 540: 4, 360: 5}
RES = {1: (1920, 1080), 2: (1600, 900), 3: (1280, 720), 4: (960, 540), 5: (640, 360)}


class Player:
    def __init__(self, to, logs):
        self.to = to
        self.logs = logs
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def osc(self, addr, *args):
        self.sock.sendto(encode_message(addr, args), self.to)

    def status(self):
        for _ in range(20):
            try:
                with open(os.path.join(self.logs, "status.json")) as f:
                    return json.load(f)
            except (OSError, ValueError):
                time.sleep(0.05)
        raise RuntimeError("cannot read status.json in " + self.logs)

    def wait(self, pred, timeout=20.0, what="state"):
        t0 = time.time()
        st = self.status()
        while time.time() - t0 < timeout:
            st = self.status()
            if pred(st):
                return st
            time.sleep(0.1)
        raise RuntimeError(f"timeout waiting for {what}; last fractal block: {json.dumps(st.get('fractal', {}))[:600]}")

    def snapshot(self, timeout=10.0):
        n0 = self.status()["snapshot"]["count"]
        self.osc("/oats/system/snapshot")
        st = self.wait(lambda s: s["snapshot"]["count"] > n0, timeout, "snapshot")
        return st["snapshot"]["path"], st

    def show(self, target, depth, palette=2, res=360, iters=0, settle=0.6):
        """Holds the zoom, sets target + depth exactly; waits until the orbit is ready. Returns the status."""
        self.osc("/oats/fractal/1/zoomspeed", ("f", 0.0))
        self.osc("/oats/fractal/1/palette", ("i", palette))
        self.osc("/oats/fractal/1/palette/speed", ("f", 0.0))
        self.osc("/oats/fractal/1/palette/offset", ("f", 0.0))
        self.osc("/oats/fractal/1/res", ("i", res))
        self.osc("/oats/fractal/1/iter", ("i", iters))
        self.osc("/oats/fractal/1/target/keepdepth", ("i", 1))
        if isinstance(target, tuple):
            self.osc("/oats/fractal/1/center", ("s", target[0]), ("s", target[1]))
            name = "CUSTOM"
        else:
            self.osc("/oats/fractal/1/target", ("s", target))
            name = target.upper()
        self.osc("/oats/fractal/1/depth", ("d", float(depth)))
        w, h = RES[LEVELS[res]] if res else (None, None)
        st = self.wait(lambda s: s.get("content") == "normal" and s["fractal"]["target"] == name
                       and abs(s["fractal"]["depth_log10"] - depth) < 1e-6 and s["fractal"]["ref_ready"]
                       and (res == 0 or s["fractal"]["internal_res"] == f"{w}x{h}") and s["zoomspeed"] == 0,
                       30, f"{name} at depth {depth}")
        time.sleep(settle)
        return self.status()


def read_bmp(path):
    """24/32-bit uncompressed BMP -> (w, h, bytes RGB top-down)."""
    with open(path, "rb") as f:
        b = f.read()
    off = struct.unpack_from("<I", b, 10)[0]
    w, h = struct.unpack_from("<ii", b, 18)
    bpp = struct.unpack_from("<H", b, 28)[0]
    comp = struct.unpack_from("<I", b, 30)[0]
    if bpp not in (24, 32) or comp not in (0, 3):
        raise RuntimeError(f"unsupported BMP {bpp} bpp, compression {comp}")
    bottom_up = h > 0
    h = abs(h)
    stride = (w * (bpp // 8) + 3) & ~3
    px = bpp // 8
    out = bytearray(w * h * 3)
    for y in range(h):
        sy = h - 1 - y if bottom_up else y
        row = b[off + sy * stride: off + sy * stride + w * px]
        o = y * w * 3
        out[o:o + w * 3:3] = row[2::px]
        out[o + 1:o + w * 3:3] = row[1::px]
        out[o + 2:o + w * 3:3] = row[0::px]
    return w, h, bytes(out)


def png_to_rgb(png):
    with tempfile.TemporaryDirectory() as d:
        bmp = os.path.join(d, "s.bmp")
        subprocess.run(["sips", "-s", "format", "bmp", png, "--out", bmp], check=True, capture_output=True)
        return read_bmp(bmp)


def lut(hexes):
    return [tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)) for h in hexes]


VLUT = lut(VIRIDIS)


def palette_rgb(t):
    x = t - math.floor(t)
    x = 1.0 - abs(2.0 * x - 1.0)
    f = x * 9.0
    i = min(int(f), 8)
    a, b, u = VLUT[i], VLUT[i + 1], f - i
    return tuple(a[k] + (b[k] - a[k]) * u for k in range(3))


def luma(rgb):
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]


def cpu_tile(cre, cim, view_w, rw, rh, tw, th, max_iter, phase, digits):
    """Plain iteration in decimal at the internal texel centres (tx, ty) = (i*sx + sx//2, j*sy + sy//2)."""
    getcontext().prec = digits
    cr, ci = Decimal(cre), Decimal(cim)
    s = Decimal(repr(view_w)) / rw
    sx, sy = rw // tw, rh // th
    R2 = Decimal(65536)
    out = []
    iters_total = 0
    for j in range(th):
        ty = j * sy + sy // 2
        im = ci - (Decimal(ty) + Decimal("0.5") - Decimal(rh) / 2) * s
        for i in range(tw):
            tx = i * sx + sx // 2
            re = cr + (Decimal(tx) + Decimal("0.5") - Decimal(rw) / 2) * s
            x = y = x2 = y2 = Decimal(0)
            n = 0
            esc = False
            while n < max_iter:                     # same loop as the GPU: escape index n, R = 256
                y = 2 * x * y + im
                x = x2 - y2 + re
                x2, y2 = x * x, y * y
                if x2 + y2 > R2:
                    esc = True
                    break
                n += 1
            iters_total += n
            if esc:
                mod = math.sqrt(float(x2 + y2))
                mu = n + 1.0 - math.log2(math.log(mod))
                out.append((luma(palette_rgb(mu * 0.03 + phase)), False, (tx, ty)))
            else:
                out.append((0.0, True, (tx, ty)))
    return out, iters_total


def gpu_luma(rgb, w, x, y):
    o = (y * w + x) * 3
    return luma((rgb[o] / 255, rgb[o + 1] / 255, rgb[o + 2] / 255))


def pearson(a, b):
    n = len(a)
    ma, mb = sum(a) / n, sum(b) / n
    va = sum((x - ma) ** 2 for x in a)
    vb = sum((y - mb) ** 2 for y in b)
    if va == 0 or vb == 0:
        return float("nan")
    return sum((x - ma) * (y - mb) for x, y in zip(a, b)) / math.sqrt(va * vb)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--to", default="127.0.0.1:7000")
    ap.add_argument("--logs", default=os.path.join(os.path.dirname(HERE), "logs"))
    ap.add_argument("--targets", default="SEAHORSE,STAR")
    ap.add_argument("--depths", default="3,10,20,27")
    ap.add_argument("--tile", default="160x90")
    ap.add_argument("--res", type=int, default=360, help="player internal resolution (height)")
    ap.add_argument("--keep", action="store_true", help="leave the test view on the player")
    a = ap.parse_args()
    tw, th = (int(v) for v in a.tile.split("x"))
    if a.res not in (360, 1080):
        sys.exit("--res must be 360 (texel t = 1080p pixel 3t+1) or 1080")
    rw, rh = RES[LEVELS[a.res]]
    if rw % tw or rh % th:
        sys.exit(f"tile {a.tile} must divide the internal resolution {rw}x{rh}")
    p = Player(parse_hostport(a.to), a.logs)
    t_start = time.time()
    st0 = p.wait(lambda s: s.get("updated_unix", 0) > t_start + 0.05, 5, "a fresh status.json")   # earlier OSC applied
    f0 = st0["fractal"]
    saved = dict(target=f0["target_index"], center=(f0["center_re"], f0["center_im"]), custom=f0["target"] == "CUSTOM",
                 depth=f0["depth_log10"], zs=st0["zoomspeed"], pal=st0["palette"], ps=st0["palette_speed"],
                 po=st0["palette_offset"], keep=f0["keepdepth"],
                 it=f0["iterations_base"] if f0["iterations_mode"] == "override" else 0,
                 res=int(f0["internal_res"].split("x")[1]) if f0["internal_res_mode"] == "override" else 0)
    print(f"player {st0['ndi_name']} (pid {st0['pid']}): saved state target {f0['target']} depth {f0['depth_log10']:.2f} "
          f"zoomspeed {st0['zoomspeed']} palette {st0['palette']}")
    results = []
    t_all = time.time()
    try:
        for tname in [t.strip().upper() for t in a.targets.split(",") if t.strip()]:
            for depth in [float(d) for d in a.depths.split(",")]:
                st = p.show(tname, depth, palette=2, res=a.res)
                png, st = p.snapshot()
                fr = st["fractal"]
                view_w, iters, phase = st["view_width"], fr["iterations"], fr["palette_phase"]
                # back to a cheap view while the CPU works (the GPU is shared with the live player)
                p.osc("/oats/fractal/1/depth", ("d", 0.0))
                w, h, rgb = png_to_rgb(png)
                t0 = time.time()
                digits = max(30, int(depth) + 18)
                tile, nit = cpu_tile(fr["center_re"], fr["center_im"], view_w, rw, rh, tw, th, iters, phase, digits)
                cpu_s = time.time() - t0
                cl, gl, agree, interior = [], [], 0, 0
                for (lv, inside, (tx, ty)) in tile:
                    k = 1920 // rw                  # 3 at 640x360: texel t is 1080p pixel 3t+1 (bilinear exact there)
                    g = gpu_luma(rgb, w, k * tx + k // 2, k * ty + k // 2)
                    g_inside = g < 0.02
                    agree += (g_inside == inside)
                    interior += inside
                    cl.append(lv)
                    gl.append(g)
                corr = pearson(cl, gl)
                mask = agree / len(tile)
                ok = (corr >= 0.90 or (math.isnan(corr) and mask == 1.0)) and mask >= 0.95
                results.append((tname, depth, corr, mask, ok))
                print(f"{tname:9s} depth {depth:5.1f}: width {view_w:.3e} iter {iters:5d} tile {tw}x{th} "
                      f"interior {interior:4d}  luma corr {corr:.3f}  mask agree {mask:.3f}  "
                      f"CPU {cpu_s:5.1f} s ({nit / max(cpu_s, 1e-9) / 1e3:.0f}k it/s, {digits} digits)  "
                      f"{'PASS' if ok else 'FAIL'}", flush=True)
    finally:
        if not a.keep:
            p.osc("/oats/fractal/1/target/keepdepth", ("i", 1))
            if saved["custom"]:
                p.osc("/oats/fractal/1/center", ("s", saved["center"][0]), ("s", saved["center"][1]))
            else:
                p.osc("/oats/fractal/1/target", ("i", saved["target"]))
            p.osc("/oats/fractal/1/depth", ("d", saved["depth"]))
            p.osc("/oats/fractal/1/target/keepdepth", ("i", 1 if saved["keep"] else 0))
            p.osc("/oats/fractal/1/palette", ("i", saved["pal"]))
            p.osc("/oats/fractal/1/palette/speed", ("f", saved["ps"]))
            p.osc("/oats/fractal/1/palette/offset", ("f", saved["po"]))
            p.osc("/oats/fractal/1/iter", ("i", saved["it"]))
            p.osc("/oats/fractal/1/res", ("i", saved["res"]))
            p.osc("/oats/fractal/1/zoomspeed", ("f", saved["zs"]))
            print("player state restored")
    n_ok = sum(r[4] for r in results)
    print(f"golden_deep: {n_ok}/{len(results)} PASS in {time.time() - t_all:.0f} s")
    sys.exit(0 if n_ok == len(results) and results else 1)


if __name__ == "__main__":
    main()
