#!/usr/bin/env python3
"""Send an sACN (ANSI E1.31-2018) data stream over UDP 5568. Stdlib only; run with python3 -I.

usage:
  python3 -I sacn_send.py [--to HOST] [--universe 10] [--priority 100] [--name NAME] [--cid HEX32]
                          [--values 255,128,0,0,0] [--rate 30] [--duration 5] [--terminate] [--preview]

--values are DMX slots from address 1 (the rest of the 512 slots are 0).
M0 map (PLAN 13.1 Part C): 1 dimmer, 2 zoom speed (128 = hold), 3 palette, 4 palette cycle speed,
5 test content (<85 normal, 85..170 deep, >170 noise).

examples:
  python3 -I sacn_send.py --values 255,128,0,0,0 --duration 10           # full dimmer, hold zoom
  python3 -I sacn_send.py --values 128,200,160,51,0 --duration 10        # zoom in, Inferno, slow cycle
  python3 -I sacn_send.py --values 255 --duration 2 --terminate          # then stream-terminated x3
"""
import argparse
import socket
import struct
import sys
import time
import uuid

ACN_ID = b"ASC-E1.17\x00\x00\x00"
PORT = 5568


def build_packet(cid: bytes, name: str, priority: int, seq: int, universe: int, values,
                 preview: bool = False, terminated: bool = False, start_code: int = 0,
                 sync: int = 0, slots: int = 512) -> bytes:
    """Builds one E1.31 data packet. values: DMX slot values from address 1."""
    data = bytes(list(values)[:slots]) + b"\x00" * max(0, slots - len(list(values)))
    count = len(data) + 1                                  # property values include the start code
    dmp = struct.pack(">HBBHHH", 0x7000 | (10 + count), 0x02, 0xA1, 0x0000, 0x0001, count) + bytes([start_code]) + data
    options = (0x80 if preview else 0) | (0x40 if terminated else 0)
    name_b = name.encode("utf-8")[:63]
    framing_body = struct.pack(">I", 0x00000002) + name_b + b"\x00" * (64 - len(name_b)) + \
        struct.pack(">BHBBH", priority, sync, seq & 0xFF, options, universe)
    framing = struct.pack(">H", 0x7000 | (2 + len(framing_body) + len(dmp))) + framing_body + dmp
    root_body = struct.pack(">I", 0x00000004) + cid
    root = struct.pack(">HH", 0x0010, 0x0000) + ACN_ID + struct.pack(">H", 0x7000 | (2 + len(root_body) + len(framing))) + root_body
    pkt = root + framing
    assert pkt[125] == start_code and len(pkt) == 126 + len(data), "layout"
    return pkt


def multicast_group(universe: int) -> str:
    return f"239.255.{(universe >> 8) & 0xFF}.{universe & 0xFF}"


class Source:
    """One sACN source (fixed CID) with its own sequence counter."""

    def __init__(self, to="127.0.0.1", universe=10, priority=100, name="oats-m0 test", cid=None, port=PORT):
        self.to = (to, port)
        self.universe = universe
        self.priority = priority
        self.name = name
        self.cid = cid if cid is not None else uuid.uuid4().bytes
        self.seq = 0
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)

    def send(self, values, preview=False, terminated=False, start_code=0, seq=None):
        if seq is None:
            self.seq = (self.seq + 1) & 0xFF
            seq = self.seq
        pkt = build_packet(self.cid, self.name, self.priority, seq, self.universe, values,
                           preview=preview, terminated=terminated, start_code=start_code)
        self.sock.sendto(pkt, self.to)
        return pkt

    def terminate(self, values=(0,), times=3):
        for _ in range(times):                    # E1.31: send three packets with the terminated bit
            self.send(values, terminated=True)
            time.sleep(0.01)

    def close(self):
        self.sock.close()


def main():
    ap = argparse.ArgumentParser(description="Send an sACN data stream", epilog=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--to", default="127.0.0.1", help="destination IP (default 127.0.0.1)")
    ap.add_argument("--multicast", action="store_true", help="send to 239.255.<hi>.<lo> instead of --to")
    ap.add_argument("--universe", type=int, default=10)
    ap.add_argument("--priority", type=int, default=100)
    ap.add_argument("--name", default="oats-m0 sacn_send")
    ap.add_argument("--cid", default="", help="32 hex digits (default: random)")
    ap.add_argument("--values", default="255,128,0,0,0", help="comma-separated slot values from address 1")
    ap.add_argument("--rate", type=float, default=30.0, help="packets per second")
    ap.add_argument("--duration", type=float, default=5.0, help="seconds")
    ap.add_argument("--terminate", action="store_true", help="end with three stream-terminated packets")
    ap.add_argument("--preview", action="store_true", help="set the preview-data option bit")
    a = ap.parse_args()
    if not 1 <= a.universe <= 63999:
        ap.error("universe must be 1..63999")
    if not 0 <= a.priority <= 200:
        ap.error("priority must be 0..200")
    cid = bytes.fromhex(a.cid) if a.cid else uuid.uuid4().bytes
    if len(cid) != 16:
        ap.error("--cid must be 32 hex digits")
    vals = [max(0, min(255, int(v))) for v in a.values.split(",") if v.strip() != ""]
    to = multicast_group(a.universe) if a.multicast else a.to
    src = Source(to=to, universe=a.universe, priority=a.priority, name=a.name, cid=cid)
    n = 0
    t0 = time.monotonic()
    period = 1.0 / a.rate if a.rate > 0 else 1.0
    while time.monotonic() - t0 < a.duration:
        src.send(vals, preview=a.preview)
        n += 1
        nxt = t0 + n * period
        time.sleep(max(0.0, nxt - time.monotonic()))
    if a.terminate:
        src.terminate(vals)
    print(f"sent {n} packets to {to}:{PORT} universe {a.universe} prio {a.priority} name '{a.name}' cid {cid.hex()[:8]} "
          f"values {vals[:8]}{'...' if len(vals) > 8 else ''}{' (preview)' if a.preview else ''}{' + terminate' if a.terminate else ''}")
    src.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
