#!/usr/bin/env python3
"""Computes the deep-zoom targets (src/deep.swift zoomTargets) with Newton's method in Python decimal.

  python3 -I tests/refine_targets.py                 refine + verify, print the table
  python3 -I tests/refine_targets.py --swift         also print the Swift lines for src/deep.swift
  python3 -I tests/refine_targets.py --check-orbit bin/oats-m0
        compare the binary's double-double parse and first orbit steps (--orbit-check) with decimal

Misiurewicz points M(k,p): z_k = z_{k+p} with exact preperiod k and period p (the critical orbit lands on a
repelling cycle). Zooming into one shows the same picture, scaled by the cycle multiplier and rotated, at every
depth. VOID is a minibrot nucleus (z_P = 0), found by the ball-period method 1e-14 from the Misiurewicz point
M(21,4) in seahorse valley (large multiplier, so a low period, 55, at size 1.7e-27: cheap to draw at the end).
The zoom passes spirals, a cross and a 16-armed star and ends in a small copy of the set at depth about 27. Stdlib only.
"""
import argparse
import cmath
import json
import subprocess
import sys
import time
from decimal import Decimal as D, getcontext

DIGITS = 70          # working precision
OUT_DIGITS = 50      # significant digits written to deep.swift

ONE = (D(1), D(0))
ZERO = (D(0), D(0))


def cmul(a, b): return (a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0])
def cadd(a, b): return (a[0] + b[0], a[1] + b[1])
def csub(a, b): return (a[0] - b[0], a[1] - b[1])
def cabs2(a): return a[0] * a[0] + a[1] * a[1]
def cabs(a): return cabs2(a).sqrt()


def cdiv(a, b):
    d = cabs2(b)
    return ((a[0] * b[0] + a[1] * b[1]) / d, (a[1] * b[0] - a[0] * b[1]) / d)


def mis_newton(c, k, p, tol, maxit=100):
    """Newton on f(c) = z_{k+p}(c) - z_k(c)."""
    for it in range(maxit):
        z = dz = ZERO
        for n in range(1, k + p + 1):
            dz = cadd(cmul((2 * z[0], 2 * z[1]), dz), ONE)
            z = cadd(cmul(z, z), c)
            if n == k:
                zk, dzk = z, dz
        step = cdiv(csub(z, zk), csub(dz, dzk))
        c = csub(c, step)
        if cabs(step) < tol:
            return c, it + 1
    raise RuntimeError("Misiurewicz Newton did not converge")


def nucleus_newton(c, period, tol, maxstep, maxit=200):
    """Newton on z_P(c) = 0, steps limited to maxstep."""
    for it in range(maxit):
        z = dz = ZERO
        for _ in range(period):
            dz = cadd(cmul((2 * z[0], 2 * z[1]), dz), ONE)
            z = cadd(cmul(z, z), c)
            if cabs2(z) > 1e20:
                raise RuntimeError("nucleus Newton escaped")
        step = cdiv(z, dz)
        a = cabs(step)
        if a > maxstep:
            step = (step[0] * maxstep / a, step[1] * maxstep / a)
        c = csub(c, step)
        if a < tol:
            return c, it + 1
    raise RuntimeError("nucleus Newton did not converge")


def ball_period(c, r, maxn=20000):
    """First n with |z_n| < |dz_n/dc| r: the period of the lowest-period minibrot within radius r of c."""
    z = dz = ZERO
    for n in range(1, maxn + 1):
        dz = cadd(cmul((2 * z[0], 2 * z[1]), dz), ONE)
        z = cadd(cmul(z, z), c)
        if cabs(z) < cabs(dz) * r:
            return n
    raise RuntimeError("no period found")


def mini_size(c, period):
    """Minibrot size estimate 1 / (b l^2) (C. Heiland-Allen)."""
    z, l, b = ZERO, ONE, ONE
    for _ in range(1, period):
        z = cadd(cmul(z, z), c)
        l = cmul((2 * z[0], 2 * z[1]), l)
        b = cadd(b, cdiv(ONE, l))
    return cabs(cdiv(ONE, cmul(b, cmul(l, l))))


def orbit(c, n):
    o, z = [ZERO], ZERO
    for _ in range(n):
        z = cadd(cmul(z, z), c)
        o.append(z)
    return o


def check_mis(c, k, p, tol):
    """Exact preperiod k and period p; returns the cycle multiplier."""
    o = orbit(c, k + p + 2)
    if cabs(csub(o[k + p], o[k])) > tol:
        raise RuntimeError("not preperiodic with (k, p)")
    if k > 0 and cabs(csub(o[k - 1 + p], o[k - 1])) < tol:
        raise RuntimeError("preperiod is less than k")
    for q in range(1, p):
        if p % q == 0 and cabs(csub(o[k + q], o[k])) < tol:
            raise RuntimeError("period is less than p")
    lam = ONE
    for j in range(k, k + p):
        lam = cmul(lam, (2 * o[j][0], 2 * o[j][1]))
    lc = complex(float(lam[0]), float(lam[1]))
    if abs(lc) <= 1:
        raise RuntimeError("cycle is not repelling: not a Misiurewicz point")
    return lc


# name, kind, seed (re, im), parameters, description
SPECS = [
    ("SEAHORSE", "mis", ("-0.743291890852", "0.131240552309"), (24, 2),
     "seahorse valley, Misiurewicz M24,2 next to the M0 centre: seahorse spirals at every depth"),
    ("SPIRAL", "mis", ("-0.775683768009", "0.136467368295"), (24, 1),
     "seahorse valley, Misiurewicz M24,1: a tight double spiral that turns forever"),
    ("JULIA", "mis", ("-0.1010963638456221", "0.9562865108091415"), (4, 1),
     "1/3 limb branch point, Misiurewicz M4,1: three-armed dendrite that looks like its own Julia set"),
    ("VOID", "nucleus", ("-0.775561253747", "0.137426583355", 21, 4), (D("1e-14"), D("0.37"), D("0.21")),
     "deep minibrot, period 55, size 1.7e-27, by the seahorse-valley point M21,4: spirals, a cross, a 16-armed star, "
     "then a small copy of the set at depth ~27 (black inside)"),
    ("ELEPHANT", "mis", ("0.292073861914", "0.015770917211"), (31, 1),
     "elephant valley, Misiurewicz M31,1: rows of elephant trunks curling into one spiral"),
    ("STAR", "mis", ("-0.5622026215", "0.6428171491"), (6, 1),
     "2/5 limb branch point, Misiurewicz M6,1: five-armed star of stars"),
    # minibrot loop targets (2026-10-22): shallow minibrots, so the endless "Minibrot loop" comes round in under a minute
    ("SEAMINI", "nucleus", ("-0.743291890852", "0.131240552309", 24, 2), (D("1e-8"), D("0.37"), D("0.21")),
     "seahorse-valley minibrot, period 201, size 4.8e-16, by SEAHORSE's M24,2: seahorse spirals, then a copy of the set "
     "at depth ~15 (Minibrot loop target)"),
    ("STARMINI", "nucleus", ("-0.5622026215", "0.6428171491", 6, 1), (D("1e-7"), D("0.37"), D("0.21")),
     "minibrot by STAR's M6,1, period 107, size 1.4e-14: five-armed stars, then a copy of the set at depth ~14 "
     "(Minibrot loop target)"),
]


def plain(x):
    """Decimal -> plain string with OUT_DIGITS significant digits."""
    q = format(x, f".{OUT_DIGITS - 1}e")
    v = D(q)
    s = format(v, "f")
    return s


def refine():
    getcontext().prec = DIGITS
    tol = D(10) ** -(DIGITS - 8)
    done = {}
    rows = []
    for name, kind, seed, par, desc in SPECS:
        t0 = time.time()
        if kind == "mis":
            k, p = par
            c, it = mis_newton((D(seed[0]), D(seed[1])), k, p, tol)
            lam = check_mis(c, k, p, D(10) ** -(DIGITS - 15))
            info = f"M({k},{p}) |multiplier| {abs(lam):.4f} arg {cmath.phase(lam):+.3f}, Newton {it} steps"
        else:
            r, ox, oy = par
            bk, bp = seed[2], seed[3]                    # the Misiurewicz point the minibrot sits next to
            base, _ = mis_newton((D(seed[0]), D(seed[1])), bk, bp, tol)
            check_mis(base, bk, bp, D(10) ** -(DIGITS - 15))
            c0 = cadd(base, (r * ox, r * oy))
            P = ball_period(c0, r)
            c, it = nucleus_newton(c0, P, tol, r)
            zP = orbit(c, P)[P]
            if cabs(zP) > D(10) ** -(DIGITS - 15):
                raise RuntimeError("nucleus check failed")
            info = f"nucleus period {P}, size {float(mini_size(c, P)):.3e}, {float(cabs(csub(c, c0)) / r):.2f} r from the seed, Newton {it} steps"
        done[name] = c
        re, im = plain(c[0]), plain(c[1])
        rows.append((name, re, im, desc, info, P if kind == "nucleus" else 0))
        print(f"{name:9s} {info} ({time.time() - t0:.1f} s)\n          re {re}\n          im {im}")
    return rows


def check_orbit(binary, rows):
    """The player's --orbit-check against decimal: parse error and Z_1..Z_4."""
    getcontext().prec = DIGITS
    worst = 0.0
    for name, re, im, _, _, _ in rows:
        out = subprocess.run(["arch", "-x86_64", binary, "--orbit-check", name, "4"], capture_output=True, text=True, check=True).stdout
        lines = [json.loads(x) for x in out.splitlines() if x.strip()]
        head = lines[0]
        dd = lambda v: D(v[0]) + D(v[1])                       # noqa: E731  exact value of hi + lo
        cre, cim = D(re), D(im)
        pe = max(abs(dd(head["re"]) - cre), abs(dd(head["im"]) - cim))
        cdd = (dd(head["re"]), dd(head["im"]))
        o = orbit(cdd, 4)
        oe = D(0)
        for ln in lines[1:]:
            if "n" in ln:
                n = ln["n"]
                oe = max(oe, abs(dd(ln["re"]) - o[n][0]), abs(dd(ln["im"]) - o[n][1]))
        worst = max(worst, float(pe), float(oe))
        print(f"{name:9s} parse error {float(pe):.1e}   Z_1..Z_4 error {float(oe):.1e}")
    ok = worst < 1e-31
    print(f"double-double check: worst {worst:.1e} -> {'PASS' if ok else 'FAIL'} (limit 1e-31)")
    return ok


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--swift", action="store_true")
    ap.add_argument("--check-orbit", metavar="BINARY")
    a = ap.parse_args()
    rows = refine()
    if a.swift:
        print("    // TARGETS-BEGIN (generated by tests/refine_targets.py --swift)")
        for name, re, im, desc, info, per in rows:
            pp = f", period: {per}" if per else ""
            print(f'    ZoomTarget(name: "{name}", re: "{re}",\n               im: "{im}",\n               desc: "{desc}"{pp}),   // {info}')
        print("    // TARGETS-END")
    if a.check_orbit:
        sys.exit(0 if check_orbit(a.check_orbit, rows) else 1)


if __name__ == "__main__":
    main()
