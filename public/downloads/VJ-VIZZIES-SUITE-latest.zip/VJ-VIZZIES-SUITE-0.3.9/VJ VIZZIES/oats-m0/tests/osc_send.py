#!/usr/bin/env python3
"""Send one OSC 1.0 message (or a #bundle) over UDP. Stdlib only; run with python3 -I.

usage:
  python3 -I osc_send.py [--to host:port] [--reply SECS] [--bundle] ADDRESS [ARG ...]

ARG is typed as  i:1  f:0.3  d:-1.5  h:5  s:deep  T  F  N   (bare 1 -> i, 0.3 -> f, text -> s)

examples:
  python3 -I osc_send.py /oats/master/blackout i:1
  python3 -I osc_send.py /oats/fractal/1/zoomspeed f:0.3
  python3 -I osc_send.py /oats/test/content s:deep
  python3 -I osc_send.py --reply 1 /oats/system/ping
"""
import argparse
import socket
import struct
import sys


def _pad(b: bytes) -> bytes:
    return b + b"\0" * (4 - len(b) % 4)          # always at least one NUL, then pad to 4


def osc_string(s: str) -> bytes:
    return _pad(s.encode("utf-8"))


def parse_arg(a: str):
    """'i:1' -> ('i', 1). Bare values are guessed."""
    if a in ("T", "F", "N"):
        return (a, None)
    if len(a) > 2 and a[1] == ":" and a[0] in "ifdhs":
        t, v = a[0], a[2:]
        if t == "i" or t == "h":
            return (t, int(v))
        if t == "f" or t == "d":
            return (t, float(v))
        return ("s", v)
    try:
        return ("i", int(a))
    except ValueError:
        pass
    try:
        return ("f", float(a))
    except ValueError:
        return ("s", a)


def encode_message(address: str, args=()) -> bytes:
    """args: iterable of (type, value) with type in i f d h s T F N."""
    tags = ","
    data = b""
    for t, v in args:
        tags += t
        if t == "i":
            data += struct.pack(">i", int(v))
        elif t == "f":
            data += struct.pack(">f", float(v))
        elif t == "d":
            data += struct.pack(">d", float(v))
        elif t == "h":
            data += struct.pack(">q", int(v))
        elif t == "s":
            data += osc_string(str(v))
        elif t in ("T", "F", "N"):
            pass
        else:
            raise ValueError("unsupported type " + t)
    return osc_string(address) + osc_string(tags) + data


def encode_bundle(elements, timetag: int = 1) -> bytes:
    """elements: list of already-encoded messages or bundles. timetag 1 = immediately."""
    out = osc_string("#bundle") + struct.pack(">Q", timetag)
    for e in elements:
        out += struct.pack(">i", len(e)) + e
    return out


def read_string(b: bytes, pos: int):
    z = b.index(b"\0", pos)
    s = b[pos:z].decode("utf-8", "replace")
    return s, (z + 4) & ~3


def decode_message(b: bytes):
    """Decodes a simple OSC message (i f d h s T F N). Returns (address, [values])."""
    addr, pos = read_string(b, 0)
    if pos >= len(b) or b[pos:pos + 1] != b",":
        return addr, []
    tags, pos = read_string(b, pos)
    vals = []
    for t in tags[1:]:
        if t == "i":
            vals.append(struct.unpack_from(">i", b, pos)[0]); pos += 4
        elif t == "f":
            vals.append(struct.unpack_from(">f", b, pos)[0]); pos += 4
        elif t == "d":
            vals.append(struct.unpack_from(">d", b, pos)[0]); pos += 8
        elif t == "h":
            vals.append(struct.unpack_from(">q", b, pos)[0]); pos += 8
        elif t == "s":
            s, pos = read_string(b, pos); vals.append(s)
        elif t in "TFN":
            vals.append({"T": True, "F": False, "N": None}[t])
    return addr, vals


def parse_hostport(s: str, default_port: int = 7000):
    if ":" in s:
        h, p = s.rsplit(":", 1)
        return h, int(p)
    return s, default_port


def send(packet: bytes, to=("127.0.0.1", 7000), reply_secs: float = 0.0, sock=None):
    """Sends a packet; with reply_secs > 0 waits for one reply and returns its bytes (or None)."""
    own = sock is None
    s = sock or socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.sendto(packet, to)
        if reply_secs > 0:
            s.settimeout(reply_secs)
            try:
                data, _ = s.recvfrom(65536)
                return data
            except socket.timeout:
                return None
    finally:
        if own:
            s.close()
    return None


def main():
    ap = argparse.ArgumentParser(description="Send an OSC message over UDP", epilog=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--to", default="127.0.0.1:7000", help="host:port (default 127.0.0.1:7000)")
    ap.add_argument("--reply", type=float, default=0.0, help="wait this many seconds for a reply and print it")
    ap.add_argument("--bundle", action="store_true", help="wrap the message in a #bundle")
    ap.add_argument("address")
    ap.add_argument("args", nargs="*")
    a = ap.parse_args()
    if not a.address.startswith("/"):
        ap.error("address must start with /")
    args = [parse_arg(x) for x in a.args]
    pkt = encode_message(a.address, args)
    if a.bundle:
        pkt = encode_bundle([pkt])
    to = parse_hostport(a.to)
    reply = send(pkt, to, a.reply)
    shown = " ".join(f"{t}:{v}" if v is not None else t for t, v in args)
    print(f"sent {a.address} {shown} to {to[0]}:{to[1]} ({len(pkt)} bytes{', bundle' if a.bundle else ''})")
    if a.reply > 0:
        if reply is None:
            print(f"no reply within {a.reply} s")
            return 1
        addr, vals = decode_message(reply)
        print(f"reply {addr} {vals}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
