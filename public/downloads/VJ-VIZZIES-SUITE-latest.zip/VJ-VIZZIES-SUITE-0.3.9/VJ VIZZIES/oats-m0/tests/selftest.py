#!/usr/bin/env python3
"""oats-m0 integration self-test. Stdlib only; run with python3 -I.

Runs against an instance started with `./m0.sh start --test` (name "OATS VIZ Test", group oatsbench,
--debug, restart loop). It talks to OSC 127.0.0.1:7000 and sACN 127.0.0.1:5568 and reads
logs/status.json and the program log.

usage:  python3 -I tests/selftest.py [--only osc,snapshot,sacn,fuzz,watchdog] [--skip watchdog] [--quick]
                                    [--fuzz-secs 22] [--fuzz-rate 300]

Sections:
  osc       every OSC address + types, clamps, bundles, /cmd, unknown, ping/pong; checks status.json
  snapshot  PNG mean luma with blackout on vs normal (PNG decoded here, stdlib zlib)
  sacn      set / hold / loss (2.5 s) / terminate (also on a 0xDD packet) / priority / equal priority /
            debounce / ownership / preview / sequence (duplicate, 19 and 20 behind, 255->0 wrap) /
            band edges of ch1-ch5 / other universe
  fuzz      structured malformations, a CID flood (64-source cap), then a timed random fuzz of both ports
            (default 22 s at 300 packets/s per port); the process must survive and still answer
  watchdog  /oats/debug/stall 0.3 (alarm, no restart) and 1.5 (exit 75, restart via m0.sh loop;
            time to restart measured from the status.json pid change and from a bench receiver's gap)
Exit code 0 = all checks passed.
"""
import argparse
import json
import os
import random
import re
import shutil
import socket
import struct
import subprocess
import sys
import time
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)                       # -I does not add the script directory; do it explicitly
import osc_send as O                            # noqa: E402
import sacn_send as S                           # noqa: E402

M = os.path.dirname(HERE)
STATUS = os.path.join(M, "logs", "status.json")
LOOPLOG = os.path.join(M, "logs", "loop.log")
LOOPPID = os.path.join(M, "run", "loop.pid")
BENCH_RECV = os.path.join(os.path.dirname(M), "ndi-bench", "bin", "receiver")
OSC_TO = ("127.0.0.1", 7000)
SACN_HOST = "127.0.0.1"
UNIVERSE = 10

results = []          # (section, name, ok, detail)
loop_ok = False       # set by preflight: the m0.sh restart loop is running (needed for the watchdog section)


# ---------------------------------------------------------------- helpers

def status():
    for _ in range(20):
        try:
            with open(STATUS) as f:
                return json.load(f)
        except (OSError, ValueError):
            time.sleep(0.05)
    raise RuntimeError("cannot read " + STATUS)


def wait_for(pred, timeout=3.0, every=0.15):
    """Polls status.json until pred(status) is true. Returns (ok, last_status)."""
    t0 = time.monotonic()
    st = status()
    while True:
        try:
            if pred(st):
                return True, st
        except (KeyError, TypeError, IndexError):
            pass
        if time.monotonic() - t0 > timeout:
            return False, st
        time.sleep(every)
        st = status()


def wait_fresh(pred, timeout=3.0, every=0.1):
    """Like wait_for, but only accepts a status.json written after this call (status.json is written once
    per second, so an older file can show the state from before the packets/messages just sent)."""
    t_call = time.time()
    return wait_for(lambda s: s["updated_unix"] > t_call + 0.02 and pred(s), timeout, every)


def check(section, name, ok, detail=""):
    results.append((section, name, bool(ok), detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}{(' - ' + detail) if detail else ''}", flush=True)
    return ok


def osc(address, *args):
    """args as (type, value) tuples or 'T'/'F'/'N'."""
    a = [(x, None) if isinstance(x, str) else x for x in args]
    O.send(O.encode_message(address, a), OSC_TO)


def near(a, b, tol=1e-3):
    return a is not None and abs(float(a) - float(b)) <= tol


def log_path():
    return status().get("log_file", "")


def log_tail_since(offset):
    p = log_path()
    try:
        with open(p, "rb") as f:
            f.seek(offset)
            return f.read().decode("utf-8", "replace")
    except OSError:
        return ""


def log_size():
    try:
        return os.path.getsize(log_path())
    except OSError:
        return 0


def pid_alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def ping(timeout=1.0):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        data = O.send(O.encode_message("/oats/system/ping"), OSC_TO, reply_secs=timeout, sock=s)
    finally:
        s.close()
    if data is None:
        return None
    return O.decode_message(data)


# ---------------------------------------------------------------- PNG (stdlib only)

def png_mean_rgb(path):
    """Decodes an 8-bit non-interlaced PNG (grey, RGB or RGBA) and returns the mean of R, G and B
    and the BT.709 video-range luma mean."""
    with open(path, "rb") as f:
        b = f.read()
    if b[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG")
    pos, idat, w = 8, b"", 0
    while pos < len(b):
        n = struct.unpack(">I", b[pos:pos + 4])[0]
        typ = b[pos + 4:pos + 8]
        data = b[pos + 8:pos + 8 + n]
        if typ == b"IHDR":
            w, h, depth, ctype, _, _, interlace = struct.unpack(">IIBBBBB", data)
            if depth != 8 or interlace != 0 or ctype not in (0, 2, 6):
                raise ValueError(f"unsupported PNG depth={depth} type={ctype} interlace={interlace}")
            bpp = {0: 1, 2: 3, 6: 4}[ctype]
        elif typ == b"IDAT":
            idat += data
        elif typ == b"IEND":
            break
        pos += 12 + n
    raw = zlib.decompress(idat)
    stride = w * bpp
    prev = bytearray(stride)
    sums = [0, 0, 0]
    i = 0
    for _ in range(h):
        ft = raw[i]
        line = bytearray(raw[i + 1:i + 1 + stride])
        i += 1 + stride
        if ft == 1:
            for x in range(bpp, stride):
                line[x] = (line[x] + line[x - bpp]) & 0xFF
        elif ft == 2:
            line = bytearray((a + c) & 0xFF for a, c in zip(line, prev))
        elif ft == 3:
            for x in range(stride):
                left = line[x - bpp] if x >= bpp else 0
                line[x] = (line[x] + ((left + prev[x]) >> 1)) & 0xFF
        elif ft == 4:
            for x in range(stride):
                a = line[x - bpp] if x >= bpp else 0
                c = prev[x - bpp] if x >= bpp else 0
                bb = prev[x]
                p = a + bb - c
                pa, pb, pc = abs(p - a), abs(p - bb), abs(p - c)
                pr = a if (pa <= pb and pa <= pc) else (bb if pb <= pc else c)
                line[x] = (line[x] + pr) & 0xFF
        if bpp == 1:
            s = sum(line)
            sums[0] += s; sums[1] += s; sums[2] += s
        else:
            sums[0] += sum(line[0::bpp]); sums[1] += sum(line[1::bpp]); sums[2] += sum(line[2::bpp])
        prev = line
    n = w * h
    r, g, bl = (s / n for s in sums)
    y = 16 + 219 * (0.2126 * r + 0.7152 * g + 0.0722 * bl) / 255
    return (r, g, bl), y


def take_snapshot(timeout=15.0):
    """Requests a snapshot and keeps polling status.json until it is written AND a 5 s status window that
    ends after it has completed. Returns (snapshot dict, status at completion, windows) where windows maps
    window_end_unix -> (longest gap ms, longest send ms) for every status window overlapping the snapshot."""
    st0 = status()
    before = st0["snapshot"]["count"]
    t_req = time.time()
    osc("/oats/system/snapshot")
    windows, snap, st_done = {}, None, None
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        st = status()
        we = st.get("window_end_unix", 0)
        if we > t_req:
            windows[we] = (st["longest_gap_ms_window"], st["longest_send_ms_window"])
        if snap is None and st["snapshot"]["count"] > before:
            snap, st_done = st["snapshot"], st
        if snap is not None and we >= snap["last_unix"] + 0.1:
            break
        time.sleep(0.15)
    return snap, st_done, windows


# ---------------------------------------------------------------- sections

def sec_preflight():
    print("preflight", flush=True)
    try:
        st = status()
    except RuntimeError as e:
        check("pre", "status.json readable", False, str(e))
        return False
    age = time.time() - st.get("updated_unix", 0)
    ok = check("pre", "status.json fresh", age < 3.0, f"age {age:.1f} s")
    ok &= check("pre", "process alive", pid_alive(st["pid"]), f"pid {st['pid']}")
    ok &= check("pre", "test name and group", st["ndi_name"] == "OATS VIZ Test" and st["ndi_groups"] == "oatsbench",
                f"{st['ndi_name']!r} / {st['ndi_groups']!r} (start with ./m0.sh start --test)")
    check("pre", "x86_64 under Rosetta", st["arch"] == "x86_64", f"arch {st['arch']} rosetta {st['rosetta']}")
    ok &= check("pre", "--debug on", st["debug"] is True)
    check("pre", "NDI pinned (adapters.allowed set)", len(st.get("ndi_adapters_allowed", [])) > 0,
          f"{st.get('ndi_config_dir')} {st.get('ndi_adapters_allowed')}")
    check("pre", "render running at ~60 fps", st["render_running"] and (st["fps"] == 0 or st["fps"] > 55), f"fps {st['fps']}")
    ok &= check("pre", "no DMX source live (test needs the universe to itself)", not st["dmx"]["live"], st["dmx"]["name"])
    global loop_ok
    try:
        with open(LOOPPID) as f:
            lp = int(f.read().strip())
    except (OSError, ValueError):
        lp = 0
    loop_ok = bool(lp) and pid_alive(lp)
    check("pre", "restart loop running (needed for watchdog)", loop_ok, f"loop pid {lp}")
    return ok


def sec_osc():
    print("osc", flush=True)
    osc("/oats/master/dimmer", ("f", 1.0))
    osc("/oats/master/blackout", ("i", 0))
    r = ping()
    check("osc", "ping -> /oats/system/pong", r is not None and r[0] == "/oats/system/pong" and "oats-m0" in str(r[1]),
          str(r)[:160] if r else "no reply")
    osc("/oats/test/content", ("s", "normal"))
    osc("/oats/fractal/1/zoomspeed", ("f", 0.0))
    ok, st = wait_for(lambda s: s["zoomspeed"] == 0 and s["content"] == "normal")
    check("osc", "zoomspeed f 0 (hold)", ok, f"zoomspeed {st['zoomspeed']}")
    osc("/oats/fractal/1/zoom", ("d", -1.0))
    ok, st = wait_for(lambda s: near(s["log10_width"], -1.0, 0.01))
    check("osc", "zoom d -1.0 (absolute log10 width)", ok, f"log10 width {st['log10_width']:.4f}")
    osc("/oats/fractal/1/zoom", ("f", 5.0))
    ok, st = wait_for(lambda s: near(s["log10_width"], 0.47712, 0.002))
    check("osc", "zoom f 5 clamps to log10(3.0)", ok, f"{st['log10_width']:.4f}")
    osc("/oats/fractal/1/zoom", ("d", -40.0))
    ok, st = wait_for(lambda s: near(s["log10_width"], -27.52288, 0.002))
    check("osc", "zoom d -40 clamps to log10(3e-28) (deep zoom limit)", ok, f"{st['log10_width']:.4f}")
    osc("/oats/fractal/1/depth", ("d", 12.0))
    ok, st = wait_for(lambda s: near(s.get("fractal", {}).get("depth_log10", -1), 12.0, 0.002))
    check("osc", "depth d 12 (log10 zoom)", ok, f"{st.get('fractal', {}).get('depth_log10')}")
    osc("/oats/fractal/1/target", ("s", "julia"))
    ok, st = wait_for(lambda s: s.get("fractal", {}).get("target") == "JULIA" and s["fractal"]["ref_ready"]
                      and near(s["fractal"]["depth_log10"], 0.0, 0.002))
    check("osc", "target s julia (depth back to 0, orbit ready)", ok, f"{st.get('fractal', {}).get('target')} depth {st.get('fractal', {}).get('depth_log10')}")
    osc("/oats/fractal/1/target", ("i", 1))
    ok, st = wait_for(lambda s: s.get("fractal", {}).get("target") == "SEAHORSE")
    check("osc", "target i 1 (SEAHORSE)", ok, f"{st.get('fractal', {}).get('target')}")
    # clock-driven zoom: 0.3 decades/s in from width 1 (log10 0)
    osc("/oats/fractal/1/zoom", ("d", 0.0))
    wait_for(lambda s: near(s["log10_width"], 0.0, 0.01))
    osc("/oats/fractal/1/zoomspeed", ("f", 0.3))
    ok, s0 = wait_for(lambda s: near(s["zoomspeed"], 0.3, 1e-6))
    time.sleep(2.2)
    s1 = status()
    rate = (s0["log10_width"] - s1["log10_width"]) / max(1e-3, s1["updated_unix"] - s0["updated_unix"])
    check("osc", "zoomspeed f 0.3: width integrates by clock (~0.3 decades/s)", ok and 0.2 < rate < 0.4, f"{rate:.3f} decades/s")
    osc("/oats/fractal/1/zoomspeed", ("i", -1))
    ok, st = wait_for(lambda s: s["zoomspeed"] == -1)
    check("osc", "zoomspeed i -1 (zoom out)", ok, f"{st['zoomspeed']}")
    osc("/oats/fractal/1/zoomspeed", ("h", 0))
    ok, st = wait_for(lambda s: s["zoomspeed"] == 0)
    check("osc", "zoomspeed h 0 (int64)", ok, f"{st['zoomspeed']}")
    osc("/oats/fractal/1/zoomspeed", ("d", 0.25))
    ok, st = wait_for(lambda s: near(s["zoomspeed"], 0.25, 1e-9))
    check("osc", "zoomspeed d 0.25", ok, f"{st['zoomspeed']}")
    osc("/oats/fractal/1/zoomspeed", ("d", 0.0))
    ok, st = wait_for(lambda s: s["zoomspeed"] == 0)
    check("osc", "zoomspeed d 0", ok)
    for (arg, want, label) in [(("i", 3), 3, "palette i 3 (Magma)"), (("f", 2.0), 2, "palette f 2.0"),
                               (("i", 9), 5, "palette i 9 clamps to 5"), (("i", 0), 1, "palette i 0 clamps to 1"),
                               (("i", 1), 1, "palette i 1 (OATS Navy)")]:
        osc("/oats/fractal/1/palette", arg)
        ok, st = wait_for(lambda s, w=want: s["palette"] == w)
        check("osc", label, ok, f"palette {st['palette']} {st['palette_name']}")
    osc("/oats/fractal/1/palette/speed", ("f", 0.25))
    ok, st = wait_for(lambda s: near(s["palette_speed"], 0.25))
    check("osc", "palette/speed f 0.25", ok, f"{st['palette_speed']}")
    osc("/oats/fractal/1/palette/offset", ("f", 0.5))
    ok, st = wait_for(lambda s: near(s["palette_offset"], 0.5))
    check("osc", "palette/offset f 0.5", ok, f"{st['palette_offset']}")
    osc("/oats/fractal/1/palette/offset", ("f", 1.5))
    ok, st = wait_for(lambda s: near(s["palette_offset"], 1.0))
    check("osc", "palette/offset f 1.5 clamps to 1", ok, f"{st['palette_offset']}")
    for arg, want, label in [(("i", 1), True, "blackout i 1"), (("i", 0), False, "blackout i 0"),
                             ("T", True, "blackout T"), ("F", False, "blackout F"),
                             (("f", 1.0), True, "blackout f 1"), (("f", 0.0), False, "blackout f 0")]:
        osc("/oats/master/blackout", arg)
        ok, st = wait_for(lambda s, w=want: s["blackout"] is w and (s["dimmer_effective"] == 0) == w)
        check("osc", label, ok, f"blackout {st['blackout']} effective dimmer {st['dimmer_effective']}")
    offn = log_size()
    osc("/oats/master/blackout", "N")
    time.sleep(0.3)
    ok, st = wait_fresh(lambda s: True, 2)
    check("osc", "blackout N (nil) -> bad args, blackout unchanged", "bad args" in log_tail_since(offn) and st["blackout"] is False,
          f"blackout {st['blackout']}")
    osc("/oats/master/dimmer", ("f", 0.5))
    ok, st = wait_for(lambda s: near(s["dimmer"], 0.5))
    check("osc", "dimmer f 0.5", ok, f"{st['dimmer']}")
    osc("/oats/master/dimmer", ("f", 2.0))
    ok, st = wait_for(lambda s: near(s["dimmer"], 1.0))
    check("osc", "dimmer f 2 clamps to 1", ok, f"{st['dimmer']}")
    for c in ("deep", "noise", "normal"):
        osc("/oats/test/content", ("s", c))
        ok, st = wait_for(lambda s, c=c: s["content"] == c)
        check("osc", f"test/content s {c}", ok, f"content {st['content']} width {st['view_width']:.3g}")
    off = log_size()
    osc("/oats/test/content", ("s", "bogus"))
    osc("/oats/tempo/bpm", ("f", 128.0))
    ok, st = wait_for(lambda s: near(s["bpm"], 128.0))
    check("osc", "tempo/bpm f 128 stored", ok and st["content"] == "normal", f"bpm {st['bpm']} content {st['content']}")
    osc("/cmd", ("s", "Go+ Executor 201"))
    osc("/oats/no/such/address", ("i", 1))
    time.sleep(0.4)
    t = log_tail_since(off)
    check("osc", "log line format 'OSC <ip>:<port> <address> <types> <args>'",
          re.search(r"OSC 127\.0\.0\.1:\d+ /oats/tempo/bpm ,f 128", t) is not None)
    check("osc", "bad content arg rejected with a log line", "bad args" in t)
    check("osc", "/cmd ignored with a log line", "/cmd" in t and "ignored" in t)
    check("osc", "unknown address logged as unhandled", "/oats/no/such/address" in t and "unhandled" in t)
    # network text is cleaned before logging: a newline in an address must not forge a log line
    off2 = log_size()
    O.send(O.osc_string("/oats/x\nSTALL > 1 s, exiting for restart") + O.osc_string(","), OSC_TO)
    O.send(O.osc_string("/" + "a" * 5000) + O.osc_string(",i") + struct.pack(">i", 1), OSC_TO)
    time.sleep(0.4)
    t2 = log_tail_since(off2)
    lines2 = t2.splitlines()
    check("osc", "control characters in an address are logged as '?' (no forged line)",
          "/oats/x?STALL" in t2 and not any(l.startswith("STALL") for l in lines2))
    check("osc", "a 5000-character address is logged shortened", any("/aaaa" in l for l in lines2) and max((len(l) for l in lines2), default=0) < 800,
          f"longest line {max((len(l) for l in lines2), default=0)} chars")
    # bundle (nested) applies every message
    inner = O.encode_bundle([O.encode_message("/oats/master/dimmer", [("f", 0.8)])])
    O.send(O.encode_bundle([O.encode_message("/oats/fractal/1/palette", [("i", 4)]), inner]), OSC_TO)
    ok, st = wait_for(lambda s: s["palette"] == 4 and near(s["dimmer"], 0.8))
    check("osc", "#bundle (nested) applies both messages", ok, f"palette {st['palette']} dimmer {st['dimmer']}")
    c0 = st["osc"]["count"]
    osc("/oats/tempo/bpm", ("f", 120.0))
    ok, st = wait_for(lambda s: s["osc"]["count"] > c0 and s["osc"]["last_address"] == "/oats/tempo/bpm")
    check("osc", "status osc count / last address", ok, f"count {st['osc']['count']} last {st['osc']['last_address']}")
    # restore
    for a, v in [("/oats/fractal/1/palette", ("i", 1)), ("/oats/master/dimmer", ("f", 1.0)),
                 ("/oats/fractal/1/palette/speed", ("f", 0.0)), ("/oats/fractal/1/palette/offset", ("f", 0.0)),
                 ("/oats/fractal/1/zoom", ("d", 0.47712125))]:
        osc(a, v)


def sec_snapshot():
    print("snapshot", flush=True)
    osc("/oats/test/content", ("s", "normal"))
    osc("/oats/fractal/1/zoomspeed", ("f", 0.0))
    osc("/oats/fractal/1/zoom", ("d", 0.0))
    osc("/oats/fractal/1/palette", ("i", 2))
    osc("/oats/fractal/1/palette/offset", ("f", 0.5))
    osc("/oats/master/dimmer", ("f", 1.0))
    osc("/oats/master/blackout", ("i", 0))
    wait_for(lambda s: s["palette"] == 2 and not s["blackout"])
    time.sleep(0.3)
    copy_n = os.path.join(M, "logs", ".selftest-normal.png")
    a0 = status()["alarms_gap"]
    snap_n, st, win_n = take_snapshot()
    if not check("snapshot", "snapshot written (normal, Viridis, offset 0.5)", snap_n is not None):
        return
    shutil.copyfile(snap_n["path"], copy_n)           # the blackout snapshot overwrites snapshot.png
    a1 = st["alarms_gap"]
    osc("/oats/master/blackout", ("i", 1))
    wait_for(lambda s: s["blackout"] is True)
    time.sleep(0.2)
    snap_b, st, win_b = take_snapshot()
    if not check("snapshot", "snapshot written (blackout)", snap_b is not None):
        return
    a2 = st["alarms_gap"]
    osc("/oats/master/blackout", ("i", 0))
    # render-loop checks first, from status read before any PNG decoding (the decodes are slow and load the CPU)
    check("snapshot", "no sender frame-gap alarm during either snapshot", a1 == a0 and a2 == a1,
          f"alarms_gap {a0} -> {a1} (normal) -> {a2} (blackout)")
    gaps = [g for (g, _) in list(win_n.values()) + list(win_b.values())]
    check("snapshot", "longest frame gap in the status windows around each snapshot < 50 ms",
          bool(gaps) and max(gaps) < 50, f"windows {sorted(round(g, 1) for g in gaps)} ms; "
          f"convert+PNG {snap_n['ms']} / {snap_b['ms']} ms on the snapshot thread")
    t0 = time.monotonic()
    (rgb_n, y_n) = png_mean_rgb(copy_n)
    dec = time.monotonic() - t0
    check("snapshot", "normal frame PNG is not black", y_n > 25, f"PNG mean RGB {tuple(round(x, 1) for x in rgb_n)}, luma {y_n:.1f}; "
          f"program luma {snap_n['mean_luma']}; decode {dec:.1f} s")
    (rgb_b, y_b) = png_mean_rgb(snap_b["path"])
    check("snapshot", "blackout PNG is black (RGB 0, luma 16)", max(rgb_b) < 1.0 and near(snap_b["mean_luma"], 16.0, 0.5),
          f"PNG mean RGB {tuple(round(x, 2) for x in rgb_b)}, program luma {snap_b['mean_luma']}")
    check("snapshot", "normal brighter than blackout", y_n > y_b + 5, f"{y_n:.1f} vs {y_b:.1f}")
    try:
        os.remove(copy_n)
    except OSError:
        pass
    osc("/oats/fractal/1/palette", ("i", 1))
    osc("/oats/fractal/1/palette/offset", ("f", 0.0))
    osc("/oats/fractal/1/zoom", ("d", 0.47712125))


class Stream:
    """A Source sent at 30 Hz from a background thread, values changeable."""

    def __init__(self, name, priority=100, values=(0,), rate=30.0):
        import threading
        self.src = S.Source(to=SACN_HOST, universe=UNIVERSE, priority=priority, name=name)
        self.values = list(values)
        self.rate = rate
        self.running = True
        self.paused = False
        self.lock = threading.Lock()
        self.t = threading.Thread(target=self._run, daemon=True)
        self.t.start()

    def _run(self):
        while self.running:
            with self.lock:
                if not self.paused:
                    self.src.send(self.values)
            time.sleep(1.0 / self.rate)

    def set(self, values):
        with self.lock:
            self.values = list(values)

    def manual(self, values, n=1, gap=0.034, **kw):
        with self.lock:
            self.paused = True
            for _ in range(n):
                self.src.send(values, **kw)
                time.sleep(gap)
            self.values = list(values) if not kw else self.values

    def resume(self):
        with self.lock:
            self.paused = False

    def stop(self, terminate=True):
        self.running = False
        self.t.join()
        if terminate:
            self.src.terminate(self.values)
        self.src.close()


def sec_sacn():
    print("sacn", flush=True)
    off = log_size()
    A = Stream("selftest-A", 100, [128, 128, 160, 51, 0])
    ok, st = wait_for(lambda s: s["dmx"]["live"] and s["dmx"]["name"] == "selftest-A", 3)
    check("sacn", "source A live (prio 100)", ok, f"{st['dmx']['name']} prio {st['dmx']['priority']} ip {st['dmx']['ip']}")
    ok, st = wait_for(lambda s: near(s["dimmer"], 128 / 255) and s["zoomspeed"] == 0 and s["palette"] == 4
                      and near(s["palette_speed"], 51 / 255 * 0.5) and s["content"] == "normal", 3)
    check("sacn", "set: ch1 dimmer 128, ch2 hold, ch3 160 -> palette 4, ch4 51 -> 0.1 c/s, ch5 0 normal", ok,
          f"dimmer {st['dimmer']:.3f} zs {st['zoomspeed']} palette {st['palette']} speed {st['palette_speed']:.3f} content {st['content']}")
    check("sacn", "owner = dmx", st["owner"] == "dmx")
    ok2, st = wait_for(lambda s: s["dmx"]["pps"] > 20, 3)
    check("sacn", "packets/s reported", ok2, f"{st['dmx']['pps']} pkt/s")
    # zoom channel
    for v, want in [(255, 0.5), (0, -0.5), (131, 0.0), (125, 0.0), (193, 0.25)]:
        A.set([128, v, 160, 51, 0])
        ok, st = wait_for(lambda s, w=want: near(s["zoomspeed"], w, 0.003), 2)
        check("sacn", f"ch2={v} -> zoomspeed {want:+.2f}", ok, f"{st['zoomspeed']:.4f}")
    A.set([128, 128, 160, 51, 0])
    # ownership: latest move wins (OSC applies at once; DMX repeating unchanged values doesn't snap it back)
    osc("/oats/master/dimmer", ("f", 0.9))
    osc("/oats/fractal/1/palette", ("i", 2))
    osc("/oats/test/content", ("s", "deep"))
    osc("/oats/fractal/1/palette/speed", ("f", 0.4))
    time.sleep(1.5)
    st = status()
    check("sacn", "LTP: OSC dimmer/palette/content/palette speed apply and hold while DMX repeats", near(st["dimmer"], 0.9)
          and st["palette"] == 2 and st["content"] == "deep" and near(st["palette_speed"], 0.4)
          and st["owners"]["palette"] == "osc" and st["owner"] == "mixed",
          f"dimmer {st['dimmer']:.3f} palette {st['palette']} content {st['content']} owners {st.get('owners')}")
    A.set([128, 128, 120, 51, 0])                                   # console moves ch3 only: DMX retakes the palette
    ok, st = wait_for(lambda s: s["palette"] == 3 and s["owners"]["palette"] == "dmx", 2)
    check("sacn", "LTP: console move on ch3 retakes palette (dimmer stays OSC)", ok and near(st["dimmer"], 0.9),
          f"palette {st['palette']} dimmer {st['dimmer']:.3f}")
    check("sacn", "log: 'DMX retakes'", "DMX retakes" in log_tail_since(off))
    A.set([128, 128, 160, 51, 0])
    osc("/oats/master/dimmer", ("f", 128 / 255)); osc("/oats/test/content", ("s", "normal"))
    osc("/oats/fractal/1/palette/speed", ("f", 51 / 255 * 0.5))
    wait_for(lambda s: s["palette"] == 4 and s["content"] == "normal", 2)
    # debounce ch3 (palette) and ch5 (content)
    base = [128, 128, 160, 51, 0]
    A.manual(base, 3)
    A.manual([128, 128, 40, 51, 0], 1)
    A.manual(base, 3)
    time.sleep(1.2)                                   # status.json is written once per second
    st = status()
    check("sacn", "debounce: one packet of ch3=40 does not change the palette", st["palette"] == 4, f"palette {st['palette']}")
    A.manual([128, 128, 40, 51, 0], 2)
    ok, st = wait_for(lambda s: s["palette"] == 1, 2)
    check("sacn", "debounce: two packets of ch3=40 -> palette 1", ok, f"palette {st['palette']}")
    A.manual([128, 128, 40, 51, 120], 1)
    A.manual([128, 128, 40, 51, 0], 3)
    time.sleep(1.2)
    st = status()
    check("sacn", "debounce: one packet of ch5=120 does not change content", st["content"] == "normal", st["content"])
    A.manual([128, 128, 40, 51, 120], 2)
    ok, st = wait_for(lambda s: s["content"] == "deep", 2)
    check("sacn", "debounce: two packets of ch5=120 -> deep", ok, st["content"])
    A.manual([128, 128, 40, 51, 200], 2)
    ok, st = wait_for(lambda s: s["content"] == "noise", 2)
    check("sacn", "ch5=200 -> noise", ok, st["content"])
    A.manual(base, 3)
    A.resume()
    ok, st = wait_for(lambda s: s["content"] == "normal" and s["palette"] == 4, 2)
    check("sacn", "back to normal / palette 4", ok)
    # band edges (README / PLAN 13.1 Part C); each step changes the expected value, and only a status.json
    # written after the packets counts. A is paused (manual packets only) for at most ~1.2 s per step.
    for v, want in [(0, 1), (52, 2), (51, 1), (103, 3), (102, 2), (154, 4), (153, 3), (205, 5), (204, 4), (255, 5)]:
        A.manual([128, 128, v, 51, 0], 2)
        ok, st = wait_fresh(lambda s, w=want: s["palette"] == w, 2)
        check("sacn", f"ch3={v} -> palette {want}", ok, str(st["palette"]))
    for v, want in [(85, "deep"), (84, "normal"), (170, "deep"), (171, "noise"), (0, "normal")]:
        A.manual([128, 128, 160, 51, v], 2)
        ok, st = wait_fresh(lambda s, w=want: s["content"] == w, 2)
        check("sacn", f"ch5={v} -> {want}", ok, st["content"])
    for vals, key, want in [([0, 128, 160, 51, 0], "dimmer", 0.0), ([255, 128, 160, 255, 0], "dimmer", 1.0),
                            ([255, 128, 160, 0, 0], "palette_speed", 0.0), ([255, 128, 160, 255, 0], "palette_speed", 0.5)]:
        A.manual(vals, 2)
        ok, st = wait_fresh(lambda s, k=key, w=want: near(s[k], w), 2)
        check("sacn", f"{key} {vals} -> {want}", ok, str(st[key]))
    A.manual(base, 3)
    A.resume()
    ok, st = wait_fresh(lambda s: near(s["dimmer"], 128 / 255) and s["palette"] == 4 and near(s["palette_speed"], 51 / 255 * 0.5), 2)
    check("sacn", "back to the base look", ok)
    # another universe is ignored, even at priority 200
    X = S.Source(to=SACN_HOST, universe=UNIVERSE + 1, priority=200, name="selftest-other-universe")
    ou0 = status()["dmx"]["other_universe"]
    for _ in range(5):
        X.send([0] * 5)
        time.sleep(0.02)
    X.close()
    ok, st = wait_fresh(lambda s: s["dmx"]["other_universe"] >= ou0 + 5, 2)
    check("sacn", f"universe {UNIVERSE + 1} ignored", ok and st["dmx"]["name"] == "selftest-A" and near(st["dimmer"], 128 / 255),
          f"other_universe {ou0}->{st['dmx']['other_universe']} winner {st['dmx']['name']}")
    # sequence (E1.31: drop when (int8)(new - last) <= 0 and > -20): duplicate and 19 behind dropped, 20 behind accepted
    A.manual(base, 2)                                 # A paused from here
    sd0 = wait_fresh(lambda s: True, 2)[1]["dmx"]["seq_dropped"]
    with A.lock:
        cur = A.src.seq
        A.src.send([0, 128, 160, 51, 0], seq=cur)                    # duplicate
        A.src.send([0, 128, 160, 51, 0], seq=(cur - 5) & 0xFF)       # 5 behind
        A.src.send([0, 128, 160, 51, 0], seq=(cur - 19) & 0xFF)      # 19 behind
    ok, st = wait_fresh(lambda s: s["dmx"]["seq_dropped"] >= sd0 + 3, 2)
    check("sacn", "sequence: duplicate, 5 and 19 behind are dropped", ok and near(st["dimmer"], 128 / 255),
          f"seq_dropped {sd0}->{st['dmx']['seq_dropped']} dimmer {st['dimmer']:.3f}")
    sd1 = st["dmx"]["seq_dropped"]
    A.manual(base, 1)                                 # dropped packets don't keep a source alive: refresh A first
    with A.lock:
        A.src.send([10, 128, 160, 51, 0], seq=(A.src.seq - 20) & 0xFF)   # 20 behind: accepted
    ok, st = wait_fresh(lambda s: near(s["dimmer"], 10 / 255), 2)
    check("sacn", "sequence: 20 behind is accepted", ok and st["dmx"]["seq_dropped"] == sd1,
          f"dimmer {st['dimmer']:.3f} seq_dropped {sd1}->{st['dmx']['seq_dropped']}")
    A.manual(base, 2)
    A.resume()
    # sequence wrap 255 -> 0 from a higher-priority source, then a terminate sent on a 0xDD packet
    W = S.Source(to=SACN_HOST, universe=UNIVERSE, priority=120, name="selftest-wrap")
    W.seq = 249
    for d in [20, 30, 40, 50, 60, 70, 80, 90, 99]:  # sequence 250 .. 255, 0, 1, 2
        W.send([d, 128, 160, 51, 0])
        time.sleep(0.03)
    ok, st = wait_fresh(lambda s: s["dmx"]["name"] == "selftest-wrap" and near(s["dimmer"], 99 / 255), 2)
    wsrc = [x for x in st["dmx"]["sources"] if x["name"] == "selftest-wrap"]
    check("sacn", "sequence wrap 255 -> 0 accepted", ok and wsrc and wsrc[0]["seq_dropped"] == 0,
          f"winner {st['dmx']['name']} dimmer {st['dimmer']:.3f} {wsrc[0] if wsrc else ''}")
    t0 = time.monotonic()
    for _ in range(3):
        W.send([99, 128, 160, 51, 0], terminated=True, start_code=0xDD)
        time.sleep(0.01)
    W.close()
    ok, st = wait_for(lambda s: s["dmx"]["name"] == "selftest-A", 3, every=0.05)
    dt = time.monotonic() - t0
    check("sacn", "stream-terminated on a 0xDD packet drops the source at once", ok and dt < 1.5, f"{dt:.2f} s, winner {st['dmx']['name']}")
    # preview from a higher-priority source is ignored
    P = S.Source(to=SACN_HOST, universe=UNIVERSE, priority=200, name="selftest-preview")
    pv0 = status()["dmx"]["preview"]
    for _ in range(10):
        P.send([255, 128, 160, 51, 0], preview=True)
        time.sleep(0.03)
    ok, st = wait_for(lambda s: s["dmx"]["preview"] >= pv0 + 10, 2)
    check("sacn", "preview packets ignored", ok and st["dmx"]["name"] == "selftest-A" and near(st["dimmer"], 128 / 255),
          f"preview {pv0}->{st['dmx']['preview']} winner {st['dmx']['name']}")
    P.close()
    # higher priority wins, then falls back on terminate
    B = Stream("selftest-B", 150, [255, 128, 160, 51, 0])
    ok, st = wait_for(lambda s: s["dmx"]["name"] == "selftest-B" and near(s["dimmer"], 1.0), 3)
    check("sacn", "priority: B (150) wins over A (100)", ok, f"winner {st['dmx']['name']} dimmer {st['dimmer']:.3f}")
    t0 = time.monotonic()
    B.stop(terminate=True)
    ok, st = wait_for(lambda s: s["dmx"]["name"] == "selftest-A" and near(s["dimmer"], 128 / 255), 3)
    check("sacn", "terminate B: A takes over at once", ok and time.monotonic() - t0 < 1.5,
          f"{time.monotonic() - t0:.2f} s, winner {st['dmx']['name']}")
    # equal priority: the most recently started source wins
    C = Stream("selftest-C", 100, [64, 128, 160, 51, 0])
    ok, st = wait_for(lambda s: s["dmx"]["name"] == "selftest-C" and near(s["dimmer"], 64 / 255), 3)
    check("sacn", "equal priority: newer source C wins", ok, f"winner {st['dmx']['name']} dimmer {st['dimmer']:.3f}")
    C.stop(terminate=True)
    ok, st = wait_for(lambda s: s["dmx"]["name"] == "selftest-A", 3)
    check("sacn", "C terminated: back to A", ok)
    # terminate A: lost at once, hold last look, OSC owns again
    t0 = time.monotonic()
    A.stop(terminate=True)
    ok, st = wait_for(lambda s: not s["dmx"]["live"], 2.5, every=0.05)
    dt = time.monotonic() - t0
    check("sacn", "terminate A: DMX lost at once", ok and dt < 1.5, f"{dt:.2f} s (status.json is written once per second)")
    check("sacn", "hold last look (dimmer, palette kept)", near(st["dimmer"], 128 / 255) and st["palette"] == 4,
          f"dimmer {st['dimmer']:.3f} palette {st['palette']}")
    check("sacn", "owner back to osc", st["owner"] == "osc")
    # loss by silence: 2.5 s
    D = Stream("selftest-D", 100, [200, 128, 160, 51, 0])
    wait_for(lambda s: s["dmx"]["live"] and s["dmx"]["name"] == "selftest-D", 3)
    t0 = time.monotonic()
    D.stop(terminate=False)
    ok, st = wait_for(lambda s: not s["dmx"]["live"], 6, every=0.05)
    dt = time.monotonic() - t0
    check("sacn", "silence: source lost after 2.5 s (not sooner)", ok and 2.4 <= dt <= 3.8, f"{dt:.2f} s")
    check("sacn", "hold last look after silence", near(st["dimmer"], 200 / 255), f"dimmer {st['dimmer']:.3f}")
    osc("/oats/master/dimmer", ("f", 1.0))
    ok, st = wait_for(lambda s: near(s["dimmer"], 1.0), 2)
    check("sacn", "OSC dimmer works again after DMX loss", ok)
    t = log_tail_since(off)
    check("sacn", "log: source added / dropped / lost lines",
          "DMX source ADDED" in t and "stream terminated" in t and "2.5 s silence" in t and "DMX lost, holding last look" in t)
    check("sacn", "log: equal-priority decision logged", "most recently started" in t)
    osc("/oats/fractal/1/palette", ("i", 1))
    osc("/oats/fractal/1/palette/speed", ("f", 0.0))
    osc("/oats/fractal/1/zoomspeed", ("f", 0.0))


def sec_fuzz(quick=False, secs=22.0, rate=300):
    print("fuzz", flush=True)
    st0 = status()
    pid = st0["pid"]
    m0, b0, ig0 = st0["osc"]["malformed"], st0["dmx"]["bad"], st0["dmx"]["ignored"]
    off = log_size()
    rnd = random.Random(1234)
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 1 << 20)
    sent = {7000: 0, 5568: 0}

    def tx(pkt, port, pace=True):
        s.sendto(pkt, ("127.0.0.1", port))
        sent[port] += 1
        if pace and (sent[7000] + sent[5568]) % 50 == 0:
            time.sleep(0.01)                   # don't overrun the socket buffer

    # 1. structured malformations
    good = O.encode_message("/oats/fractal/1/palette", [("i", 1)])
    for k in range(1, len(good)):
        tx(good[:k], 7000)
    evil = [
        b"/oats", b"/oats\0\0\0", b"/oats\0\0\0,iii\0\0\0\0", b"oats\0\0\0\0", b"#bundle\0", b"#bundle\0" + b"\0" * 8 + b"\x7f\xff\xff\xff",
        b"#bundle\0" + b"\0" * 8 + b"\xff\xff\xff\xf0" + b"/x\0\0", b"/a\0\0,b\0\0\x80\0\0\0", b"/a\0\0,b\0\0\0\0\0\x10abc",
        b"/a\0\0,s\0\0abcd", b"/a\0\0,z\0\0\0\0\0\0", b"/a\0\0,ffffffffffffffff\0\0\0\0", b"/" + b"a" * 5000,
        b"\0" * 64, b"/a\0\0,d\0\0\0\0\0\0", b"/a\0\0,h\0\0\0\0", b"/a\0\0," + b"i" * 3000 + b"\0",
    ]
    nest = O.encode_message("/oats/tempo/bpm", [("f", 1.0)])
    for _ in range(40):
        nest = O.encode_bundle([nest])
    evil.append(nest)
    for e in evil:
        tx(e, 7000)
    valid = S.build_packet(os.urandom(16), "fuzz", 100, 1, UNIVERSE, [255, 128, 0, 0, 0])
    for k in range(0, len(valid), 1 if not quick else 7):
        tx(valid[:k], 5568)

    def mut(pkt, off, val):
        b = bytearray(pkt)
        b[off:off + len(val)] = val
        return bytes(b)
    for o, val in [(0, b"\x00\x11"), (4, b"XSC"), (16, b"\x70\x05"), (16, b"\x00\x00"), (18, b"\0\0\0\x05"), (38, b"\x72\x00"),
                   (40, b"\0\0\0\x09"), (108, b"\xff"), (113, b"\0\0"), (113, b"\xff\xff"), (115, b"\x70\x05"), (115, b"\x30\x0b"),
                   (117, b"\x07"), (118, b"\xa2"), (119, b"\0\x01"), (121, b"\0\x02"),
                   (123, b"\x02\x58"), (123, b"\0\0"), (123, b"\x02\x02"), (123, b"\x00\x06")]:
        tx(mut(valid, o, val), 5568)
    tx(mut(valid, 125, b"\xdd"), 5568)          # per-address priority start code: valid but ignored
    # 2. CID flood: valid packets from 100 different CIDs (priority 0, default look); at most 64 are tracked
    for i in range(100):
        tx(S.build_packet(rnd.randbytes(16), f"fuzz-cid-{i}", 0, 1, UNIVERSE, [255, 128, 0, 0, 0]), 5568)
    _, st = wait_fresh(lambda s: s["dmx"]["ignored"] >= ig0 + 30, 3)
    check("fuzz", "CID flood: at most 64 sources tracked", len(st["dmx"]["sources"]) <= 64 and st["dmx"]["ignored"] >= ig0 + 30,
          f"{len(st['dmx']['sources'])} sources, ignored {ig0}->{st['dmx']['ignored']}")
    check("fuzz", "log: '64 sources already tracked'", "64 sources already tracked" in log_tail_since(off))

    # 3. timed random fuzz, both ports, `rate` packets/s each
    def rand_osc():
        k = rnd.random()
        if k < 0.4:
            return rnd.randbytes(rnd.randint(1, 600))
        if k < 0.7:                              # address + type tags + random payload: reaches the arg parser
            addr = "/" + "".join(rnd.choice("oats/fractl1zmpe") for _ in range(rnd.randint(0, 40)))
            tags = "," + "".join(rnd.choice("ifsdhTFNbtcrmI[]Sz") for _ in range(rnd.randint(0, 12)))
            return O.osc_string(addr) + O.osc_string(tags) + rnd.randbytes(rnd.randint(0, 64))
        if k < 0.85:
            return b"#bundle\0" + rnd.randbytes(8) + struct.pack(">i", rnd.randint(-8, 200)) + rnd.randbytes(rnd.randint(0, 200))
        b = bytearray(good)
        for _ in range(rnd.randint(1, 4)):
            b[rnd.randrange(len(b))] = rnd.getrandbits(8)
        return bytes(b)

    def rand_sacn():
        k = rnd.random()
        if k < 0.3:
            return rnd.randbytes(rnd.randint(1, 700))
        if k < 0.8:                              # valid packet with 1-4 random bytes changed
            b = bytearray(valid)
            for _ in range(rnd.randint(1, 4)):
                b[rnd.randrange(len(b))] = rnd.getrandbits(8)
            return bytes(b)
        return valid[:rnd.randint(0, len(valid))]

    dur = 5.0 if quick else secs
    per_tick = max(1, int(round(rate / 100)))     # 10 ms ticks
    n0 = dict(sent)
    alive_checks, dead = 0, []
    t_start = time.monotonic()
    nxt, last_chk = t_start, t_start
    while time.monotonic() - t_start < dur:
        for _ in range(per_tick):
            tx(rand_osc(), 7000, pace=False)
            tx(rand_sacn(), 5568, pace=False)
        nxt += 0.01
        now = time.monotonic()
        if nxt > now:
            time.sleep(nxt - now)
        if now - last_chk >= 2.0:
            last_chk = now
            alive_checks += 1
            if not pid_alive(pid):
                dead.append(round(now - t_start, 1))
    elapsed = time.monotonic() - t_start
    n_osc, n_sacn = sent[7000] - n0[7000], sent[5568] - n0[5568]
    s.close()
    print(f"  timed fuzz: {elapsed:.1f} s, OSC {n_osc} packets ({n_osc / elapsed:.0f}/s), sACN {n_sacn} packets ({n_sacn / elapsed:.0f}/s), "
          f"{alive_checks} liveness checks", flush=True)
    check("fuzz", f"timed fuzz ran {elapsed:.1f} s at {n_osc / elapsed:.0f} + {n_sacn / elapsed:.0f} packets/s, process alive throughout",
          not dead and elapsed >= dur - 0.5 and pid_alive(pid), f"dead at {dead}" if dead else f"{alive_checks} checks")
    time.sleep(1.5)
    alive = pid_alive(pid)
    st = status()
    check("fuzz", f"process survived {sent[7000] + sent[5568]} fuzz packets", alive and st["pid"] == pid and time.time() - st["updated_unix"] < 3,
          f"pid {pid} alive={alive}")
    check("fuzz", "malformed OSC counted", st["osc"]["malformed"] > m0, f"{m0} -> {st['osc']['malformed']}")
    check("fuzz", "malformed sACN counted", st["dmx"]["bad"] > b0, f"{b0} -> {st['dmx']['bad']}")
    check("fuzz", "log stays bounded (rate-limited malformed/unhandled lines)", True,
          f"{(log_size() - off) / 1024:.0f} KB of log for the whole fuzz section")
    r = ping()
    check("fuzz", "still answers ping after fuzzing", r is not None and r[0] == "/oats/system/pong")
    # mutated valid packets can form short-lived sources; all must be gone 2.5 s after the fuzz stops
    ok, st = wait_for(lambda s: not s["dmx"]["live"], 5)
    check("fuzz", "no fuzz source left live", ok, st["dmx"]["name"])
    check("fuzz", "render still at ~60 fps", st["fps"] > 55, f"fps {st['fps']}")
    for a, v in [("/oats/master/dimmer", ("f", 1.0)), ("/oats/master/blackout", ("i", 0)), ("/oats/fractal/1/zoomspeed", ("f", 0.0)),
                 ("/oats/fractal/1/palette", ("i", 1)), ("/oats/fractal/1/palette/speed", ("f", 0.0)),
                 ("/oats/fractal/1/palette/offset", ("f", 0.0)), ("/oats/test/content", ("s", "normal")),
                 ("/oats/fractal/1/zoom", ("d", 0.47712125))]:
        osc(a, v)


class BenchReceiver:
    """ndi-bench receiver connected to OATS VIZ Test, for measuring how long the picture is gone."""

    def __init__(self, tag, secs=60):
        self.path = os.path.join(M, "logs", f"selftest-recv-{tag}.txt")
        self.p = None
        if not os.access(BENCH_RECV, os.X_OK):
            return
        env = {k: v for k, v in os.environ.items() if k != "NDI_CONFIG_DIR"}
        self.f = open(self.path, "w")
        self.p = subprocess.Popen([BENCH_RECV, "--match", "OATS VIZ Test", "--groups", "oatsbench", "--findwait", "15",
                                   "--warm", "1", "--secs", str(secs)], stdout=self.f, stderr=subprocess.STDOUT, env=env)

    def text(self):
        try:
            with open(self.path, encoding="utf-8", errors="replace") as f:
                return f.read()
        except OSError:
            return ""

    def wait_text(self, pred, timeout):
        t0 = time.monotonic()
        while time.monotonic() - t0 < timeout:
            t = self.text()
            if pred(t):
                return True, t
            if self.p is not None and self.p.poll() is not None:
                break
            time.sleep(0.1)
        return False, self.text()

    def stalls(self):
        return [float(g) for g in re.findall(r"STALL at t=[0-9.]+ s gap=([0-9.]+) ms", self.text())]

    def stop(self):
        if self.p is not None and self.p.poll() is None:
            self.p.terminate()
            try:
                self.p.wait(3)
            except subprocess.TimeoutExpired:
                self.p.kill()
        if self.p is not None:
            self.f.close()


def sec_watchdog():
    print("watchdog", flush=True)
    rc = BenchReceiver("watchdog", secs=60)
    if rc.p is not None:
        ok, t = rc.wait_text(lambda t: "FIRST FRAME" in t, 20)
        check("watchdog", "bench receiver connected to OATS VIZ Test", ok, (re.search(r"found source '[^']*OATS VIZ Test[^']*' url=\S+", t) or [""])[0])
        time.sleep(1.5)                                    # past the receiver's 1 s warm-up: STALL lines are printed from here on
    st = status()
    pid0, a0 = st["pid"], st["alarms_gap"]
    osc("/oats/debug/stall", ("f", 0.3))
    ok, st = wait_for(lambda s: s["alarms_gap"] > a0, 3)
    check("watchdog", "stall 0.3 s: gap ALARM, no restart", ok and st["pid"] == pid0,
          f"alarms_gap {a0}->{st['alarms_gap']} longest gap {st['longest_gap_ms_total']} ms")
    time.sleep(0.5)
    n_stall0 = len(rc.stalls()) if rc.p is not None else 0
    loop0 = os.path.getsize(LOOPLOG) if os.path.exists(LOOPLOG) else 0
    old_log = st["log_file"]
    t0 = time.monotonic()
    osc("/oats/debug/stall", ("f", 1.5))
    ok, st = wait_for(lambda s: s["pid"] != pid0, 20, every=0.05)
    t_pid = time.monotonic() - t0
    if not check("watchdog", "stall 1.5 s: process exits and the loop restarts it (new pid)", ok, f"pid {pid0} -> {st['pid']} after {t_pid:.2f} s"):
        rc.stop()
        return
    ok2, st = wait_for(lambda s: s["frames_sent"] > 0 and s["render_running"], 20, every=0.05)
    t_frames = time.monotonic() - t0
    check("watchdog", "restarted process sends frames again", ok2, f"first frames {t_frames:.2f} s after the stall command "
          f"(stall 1.0 s to notice + restart + init)")
    check("watchdog", "restarted instance is pinned and named OATS VIZ Test",
          bool(st.get("ndi_adapters_allowed")) and st["ndi_name"] == "OATS VIZ Test" and st["ndi_groups"] == "oatsbench",
          f"{st['ndi_name']!r} {st['ndi_groups']!r} {st.get('ndi_adapters_allowed')}")
    gap_ms = None
    if rc.p is not None:
        okr, _ = rc.wait_text(lambda t: len(re.findall(r"STALL at t=", t)) > n_stall0, 25)
        g = rc.stalls()
        gap_ms = g[-1] if okr and len(g) > n_stall0 else None
        check("watchdog", "bench receiver gets frames again after the restart (same receiver, no reconnect by hand)",
              gap_ms is not None, f"receiver gap {gap_ms:.0f} ms" if gap_ms is not None else "no frames within 25 s")
    rc.stop()
    try:
        with open(old_log, encoding="utf-8", errors="replace") as f:
            tail = f.read()[-4000:]
    except OSError:
        tail = ""
    check("watchdog", "old log ends with 'STALL > 1 s, exiting for restart'",
          re.search(r"^\S+ \S+ STALL > 1 s, exiting for restart", tail, re.M) is not None)
    loop = ""
    if os.path.exists(LOOPLOG):
        with open(LOOPLOG, encoding="utf-8", errors="replace") as f:
            f.seek(loop0)
            loop = f.read()
    check("watchdog", "loop.log: RESTART # with exit 75", "RESTART #" in loop and "exit 75" in loop, loop.strip().splitlines()[-1] if loop.strip() else "")
    print(f"  time to restart: new pid after {t_pid:.2f} s, frames after {t_frames:.2f} s (from the stall command, "
          f"status.json polled every 50 ms but written once per second)"
          + (f"; bench receiver saw no frames for {gap_ms / 1000:.2f} s" if gap_ms is not None else ""), flush=True)


def main():
    ap = argparse.ArgumentParser(description="oats-m0 integration self-test", epilog=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", default="", help="comma list of sections")
    ap.add_argument("--skip", default="", help="comma list of sections to skip")
    ap.add_argument("--quick", action="store_true", help="short fuzz (5 s)")
    ap.add_argument("--fuzz-secs", type=float, default=22.0, help="duration of the timed random fuzz")
    ap.add_argument("--fuzz-rate", type=int, default=300, help="packets/s per port in the timed fuzz")
    a = ap.parse_args()
    order = ["osc", "snapshot", "sacn", "fuzz", "watchdog"]
    only = [x for x in a.only.split(",") if x] or order
    skip = [x for x in a.skip.split(",") if x]
    t0 = time.monotonic()
    if not sec_preflight():
        print("preflight failed: start the program with ./m0.sh start --test and stop any DMX to universe 10")
        return 2
    if not loop_ok and "watchdog" in only and "watchdog" not in skip:
        print("watchdog section skipped: no m0.sh restart loop (a stall would end the instance for good)")
        skip.append("watchdog")
    for sec in order:
        if sec in only and sec not in skip:
            try:
                if sec == "fuzz":
                    sec_fuzz(a.quick, a.fuzz_secs, a.fuzz_rate)
                else:
                    globals()["sec_" + sec]()
            except Exception as e:                      # a crash in the test is a failed check, not a silent pass
                check(sec, "section ran without a test error", False, f"{type(e).__name__}: {e}")
    n_ok = sum(1 for r in results if r[2])
    n_bad = len(results) - n_ok
    print(f"\n{n_ok} passed, {n_bad} failed, {time.monotonic() - t0:.0f} s")
    for sec, name, ok, detail in results:
        if not ok:
            print(f"FAIL [{sec}] {name} {detail}")
    return 0 if n_bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
