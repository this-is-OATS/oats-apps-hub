#!/bin/zsh
# M0 Parts D and E (PLAN 13.1), measured with a loopback receiver next to Vision.
#   D: deep 300 s, then noise 300 s, receiver at lowest bandwidth (as Vision Low)
#   E: normal content with a slow zoom/colour cycle for 1680 s, then one `m0.sh restart`, timed
# Content is switched over OSC from this Mac (same addresses as the MA3 macros, which passed in Part B).
# usage: tests/run_parts_de.sh [D|E|DE]   (default DE). Output: logs/parts-de-<stamp>.txt + perf-*.json
set -u
M=${0:A:h:h}
cd $M
WHAT=${1:-DE}
STAMP=$(date +%Y%m%d-%H%M%S)
OUT=$M/logs/parts-de-$STAMP.txt
RECV="$M/../ndi-bench/bin/receiver"
osc() { python3 -I tests/osc_send.py "$@" >/dev/null; }
say() { print -r -- "$(date '+%H:%M:%S') $*" | tee -a $OUT; }
pid_now() { python3 -I -c "import json;print(json.load(open('logs/status.json'))['pid'])" 2>/dev/null; }

say "parts $WHAT: restarting oats-m0 with --gate --no-ndi-meta --universe 5"
OLD=$(pid_now)
./m0.sh stop >>$OUT 2>&1
./m0.sh start --gate --no-ndi-meta --universe 5 >>$OUT 2>&1
python3 -I - "$OLD" <<'EOF' >>$OUT 2>&1
import json, sys, time
old = sys.argv[1]
t0 = time.time()
while time.time() - t0 < 1200:
    try:
        d = json.load(open("logs/status.json"))
        if str(d["pid"]) != old and time.time() - d["updated_unix"] < 2 and d["fps"] > 50:
            print(f"ready after {time.time() - t0:.0f} s: pid {d['pid']} fps {d['fps']} universe {d['dmx']['universe']} conns {d['ndi_connections']}")
            break
    except Exception:
        pass
    time.sleep(1)
else:
    print("NOT READY after 20 min")
EOF
tail -1 $OUT
say "load $(sysctl -n vm.loadavg)  swap $(sysctl -n vm.swapusage | cut -c1-60)"

if [[ $WHAT == *D* ]]; then
  osc /oats/master/blackout i:0; osc /oats/master/dimmer f:1
  for c in deep noise; do
    osc /oats/test/content s:$c
    say "PART D: content $c for 300 s (Vision should show it now)"
    python3 -I tests/perf.py --observe --match "OATS VIZ Program" --groups public --phases $c:300:0 --tag D-$c-$STAMP 2>&1 | tee -a $OUT | grep -E 'PASS|FAIL|ERROR|results:'
  done
  osc /oats/test/content s:normal
fi

if [[ $WHAT == *E* ]]; then
  osc /oats/test/content s:normal; osc /oats/fractal/1/zoom d:0.47712125
  osc /oats/fractal/1/zoomspeed f:0.04; osc /oats/fractal/1/palette/speed f:0.1
  say "PART E: normal content with slow zoom and colour cycle for 1680 s"
  python3 -I tests/perf.py --observe --match "OATS VIZ Program" --groups public --phases normal:1680:0 --tag E-$STAMP 2>&1 | tee -a $OUT | grep -E 'PASS|FAIL|ERROR|results:'
  say "PART E: restart test (receiver runs 45 s, restart at +10 s)"
  "$RECV" --match "OATS VIZ Program" --groups public --bw 0 --secs 45 --warm 1 --findwait 10 > $M/logs/E-restart-$STAMP.recv.txt 2>&1 &
  RP=$!
  python3 -I -c "import time; time.sleep(10)"
  say "m0.sh restart now"
  ./m0.sh restart >>$OUT 2>&1
  wait $RP
  grep -E 'STALL|WINDOW|capture_interval' $M/logs/E-restart-$STAMP.recv.txt | tee -a $OUT
  osc /oats/fractal/1/palette/speed f:0.1
  say "restart test done (palette cycle re-fired)"
fi
say "parts $WHAT finished; full log $OUT"
