import Foundation
import Darwin

// NDI frame ring (2026-10-22): POSIX shared memory between the renderer (the native arm64 player, producer) and an NDI
// sender (consumer): the x86_64 helper `oats-ndi` (helper mode: libndi 6.3.2 under Rosetta, which does not freeze) or a
// thread inside the player (native / native-soft: the arm64 libndi). Compiled into both programs (same layout on both
// architectures: little-endian 64-bit words at fixed offsets, no Swift structs in shared memory).
//
// The producer never waits: it writes a frame into a slot no consumer uses, publishes it in one atomic word (`latest`),
// and posts the "frame ready" semaphore (sem_post never blocks). A consumer claims `latest` with compare-and-swap, marks
// the slot busy for the duration of the NDI call, then held (async send: NDI reads the buffer until the next call
// returns). With 3 slots, a consumer that falls behind costs dropped NDI frames (counted), never a renderer stall.
//
// Layout (16 KiB header + 3 slots of 1920x1080 UYVY, each rounded up to 16 KiB):
//   words 0..15     global (magic, generation, latest, want bits, producer heartbeat, config seq, fps, slot sizes, ...)
//   words 16..31    consumer area 0 (helper), words 40..55 consumer area 1 (native thread in the player)
//   bytes 2048..    config strings (NDI name, groups); bytes 4096.. / 6144.. consumer area strings (version, arch, error, receivers)

let ringMagic: UInt64 = 0x4F41_5453_524E_4731      // "OATSRNG1"
let ringSlots = 3
let ringHeaderBytes = 16384
let ringMaxW = 1920, ringMaxH = 1080
let ringSlotBytes = (ringMaxW * 2 * ringMaxH + 16383) / 16384 * 16384
let ringTotalBytes = ringHeaderBytes + ringSlots * ringSlotBytes

/// Global word indices.
enum RG {
    static let magic = 0, gen = 1, latest = 2, want = 3, prodBeat = 4, cfgSeq = 5, fps = 6
    static let dim0 = 7                     // 7, 8, 9: (w << 32) | h of the frame in slot 0, 1, 2
    static let noMeta = 10, prodPid = 11, prodDropped = 12, prodPublished = 13
    static let nameOff = 2048, nameMax = 256, groupsOff = 2304, groupsMax = 256
}
/// Bits of RG.want: which consumer should send right now.
let wantHelper: UInt64 = 1, wantNative: UInt64 = 2
/// `latest` = (seq << 8) | consumed bit | slot; seq 0 = nothing published yet.
let latestConsumed: UInt64 = 0x80

/// One consumer's words (relative to its base) and strings.
struct RingArea {
    let base: Int, strBase: Int, want: UInt64, label: String
    static let helper = RingArea(base: 16, strBase: 4096, want: wantHelper, label: "helper")
    static let native = RingArea(base: 40, strBase: 6144, want: wantNative, label: "native")
    // word offsets
    static let beat = 0, sendSince = 1, pid = 2, sent = 3, stalls50 = 4, stalls100 = 5, maxSendUs = 6, lastSendUs = 7
    static let conns = 8, state = 9, busy = 10, held = 11, over1s = 12, totalSendUs = 13
    // string offsets (relative to strBase) and sizes
    static let sVersion = (0, 128), sArch = (128, 32), sError = (160, 224), sProducts = (384, 1024)
}
/// RingArea.state values.
enum RingState: UInt64 { case idle = 0, sending = 1, error = 2, loading = 3 }

@inline(__always) func monoNs() -> UInt64 { clock_gettime_nsec_np(CLOCK_UPTIME_RAW) }   // the same clock in both processes (Rosetta too)

final class FrameRing {
    let key: String
    let shmName: String
    let semName: String
    let base: UnsafeMutableRawPointer
    let created: Bool

    /// Opens (creating if needed) the shared memory "/oatsndi.<key>" and maps it. nil + reason on failure.
    static func open(key: String) -> (FrameRing?, String) {
        let name = "/oatsndi.\(key)"                     // PSHMNAMLEN is 31 on macOS
        var created = false
        var fd = oats_shm_open(name, O_RDWR | O_CREAT | O_EXCL, 0o600)
        if fd >= 0 { created = true } else if errno == EEXIST { fd = oats_shm_open(name, O_RDWR, 0o600) }
        guard fd >= 0 else { return (nil, "shm_open(\(name)) failed: \(String(cString: strerror(errno)))") }
        defer { close(fd) }
        var st = stat()
        if fstat(fd, &st) != 0 { return (nil, "fstat(\(name)) failed: \(String(cString: strerror(errno)))") }
        if st.st_size == 0 {
            if ftruncate(fd, off_t(ringTotalBytes)) != 0 { return (nil, "ftruncate(\(name), \(ringTotalBytes)) failed: \(String(cString: strerror(errno)))") }
        } else if Int(st.st_size) < ringTotalBytes {
            return (nil, "\(name) has \(st.st_size) bytes, need \(ringTotalBytes) (an older layout? remove it: reboot, or stop every OATS process)")
        }
        guard let p = mmap(nil, ringTotalBytes, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0), p != MAP_FAILED else {
            return (nil, "mmap(\(name)) failed: \(String(cString: strerror(errno)))")
        }
        let r = FrameRing(key: key, shmName: name, base: p, created: created)
        if r.load(RG.magic) != ringMagic {
            // fresh object (zero-filled by the kernel): stamp it. Both sides do the same, harmlessly.
            r.store(RG.magic, ringMagic)
        }
        return (r, "")
    }

    private init(key: String, shmName: String, base: UnsafeMutableRawPointer, created: Bool) {
        self.key = key; self.shmName = shmName; self.base = base; self.created = created
        self.semName = shmName + ".s"
    }

    @inline(__always) func word(_ i: Int) -> UnsafeMutablePointer<UInt64> { (base + i * 8).assumingMemoryBound(to: UInt64.self) }
    @inline(__always) func load(_ i: Int) -> UInt64 { oats_load_u64(word(i)) }
    @inline(__always) func store(_ i: Int, _ v: UInt64) { oats_store_u64(word(i), v) }
    @inline(__always) func cas(_ i: Int, _ expected: UInt64, _ desired: UInt64) -> Bool { oats_cas_u64(word(i), expected, desired) }
    @discardableResult @inline(__always) func add(_ i: Int, _ v: UInt64) -> UInt64 { oats_add_u64(word(i), v) }
    @inline(__always) func aload(_ a: RingArea, _ i: Int) -> UInt64 { load(a.base + i) }
    @inline(__always) func astore(_ a: RingArea, _ i: Int, _ v: UInt64) { store(a.base + i, v) }

    func slotPtr(_ s: Int) -> UnsafeMutableRawPointer { base + ringHeaderBytes + s * ringSlotBytes }
    func slotOffset(_ s: Int) -> Int { ringHeaderBytes + s * ringSlotBytes }

    func setString(_ off: Int, _ max: Int, _ s: String) {
        let b = Array(s.utf8.prefix(max - 1))
        let p = (base + off).assumingMemoryBound(to: UInt8.self)
        for (i, c) in b.enumerated() { p[i] = c }
        p[b.count] = 0
    }
    func getString(_ off: Int, _ max: Int) -> String {
        let p = (base + off).assumingMemoryBound(to: UInt8.self)
        var n = 0
        while n < max - 1 && p[n] != 0 { n += 1 }
        return String(decoding: UnsafeBufferPointer(start: p, count: n), as: UTF8.self)
    }
    func setAreaString(_ a: RingArea, _ f: (Int, Int), _ s: String) { setString(a.strBase + f.0, f.1, s) }
    func areaString(_ a: RingArea, _ f: (Int, Int)) -> String { getString(a.strBase + f.0, f.1) }

    /// Slots a consumer may be reading: the published one (claimed or not) and each consumer's busy + held slot.
    func slotsInUse() -> [Bool] {
        var u = [Bool](repeating: false, count: ringSlots)
        let l = load(RG.latest)
        if l >> 8 != 0 { u[Int(l & 0x3) % ringSlots] = true }
        for a in [RingArea.helper, RingArea.native] {
            for k in [RingArea.busy, RingArea.held] {
                let v = aload(a, k)
                if v >= 1 && v <= UInt64(ringSlots) { u[Int(v) - 1] = true }
            }
        }
        return u
    }
}

/// Named "frame ready" semaphore (the helper waits on it; the player posts it). sem_post never blocks.
final class RingSemaphore {
    let sem: UnsafeMutablePointer<sem_t>
    init?(name: String) {
        guard let ss = oats_sem_open(name, O_CREAT, 0o600, 0) else { return nil }
        sem = ss
    }
    @inline(__always) func post() { sem_post(sem) }
    func wait() { while sem_wait(sem) != 0 && errno == EINTR {} }
}

/// The consumer side: claims published frames and calls the NDI async send. Runs in the helper (area .helper) or as a
/// thread inside the player (area .native). Everything it learns (sends, stalls, connections, receivers) goes into its
/// area, which the player's status reads. The NDI sender is created while the producer asks for this consumer and
/// destroyed when it stops asking (or, in the helper, after `staleSec` without a producer heartbeat).
final class NDIConsumer {
    let ring: FrameRing
    let area: RingArea
    let lib: NDILib
    let waitFrame: () -> Void
    let staleSec: Double
    let log: (String) -> Void
    private let sndLock = NSLock()
    private var snd: NDIlib_send_instance_t? = nil
    private let stopLock = NSLock()
    private var _stop = false
    var stopping: Bool {
        get { stopLock.lock(); defer { stopLock.unlock() }; return _stop }
        set { stopLock.lock(); _stop = newValue; stopLock.unlock() }
    }
    let done = DispatchSemaphore(value: 0)
    private let frames: [UnsafeMutablePointer<NDIlib_video_frame_v2_t>]
    private var lastStallLog = 0.0, stallsSinceLog = 0

    init(ring: FrameRing, area: RingArea, lib: NDILib, staleSec: Double, waitFrame: @escaping () -> Void, log: @escaping (String) -> Void) {
        self.ring = ring; self.area = area; self.lib = lib; self.staleSec = staleSec; self.waitFrame = waitFrame; self.log = log
        frames = (0..<ringSlots).map { _ in
            let p = UnsafeMutablePointer<NDIlib_video_frame_v2_t>.allocate(capacity: 1)
            p.initialize(to: NDIlib_video_frame_v2_t())
            p.pointee.FourCC = fourCC("UYVY")
            p.pointee.frame_format_type = 1
            return p
        }
        ring.astore(area, RingArea.pid, UInt64(getpid()))
        ring.astore(area, RingArea.busy, 0)
        ring.astore(area, RingArea.held, 0)
        ring.astore(area, RingArea.sendSince, 0)
        ring.astore(area, RingArea.state, RingState.idle.rawValue)
        ring.setAreaString(area, RingArea.sVersion, lib.versionString)
        ring.setAreaString(area, RingArea.sArch, processArchText())
        ring.setAreaString(area, RingArea.sError, "")
        ring.setAreaString(area, RingArea.sProducts, "")
    }

    func start(name: String) {
        let t = Thread { [self] in
            pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0)
            self.run()
        }
        t.name = name
        t.qualityOfService = .userInteractive
        t.start()
        let m = Thread { [self] in self.metaLoop() }
        m.name = name + "-meta"
        m.qualityOfService = .userInitiated
        m.start()
    }

    private func wanted() -> Bool {
        guard ring.load(RG.want) & area.want != 0 else { return false }
        let pb = ring.load(RG.prodBeat), now = monoNs()
        return pb != 0 && (now <= pb || Double(now - pb) / 1e9 < staleSec)
    }

    private func createSender() {
        let name = ring.getString(RG.nameOff, RG.nameMax)
        let groups = ring.getString(RG.groupsOff, RG.groupsMax)
        let cname = strdup(name.isEmpty ? "OATS VIZ Program" : name)!
        let cgroups: UnsafeMutablePointer<CChar>? = groups.isEmpty ? nil : strdup(groups)
        var sc = NDIlib_send_create_t(p_ndi_name: UnsafePointer(cname), p_groups: cgroups.map { UnsafePointer($0) }, clock_video: false, clock_audio: false)
        let s = lib.send_create(&sc)
        free(cname); if let g = cgroups { free(g) }
        sndLock.lock(); snd = s; sndLock.unlock()
        if s == nil {
            ring.astore(area, RingArea.state, RingState.error.rawValue)
            ring.setAreaString(area, RingArea.sError, "NDIlib_send_create failed")
            log("NDI (\(area.label)): NDIlib_send_create failed")
        } else {
            ring.astore(area, RingArea.state, RingState.sending.rawValue)
            ring.setAreaString(area, RingArea.sError, "")
            log("NDI (\(area.label)): sender created name='\(name)' groups=\(groups.isEmpty ? "NULL (Public)" : "'\(groups)'") clock_video=false, libndi \(lib.versionString) \(processArchText())")
        }
    }

    private func destroySender(_ why: String) {
        sndLock.lock(); let s = snd; snd = nil; sndLock.unlock()
        guard let sp = s else { return }
        lib.send_send_video_async_v2(sp, nil)               // flush: NDI releases the held buffer
        ring.astore(area, RingArea.held, 0)
        lib.send_destroy(sp)
        ring.astore(area, RingArea.conns, 0)
        ring.setAreaString(area, RingArea.sProducts, "")
        ring.astore(area, RingArea.state, RingState.idle.rawValue)
        log("NDI (\(area.label)): sender destroyed (\(why))")
    }

    private func run() {
        var lastCfg: UInt64 = .max, lastGen: UInt64 = .max, lastSeq: UInt64 = 0
        var frameBase: Int64 = 0, lastFrameNo: Int64 = -1
        var lastConnPoll = 0.0
        while true {
            waitFrame()
            let now = monoNs()
            ring.astore(area, RingArea.beat, now)
            if stopping { break }
            if !wanted() {
                if snd != nil { destroySender(ring.load(RG.want) & area.want == 0 ? "not the active NDI mode" : "no producer heartbeat for \(Int(staleSec)) s") }
                continue
            }
            let cfg = ring.load(RG.cfgSeq)
            if snd == nil || cfg != lastCfg {
                if snd != nil { destroySender("name / groups changed") }
                createSender(); lastCfg = cfg
                if snd == nil { usleep(1_000_000); continue }
            }
            let gen = ring.load(RG.gen)
            if gen != lastGen { lastGen = gen; lastSeq = 0; frameBase = lastFrameNo + 1 }
            let noMeta = ring.load(RG.noMeta) != 0
            let tnow = Double(now) / 1e9
            if noMeta && tnow - lastConnPoll >= 0.5, let s = snd {
                lastConnPoll = tnow
                ring.astore(area, RingArea.conns, UInt64(max(0, Int(lib.send_get_no_connections(s, 0)))))
            }
            let l = ring.load(RG.latest)
            let seq = l >> 8
            if seq == 0 || l & latestConsumed != 0 || seq <= lastSeq { continue }
            guard ring.cas(RG.latest, l, l | latestConsumed) else { continue }   // the renderer published a newer one: next round
            let slot = Int(l & 0x3) % ringSlots
            lastSeq = seq
            ring.astore(area, RingArea.busy, UInt64(slot + 1))
            let dim = ring.load(RG.dim0 + slot)
            let w = Int32(truncatingIfNeeded: dim >> 32), h = Int32(truncatingIfNeeded: dim & 0xffff_ffff)
            let fps = ring.load(RG.fps)
            let fpsN = Int32(truncatingIfNeeded: fps >> 32), fpsD = Int32(truncatingIfNeeded: fps & 0xffff_ffff)
            let fp = frames[slot]
            fp.pointee.xres = w > 0 ? w : 1920; fp.pointee.yres = h > 0 ? h : 1080
            fp.pointee.line_stride_in_bytes = fp.pointee.xres * 2
            fp.pointee.frame_rate_N = fpsN > 0 ? fpsN : 60; fp.pointee.frame_rate_D = fpsD > 0 ? fpsD : 1
            fp.pointee.picture_aspect_ratio = Float(fp.pointee.xres) / Float(fp.pointee.yres)
            fp.pointee.p_data = ring.slotPtr(slot).assumingMemoryBound(to: UInt8.self)
            let frameNo = frameBase + Int64(seq)
            lastFrameNo = frameNo
            fp.pointee.timecode = frameNo * 10_000_000 * Int64(fp.pointee.frame_rate_D) / Int64(fp.pointee.frame_rate_N)
            guard let s = snd else { ring.astore(area, RingArea.busy, 0); continue }
            let t1 = monoNs()
            ring.astore(area, RingArea.sendSince, t1)
            lib.send_send_video_async_v2(s, fp)
            let t2 = monoNs()
            ring.astore(area, RingArea.sendSince, 0)
            ring.astore(area, RingArea.held, UInt64(slot + 1))   // held first, then not busy: the slot is never seen free in between
            ring.astore(area, RingArea.busy, 0)
            let us = (t2 &- t1) / 1000
            ring.add(area.base + RingArea.sent, 1)
            ring.add(area.base + RingArea.totalSendUs, us)
            ring.astore(area, RingArea.lastSendUs, us)
            if us > ring.aload(area, RingArea.maxSendUs) { ring.astore(area, RingArea.maxSendUs, us) }
            if us > 50_000 {
                ring.add(area.base + RingArea.stalls50, 1)
                if us > 100_000 { ring.add(area.base + RingArea.stalls100, 1) }
                if us > 1_000_000 { ring.add(area.base + RingArea.over1s, 1) }
                stallsSinceLog += 1
                let tn = Double(t2) / 1e9
                if tn - lastStallLog >= 1 {
                    log(String(format: "NDI (%@): send call %.1f ms (frame %lld)%@", area.label, Double(us) / 1000, frameNo,
                               stallsSinceLog > 1 ? " (+\(stallsSinceLog - 1) more > 50 ms since the last line)" : ""))
                    lastStallLog = tn; stallsSinceLog = 0
                }
            }
        }
        destroySender("stopping")
        ring.astore(area, RingArea.busy, 0)
        ring.astore(area, RingArea.held, 0)
        done.signal()
    }

    /// Receiver metadata (<ndi_product>) and the connection count, as the player's ndi-meta thread did; with
    /// noMeta set (m0.sh --no-ndi-meta), only the send loop's connection poll runs.
    private func metaLoop() {
        var mf = NDIlib_metadata_frame_t()
        var products: [String] = []
        var lastConns = -1
        while !stopping {
            if ring.load(RG.noMeta) != 0 { usleep(250_000); continue }
            sndLock.lock()
            guard let s = snd else { sndLock.unlock(); products = []; lastConns = -1; usleep(250_000); continue }
            let t = lib.send_capture(s, &mf, 250)
            if t == 3 {
                if let p = mf.p_data {
                    let txt = String(cString: p)
                    if let r = txt.range(of: "<ndi_product") {
                        let tail = txt[r.lowerBound...]
                        let elem = tail.range(of: ">").map { String(tail[..<$0.upperBound]) } ?? String(tail.prefix(300))
                        if !products.contains(elem) { products.append(elem); if products.count > 6 { products.removeFirst() } }
                        log("NDI (\(area.label)) receiver metadata: \(elem.prefix(300))")
                        ring.setAreaString(area, RingArea.sProducts, products.joined(separator: "\n"))
                    }
                }
                lib.send_free_metadata(s, &mf)
            }
            let c = Int(lib.send_get_no_connections(s, 0))
            sndLock.unlock()
            if t == 4 { usleep(250_000) }
            if c != lastConns {
                log(lastConns < 0 ? "NDI (\(area.label)) connections: \(c)" : "NDI (\(area.label)) connections: \(lastConns) -> \(c)")
                lastConns = c
                if c == 0 { products = []; ring.setAreaString(area, RingArea.sProducts, "") }
                ring.astore(area, RingArea.conns, UInt64(max(0, c)))
            }
        }
    }
}

func processArchText() -> String {
    #if arch(x86_64)
    let a = "x86_64"
    #elseif arch(arm64)
    let a = "arm64"
    #else
    let a = "unknown"
    #endif
    var translated: Int32 = 0
    var size = MemoryLayout<Int32>.size
    if sysctlbyname("sysctl.proc_translated", &translated, &size, nil, 0) != 0 { translated = 0 }
    return a + (translated == 1 ? " (Rosetta 2)" : " (native)")
}
