import Foundation
import Darwin

// Watchdog thread at 10 Hz, started right after the log opens (so Metal init and the first frame are
// covered too). When the render or frame-out heartbeat has been silent for > 1.0 s (the render thread is stuck), or no
// frame has been rendered 30 s after start, it logs "STALL > 1 s, exiting for restart" (or the start-up variant),
// flushes the log and calls _exit(75) without destroying anything (NDI may be hung). m0.sh restarts it.
// The watchdog takes no lock on its normal path: ALARM lines are queued and logged by the status thread,
// and on the exit path an independent 0.5 s backstop thread exits even if logging or onStall blocks.

final class Watchdog {
    let stallLimit = 1.0
    let firstFrameLimit = 30.0
    private var warnedSendStart: UInt64 = 0
    private let lock = NSLock()
    private var _onStall: (() -> Void)? = nil
    /// Set once the status reporter exists (it writes status.json with state "stall-exit").
    var onStall: (() -> Void)? {
        get { lock.lock(); defer { lock.unlock() }; return _onStall }
        set { lock.lock(); _onStall = newValue; lock.unlock() }
    }

    func start() {
        let t = Thread { [self] in self.run() }
        t.name = "watchdog"
        t.qualityOfService = .userInteractive
        t.start()
    }

    private func exitForRestart(_ msg: String) -> Never {
        let backstop = Thread { usleep(500_000); _exit(75) }   // a stuck thread may hold the logger or a status lock
        backstop.qualityOfService = .userInteractive
        backstop.start()
        olog(msg)
        onStall?()
        Logger.shared.sync()
        _exit(75)
    }

    private func run() {
        while true {
            usleep(100_000)
            if gFlags.stopping { continue }
            // Heartbeats first, then the clock: read the other way round, a heartbeat stored between the two
            // reads is newer than `now`, and now &- beat wraps to ~2^64 ns (a false "STALL", seen in testing
            // when this thread woke together with the render thread). age() also clamps that case to 0.
            let rb = gBeats.render, sb = gBeats.send, sip = gBeats.sendInProgress
            let now = nowTicks()
            func age(_ t: UInt64) -> Double { t >= now ? 0 : ticksToSec(now - t) }
            if rb == 0 || sb == 0 {                             // first frame not sent yet
                let up = age(gStartTicks)
                if up > firstFrameLimit {
                    exitForRestart(String(format: "STALL: no frame sent %.1f s after start (init or first frame hung), exiting for restart", up))
                }
                continue
            }
            let rAge = age(rb), sAge = age(sb)
            if rAge > stallLimit || sAge > stallLimit {
                exitForRestart(String(format: "STALL > 1 s, exiting for restart (render heartbeat %.2f s ago, send heartbeat %.2f s ago, send in progress %@)",
                                      rAge, sAge, sip != 0 ? String(format: "%.2f s", age(sip)) : "no"))
            }
            // NDI send stalls are no longer this watchdog's business: the render thread never calls NDI (ndiout.swift
            // reports them as alarms, and kills a helper stuck in one call for 3 s; the renderer keeps running).
            _ = warnedSendStart
        }
    }
}
