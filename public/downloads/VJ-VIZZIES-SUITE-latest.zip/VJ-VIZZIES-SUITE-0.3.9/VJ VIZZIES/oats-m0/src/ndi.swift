import Foundation
import Darwin

// Copied from ndi-bench/src/ndi.swift for oats-m0. Changes: NDIlib_send_capture and
// NDIlib_send_free_metadata added; load() throws instead of printing and exiting; layout check.

/// libndi loaded at runtime with dlopen/dlsym (no SDK headers needed; types come from ndi_min.h).
struct NDILib {
    let path: String
    let initialize: fn_initialize
    let destroy: fn_destroy
    let version: fn_version
    let send_create: fn_send_create
    let send_destroy: fn_send_destroy
    let send_send_video_v2: fn_send_video
    let send_send_video_async_v2: fn_send_video
    let send_get_no_connections: fn_send_get_no_connections
    let send_capture: fn_send_capture
    let send_free_metadata: fn_send_free_metadata

    struct LoadError: Error, CustomStringConvertible { let description: String }

    static func load(_ path: String = ProcessInfo.processInfo.environment["NDI_LIB"] ?? "/usr/local/lib/libndi.dylib") throws -> NDILib {
        guard let h = dlopen(path, RTLD_NOW | RTLD_LOCAL) else {
            throw LoadError(description: "dlopen(\(path)) failed: \(String(cString: dlerror()))")
        }
        func s<T>(_ name: String) throws -> T {
            guard let p = dlsym(h, name) else { throw LoadError(description: "dlsym failed: \(name)") }
            return unsafeBitCast(p, to: T.self)
        }
        return NDILib(
            path: path,
            initialize: try s("NDIlib_initialize"), destroy: try s("NDIlib_destroy"), version: try s("NDIlib_version"),
            send_create: try s("NDIlib_send_create"), send_destroy: try s("NDIlib_send_destroy"),
            send_send_video_v2: try s("NDIlib_send_send_video_v2"),
            send_send_video_async_v2: try s("NDIlib_send_send_video_async_v2"),
            send_get_no_connections: try s("NDIlib_send_get_no_connections"),
            send_capture: try s("NDIlib_send_capture"),
            send_free_metadata: try s("NDIlib_send_free_metadata"))
    }

    var versionString: String {
        guard let p = version() else { return "?" }
        return String(cString: p)
    }
}

func fourCC(_ s: String) -> UInt32 {
    let b = Array(s.utf8)
    return UInt32(b[0]) | UInt32(b[1]) << 8 | UInt32(b[2]) << 16 | UInt32(b[3]) << 24
}

func fourCCString(_ v: UInt32) -> String {
    String(decoding: [UInt8(v & 0xff), UInt8((v >> 8) & 0xff), UInt8((v >> 16) & 0xff), UInt8((v >> 24) & 0xff)], as: UTF8.self)
}

/// Checks the hand-declared struct layouts against the NDI 6 ABI. Returns a description and whether it matches.
func ndiLayoutCheck() -> (String, Bool) {
    typealias VF = NDIlib_video_frame_v2_t
    typealias MF = NDIlib_metadata_frame_t
    func o(_ k: PartialKeyPath<VF>) -> Int { MemoryLayout<VF>.offset(of: k) ?? -1 }
    func m(_ k: PartialKeyPath<MF>) -> Int { MemoryLayout<MF>.offset(of: k) ?? -1 }
    let ok = MemoryLayout<VF>.size == 72 && o(\VF.timecode) == 32 && o(\VF.p_data) == 40
        && MemoryLayout<MF>.size == 24 && m(\MF.length) == 0 && m(\MF.timecode) == 8 && m(\MF.p_data) == 16
        && MemoryLayout<NDIlib_send_create_t>.size == 24 && MemoryLayout<OatsParams>.size == 48
    let s = "layout video_frame_v2 size=\(MemoryLayout<VF>.size) timecode@\(o(\VF.timecode)) p_data@\(o(\VF.p_data)) stride@\(o(\VF.line_stride_in_bytes)) | metadata_frame size=\(MemoryLayout<MF>.size) length@\(m(\MF.length)) timecode@\(m(\MF.timecode)) p_data@\(m(\MF.p_data)) | send_create size=\(MemoryLayout<NDIlib_send_create_t>.size) | params size=\(MemoryLayout<OatsParams>.size)"
    return (s, ok)
}

/// Major/minor/patch from a version string such as "NDI SDK APPLE 12:49:17 Apr 13 2026 6.3.2.0".
func ndiVersionNumbers(_ s: String) -> [Int] {
    var best: [Int] = []
    for token in s.split(separator: " ") {
        let parts = token.split(separator: ".").compactMap { Int($0) }
        if parts.count >= 3 && parts.count == token.split(separator: ".").count { best = parts }
    }
    return best
}
