import Foundation
import Metal

// Motion modifiers + effects (2026-10-22). Per clip layer: a TRANSFORM (position, scale, rotation, spin, flip, tile /
// mirror-tile), 2 FX slots (type + amount + speed) and one BEAT MOD (an LFO phase-locked to the tempo clock that
// modulates one target). Plus one MASTER FX slot on the final output, before NDI.
// GPU: everything runs inside the existing composite kernel (uniform branches per layer); the master slot is one
// extra full-frame pass, only while it is active. Blur / EdgeGlow / ZoomBlur / RGBSplit are fixed-tap. Trails keep a
// per-layer half-resolution history (ping-pong pair, rgba16Float), allocated the first time Trails is used.
// StarTrails / WarpTrails / SpiralTrails (long exposure) use the same mechanism at full resolution (crisp 1-2 px stars):
// on STAMP frames the history is resampled (bilinear) rotated and / or zoomed around the layer centre, faded, and max-ed
// with the new frame, which stays full resolution on top; between stamps it is held exactly (Win95 mouse trails /
// Solitaire cards: discrete crisp copies, not a smear; 2026-10-23). Stamps are beat-synced to the tempo clock (1/2, 1/4
// or 1/8 beat from the speed; 8 Hz when no tempo is known). No extra pass: one more sample + write per pixel.
// Order per pixel: screen-space UV FX (slot 1, slot 2) -> inverse transform -> tile -> cover sample (multi-tap FX:
// slot 1 outer, slot 2 inner) -> colour FX / Trails in slot order -> colour link -> blend.

enum FXType: Int, CaseIterable {
    case none = 0, kaleido, mirror, warp, twist, ripple, zoomBlur, hueSpin, posterize, invert, duotone, rgbSplit,
         pixelate, sliceShift, strobe, blur, edgeGlow, trails,
         starTrails, warpTrails, spiralTrails                // 2026-10-23: long-exposure feedback (appended: DMX bands keep their values)
    static let names = ["None", "Kaleido", "Mirror", "Warp", "Twist", "Ripple", "ZoomBlur", "HueSpin", "Posterize", "Invert",
                        "Duotone", "RGBSplit", "Pixelate", "SliceShift", "Strobe", "Blur", "EdgeGlow", "Trails",
                        "StarTrails", "WarpTrails", "SpiralTrails"]
    var name: String { FXType.names[rawValue] }
    /// Trails family: one feedback history per layer (Trails: half resolution; Star/Warp/Spiral: full resolution).
    var isFeedback: Bool { self == .trails || self == .starTrails || self == .warpTrails || self == .spiralTrails }
    /// The Star/Warp/Spiral family: speed 0.5 = still, below / above = counter-clockwise / clockwise (Warp: in / out).
    var isLongExposure: Bool { self == .starTrails || self == .warpTrails || self == .spiralTrails }
    static var maxIndex: Int { allCases.count - 1 }
    /// "kaleido", "Zoom Blur", "rgb-split", "star trails" (case, spaces, - and _ ignored) or i 0..20 (0 = None).
    static func parse(_ a: OSCArg?) -> FXType? {
        guard let a = a else { return nil }
        if case .s(let s) = a {
            let k = s.lowercased().filter { $0.isLetter || $0.isNumber }
            if k == "off" || k.isEmpty { return FXType.none }
            return allCases.first { $0.name.lowercased() == k }
        }
        if let v = a.number, v.isFinite, abs(v) < 1e6 { return FXType(rawValue: Int(v.rounded())) }
        return nil
    }
}

enum ModTarget: Int, CaseIterable {
    case none = 0, rotation, scale, posX, posY, fx1, fx2, opacity
    static let names = ["none", "rotation", "scale", "posx", "posy", "fx1", "fx2", "opacity"]
    var name: String { ModTarget.names[rawValue] }
    static func parse(_ a: OSCArg?) -> ModTarget? {
        guard let a = a else { return nil }
        if case .s(let s) = a {
            var k = s.lowercased().filter { $0.isLetter || $0.isNumber }
            if k == "off" { k = "none" }
            if k == "x" || k == "positionx" { k = "posx" }
            if k == "y" || k == "positiony" { k = "posy" }
            if k.hasPrefix("fx1") { k = "fx1" }
            if k.hasPrefix("fx2") { k = "fx2" }
            if k == "rot" { k = "rotation" }
            return allCases.first { $0.name == k }
        }
        if let v = a.number, v.isFinite, abs(v) < 1e6 { return ModTarget(rawValue: Int(v.rounded())) }
        return nil
    }
}

enum ModShape: Int, CaseIterable {
    case sine = 0, saw, square, random
    static let names = ["sine", "saw", "square", "random"]
    var name: String { ModShape.names[rawValue] }
    static func parse(_ a: OSCArg?) -> ModShape? {
        guard let a = a else { return nil }
        if case .s(let s) = a {
            let k = s.lowercased().filter { $0.isLetter }
            if k == "randomstep" || k == "step" || k == "rnd" { return .random }
            if k == "sin" { return .sine }
            return allCases.first { $0.name == k }
        }
        if let v = a.number, v.isFinite, abs(v) < 1e6 { return ModShape(rawValue: Int(v.rounded())) }
        return nil
    }
}

/// Beat-mod rates (beats per LFO cycle). OSC values snap to the nearest one (log scale); DMX ch 18 bands in this order.
let modBeatValues: [Double] = [0.25, 0.5, 1, 2, 4, 8, 16]
func snapModBeats(_ v: Double) -> Double {
    let x = max(1e-3, v)
    return modBeatValues.min { abs(log2($0) - log2(x)) < abs(log2($1) - log2(x)) }!
}
func modBeatName(_ b: Double) -> String { b == 0.25 ? "1/4" : b == 0.5 ? "1/2" : String(Int(b)) }

/// Clip layers only: how a turned clip still covers the frame (generators turn inside their pattern, fractals in the formula).
enum SpinFill: String, CaseIterable {
    case auto, locked, mirror, off
    static func parse(_ a: OSCArg?) -> SpinFill? {
        guard let a = a else { return nil }
        if case .s(let s) = a { let k = s.lowercased().filter { $0.isLetter }; return k == "none" ? .off : (k == "lock" ? .locked : SpinFill(rawValue: k)) }
        if let v = a.number, v.isFinite, abs(v) < 1e6 { let i = Int(v.rounded()); return (0...3).contains(i) ? allCases[i] : nil }
        return nil
    }
}
/// Layer edge shape (alpha in layer space): rect = the layer frame, oval = the inscribed ellipse, circle = a centred
/// round porthole with the frame's shorter side as diameter.
enum EdgeShape: String, CaseIterable {
    case rect, oval, circle
    static func parse(_ a: OSCArg?) -> EdgeShape? {
        guard let a = a else { return nil }
        if case .s(let s) = a { let k = s.lowercased().filter { $0.isLetter }; return k == "rectangle" || k == "frame" ? .rect : (k == "ellipse" ? .oval : (k == "porthole" || k == "round" ? .circle : EdgeShape(rawValue: k))) }
        if let v = a.number, v.isFinite, abs(v) < 1e6 { let i = Int(v.rounded()); return (0...2).contains(i) ? allCases[i] : nil }
        return nil
    }
    var index: Int { EdgeShape.allCases.firstIndex(of: self)! }
}

/// Spin fill "auto" factor: the scale that makes a turned W x H rectangle cover the W x H frame at angle a (radians).
func spinFillScale(_ a: Double, w: Double, h: Double) -> Double {
    let c = abs(cos(a)), s = abs(sin(a))
    return max((w * c + h * s) / w, (w * s + h * c) / h)
}
/// Spin fill "locked": the worst case over every angle (constant: no pumping while it spins).
func spinFillWorst(w: Double, h: Double) -> Double { max((w * w + h * h).squareRoot() / w, (w * w + h * h).squareRoot() / h) }

struct FXSlot: Equatable {
    var type: FXType = .none
    var amount = 0.5                    // 0..1
    var speed = 0.5                     // 0..1; 0.5 = default rate, 0 = stopped
    var dict: [String: Any] {
        var d: [String: Any] = ["type": type.name, "amount": (amount * 1000).rounded() / 1000, "speed": (speed * 1000).rounded() / 1000]
        if type.isLongExposure {                                 // Star/Warp/Spiral: the stamp clock (fx.swift stampRate)
            let pb = gPlayback.with { ($0.bpm, $0.bpmSource) }
            let r = FXRuntime.stampRate(speed: speed, bpm: pb.0, known: pb.1 != "default")
            d["stamp_hz"] = (r.hz * 100).rounded() / 100; d["stamping"] = r.synced
        }
        return d
    }
}

/// Speed 0..1 -> rate multiplier: 0 stopped, then 1/8x .. 1x (0.5) .. 8x (1).
func fxRate(_ speed: Double) -> Double { speed <= 0 ? 0 : pow(8, 2 * min(1, speed) - 1) }

struct LayerFX: Equatable {
    var x = 0.0, y = 0.0                // -1..1: +1 = the layer's centre on the right / bottom frame edge
    var scale = 1.0                     // 0.1..4 (1 = cover, as before)
    var rotation = 0.0                  // degrees -180..180, + = counter-clockwise
    var spin = 0.0                      // turns/s -2..2 (+ = counter-clockwise), 0 = stop (the angle stays)
    var flipX = false, flipY = false
    var tile = 1                        // 1..8 repeats per axis (tile > 1 = endless wallpaper)
    var mirror = false                  // mirror-tile: every other tile flipped (seamless)
    var spinFill: SpinFill = .auto      // clip layers: cover the frame while turned (auto / locked zoom, mirror edges, off)
    var edgeFeather = 0.0               // 0 = hard .. 1 = a wide fade (half the shorter side), alpha in layer space
    var edgeShape: EdgeShape = .rect
    var fx = [FXSlot(), FXSlot()]
    var modTarget: ModTarget = .none
    var modShape: ModShape = .sine
    var modBeats = 1.0
    var modDepth = 0.5
    var resetSeq = 0                    // +1 per reset / preset: the render thread zeroes the spin angle
    var look = ""                       // the FX look (preset) applied last; "" after a slot type / amount / speed is changed by hand (lit indicator)

    var neutral: Bool {
        x == 0 && y == 0 && scale == 1 && rotation == 0 && spin == 0 && !flipX && !flipY && tile == 1 && !mirror
            && edgeFeather == 0 && edgeShape == .rect && fx.allSatisfy { $0.type == .none } && modTarget == .none
    }
    mutating func reset() { let s = resetSeq; self = LayerFX(); resetSeq = s + 1 }
    func dict(mod: Double, angle: Double) -> (transform: [String: Any], fx: [[String: Any]], mod: [String: Any]) {
        func r3(_ v: Double) -> Double { (v * 1000).rounded() / 1000 }
        return (["x": r3(x), "y": r3(y), "scale": r3(scale), "rotation": r3(rotation), "spin": r3(spin), "flipx": flipX, "flipy": flipY,
                 "tile": tile, "mirror": mirror, "angle_shown": r3(angle), "neutral": neutral, "spinfill": spinFill.rawValue,
                 "edge": ["feather": r3(edgeFeather), "shape": edgeShape.rawValue]],
                fx.map { $0.dict },
                ["target": modTarget.name, "shape": modShape.name, "beats": modBeats, "depth": r3(modDepth), "value": r3(mod)])
    }
}

// MARK: - presets (tools/fx_presets.json)

/// Presets: named LayerFX parameter sets. A preset starts from neutral (like /fx/reset), then sets what it lists.
/// The file is re-read on every /oats/layers/{n}/fx/preset (edit it without a restart); status.json lists the names.
final class FXPresets {
    static let shared = FXPresets()
    private let lock = NSLock()
    private var list: [(name: String, fx: LayerFX)] = []
    private var mlist: [(name: String, slot: FXSlot)] = []   // "master": [{name, type, amount, speed}] (/oats/master/fx/preset)
    private(set) var path = ""
    private var error = ""

    static func defaultPath() -> String {
        if !gPresetsDirOverride.isEmpty { return (gPresetsDirOverride as NSString).appendingPathComponent("fx_presets.json") }
        return URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath().deletingLastPathComponent()
            .deletingLastPathComponent().appendingPathComponent("tools/fx_presets.json").standardizedFileURL.path
    }

    @discardableResult func load(_ p: String = FXPresets.defaultPath()) -> String {
        var out: [(String, LayerFX)] = []
        var mout: [(String, FXSlot)] = []
        var err = ""
        if let d = FileManager.default.contents(atPath: p),
           let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any], let ps = j["presets"] as? [[String: Any]] {
            for e in ps {
                guard let n = e["name"] as? String else { continue }
                out.append((n, FXPresets.parse(e)))
            }
            for e in (j["master"] as? [[String: Any]]) ?? [] {
                guard let n = e["name"] as? String else { continue }
                var m = FXSlot()
                if let ty = e["type"] as? String, let t = FXType.parse(.s(ty)) { m.type = t }
                if let v = (e["amount"] as? NSNumber)?.doubleValue { m.amount = min(1, max(0, v)) }
                if let v = (e["speed"] as? NSNumber)?.doubleValue { m.speed = min(1, max(0, v)) }
                mout.append((n, m))
            }
        } else { err = "no readable \(p)" }
        lock.lock(); list = out; mlist = mout; path = p; error = err; lock.unlock()
        return err.isEmpty ? "\(out.count) presets from \(p)" : err
    }

    static func parse(_ e: [String: Any]) -> LayerFX {
        var f = LayerFX()
        func num(_ d: [String: Any], _ k: String) -> Double? { (d[k] as? NSNumber)?.doubleValue }
        func bool(_ d: [String: Any], _ k: String) -> Bool? { (d[k] as? NSNumber)?.boolValue }
        if let t = e["transform"] as? [String: Any] {
            if let v = num(t, "x") { f.x = min(1, max(-1, v)) }
            if let v = num(t, "y") { f.y = min(1, max(-1, v)) }
            if let v = num(t, "scale") { f.scale = min(4, max(0.1, v)) }
            if let v = num(t, "rotation") { f.rotation = min(180, max(-180, v)) }
            if let v = num(t, "spin") { f.spin = min(2, max(-2, v)) }
            if let v = bool(t, "flipx") { f.flipX = v }
            if let v = bool(t, "flipy") { f.flipY = v }
            if let v = num(t, "tile") { f.tile = min(8, max(1, Int(v.rounded()))) }
            if let v = bool(t, "mirror") { f.mirror = v }
            if let s = t["spinfill"] as? String, let v = SpinFill.parse(.s(s)) { f.spinFill = v }
        }
        if let e = e["edge"] as? [String: Any] {
            if let v = num(e, "feather") { f.edgeFeather = min(1, max(0, v)) }
            if let s = e["shape"] as? String, let v = EdgeShape.parse(.s(s)) { f.edgeShape = v }
        }
        if let fs = e["fx"] as? [[String: Any]] {
            for (i, s) in fs.prefix(2).enumerated() {
                if let ty = s["type"] as? String, let t = FXType.parse(.s(ty)) { f.fx[i].type = t }
                if let v = num(s, "amount") { f.fx[i].amount = min(1, max(0, v)) }
                if let v = num(s, "speed") { f.fx[i].speed = min(1, max(0, v)) }
            }
        }
        if let m = e["mod"] as? [String: Any] {
            if let s = m["target"] as? String, let t = ModTarget.parse(.s(s)) { f.modTarget = t }
            if let s = m["shape"] as? String, let t = ModShape.parse(.s(s)) { f.modShape = t }
            if let v = num(m, "beats") { f.modBeats = snapModBeats(v) }
            if let v = num(m, "depth") { f.modDepth = min(1, max(0, v)) }
        }
        return f
    }

    var names: [String] { lock.lock(); defer { lock.unlock() }; return list.map { $0.name } }
    var masterNames: [String] { lock.lock(); defer { lock.unlock() }; return mlist.map { $0.name } }
    func findMaster(_ name: String) -> (String, FXSlot)? {
        let k = name.lowercased().filter { $0.isLetter || $0.isNumber }
        lock.lock(); defer { lock.unlock() }
        return mlist.first { $0.name.lowercased().filter { $0.isLetter || $0.isNumber } == k }
    }
    var statusError: String { lock.lock(); defer { lock.unlock() }; return error }
    func find(_ name: String) -> (String, LayerFX)? {
        let k = name.lowercased().filter { $0.isLetter || $0.isNumber }
        lock.lock(); defer { lock.unlock() }
        return list.first { $0.name.lowercased().filter { $0.isLetter || $0.isNumber } == k }
    }
}

// MARK: - render-thread runtime

/// Per-frame FX state on the render thread: glides for DMX values, FX phases, spin angles, Trails history.
final class FXRuntime {
    let dev: MTLDevice
    let w: Int, h: Int
    let dummyR: MTLTexture              // 1x1 rgba16Float (history read when Trails is off)
    let dummyW: MTLTexture              // 1x1 rgba16Float, shaderWrite (history write when Trails is off: never written)
    private(set) var canvas2: MTLTexture? = nil          // master FX output (allocated on first use)
    private var phase = [[Double]](repeating: [0, 0], count: compCount)
    private var mPhase = 0.0
    private var spin = [Double](repeating: 0, count: compCount)
    private var seenReset = [Int](repeating: 0, count: compCount)
    private var gX = [Glide](repeating: Glide(), count: compCount), gY = [Glide](repeating: Glide(), count: compCount)
    private var gS = [Glide](repeating: Glide(), count: compCount), gR = [Glide](repeating: Glide(wrap: 360), count: compCount)
    private var gA1 = [Glide](repeating: Glide(), count: compCount), gA2 = [Glide](repeating: Glide(), count: compCount)
    private var gM = Glide()
    private var hist: [[MTLTexture]?] = [[MTLTexture]?](repeating: nil, count: compCount + 1)   // index 4 = BG, 5 = master
    private var histFull = [Bool](repeating: false, count: compCount + 1)                        // allocated at full resolution
    private var lastActive = [Int64](repeating: -10, count: compCount + 1)
    private var lastW = [Int](repeating: 0, count: compCount + 1)        // the history texture written last (read next)
    private var held = [Bool](repeating: false, count: compCount + 1)    // Trails on, layer invisible: history kept as is
    private var stampIdx = [Int64](repeating: .min, count: compCount + 1)   // Star/Warp/Spiral: the stamp slot seen last
    private var stampAcc = [Double](repeating: 0, count: compCount + 1)     // motion seconds since the last stamp
    private var tempo = (beat: 0.0, at: 0.0, rate: 120.0, frozen: false, known: false)   // gPlayback, read once per frame
    private var frame: Int64 = 0
    private(set) var histAllocated = 0
    // shown, for status.json
    private(set) var modShown = [Double](repeating: 0, count: compCount)
    private(set) var angleShown = [Double](repeating: 0, count: compCount)
    private(set) var scaleShown = [Double](repeating: 1, count: compCount)

    init?(dev: MTLDevice, w: Int, h: Int) {
        self.dev = dev; self.w = w; self.h = h
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: 1, height: 1, mipmapped: false)
        d.usage = [.shaderRead, .shaderWrite]
        guard let r = dev.makeTexture(descriptor: d), let wt = dev.makeTexture(descriptor: d) else { return nil }
        dummyR = r; dummyW = wt
    }

    /// Also frees a feedback history no layer (or the master) used for ~5 s (300 frames at 60).
    func beginFrame() {
        frame &+= 1
        tempo = gPlayback.with { ($0.beat, $0.at, $0.rate, $0.frozen, $0.bpmSource != "default") }
        if frame % 30 == 0 {
            for k in 0..<hist.count where hist[k] != nil && frame - lastActive[k] > 300 {
                hist[k] = nil; histAllocated -= 1; held[k] = false
                olog("fx: \(histFull[k] ? "StarTrails" : "Trails") history freed for \(k < compCount ? layerLabel(k) : "master") (unused for 5 s)")
            }
        }
    }

    /// The LFO (0..1, phase-locked to the beat): sine peaks on the beat, saw falls from the beat, square is high in the
    /// first half, random holds one value per cycle.
    static func lfo(_ shape: ModShape, beat: Double, beats: Double) -> Double {
        let p = beat / max(0.0625, beats)
        let f = p - floor(p)
        switch shape {
        case .sine: return 0.5 + 0.5 * cos(2 * .pi * f)
        case .saw: return 1 - f
        case .square: return f < 0.5 ? 1 : 0
        case .random:
            var s = UInt64(bitPattern: Int64(floor(p))) &* 0x9E37_79B9_7F4A_7C15
            s ^= s >> 31; s &*= 0xBF58_476D_1CE4_E5B9; s ^= s >> 29
            return Double(s & 0xFFFF) / 65535
        }
    }

    /// Star/Warp/SpiralTrails stamp subdivision in beats from the speed (one slider does both): still (0.5 +-0.02) and
    /// medium spin = 1/4 beat, gentle (|speed - 0.5| < 0.17) = 1/2 beat, near the ends (> 0.37) = 1/8 beat.
    static func stampBeats(speed: Double) -> Double {
        let m = abs(min(1, max(0, speed)) - 0.5)
        if m < 0.02 { return 0.25 }                              // a still trail is still a trail
        if m < 0.17 { return 0.5 }
        if m < 0.37 { return 0.25 }
        return 0.125
    }

    /// Stamps per second: beat-synced (stampBeats x the tempo clock) while a tempo is known (set / tap / Link / DMX BPM),
    /// else a fixed 8 Hz (= 1/4 beat at 120). synced = beat-synced.
    static func stampRate(speed: Double, bpm: Double, known: Bool) -> (hz: Double, synced: Bool) {
        guard known, bpm > 0 else { return (8, false) }
        return (bpm / 60 / stampBeats(speed: speed), true)
    }

    /// Strobe on the beat (2026-11-02): each flash starts on a beat subdivision picked from the speed: < 0.25 = 1 beat,
    /// < 0.5 = 1/2, < 0.8 = 1/4, else 1/8, on the tempo clock (set / tap / Link / DMX BPM; none known = a 120 BPM clock).
    /// PHOTOSENSITIVITY CAP: the subdivision doubles until the flash rate is at most strobeMaxHz (UK HSE club guidance is
    /// 4 flashes/s or fewer; WCAG 2.3.1 is 3 per second). At 120 BPM that is 1/2 beat at most, at 128+ BPM 1 beat.
    /// The kernel flashes on fract(ph * 6) < 0.5, so the phase handed to it is fract(beat / subdivision) / 6.
    static func strobeBeats(speed: Double) -> Double {
        let v = min(1, max(0, speed))
        return v < 0.25 ? 1 : v < 0.5 ? 0.5 : v < 0.8 ? 0.25 : 0.125
    }
    static let strobeMaxHz = 4.0
    private func strobePhase(speed: Double, beat: Double, t: Double) -> Double? {
        let known = tempo.known && tempo.rate > 0
        let bpm = known ? tempo.rate : 120, b = known ? beat : t * 2       // no tempo: a 120 BPM clock on the frame time
        var div = FXRuntime.strobeBeats(speed: speed)
        while bpm / 60 / div > FXRuntime.strobeMaxHz && div < 64 { div *= 2 }
        let p = b / div
        return (p - floor(p)) / 6
    }

    /// full: Star/Warp/Spiral history at full resolution (Trails: half). Switching between the two reallocates once.
    /// StarTrails / WarpTrails / SpiralTrails slot for the shader: (type, fade, rotation rad, log zoom) for ONE frame.
    /// Stepped stamping (2026-10-23): on a stamp frame the history moves and fades by `dt` = the motion seconds since the
    /// last stamp (the stamp interval); on every other frame (stamp false) it is held exactly (fade 1, rotation 0, zoom
    /// 0), so each copy is a crisp card. Amount = trail length: the copies fall to ~5 % after T = 0.15 s x 67^amount
    /// (0.5 = 1.2 s), in distinct brightness bands (fade^interval per stamp); amount >= 0.97 = hold forever (fade exactly
    /// 1, Solitaire). Speed: 0.5 = still (+-0.01 dead band), 0 / 1 = 90 deg/s counter-clockwise / clockwise in total
    /// (per stamp: rate x interval). Warp: zoom out (above 0.5) or in (below), up to 2.7x per second; Spiral: rotation as
    /// StarTrails plus an outward zoom of up to 1.8x per second.
    static func longExposure(_ t: FXType, amount a: Double, speed: Double, dt: Double, stamp: Bool = true) -> SIMD4<Float> {
        guard stamp else { return SIMD4<Float>(Float(t.rawValue), 1, 0, 0) }
        let len = 0.15 * pow(67, min(1, max(0, a)))
        let fade = a >= 0.97 ? 1.0 : exp(-3 * max(0, dt) / len)
        var b = (min(1, max(0, speed)) - 0.5) * 2
        if abs(b) < 0.02 { b = 0 }
        var rot = 0.0, zoom = 0.0
        switch t {
        case .starTrails: rot = b * (.pi / 2) * dt
        case .warpTrails: zoom = b * 1.0 * dt
        case .spiralTrails: rot = b * (.pi / 2) * dt; zoom = abs(b) * 0.6 * dt
        default: break
        }
        return SIMD4<Float>(Float(t.rawValue), Float(fade), Float(rot), Float(zoom))
    }

    /// The stamp clock of history k this frame: a new 1/stampBeats slot of the tempo beat (beat-synced) or of t x 8 Hz
    /// (no tempo known) = a stamp. Returns the motion seconds accumulated since the last stamp (0 on hold frames) and
    /// resets them on a stamp; frozen frames add 0, so a stamp after a freeze moves nothing. Capped at 1 s after a stall.
    private func stampTick(_ k: Int, speed: Double, beat: Double, t: Double, dt: Double) -> (stamp: Bool, interval: Double) {
        stampAcc[k] = min(1, stampAcc[k] + max(0, dt))
        let idx = Int64(floor(tempo.known ? beat / FXRuntime.stampBeats(speed: speed) : t * 8))
        guard idx != stampIdx[k] else { return (false, 0) }
        stampIdx[k] = idx
        let iv = stampAcc[k]; stampAcc[k] = 0
        return (true, iv)
    }

    /// hold: Trails is on but the layer draws nothing this frame (opacity 0 / empty): no read, no write, the history stays
    /// as it was (frozen) and is valid again when the layer comes back (freed after 5 s like an unused one).
    private func history(_ k: Int, active: Bool, full: Bool = false, hold: Bool = false) -> (r: MTLTexture, w: MTLTexture, valid: Bool) {
        guard active else { held[k] = false; return (dummyR, dummyW, false) }
        if hold { if hist[k] != nil && (held[k] || lastActive[k] == frame - 1) { held[k] = true }; return (dummyR, dummyW, false) }
        if hist[k] != nil && histFull[k] != full { hist[k] = nil; histAllocated -= 1; lastActive[k] = -10; held[k] = false }
        if hist[k] == nil {
            let hw = full ? w : w / 2, hh = full ? h : h / 2
            let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: hw, height: hh, mipmapped: false)
            d.usage = [.shaderRead, .shaderWrite]
            d.storageMode = .private
            if let a = dev.makeTexture(descriptor: d), let b = dev.makeTexture(descriptor: d) {
                hist[k] = [a, b]; histFull[k] = full; histAllocated += 1
                olog("fx: \(full ? "StarTrails" : "Trails") history allocated for \(k < compCount ? layerLabel(k) : "master") (2 x \(hw)x\(hh) rgba16Float, \((2 * hw * hh * 8) >> 20) MB)")
            } else { return (dummyR, dummyW, false) }
        }
        let valid = lastActive[k] == frame - 1 || held[k]
        held[k] = false
        lastActive[k] = frame
        let pair = hist[k]!
        let ri = lastW[k], wi = 1 - ri                   // read what was written last, write the other one
        lastW[k] = wi
        return (pair[ri], pair[wi], valid)
    }

    /// One layer's 5 float4 for the composite kernel + its opacity factor (beat mod) + history textures.
    /// dt = this frame's motion time (0 while frozen) x effect speed. duo = the Duotone colour.
    /// source: clip layers get the spin fill; gen layers get the transform back in `gen` (the generator turns its own
    /// pattern) and an identity transform in the composite; fractal layers turn in the composite as before.
    /// baseOpacity: the layer's opacity before the beat mod and audio (engine bctl); content: it has a picture this frame
    /// (clip texture with alpha, the fractal here, a generator). visible = both after mod + audio, exactly what the composite
    /// kernel skips on: an invisible layer adds no FX variant bits and leaves its Trails history untouched (phases and
    /// glides still advance, so it comes back where it would be).
    func layer(_ i: Int, _ f: LayerFX, dt: Double, beat: Double, t: Double, start: Double, dur: Double, smooth: Bool,
               duo: SIMD3<Float>, aud: LayerAudio = LayerAudio(), source: LayerSource = .clip, baseOpacity: Double = 1, content: Bool = true)
        -> (params: [SIMD4<Float>], opacity: Double, histR: MTLTexture, histW: MTLTexture, plain: Bool, stages: Int, gen: [SIMD4<Float>], visible: Bool) {
        if f.resetSeq != seenReset[i] { seenReset[i] = f.resetSeq; spin[i] = 0; phase[i] = [0, 0] }
        let x = gX[i].step(f.x, t: t, start: start, dur: dur, smooth: smooth)
        let y = gY[i].step(f.y, t: t, start: start, dur: dur, smooth: smooth)
        var sc = gS[i].step(f.scale, t: t, start: start, dur: dur, smooth: smooth)
        let rot = gR[i].step(f.rotation, t: t, start: start, dur: dur, smooth: smooth)
        var a1 = gA1[i].step(f.fx[0].amount, t: t, start: start, dur: dur, smooth: smooth)
        var a2 = gA2[i].step(f.fx[1].amount, t: t, start: start, dur: dur, smooth: smooth)
        spin[i] = (spin[i] + (f.spin + aud.spin) * 360 * dt).truncatingRemainder(dividingBy: 360)
        for k in 0..<2 { phase[i][k] = (phase[i][k] + fxRate(f.fx[k].speed) * dt).truncatingRemainder(dividingBy: 64) }
        if aud.any {                                      // audio react (audio.swift): on top of the glided values
            sc *= max(0.05, 1 + aud.scale); a1 += aud.fx1; a2 += aud.fx2
        }
        var u = 0.0, op = 1.0, mx = x + aud.x, my = y + aud.y, ang = rot + spin[i] + aud.rotation
        let noTurn = source == .fractal                   // the fractal turns inside the formula only (Deep zoom > Movement)
        if noTurn { ang = 0 }
        if f.modTarget != .none {
            u = FXRuntime.lfo(f.modShape, beat: beat, beats: f.modBeats)
            let d = f.modDepth, b = 2 * u - 1
            switch f.modTarget {
            case .rotation: if !noTurn { ang += d * 180 * b }
            case .scale: sc *= 1 + d * u
            case .posX: mx += d * b
            case .posY: my += d * b
            case .fx1: a1 *= 1 - d * (1 - u)
            case .fx2: a2 *= 1 - d * (1 - u)
            case .opacity: op = 1 - d * (1 - u)
            case .none: break
            }
        }
        let rad = ang * .pi / 180
        var flags = (f.flipX ? 1 : 0) | (f.flipY ? 2 : 0) | (f.mirror ? 4 : 0)
        if (source == .clip || source == .ndi) && f.tile == 1 {
            let turned = abs(remainder(ang, 360)) > 1e-6
            switch f.spinFill {
            case .auto: if turned { sc *= spinFillScale(rad, w: Double(w), h: Double(h)) }
            case .locked: if turned || f.spin != 0 || aud.spin != 0 { sc *= spinFillWorst(w: Double(w), h: Double(h)) }
            case .mirror: flags |= 8                     // mirror-repeat addressing outside the clip (no zoom)
            case .off: break
            }
        }
        modShown[i] = u; angleShown[i] = remainder(ang, 360); scaleShown[i] = sc
        var shownOp = baseOpacity * op
        if aud.opacity != 0 { shownOp = min(1, max(0, shownOp + aud.opacity)) }
        let visible = content && min(1, max(0, shownOp)) > 0
        // Star/Warp/Spiral stamp clock: once per layer (the first long-exposure slot runs); hidden = frozen (adds no motion)
        var tick = (stamp: false, interval: 0.0)
        if let q = f.fx.firstIndex(where: { $0.type.isLongExposure }) { tick = stampTick(i, speed: f.fx[q].speed, beat: beat, t: t, dt: visible ? dt : 0) }
        func slot(_ k: Int, _ a: Double) -> SIMD4<Float> {
            let s = f.fx[k]
            if s.type.isLongExposure && a > 0.0005 { return FXRuntime.longExposure(s.type, amount: a, speed: s.speed, dt: tick.interval, stamp: tick.stamp) }
            let ph = s.type == .strobe ? (strobePhase(speed: s.speed, beat: beat, t: t) ?? phase[i][k]) : phase[i][k]   // Strobe: on the beat
            return SIMD4<Float>(Float(s.type == .none || a <= 0.0005 ? 0 : s.type.rawValue), Float(min(1, max(0, a))), Float(ph), Float(fxRate(s.speed)))
        }
        let trails = f.fx.contains { $0.type.isFeedback }
        let hs = history(i, active: trails, full: f.fx.contains { $0.type.isLongExposure }, hold: !visible)
        let edge = SIMD4<Float>(Float(min(1, max(0, f.edgeFeather))), Float(f.edgeShape.index), 0, 0)
        let edgeOn = f.edgeFeather > 0 || f.edgeShape != .rect
        let x0 = SIMD4<Float>(Float(mx), Float(my), Float(cos(rad)), Float(sin(rad)))
        let x1 = SIMD4<Float>(Float(min(source == .clip || source == .ndi ? 12 : 4, max(0.05, sc))), Float(flags), Float(f.tile), edgeOn ? 1 : 0)
        let inGen = source == .gen
        var ps: [SIMD4<Float>] = [
            inGen ? SIMD4<Float>(0, 0, 1, 0) : x0,
            inGen ? SIMD4<Float>(1, 0, 1, 0) : x1,
            slot(0, a1), slot(1, a2),
            SIMD4<Float>(duo.x, duo.y, duo.z, hs.valid ? 1 : 0),
            edge,
        ]
        if inGen { ps[5] = SIMD4<Float>(0, 0, 0, 0) }    // the generator draws its own edge
        // plain: identity transform, no FX: the unchanged `composite` kernel can draw it. stages: function-constant bits
        // 1 UV, 2 multi-tap, 4 colour, 8 Trails (composite_fx variant)
        var st = 0
        for k in 0..<2 {
            let ty = Int(ps[2 + k].x)
            if [1, 2, 3, 4, 5, 12, 13].contains(ty) { st |= 1 } else if [6, 11, 15, 16].contains(ty) { st |= 2 }
            else if [7, 8, 9, 10, 14].contains(ty) { st |= 4 } else if ty >= 17 && ty <= 20 { st |= 8 }
        }
        let plain = st == 0 && (inGen || (mx == 0 && my == 0 && abs(remainder(ang, 360)) < 1e-9 && abs(ps[1].x - 1) < 1e-6 && flags == 0 && f.tile == 1 && !edgeOn))
        return (ps, op, hs.r, hs.w, plain, st, [x0, x1, edgeOn ? edge : SIMD4<Float>(0, 0, 0, 0)], visible)   // gen: the generator's transform; others: the overlay's (follow)
    }

    /// The master slot: nil when off (no extra pass). Returns its 2 float4 + history + output texture.
    func master(_ s: FXSlot, dt: Double, t: Double, start: Double, dur: Double, smooth: Bool, duo: SIMD3<Float>)
        -> (params: [SIMD4<Float>], histR: MTLTexture, histW: MTLTexture, out: MTLTexture)? {
        mPhase = (mPhase + fxRate(s.speed) * dt).truncatingRemainder(dividingBy: 64)
        let a = gM.step(s.amount, t: t, start: start, dur: dur, smooth: smooth)
        guard s.type != .none, a > 0.0005 else { return nil }
        if canvas2 == nil {
            let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: w, height: h, mipmapped: false)
            d.usage = [.shaderRead, .shaderWrite]
            d.storageMode = .private
            canvas2 = dev.makeTexture(descriptor: d)
            olog("fx: master FX output canvas allocated (\(w)x\(h) rgba16Float, 16 MB)")
        }
        guard let out = canvas2 else { return nil }
        let hs = history(compCount, active: s.type.isFeedback, full: s.type.isLongExposure)
        let beat = tempo.beat + (tempo.frozen ? 0 : max(0, min(1, t - tempo.at)) * tempo.rate / 60)   // tempo beat extrapolated to t
        let mph = s.type == .strobe ? (strobePhase(speed: s.speed, beat: beat, t: t) ?? mPhase) : mPhase        // Strobe: on the beat
        var p0 = SIMD4<Float>(Float(s.type.rawValue), Float(min(1, a)), Float(mph), Float(fxRate(s.speed)))
        if s.type.isLongExposure {                        // stamp clock on the tempo beat extrapolated to t (as engine does)
            let tick = stampTick(compCount, speed: s.speed, beat: beat, t: t, dt: dt)
            p0 = FXRuntime.longExposure(s.type, amount: a, speed: s.speed, dt: tick.interval, stamp: tick.stamp)
        }
        return ([p0,
                 SIMD4<Float>(duo.x, duo.y, duo.z, hs.valid ? 1 : 0)], hs.r, hs.w, out)
    }
}

/// Layer accent colours (GUI --l1..--l4): the Duotone colour when the colour link is off.
let layerAccent: [SIMD3<Float>] = [SIMD3(0x22, 0xd3, 0xee), SIMD3(0xf4, 0x72, 0xd0), SIMD3(0xfb, 0xbf, 0x24), SIMD3(0xa3, 0xe6, 0x35), SIMD3(0xa7, 0x8b, 0xfa)].map { $0 / 255 }   // + BG violet
let masterAccent = SIMD3<Float>(0xa7, 0x8b, 0xfa) / 255

// MARK: - MSL (inserted into shaders.swift)

/// Multi-tap stage: fixed-tap ZoomBlur (6), RGBSplit (3), Blur (5), EdgeGlow (5); else one BASE sample.
/// One multi-tap stage per layer (nesting would multiply the cost): if both slots are multi-tap, only slot 1's runs.
private func tapMSL(_ name: String, args: String, fxArgs: String, base: (String) -> String) -> String {
    """
    inline float4 \(name)(\(args), \(fxArgs), float2 f) {
        uint t = uint(fx.x + 0.5); float a = fx.y, ph = fx.z;
        float asp = outSz.x / outSz.y;
        if (t == 6u) {                                         // ZoomBlur: 8 taps toward the centre
            float k = a * 0.22 * (0.8 + 0.2 * sin(6.2831853 * ph));
            float4 acc = float4(0.0);
            for (int j = 0; j < 6; ++j) { float s = 1.0 - k * float(j) / 5.0; acc += \(base("0.5 + (f - 0.5) * s")); }
            return acc / 6.0;
        }
        if (t == 11u) {                                        // RGBSplit: R left, B right (classic chromatic split)
            // amount = the split, up to 3 % of the width; speed = how hard it pumps (the split breathes between 55 % and
            // 100 % at the FX rate, with a touch of vertical wobble). Rate 0 (speed 0) = a steady full split, horizontal:
            // the old version rotated the direction with the phase, so it spun at the default speed and stopped at a
            // random angle (user, 2026-10-24: "not working correctly").
            float pump = fx.w > 0.0 ? 0.55 + 0.45 * (0.5 + 0.5 * sin(6.2831853 * ph)) : 1.0;
            float wob = fx.w > 0.0 ? 0.12 * sin(12.566371 * ph) : 0.0;
            float2 d = a * 0.03 * pump * float2(1.0 / asp, wob);
            float4 r = \(base("f - d")), g = \(base("f")), b = \(base("f + d"));
            return float4(r.r, g.g, b.b, max(max(r.a, g.a), b.a));
        }
        if (t == 15u) {                                        // Blur: centre + 4 diagonal bilinear taps, up to 14 px
            float2 o = (0.75 + a * 13.0) / outSz;
            return (2.0 * \(base("f")) + \(base("f + o")) + \(base("f - o")) + \(base("f + float2(o.x, -o.y)")) + \(base("f + float2(-o.x, o.y)"))) / 6.0;
        }
        if (t == 16u) {                                        // EdgeGlow: Laplacian of luma, glowing in the clip's colours
            float2 o = 1.5 / outSz;
            float4 c0 = \(base("f")), c1 = \(base("f + float2(o.x, 0.0)")), c2 = \(base("f - float2(o.x, 0.0)")),
                   c3 = \(base("f + float2(0.0, o.y)")), c4 = \(base("f - float2(0.0, o.y)"));
            float3 L = float3(0.2126, 0.7152, 0.0722);
            float e = clamp(abs(4.0 * dot(c0.rgb, L) - dot(c1.rgb, L) - dot(c2.rgb, L) - dot(c3.rgb, L) - dot(c4.rgb, L)) * 5.0, 0.0, 1.0);
            float3 st = c0.rgb / max(c0.a, 1e-4);
            float3 glow = (st * 1.4 + 0.25) * e * c0.a;
            return float4(c0.rgb * (1.0 - 0.7 * a) + glow * (0.6 + 1.4 * a) * a, c0.a);
        }
        return \(base("f"));
    }

    """
}

let fxMSL: String = {
    let layerArgs = "texture2d<float, access::sample> ta, texture2d<float, access::sample> tb, float aA, float aB, float4 x0, float4 x1, float4 e, float2 outSz, texture2d<float, access::sample> to, float om"
    let layerPass = "ta, tb, aA, aB, x0, x1, e, outSz, to, om"
    let masterArgs = "texture2d<float, access::sample> ta, float2 outSz"
    let masterPass = "ta, outSz"
    return """
    // ---- FX (src/fx.swift) ----
    inline float hash21(float2 p) { p = fract(p * float2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
    inline bool fxIsUV(uint t) { return (t >= 1u && t <= 5u) || t == 12u || t == 13u; }
    inline bool fxIsColor(uint t) { return (t >= 7u && t <= 10u) || t == 14u; }
    inline bool fxIsTap(uint t) { return t == 6u || t == 11u || t == 15u || t == 16u; }
    inline bool fxIsLongExp(uint t) { return t >= 18u && t <= 20u; }
    // StarTrails / WarpTrails / SpiralTrails: the full-resolution history, rotated (fx.z rad, + = clockwise on screen) and
    // zoomed (fx.w log scale, + = outward) around centre c (frame 0..1), faded by fx.y. Between stamps (fx.swift
    // stampTick) fx = (type, 1, 0, 0): the same-size history sampled at the pixel centre = an exact copy, held crisp.
    // The caller max-es it with the live frame, so new content never dims an old copy. Outside the frame the history is
    // MIRRORED, not zero: with zero (or a fade) the previous frame's 16:9 edge, rotated a few degrees per frame, stays
    // visible as a tilted rectangle inside the picture (the user saw a "16:9 mask rotated 3-6 degrees", 2026-10-23).
    // Mirroring continues the trail past the edge, so there is no boundary to see; the reflection near the edge is
    // faded trail only, never the live frame.
    inline float4 fxLongExp(texture2d<float, access::sample> hist, float4 fx, float2 fs, float2 c, float2 outSz) {
        constexpr sampler hs(coord::normalized, filter::linear, address::mirrored_repeat);
        float asp = outSz.x / outSz.y;
        float2 d = (fs - c) * float2(asp, 1.0);
        float cs = cos(fx.z), sn = sin(fx.z);
        d = float2(cs * d.x + sn * d.y, -sn * d.x + cs * d.y) * exp(-fx.w);
        return hist.sample(hs, c + d / float2(asp, 1.0)) * fx.y;
    }

    // Layer edge (fx.swift LayerFX edge): alpha from u (layer frame 0..1, y down) in layer pixels; e = (feather 0..1,
    // shape 0 rect 1 oval 2 circle). feather 0 = a hard edge (about 1 screen pixel), 1 = fade over half the shorter side.
    inline float edgeAlpha(float2 u, float2 outSz, float sc, float4 e) {
        float ms = min(outSz.x, outSz.y);
        float wd = max(1.0 / max(sc, 0.05), e.x * 0.5 * ms);
        uint sh = uint(e.y + 0.5);
        float d;
        if (sh == 2u) d = 0.5 * ms - length((u - 0.5) * outSz);                   // circle: diameter = shorter side
        else if (sh == 1u) d = (1.0 - length((u - 0.5) * 2.0)) * 0.5 * ms;       // oval: the inscribed ellipse
        else { float2 dd = min(u, 1.0 - u) * outSz; d = min(dd.x, dd.y); }
        float a = clamp(d / wd, 0.0, 1.0);
        return a * a * (3.0 - 2.0 * a);
    }

    // Screen-space UV FX: f = frame coordinates 0..1 (y down). Kaleido, Mirror, Warp, Twist, Ripple, Pixelate, SliceShift.
    inline float2 fxUV(uint t, float a, float ph, float2 f, float2 outSz) {
        float asp = outSz.x / outSz.y;
        float2 c = (f - 0.5) * float2(asp, 1.0);
        if (t == 1u) {                                         // Kaleido: 3..12 mirrored segments, turning slowly
            float n = 3.0 + floor(a * 9.0 + 0.5);
            float seg = 6.2831853 / n;
            float r = length(c);
            float th = atan2(c.y, c.x) + ph * 6.2831853 * 0.125;
            th = th - seg * floor(th / seg);
            th = abs(th - 0.5 * seg);
            c = mix(c, r * float2(cos(th), sin(th)), min(1.0, a * 5.0));
        } else if (t == 2u) {                                  // Mirror: 0-.33 left|right, -.66 top|bottom, else both
            if (a <= 0.34 || a > 0.66) c.x = -abs(c.x);
            if (a > 0.34) c.y = -abs(c.y);
        } else if (t == 3u) {                                  // Warp: two crossing sine waves
            float k = a * 0.07;
            c += k * float2(sin(6.2831853 * (c.y * 2.0 + ph)), sin(6.2831853 * (c.x * 1.5 + ph)));
        } else if (t == 4u) {                                  // Twist: swirl around the centre, breathing
            float r = length(c);
            float wv = max(0.0, 1.0 - r / 0.9);
            float an = a * 5.0 * wv * wv * sin(6.2831853 * ph * 0.5);
            float cs = cos(an), sn = sin(an);
            c = float2(cs * c.x - sn * c.y, sn * c.x + cs * c.y);
        } else if (t == 5u) {                                  // Ripple: rings running outward
            float r = length(c);
            if (r > 1e-4) c += c / r * a * 0.025 * sin(6.2831853 * (r * 10.0 - ph));
        } else if (t == 12u) {                                 // Pixelate: square blocks 1..96 px
            float bs = mix(1.0, 96.0, a * a) / outSz.y;
            c = (floor(c / bs) + 0.5) * bs;
        } else if (t == 13u) {                                 // SliceShift: random rows shift sideways, 4 new patterns/cycle
            float row = floor(f.y * 14.0), st = floor(ph * 4.0);
            if (hash21(float2(row, st)) > 0.45) c.x += (hash21(float2(row + 17.0, st)) - 0.5) * a * 0.5 * asp;
        }
        return c / float2(asp, 1.0) + 0.5;
    }

    // Colour FX on premultiplied (rgb, coverage): HueSpin, Posterize, Invert, Duotone, Strobe.
    inline float4 fxColor(uint t, float a, float ph, float4 s, float3 duo) {
        if (t == 14u) { return s * (fract(ph * 6.0) < 0.5 ? 1.0 : 1.0 - a); }     // Strobe: beat-locked phase from the CPU, capped at 4 flashes/s (fx.swift strobePhase)
        if (s.a <= 1e-5) return s;
        float3 c = clamp(s.rgb / s.a, 0.0, 1.0);
        if (t == 7u) {                                         // HueSpin: offset a/2 turn + spin with the phase
            float3 hv = rgb2hsv(c);
            hv.x = fract(hv.x + fract(ph * 0.25) + a * 0.5);
            c = mix(c, hsv2rgb(hv), min(1.0, a * 4.0));
        } else if (t == 8u) {                                  // Posterize: 12 .. 2 levels
            float lv = mix(12.0, 2.0, a) - 1.0;
            c = mix(c, floor(c * lv + 0.5) / lv, min(1.0, a * 4.0));
        } else if (t == 9u) {
            c = mix(c, 1.0 - c, a);                            // Invert
        } else if (t == 10u) {                                 // Duotone: shadows dark complementary, highlights the colour
            float mx = max(max(duo.r, duo.g), duo.b);
            float3 hi = mx > 0.001 ? duo / mx : float3(1.0);
            float3 hh = rgb2hsv(hi);
            float3 lo = hsv2rgb(float3(fract(hh.x + 0.5), min(1.0, hh.y), 0.16));
            float y = dot(c, float3(0.2126, 0.7152, 0.0722));
            c = mix(c, mix(lo, hi, smoothstep(0.04, 0.92, y)), a);
        }
        return float4(c * s.a, s.a);
    }

    // Layer source: inverse transform (pos, rotation, scale, flip), tile / mirror-tile, cover sample of A and B.
    // x0 = (pos x, pos y, cos, sin), x1 = (scale, flags: 1 flip x, 2 flip y, 4 mirror tile, tiles). Returns (rgb x cov, cov).
    inline float4 L_base(\(layerArgs), float2 fs) {
        float asp = outSz.x / outSz.y;
        float2 c = (fs - 0.5) * float2(asp, 1.0) - x0.xy * float2(asp, 1.0) * 0.5;
        c = float2(x0.z * c.x - x0.w * c.y, x0.w * c.x + x0.z * c.y) / max(x1.x, 0.01);
        uint fl = uint(x1.y + 0.5);
        if ((fl & 1u) != 0u) c.x = -c.x;
        if ((fl & 2u) != 0u) c.y = -c.y;
        float2 u = c / float2(asp, 1.0) + 0.5;
        float cov = 1.0;
        float n = max(1.0, x1.z);
        if (n > 1.5) {
            float2 g = u * n, cell = floor(g);
            u = fract(g);
            if ((fl & 4u) != 0u) u = select(u, 1.0 - u, fmod(cell, 2.0) != 0.0);
        } else if ((fl & 8u) != 0u) {
            if (x1.w > 0.5) cov = edgeAlpha(u, outSz, x1.x, e);       // the edge follows the layer frame
            float2 t2 = fract(u * 0.5) * 2.0;                       // spin fill mirror: mirror-repeat outside the clip
            u = select(t2, 2.0 - t2, t2 > 1.0);
        } else {
            float2 d = min(u, 1.0 - u) * outSz * x1.x;
            cov = clamp(min(d.x, d.y) + 0.5, 0.0, 1.0);
        }
        if (x1.w > 0.5 && (fl & 8u) == 0u) cov *= edgeAlpha(u, outSz, x1.x, e);
        float2 q = u * outSz;
        float4 col = float4(0.0);                              // premultiplied (clips / fractal: alpha 1)
        bool fit = (fl & 16u) != 0u;                           // clip scaling fit (mapping.swift layer_fit)
        if (aA > 0.0) col += coverSample(ta, q, outSz, fit) * aA;
        if (aB > 0.0) col += coverSample(tb, q, outSz, fit) * aB;
        col = clamp(col / max(aA + aB, 1e-4), 0.0, 1.0) * cov;
        if (om > 0.5) {                                        // layer overlay (gen.swift): screen-space texture, sampled at fs
            constexpr sampler os(coord::normalized, filter::linear, address::clamp_to_edge);
            col = ovMix(col, to.sample(os, fs), uint(om - 0.5));
        }
        return col;
    }
    inline float4 M_base(\(masterArgs), float2 f) {
        constexpr sampler s(coord::normalized, filter::linear, address::clamp_to_edge);
        return float4(clamp(ta.sample(s, f).rgb, 0.0, 1.0), 1.0);
    }
    \(tapMSL("L_tap", args: layerArgs, fxArgs: "float4 fx") { "L_base(\(layerPass), \($0))" })
    \(tapMSL("M_tap", args: masterArgs, fxArgs: "float4 fx") { "M_base(\(masterPass), \($0))" })

    // Master FX: canvas -> canvas2 (to_uyvy, analysis read canvas2 while it runs). p[0] = (type, amount, phase, rate),
    // p[1] = (duotone rgb, history valid). Trails history: half resolution, written by the even pixels.
    kernel void master_fx(texture2d<float, access::sample> src [[texture(0)]],
                          texture2d<float, access::write> dst [[texture(1)]],
                          texture2d<float, access::sample> hr [[texture(2)]],
                          texture2d<float, access::write> hw [[texture(3)]],
                          constant float4* p [[buffer(0)]],
                          uint2 gid [[thread_position_in_grid]]) {
        uint w = dst.get_width(), h = dst.get_height();
        if (gid.x >= w || gid.y >= h) return;
        float2 outSz = float2(float(w), float(h));
        float2 fs = (float2(gid) + 0.5) / outSz;
        float4 fx = p[0];
        uint t = uint(fx.x + 0.5);
        float2 fu = fxIsUV(t) ? fxUV(t, fx.y, fx.z, fs, outSz) : fs;
        float4 s = M_tap(src, outSz, fx, fu);
        if (fxIsColor(t)) s = fxColor(t, fx.y, fx.z, s, p[1].xyz);
        if (t == 17u) {
            constexpr sampler sl(coord::normalized, filter::linear, address::clamp_to_edge);
            float4 hh = p[1].w > 0.5 ? hr.sample(sl, fs) : float4(0.0);
            s = max(s, hh * pow(0.985 * pow(fx.y, 0.3), max(fx.w, 0.05)));
            if ((gid.x & 1u) == 0u && (gid.y & 1u) == 0u && gid.x / 2u < hw.get_width() && gid.y / 2u < hw.get_height()) hw.write(s, gid / 2u);
        } else if (fxIsLongExp(t)) {
            if (p[1].w > 0.5) s = max(s, fxLongExp(hr, fx, fs, float2(0.5), outSz));
            if (gid.x < hw.get_width() && gid.y < hw.get_height()) hw.write(s, gid);
        }
        dst.write(float4(clamp(s.rgb, 0.0, 1.0), 1.0), gid);
    }

    """
}()
