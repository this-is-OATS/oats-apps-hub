import Foundation
import Metal
import CoreVideo

// NDI sources as a layer source (2026-11-01): any NDI sender on the LAN (the camera senders "OBS.HOST (OBSBOT Cam)",
// "OBS.HOST (Link Cam)", other Macs, djay ...) on any layer 0-4, through the full layer pipeline.
//
// Receive runs IN THIS PROCESS with the arm64 libndi (dlopen, like the NDI audio receive in audio.swift; the known 6.3.2
// arm64 freeze is on SEND of fine detail, receive has been running natively since the audio react). One supervisor thread
// (finder + receiver bookkeeping, 4x/s) and one capture thread per receiver (at most 4; a source used on two layers shares
// one). A capture thread copies each BGRA frame into an IOSurface-backed CVPixelBuffer from a small pool and makes a Metal
// texture of it through a CVMetalTextureCache; the render thread only takes the newest one under a lock (never waits) and
// the command buffer holds it until the GPU is done (the pool reuses it after that). No frame for 2 s = black + a note.
// Audio is ignored (the audio react has its own receiver).
//
// Discovery: the finder's source list (name, url, age) is in status.json `ndi_sources[]` with stable slot numbers: sorted
// by NDI name (case-insensitive), `ndi_order.json` next to scenes.json can pin names to slots (DMX Layer ch 3 picks slot n
// while ch 14 Source = NDI). The player's own sender ("... (OATS VIZ Program)") is left out, so it never feeds itself.

enum NDIBandwidth: String, CaseIterable {
    case full, proxy
    static func parse(_ a: OSCArg?) -> NDIBandwidth? {
        guard let a = a else { return nil }
        if case .s(let s) = a {
            switch s.lowercased().trimmingCharacters(in: .whitespaces) {
            case "full", "high", "highest": return .full
            case "proxy", "low", "lowest", "preview": return .proxy
            default: return nil
            }
        }
        if let v = a.number, v.isFinite { return v.rounded() == 0 ? .proxy : .full }
        return nil
    }
    var ndiValue: Int32 { self == .full ? 100 : 0 }            // NDIlib_recv_bandwidth_highest / _lowest
}

/// libndi video receive side (dlopen; the send side stays in ndi.swift / the helper, audio receive in audio.swift).
struct NDIInLib {
    let initialize: fn_initialize
    let version: fn_version
    let find_create_v2: fn_find_create_v2
    let find_destroy: fn_find_destroy
    let find_get_current_sources: fn_find_get_current
    let recv_create_v3: fn_recv_create_v3
    let recv_destroy: fn_recv_destroy
    let recv_capture: fn_recv_capture_v2
    let recv_free_video: fn_recv_free_video_v2
    let recv_connections: fn_recv_get_no_connections

    static func load() throws -> NDIInLib {
        let path = ProcessInfo.processInfo.environment["NDI_LIB"] ?? "/usr/local/lib/libndi.dylib"
        guard let h = dlopen(path, RTLD_NOW | RTLD_LOCAL) else { throw NDILib.LoadError(description: "dlopen(\(path)) failed: \(String(cString: dlerror()))") }
        func s<T>(_ n: String) throws -> T {
            guard let p = dlsym(h, n) else { throw NDILib.LoadError(description: "dlsym failed: \(n)") }
            return unsafeBitCast(p, to: T.self)
        }
        return NDIInLib(initialize: try s("NDIlib_initialize"), version: try s("NDIlib_version"),
                        find_create_v2: try s("NDIlib_find_create_v2"), find_destroy: try s("NDIlib_find_destroy"),
                        find_get_current_sources: try s("NDIlib_find_get_current_sources"),
                        recv_create_v3: try s("NDIlib_recv_create_v3"), recv_destroy: try s("NDIlib_recv_destroy"),
                        recv_capture: try s("NDIlib_recv_capture_v2"), recv_free_video: try s("NDIlib_recv_free_video_v2"),
                        recv_connections: try s("NDIlib_recv_get_no_connections"))
    }
}

/// One discovered source (kept 10 s after it disappears, with its age).
struct NDISourceInfo {
    var name: String
    var url: String
    var firstSeen: UInt64
    var lastSeen: UInt64
    var slot = 0                 // 1-based, stable (name-sorted / pinned); 0 = none
    var pinned = false
    /// "OBS.HOST (OBSBOT Cam)" -> "OBSBOT Cam" (the GUI chips); a name without brackets stays as it is.
    static func short(_ n: String) -> String {
        if let o = n.firstIndex(of: "("), let c = n.lastIndex(of: ")"), o < c { return String(n[n.index(after: o)..<c]) }
        return n
    }
}

/// One receiver: a capture thread, the newest frame as a Metal texture, counters.
final class NDIReceiver {
    let name: String, url: String, bw: NDIBandwidth
    let lib: NDIInLib
    let created = nowTicks()
    private let lock = NSLock()
    private var stop = false
    private var cache: CVMetalTextureCache? = nil
    private var pool: CVPixelBufferPool? = nil
    private var poolW = 0, poolH = 0
    private var viewFailed = false
    // newest frame (capture thread writes, render thread takes)
    private var latestCV: CVMetalTexture? = nil
    private var latestTex: MTLTexture? = nil
    private var latestAt: UInt64 = 0
    private var latestTaken = true
    private(set) var frames: Int64 = 0, dropped: Int64 = 0, width = 0, height = 0
    private(set) var lastFrame: UInt64 = 0
    private(set) var fps = 0.0
    private var winFrames = 0, winStart = nowTicks()
    private(set) var connected = false
    private(set) var inCallSince: UInt64 = 0
    private(set) var fourcc = ""
    private(set) var error = ""
    var users: Set<Int> = []            // layer indices showing it (supervisor thread)
    var unusedSince: UInt64 = 0         // 0 = in use
    var shownAgeMs = 0.0                // EMA of (now - capture time) when the render thread took a frame (our added latency)
    var shownAgeMaxMs = 0.0

    init(name: String, url: String, bw: NDIBandwidth, lib: NDIInLib, dev: MTLDevice) {
        self.name = name; self.url = url; self.bw = bw; self.lib = lib
        var c: CVMetalTextureCache? = nil
        if CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, dev, nil, &c) == kCVReturnSuccess { cache = c }
        let t = Thread { [self] in self.run() }
        t.name = "ndi-in"; t.qualityOfService = .userInitiated
        t.start()
    }

    func end() { lock.lock(); stop = true; lock.unlock() }
    private var stopping: Bool { lock.lock(); defer { lock.unlock() }; return stop }

    private func run() {
        let cn = strdup(name), cu = url.isEmpty ? nil : strdup(url), rn = strdup("VJ VIZZIES layer")
        defer { free(cn); if let u = cu { free(u) }; free(rn) }
        let src = NDIlib_source_t(p_ndi_name: UnsafePointer(cn), p_url_address: cu.map { UnsafePointer($0) })
        var rc = NDIlib_recv_create_v3_t(source_to_connect_to: src, color_format: 0,            // BGRX_BGRA: libndi converts
                                         bandwidth: bw.ndiValue, allow_video_fields: false, p_ndi_recv_name: UnsafePointer(rn))
        guard let recv = lib.recv_create_v3(&rc) else {
            lock.lock(); error = "NDIlib_recv_create_v3 failed"; lock.unlock()
            olog("ndi-in: NDIlib_recv_create_v3 failed for '\(name)'"); return
        }
        olog("ndi-in: receiver created on '\(name)' (\(bw.rawValue) bandwidth, BGRA, video only)")
        var vf = NDIlib_video_frame_v2_t()
        var first = true, tick = 0
        while !stopping && !gFlags.stopping {
            lock.lock(); inCallSince = nowTicks(); lock.unlock()
            let ty = lib.recv_capture(recv, &vf, nil, nil, 100)
            lock.lock(); inCallSince = 0; lock.unlock()
            tick += 1
            if tick % 10 == 0 { let n = lib.recv_connections(recv); lock.lock(); connected = n > 0; lock.unlock() }
            if ty == 1 {
                if first { first = false; olog("ndi-in: first frame from '\(name)': \(vf.xres)x\(vf.yres) \(fourCCString(vf.FourCC)) \(vf.frame_rate_N)/\(vf.frame_rate_D) fps, stride \(vf.line_stride_in_bytes)") }
                handle(&vf)
                lib.recv_free_video(recv, &vf)
            } else if ty == 4 {
                olog("ndi-in: capture error on '\(name)'")
                lock.lock(); error = "capture error"; lock.unlock()
                break
            }
            let now = nowTicks(), ws = ticksToSec(now &- winStart)
            if ws >= 1 { lock.lock(); fps = Double(winFrames) / ws; winFrames = 0; winStart = now; lock.unlock() }
        }
        lib.recv_destroy(recv)
        lock.lock(); latestCV = nil; latestTex = nil; lock.unlock()
        olog("ndi-in: receiver on '\(name)' destroyed (\(frames) frames, \(dropped) dropped)")
    }

    private func handle(_ vf: inout NDIlib_video_frame_v2_t) {
        let w = Int(vf.xres), h = Int(vf.yres)
        guard w > 0, h > 0, let data = vf.p_data, let cache = cache else { return }
        let fc = fourCCString(vf.FourCC)
        let opaque = fc != "BGRA"                       // BGRX: the alpha bytes mean nothing -> a view with alpha = 1
        if pool == nil || poolW != w || poolH != h {
            let attrs: [String: Any] = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                                        kCVPixelBufferWidthKey as String: w, kCVPixelBufferHeightKey as String: h,
                                        kCVPixelBufferMetalCompatibilityKey as String: true,
                                        kCVPixelBufferIOSurfacePropertiesKey as String: [String: Any]()]
            var p: CVPixelBufferPool? = nil
            CVPixelBufferPoolCreate(kCFAllocatorDefault, nil, attrs as CFDictionary, &p)
            pool = p; poolW = w; poolH = h
            lock.lock(); width = w; height = h; fourcc = fc; lock.unlock()
        }
        guard let pool = pool else { return }
        let aux = [kCVPixelBufferPoolAllocationThresholdKey as String: 6]
        var pb: CVPixelBuffer? = nil
        guard CVPixelBufferPoolCreatePixelBufferWithAuxAttributes(kCFAllocatorDefault, pool, aux as CFDictionary, &pb) == kCVReturnSuccess, let buf = pb else {
            lock.lock(); dropped += 1; lock.unlock(); return                  // the GPU still holds every buffer: skip this frame
        }
        CVPixelBufferLockBaseAddress(buf, [])
        if let dst = CVPixelBufferGetBaseAddress(buf) {
            let dstStride = CVPixelBufferGetBytesPerRow(buf), srcStride = Int(vf.line_stride_in_bytes), row = w * 4
            if dstStride == srcStride { memcpy(dst, data, srcStride * h) }
            else { for y in 0..<h { memcpy(dst + y * dstStride, data + y * srcStride, min(row, min(dstStride, srcStride))) } }
        }
        CVPixelBufferUnlockBaseAddress(buf, [])
        var cv: CVMetalTexture? = nil
        guard CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, cache, buf, nil, .bgra8Unorm, w, h, 0, &cv) == kCVReturnSuccess,
              let cvt = cv, let mtl = CVMetalTextureGetTexture(cvt) else { lock.lock(); dropped += 1; lock.unlock(); return }
        var tex: MTLTexture = mtl
        if opaque && !viewFailed {
            if let v = mtl.makeTextureView(pixelFormat: .bgra8Unorm, textureType: .type2D, levels: 0..<1, slices: 0..<1,
                                           swizzle: MTLTextureSwizzleChannels(red: .red, green: .green, blue: .blue, alpha: .one)) { tex = v }
            else { viewFailed = true; olog("ndi-in: no swizzle view for '\(name)': alpha fixed on the CPU instead") }
        }
        if opaque && viewFailed, let dst = CVPixelBufferGetBaseAddress(buf) {          // fallback: force alpha = 255
            CVPixelBufferLockBaseAddress(buf, [])
            let stride = CVPixelBufferGetBytesPerRow(buf) / 4
            let p = dst.assumingMemoryBound(to: UInt32.self)
            for y in 0..<h { let r = p + y * stride; for x in 0..<w { r[x] |= 0xFF00_0000 } }
            CVPixelBufferUnlockBaseAddress(buf, [])
        }
        let now = nowTicks()
        lock.lock()
        if !latestTaken { dropped += 1 }                 // the render thread never showed the previous one
        latestCV = cvt; latestTex = tex; latestAt = now; latestTaken = false
        frames += 1; winFrames += 1; lastFrame = now
        lock.unlock()
    }

    /// Render thread: the newest frame (texture + the object the command buffer must hold), or nil.
    func take() -> (tex: MTLTexture, keep: AnyObject)? {
        lock.lock(); defer { lock.unlock() }
        guard let t = latestTex, let cv = latestCV else { return nil }
        if !latestTaken {
            latestTaken = true
            let age = ticksToSec(nowTicks() &- latestAt) * 1000
            shownAgeMs = shownAgeMs == 0 ? age : shownAgeMs + (age - shownAgeMs) * 0.05
            shownAgeMaxMs = max(shownAgeMaxMs, age)
        }
        return (t, cv)
    }

    func info() -> (frames: Int64, dropped: Int64, w: Int, h: Int, fps: Double, last: UInt64, connected: Bool, stuck: Bool, error: String, fourcc: String) {
        lock.lock(); defer { lock.unlock() }
        let stuck = inCallSince != 0 && ticksToSec(nowTicks() &- inCallSince) > 2
        return (frames, dropped, width, height, fps, lastFrame, connected, stuck, error, fourcc)
    }
}

let ndiInMaxReceivers = 4
let ndiInNoSignalSec = 2.0

final class NDIIn {
    private let lock = NSLock()
    private var lib: NDIInLib? = nil
    private var libErr = ""
    private var finder: NDIlib_find_instance_t? = nil
    private var dev: MTLDevice? = nil
    private var ownName = ""
    private var sources: [String: NDISourceInfo] = [:]        // by full NDI name, incl. recently gone ones
    private var slots: [NDISourceInfo] = []                   // slot order (index 0 = slot 1); pinned names reserve slots
    private var wants = [(name: String, bw: NDIBandwidth)?](repeating: nil, count: compCount)   // render thread -> supervisor
    private var receivers: [NDIReceiver] = []
    private var layerRecv = [NDIReceiver?](repeating: nil, count: compCount)
    private var layerNote = [String](repeating: "", count: compCount)
    private var resolved = [String](repeating: "", count: compCount)
    private var started = false
    private var listedAt: UInt64 = 0
    private var orderMtime: TimeInterval = -1
    private var orderPins: [Int: String] = [:]                // slot -> name part (ndi_order.json)
    private var orderError = ""
    private var dumpRequest = false
    private(set) var blackTex: MTLTexture? = nil

    func start(cfg: Config, dev: MTLDevice) {
        lock.lock(); self.dev = dev; ownName = cfg.name; started = true; lock.unlock()
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .bgra8Unorm, width: 2, height: 2, mipmapped: false)
        d.usage = [.shaderRead]
        if let t = dev.makeTexture(descriptor: d) {
            var z = [UInt8](repeating: 0, count: 16)
            for i in stride(from: 3, to: 16, by: 4) { z[i] = 255 }
            t.replace(region: MTLRegionMake2D(0, 0, 2, 2), mipmapLevel: 0, withBytes: &z, bytesPerRow: 8)
            blackTex = t
        }
        let t = Thread { [self] in self.supervise() }
        t.name = "ndi-in-super"; t.qualityOfService = .utility
        t.start()
    }

    // MARK: render thread

    /// Once per frame: which layers want which source (nil = the layer is not on NDI). Cheap: a lock and a compare.
    func setWants(_ w: [(name: String, bw: NDIBandwidth)?]) {
        lock.lock()
        for i in 0..<min(w.count, wants.count) {
            if w[i]?.name != wants[i]?.name || w[i]?.bw != wants[i]?.bw { wants[i] = w[i] }
        }
        lock.unlock()
    }

    /// The texture for layer li this frame: the newest frame, black after 2 s without one, nil while it is still connecting.
    func frame(_ li: Int) -> (tex: MTLTexture?, keep: AnyObject?) {
        lock.lock(); let r = li < layerRecv.count ? layerRecv[li] : nil, wanted = li < wants.count && wants[li] != nil; lock.unlock()
        guard let rc = r else { return (wanted ? blackTex : nil, nil) }
        if let f = rc.take() { return (f.tex, f.keep) }
        let last = rc.lastFrame == 0 ? rc.created : rc.lastFrame
        return (ticksToSec(nowTicks() &- last) > ndiInNoSignalSec ? blackTex : nil, nil)
    }

    // MARK: supervisor thread

    private func supervise() {
        var tick = 0
        while !gFlags.stopping {
            usleep(250_000)
            tick += 1
            let anyWant: Bool = { lock.lock(); defer { lock.unlock() }; return wants.contains { $0 != nil } }()
            // the library and the finder are loaded on first use (a layer on NDI, a list request); the finder stays
            if anyWant || tick % 4 == 0 { ensureLib() }
            if lib != nil, tick % 4 == 0 { refreshSources() }
            if dumpRequest { dumpRequest = false; olog("ndi-in: sources: " + describeSources()) }
            reconcile()
        }
        lock.lock(); let rs = receivers; lock.unlock()
        for r in rs { r.end() }
    }

    private func ensureLib() {
        if lib == nil && libErr.isEmpty {
            do {
                let l = try NDIInLib.load()
                guard l.initialize() else { throw NDILib.LoadError(description: "NDIlib_initialize failed") }
                lib = l
                olog("ndi-in: libndi \(l.version().map { String(cString: $0) } ?? "?") loaded for NDI video receive (arm64, this process; receive only)")
            } catch { libErr = "\(error)"; olog("ndi-in: NDI unavailable: \(libErr)") }
        }
        if let l = lib, finder == nil {
            var fc = NDIlib_find_create_t(show_local_sources: true, p_groups: nil, p_extra_ips: nil)
            finder = l.find_create_v2(&fc)
            if finder == nil { olog("ndi-in: NDIlib_find_create_v2 failed") }
        }
    }

    private func readOrderFile() {
        let path = (m0Dir() as NSString).appendingPathComponent("ndi_order.json")
        let mt = (try? FileManager.default.attributesOfItem(atPath: path))?[.modificationDate] as? Date
        let m = mt?.timeIntervalSince1970 ?? 0
        if m == orderMtime { return }
        orderMtime = m
        var pins: [Int: String] = [:]
        var err = ""
        if mt != nil, let d = FileManager.default.contents(atPath: path) {
            if let j = try? JSONSerialization.jsonObject(with: d) {
                if let arr = j as? [Any] {                                   // ["Link Cam", "OBSBOT Cam"] = slots 1, 2, ...
                    for (i, x) in arr.enumerated() { if let s = x as? String, !s.isEmpty { pins[i + 1] = s } }
                } else if let obj = j as? [String: Any] {                    // {"1": "Link Cam", "3": "OBSBOT"} = pinned slot numbers
                    let src = (obj["slots"] as? [String: Any]) ?? obj
                    for (k, v) in src { if let n = Int(k), n >= 1, n <= 255, let s = v as? String, !s.isEmpty { pins[n] = s } }
                } else { err = "ndi_order.json: want a list of names or {\"slot\": \"name\"}" }
            } else { err = "ndi_order.json: not valid JSON" }
        }
        lock.lock(); orderPins = pins; orderError = err; lock.unlock()
        if mt != nil { olog("ndi-in: ndi_order.json: " + (err.isEmpty ? pins.keys.sorted().map { "slot \($0) = '\(pins[$0]!)'" }.joined(separator: ", ") : err)) }
    }

    private func refreshSources() {
        guard let l = lib, let f = finder else { return }
        readOrderFile()
        var n: UInt32 = 0
        let now = nowTicks()
        var seen: [(String, String)] = []
        if let arr = l.find_get_current_sources(f, &n) {
            for i in 0..<Int(n) {
                let nm = arr[i].p_ndi_name.map { String(cString: $0) } ?? "", u = arr[i].p_url_address.map { String(cString: $0) } ?? ""
                if nm.isEmpty { continue }
                if !ownName.isEmpty && nm.lowercased().hasSuffix("(\(ownName.lowercased()))") { continue }   // never the player's own sender
                seen.append((nm, u))
            }
        }
        lock.lock()
        let before = Set(sources.filter { ticksToSec(now &- $0.value.lastSeen) < 3 }.keys)   // live a moment ago (the list refreshes every 1 s)
        for (nm, u) in seen {
            if var s = sources[nm] { s.lastSeen = now; s.url = u; sources[nm] = s }
            else { sources[nm] = NDISourceInfo(name: nm, url: u, firstSeen: now, lastSeen: now) }
        }
        for (k, s) in sources where ticksToSec(now &- s.lastSeen) > 10 { sources.removeValue(forKey: k) }
        let after = Set(seen.map { $0.0 })
        // slots: pinned names first (slot numbers from ndi_order.json), the rest alphabetical in the free slots
        let list = sources.values.sorted { $0.name.lowercased() < $1.name.lowercased() }
        var bySlot: [Int: NDISourceInfo] = [:]
        var usedNames = Set<String>()
        for (slot, part) in orderPins.sorted(by: { $0.key < $1.key }) {
            let p = part.lowercased()
            if let i = list.firstIndex(where: { !usedNames.contains($0.name) && ($0.name.lowercased() == p || $0.name.lowercased().contains(p)) }) {
                var s = list[i]; s.slot = slot; s.pinned = true; bySlot[slot] = s; usedNames.insert(s.name)
            } else {
                bySlot[slot] = NDISourceInfo(name: part, url: "", firstSeen: 0, lastSeen: 0, slot: slot, pinned: true)   // reserved, not visible
            }
        }
        var next = 1
        for s in list where !usedNames.contains(s.name) {
            while bySlot[next] != nil { next += 1 }
            var x = s; x.slot = next; bySlot[next] = x; next += 1
        }
        slots = bySlot.keys.sorted().map { bySlot[$0]! }
        for i in slots.indices { if let s = sources[slots[i].name] { sources[slots[i].name] = { var t = s; t.slot = slots[i].slot; t.pinned = slots[i].pinned; return t }() } }
        listedAt = now
        lock.unlock()
        let came = after.subtracting(before), went = before.subtracting(after)
        if !came.isEmpty { olog("ndi-in: source(s) appeared: " + came.sorted().joined(separator: ", ")) }
        if !went.isEmpty { olog("ndi-in: source(s) gone: " + went.sorted().joined(separator: ", ")) }
    }

    /// Resolves a wanted name (exact NDI name, else a case-insensitive part such as "OBSBOT") to a visible source.
    private func resolveLocked(_ want: String) -> NDISourceInfo? {
        let w = want.lowercased().trimmingCharacters(in: .whitespaces)
        if w.isEmpty { return nil }
        let live = sources.values.filter { ticksToSec(nowTicks() &- $0.lastSeen) < 3 }
        if let s = live.first(where: { $0.name.lowercased() == w }) { return s }
        let hits = live.filter { $0.name.lowercased().contains(w) }.sorted { $0.name.lowercased() < $1.name.lowercased() }
        if let s = hits.first(where: { NDISourceInfo.short($0.name).lowercased() == w }) { return s }
        return hits.first
    }

    private func reconcile() {
        guard let l = lib, let dev = dev else {
            lock.lock()
            for i in 0..<compCount { layerNote[i] = wants[i] == nil ? "" : (libErr.isEmpty ? "loading NDI" : "NDI unavailable: \(libErr)") }
            lock.unlock(); return
        }
        let now = nowTicks()
        lock.lock()
        var newReceivers: [NDIReceiver] = []
        var newLayer = [NDIReceiver?](repeating: nil, count: compCount)
        for r in receivers { r.users = [] }
        for i in 0..<compCount {
            resolved[i] = ""
            guard let w = wants[i] else { layerNote[i] = ""; continue }
            if w.name.isEmpty { layerNote[i] = "no NDI source set (/oats/layers/\(layerNum(i))/ndi s NAME, or pick one)"; continue }
            guard let s = resolveLocked(w.name) else {
                layerNote[i] = "searching for '\(w.name)' (\(sources.count) source\(sources.count == 1 ? "" : "s") visible)"; continue
            }
            resolved[i] = s.name
            if let r = (receivers + newReceivers).first(where: { $0.name == s.name && $0.bw == w.bw && $0.info().error.isEmpty }) {
                r.users.insert(i); newLayer[i] = r; layerNote[i] = ""
            } else if receivers.count + newReceivers.count < ndiInMaxReceivers {
                let r = NDIReceiver(name: s.name, url: s.url, bw: w.bw, lib: l, dev: dev)
                r.users.insert(i); newReceivers.append(r); newLayer[i] = r; layerNote[i] = ""
                olog("ndi-in: \(layerLabel(i)) -> '\(s.name)' (\(w.bw.rawValue))")
            } else {
                layerNote[i] = "receiver limit (\(ndiInMaxReceivers)): shares none"
            }
        }
        // receivers nobody uses: kept 3 s (a quick switch back costs nothing); a dead or stuck one (a capture call
        // over 2 s, a capture error) is ended and replaced on the next round
        var keep: [NDIReceiver] = []
        for r in receivers {
            let inf = r.info()
            if inf.stuck || !inf.error.isEmpty {
                if !r.users.isEmpty { olog("ndi-in: receiver on '\(r.name)' \(inf.stuck ? "stuck in a capture call > 2 s" : inf.error): dropped, reconnecting") }
                r.end()
                for i in 0..<compCount where newLayer[i] === r { newLayer[i] = nil; layerNote[i] = "reconnecting" }
                continue
            }
            if !r.users.isEmpty { r.unusedSince = 0; keep.append(r); continue }
            if r.unusedSince == 0 { r.unusedSince = now }
            if ticksToSec(now &- r.unusedSince) > 3 { r.end() } else { keep.append(r) }
        }
        receivers = keep + newReceivers
        layerRecv = newLayer
        lock.unlock()
    }

    // MARK: control / status

    /// /oats/ndi/sources: the supervisor logs the list on its next tick (the library loads on its 1 s tick anyway).
    func requestSourceLog() { dumpRequest = true }

    /// Full NDI name for DMX slot n (1-based) in the stable list, "" if none.
    func nameForSlot(_ n: Int) -> String {
        lock.lock(); defer { lock.unlock() }
        return slots.first { $0.slot == n }?.name ?? ""
    }

    func describeSources() -> String {
        lock.lock(); defer { lock.unlock() }
        if sources.isEmpty && slots.isEmpty { return libErr.isEmpty ? "none visible" : "NDI unavailable: \(libErr)" }
        let now = nowTicks()
        return slots.map { s in
            let age = s.lastSeen == 0 ? -1.0 : ticksToSec(now &- s.lastSeen)
            return "slot \(s.slot) = '\(s.name)'" + (s.pinned ? " (pinned)" : "") + (age < 0 ? " (not visible)" : age > 2 ? String(format: " (gone %.0f s)", age) : "") + (s.url.isEmpty ? "" : " \(s.url)")
        }.joined(separator: "; ")
    }

    func sourcesStatus() -> [[String: Any]] {
        lock.lock(); defer { lock.unlock() }
        let now = nowTicks()
        let used = Dictionary(grouping: (0..<compCount).filter { !resolved[$0].isEmpty }, by: { resolved[$0] })
        return slots.map { s in
            let age = s.lastSeen == 0 ? -1.0 : ticksToSec(now &- s.lastSeen)
            return ["slot": s.slot, "name": s.name, "short": NDISourceInfo.short(s.name), "url": s.url,
                    "age_s": age < 0 ? -1 : (age * 10).rounded() / 10, "live": age >= 0 && age < 3, "pinned": s.pinned,
                    "layers": (used[s.name] ?? []).map { layerNum($0) }] as [String: Any]
        }
    }

    func status() -> [String: Any] {
        lock.lock(); defer { lock.unlock() }
        return ["lib": lib != nil ? "loaded" : (libErr.isEmpty ? "not loaded (loads on first use)" : libErr),
                "receivers": receivers.map { r -> [String: Any] in
                    let i = r.info()
                    return ["name": r.name, "bandwidth": r.bw.rawValue, "fps": (i.fps * 10).rounded() / 10, "width": i.w, "height": i.h, "frames": i.frames,
                            "dropped": i.dropped, "connected": i.connected, "layers": r.users.sorted().map { layerNum($0) },
                            "shown_age_ms": (r.shownAgeMs * 10).rounded() / 10, "shown_age_max_ms": (r.shownAgeMaxMs * 10).rounded() / 10, "fourcc": i.fourcc] },
                "max_receivers": ndiInMaxReceivers, "sources_visible": sources.count, "excluded_own": ownName,
                "order_file": (m0Dir() as NSString).appendingPathComponent("ndi_order.json"), "order_pins": orderPins.keys.sorted().map { "\($0)=\(orderPins[$0]!)" },
                "order_error": orderError, "order_rule": "slots = NDI names sorted A-Z (case-insensitive); ndi_order.json pins names to slots"] as [String: Any]
    }

    /// status.json layers[].ndi for layer li.
    func layerStatus(_ li: Int, want: String, bw: NDIBandwidth) -> [String: Any] {
        lock.lock()
        let r = li < layerRecv.count ? layerRecv[li] : nil
        let note = li < layerNote.count ? layerNote[li] : ""
        let res = li < resolved.count ? resolved[li] : ""
        lock.unlock()
        var d: [String: Any] = ["name": want, "source": res, "short": res.isEmpty ? "" : NDISourceInfo.short(res), "bandwidth": bw.rawValue,
                                "connected": false, "fps": 0.0, "width": 0, "height": 0, "age_ms": -1, "dropped": 0, "frames": 0, "note": note]
        guard let rc = r else { return d }
        let i = rc.info()
        let age = i.last == 0 ? -1.0 : ticksToSec(nowTicks() &- i.last) * 1000
        d["connected"] = i.connected || (age >= 0 && age < 1000)
        d["fps"] = (i.fps * 10).rounded() / 10; d["width"] = i.w; d["height"] = i.h
        d["age_ms"] = age < 0 ? -1 : age.rounded(); d["dropped"] = i.dropped; d["frames"] = i.frames
        d["shown_age_ms"] = (rc.shownAgeMs * 10).rounded() / 10
        if note.isEmpty {
            if age < 0 { d["note"] = ticksToSec(nowTicks() &- rc.created) > ndiInNoSignalSec ? "no signal (connecting to '\(NDISourceInfo.short(rc.name))')" : "connecting" }
            else if age > ndiInNoSignalSec * 1000 { d["note"] = String(format: "no signal for %.0f s", age / 1000) }
        }
        return d
    }
}

let gNDIIn = NDIIn()
