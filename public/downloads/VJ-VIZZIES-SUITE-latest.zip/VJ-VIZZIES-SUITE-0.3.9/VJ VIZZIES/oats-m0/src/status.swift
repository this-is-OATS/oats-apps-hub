import Foundation
import Darwin

// Status: one log line every 5 s, and <log-dir>/status.json once per second (written to a temp file,
// then renamed, so readers never see a half-written file).

struct StaticInfo {
    var libndiVersion = ""
    var libndiPath = ""
    var arch = ""
    var rosetta = false
    var ndiConfigDir = ""
    var adaptersAllowed: [String] = []
    var logFile = ""
}

final class StatusReporter {
    let cfg: Config
    let info: StaticInfo
    weak var sacn: SACNReceiver?
    let filter: SourceFilter
    private let lock = NSLock()
    // last completed 5 s window
    private var winFPS = 0.0
    private var winDropped: Int64 = 0
    private var winMaxSend = 0.0
    private var winMaxGap = 0.0
    private var winMaxGpu = 0.0
    private var winLate: Int64 = 0
    private var winHeld: Int64 = 0
    private var winCPU = 0.0
    private var winSecs = 0.0
    private var winEndUnix = 0.0
    private var state = "running"

    init(cfg: Config, info: StaticInfo, sacn: SACNReceiver?, filter: SourceFilter) {
        self.cfg = cfg
        self.info = info
        self.sacn = sacn
        self.filter = filter
    }

    func setState(_ s: String) { lock.lock(); state = s; lock.unlock() }

    func start() {
        let t = Thread { [self] in self.run() }
        t.name = "status"
        t.qualityOfService = .utility
        t.start()
    }

    private func run() {
        var wStart = nowTicks()
        var cpu0 = procCPUSeconds()
        var lastJSON = nowTicks()
        var lastMon = nowTicks()
        while true {
            usleep(50_000)
            if ticksToSec(nowTicks() &- lastMon) >= 0.25 { lastMon = nowTicks(); gNDIOut?.monitor() }   // NDI sender watch (ndiout.swift)
            // ALARM lines queued by the render loop and the watchdog (the watchdog itself never logs on its normal path)
            let alarms: [String] = gStats.with { r in
                if r.pendingAlarms.isEmpty { return [] }
                let a = r.pendingAlarms; r.pendingAlarms.removeAll(keepingCapacity: true); return a
            }
            for a in alarms { olog(a) }
            let now = nowTicks()
            if ticksToSec(now &- wStart) >= 5.0 {
                let wall = ticksToSec(now &- wStart)
                let cpu1 = procCPUSeconds()
                var heldW: Int64 = 0
                let w: (Int64, Int64, Double, Double, Double, Int64) = gStats.with { r in
                    let v = (r.wFrames, r.wDropped, r.wMaxSend, r.wMaxGap, r.wMaxGpu, r.wLate)
                    heldW = r.wHeld
                    r.wFrames = 0; r.wDropped = 0; r.wMaxSend = 0; r.wMaxGap = 0; r.wMaxGpu = 0; r.wLate = 0; r.wHeld = 0
                    return v
                }
                lock.lock()
                winFPS = Double(w.0) / wall; winDropped = w.1; winMaxSend = w.2; winMaxGap = w.3; winMaxGpu = w.4; winLate = w.5; winHeld = heldW
                winCPU = (cpu1 - cpu0) / wall * 100; winSecs = wall; winEndUnix = Date().timeIntervalSince1970
                lock.unlock()
                cpu0 = cpu1; wStart = now
                olog(statusLine())
            }
            if ticksToSec(now &- lastJSON) >= 1.0 {
                lastJSON = now
                writeJSON()
            }
        }
    }

    /// Summary of the owners map: "dmx" (DMX live and nothing taken over OSC), "mixed" (DMX live, some parameters
    /// taken over OSC/GUI), "osc" (no live DMX: every command applies; DMX-set values are held).
    private func ownerSummary(_ c: Control, live: Bool) -> String {
        if !live { return "osc" }
        return Param.allCases.contains { c.owner($0) == .osc } || c.layerOwners.values.contains(.osc) ? "mixed" : "dmx"
    }

    func statusLine() -> String {
        let r = gStats.with { $0 }
        let c = gControl.snapshot
        let d = sacn?.currentSummary()
        lock.lock()
        let (fps, dr, _, mg, cpu) = (winFPS, winDropped, winMaxSend, winMaxGap, winCPU)
        lock.unlock()
        let ms = (gNDIOut?.statusDict()["send_ms_max"] as? Double) ?? 0
        let m = memMB()
        let dmx: String
        if let d = d, d.live {
            dmx = String(format: "'%@' prio=%d %.1f pkt/s", d.winnerName, d.winnerPriority, d.winnerPPS)
        } else { dmx = "none" }
        let osc = c.lastOSCTicks == 0 ? "none" : String(format: "%@ %.1fs ago", c.lastOSCAddress, ticksToSec(nowTicks() &- c.lastOSCTicks))
        let content = r.content.rawValue
        let width = r.content == .noise ? "n/a" : String(format: "%.4g", r.viewWidth)
        let f = r.fractal
        let deep = r.content == .normal ? String(format: " target=%@ depth=%.2f iter=%d res=%dx%d gpu_p95=%.1fms ref=%d%@", f.target, f.depth, f.iterations, f.resW, f.resH, f.gpuP95, f.refLen, f.refReady ? "" : " (orbit pending)") : ""
        let nd = gNDIOut?.statusDict() ?? [:]
        let ndiText = String(format: " ndi=%@%@ ndi_quality=%@ ndi_dropped=%lld late=%lld (budget %.1fms)", nd["mode"] as? String ?? "off",
                             (nd["sending"] as? Bool ?? false) ? "" : "(idle)", nd["quality"] as? String ?? "-", (nd["dropped"] as? Int64) ?? 0, winLate, gFrameBudgetMs)
            + gGPUStages.logText()
        return String(format: "STATUS fps=%.2f dropped=%lld (total %lld) max_send=%.1fms max_gap=%.1fms alarms=%d (send %d, gap %d) gate_fails=%d (send>100ms %d, gap>200ms %d) ndi_conns=%d content=%@ width=%@%@ palette=%d %@ dimmer=%.2f blackout=%@ dmx=%@ osc_last=%@ cpu=%.1f%% rss=%.0fMB%@",
                      fps, dr, r.droppedTotal, ms, mg, r.alarmsSend + r.alarmsGap, r.alarmsSend, r.alarmsGap,
                      r.sendOver100 + r.gapOver200, r.sendOver100, r.gapOver200, gNDI.connections,
                      content, width, deep, c.palette, paletteNames[min(5, max(1, c.palette))], c.dimmer, c.blackout ? "ON" : "off", dmx, osc, cpu, m.rss,
                      r.gpuErrors > 0 ? " gpu_errors=\(r.gpuErrors)" : "")
            + " layers=" + r.layers.map { l in l.slot == 0 && l.decoders == 0 ? "\(l.n):-" : String(format: "%d:%d/%d@%.2f%@%@ dec%.0ffps", l.n, l.bank, l.slot, l.opacity, l.blend.prefix(3) as CVarArg, l.fade >= 0 ? String(format: " fade%.2f", l.fade) : "", l.fpsDecoded) }.joined(separator: ",")
            + String(format: " frac_op=%.2f", r.fractalOpacity) + ndiText
    }

    /// Short status string for the /oats/system/pong reply.
    func pongString() -> String {
        let r = gStats.with { $0 }
        let c = gControl.snapshot
        let d = sacn?.currentSummary()
        lock.lock(); let fps = winFPS; lock.unlock()
        return String(format: "oats-m0 name=%@ pid=%d up=%.0fs fps=%.2f frames=%lld ndi_conns=%d content=%@ palette=%d dimmer=%.2f blackout=%d dmx=%@ arch=%@",
                      cfg.name, getpid(), ticksToSec(nowTicks() &- gStartTicks), fps, r.framesSent, gNDI.connections, r.content.rawValue,
                      c.palette, c.dimmer, c.blackout ? 1 : 0, (d?.live ?? false) ? d!.winnerName : "none", info.arch)
    }

    func dict() -> [String: Any] {
        let r = gStats.with { $0 }
        let c = gControl.snapshot
        let d = sacn?.currentSummary() ?? DMXSummary()
        let snap = gSnapshot.with { $0 }
        lock.lock()
        let (fps, dr, _, mg, mgpu, cpu, ws, st, wend) = (winFPS, winDropped, winMaxSend, winMaxGap, winMaxGpu, winCPU, winSecs, state, winEndUnix)
        let wl = winLate, wh = winHeld
        lock.unlock()
        let nd = gNDIOut?.statusDict() ?? ["mode": "off"]
        let ndSendMax = nd["send_ms_max"] as? Double ?? 0
        let ms = ndSendMax
        let m = memMB()
        func r2(_ v: Double) -> Double { (v * 100).rounded() / 100 }
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        iso.timeZone = TimeZone.current
        var out: [String: Any] = [
            "pid": Int(getpid()),
            "state": st,
            "start_time": iso.string(from: gStartDate),
            "start_unix": gStartDate.timeIntervalSince1970,
            "updated_unix": Date().timeIntervalSince1970,
            "uptime_s": r2(ticksToSec(nowTicks() &- gStartTicks)),
            "libndi_version": nd["libndi_version"] as? String ?? "",
            "libndi_path": "",
            "ndi": nd,
            "budget_ms": gFrameBudgetMs,
            "late_frames_window": wl,
            "late_frames_total": r.lateFrames,
            "held_ticks_window": wh,
            "held_ticks_total": r.heldTicks,
            "arch": info.arch,
            "rosetta": info.rosetta,
            "ndi_name": cfg.name,
            "ndi_groups": cfg.groups.isEmpty ? "(Public: NULL)" : cfg.groups,
            "ndi_config_dir": info.ndiConfigDir,
            "ndi_adapters_allowed": info.adaptersAllowed,
            "ndi_connections": gNDI.connections,
            "ndi_receivers": gNDI.products,
            "resolution": "\(gCanvasW)x\(gCanvasH)",
            "format": "UYVY",
            "frame_rate": "\(cfg.fpsN)/\(cfg.fpsD)",
            "fps": r2(fps),
            "window_s": r2(ws),
            "window_end_unix": wend,
            "frames_sent": r.framesSent,
            "render_running": r.running,
            "dropped_ticks_window": dr,
            "dropped_ticks_total": r.droppedTotal,
            "longest_send_ms_window": r2(ms),
            "longest_send_ms_total": r2(ndSendMax),
            "longest_gap_ms_window": r2(mg),
            "longest_gap_ms_total": r2(r.maxGapAll),
            "gpu_ms_max_window": r2(mgpu),
            "alarms_send": r.alarmsSend,
            "alarms_gap": r.alarmsGap,
            "alarms_total": r.alarmsSend + r.alarmsGap,
            "gate_send_over_100ms": r.sendOver100,
            "gate_gap_over_200ms": r.gapOver200,
            "gpu_errors": r.gpuErrors,
            "ndi_meta_thread": !cfg.noNdiMeta,
            "ndi_mode": nd["mode"] as? String ?? "off",
            "ndi_quality": nd["quality"] as? String ?? "",
            "content": r.content.rawValue,
            "content_set": c.content.short,
            "startup": gStartup.statusDict,
            "view_width": r.viewWidth,
            "log10_width": r.log10Width,
            "zoomspeed": c.zoomSpeed,
            "palette": c.palette,
            "palette_name": paletteNames[min(5, max(1, c.palette))],
            "palette_speed": c.paletteSpeed,
            "palette_offset": c.paletteOffset,
            "dimmer": c.dimmer,
            "effect_speed": c.effectSpeed,
            "blackout": c.blackout,
            "blackout_dmx": r.blackoutDMX,
            "freeze": r.frozen,
            "safe_look": r.safeLook,
            "dimmer_effective": r.dimmerOut,
            "bpm": c.bpm,
            "owner": ownerSummary(c, live: d.live),
            "owners": Dictionary(uniqueKeysWithValues: Param.allCases.map { ($0.rawValue, c.owner($0).rawValue) })
                .merging(c.layerOwners.mapValues { $0.rawValue }) { a, _ in a },
            "cpu_pct_one_core": r2(cpu),
            "rss_mb": r2(m.rss),
            "footprint_mb": r2(m.footprint),
            "debug": cfg.debug,
            "log_file": info.logFile,
            "control_allowed": filter.any ? ["any"] : filter.list,
            "control_allowed_from": filter.any ? "--allow-any" : (filter.fromEn0 ? "en0" : "--allow-net"),
            "listen": gListen.snapshot(),          // bound addresses: osc / sacn / preview (127.0.0.1 + en0, never 0.0.0.0)
        ]
        out["dmx"] = [
            "universe": cfg.universe,
            "multicast_if": cfg.sacnMulticastIf ?? "",
            "live": d.live,
            "name": d.winnerName,
            "cid": d.winnerCID,
            "ip": d.winnerIP,
            "priority": d.winnerPriority,
            "pps": r2(d.winnerPPS),
            "sources": d.sources,
            "packets": d.packets,
            "bad": d.bad,
            "ignored": d.ignored,
            "other_universe": d.otherUniverse,
            "preview": d.preview,
            "seq_dropped": d.seqDropped,
            "rejected": d.rejected,
            "channels": d.channels,
            "map": d.map,
            "master": d.master,
            "fractal": d.fractal,
            "layers": d.layers,
            "color": d.color,
            "layer_fx": d.layerFX,
        ] as [String: Any]
        out["osc"] = [
            "port": cfg.oscPort,
            "count": c.oscCount,
            "malformed": c.oscMalformed,
            "rejected": c.oscRejected,
            "last_address": c.lastOSCAddress,
            "last_age_s": c.lastOSCTicks == 0 ? -1 : r2(ticksToSec(nowTicks() &- c.lastOSCTicks)),
        ] as [String: Any]
        let f = r.fractal
        out["fractal"] = [
            "engine": "perturbation",
            "look": c.frac.preset,                           // the fractal look (preset) that stands; "" after a change by hand (lit indicator; = formula.preset)
            "depth_log10": f.depth,
            "depth_max": zoomDepthMax,
            "view_width": r.viewWidth,
            "target": f.target,
            "target_index": f.targetIndex,
            "target_pending": f.pending,
            "keepdepth": c.keepDepth, "dive_on_select": c.diveOnSelect,
            "center_re": f.centerRe,
            "center_im": f.centerIm,
            "iterations": f.iterations,
            "iterations_base": f.iterBase,
            "iterations_mode": c.iterOverride > 0 ? "override" : "auto",
            "iteration_scale": r2(f.iterScale),
            "ref_orbit_len": f.refLen,
            "ref_ready": f.refReady,
            "ref_escaped": f.refEscaped,
            "ref_ms": r2(f.refMs),
            "ref_orbits_computed": f.refComputed,
            "internal_res": "\(f.resW)x\(f.resH)",
            "internal_res_mode": f.resAuto ? "governor" : "override",
            "gpu_ms_p95": r2(f.gpuP95),
            "governor_changes": f.governorChanges,
            "palette_phase": r.palettePhase,
            "offset_x": f.offsetX,
            "offset_y": f.offsetY,
            "rotation_deg": f.rotation,
            "depth_shown": f.depthShown,
            "spread": c.frac.spread,
            "spread_shown": r2(r.spreadShown),
            "phasers": c.frac.phasers.enumerated().map { (k, p) -> [String: Any] in
                p.dict.merging(["n": k + 1, "value": k < r.phaserShown.count ? r2(r.phaserShown[k]) : 0.0,
                                "paused_by": (k < r.phaserPaused.count ? r.phaserPaused[k] : nil).map { $0 as Any } ?? NSNull()]) { a, _ in a } },
            "phaser_free": c.frac.phaserFree,
            "phaser_preset": c.frac.phaserPreset,
            "phaser_presets": gPhaserPresetNames,
            "phaser_note": r.phaserNote,
            "phaser_targets": PhaserTarget.allCases.map { ["key": $0.rawValue, "label": $0.label] },
            "phaser_shapes": PhaserShape.allCases.map { $0.rawValue },
            "phaser_beats": phaserBeatValues,
            "rotation_set_deg": c.rotation,
            "spin": c.fractalSpin,
            "spin_angle_deg": r2(r.fractalSpinAngle),
            "layer": r.fractalLayerShown,
            "layer_requested": c.fractalLayer,
            "targets": zoomTargets.map { ["name": $0.name, "desc": $0.desc, "minibrot": $0.period > 0] },
            "shape_memory": c.shapeMemoryDict,
            "shape_memory_on": c.shapeMemoryOn,
            "shape_target": zoomTargets[min(zoomTargets.count - 1, max(0, c.shapeTarget))].name,
            "iterations_override": c.iterOverride,
            "formula": [
                "name": c.frac.formula.name, "key": c.frac.formula.key, "drawn": f.formula, "path": f.path,
                "deep_safe": !c.frac.direct, "depth_cap": f.depthCap,
                "fold": c.frac.fold, "fold_mirror": c.frac.foldMirror, "fold_mode": c.frac.foldMode.rawValue, "wild_ss": f.wildSS, "foldc": c.frac.foldC, "foldc_mirror": c.frac.foldCMirror,
                "julia": c.frac.julia, "julia_c": [c.frac.juliaRe, c.frac.juliaIm], "julia_c_shown": [(f.juliaShownRe * 1e4).rounded() / 1e4, (f.juliaShownIm * 1e4).rounded() / 1e4],
                "julia_drift": c.frac.juliaDrift, "julia_beat": c.frac.juliaBeat, "warp": c.frac.warp, "bailout": c.frac.bailout,
                "trap": c.frac.trap.rawValue, "trap_mix": c.frac.trapMix, "trap_size": c.frac.trapSize,
                "preset": c.frac.preset, "presets": gFractalPresetNames,
                "formulas": Formula.names, "traps": TrapShape.allCases.map { $0.rawValue },
                "power": (c.frac.power * 1000).rounded() / 1000, "power_polar": c.frac.polarPower, "power_range": [powerMin, powerMax],
                "shape": c.frac.shapeName, "shapes": shapePresets.map { $0.name },
                "note": c.frac.direct ? String(format: "%@: direct float32 path, depth capped at 1e%.1f",
                    [c.frac.foldZ.n > 0 ? "wild twist" : "", c.frac.julia > 0.0005 ? "Julia morph" : "", abs(c.frac.warp) > 0.0005 ? "warp" : "",
                     c.frac.polarPower ? String(format: "power %.2f", c.frac.power) : ""].filter { !$0.isEmpty }.joined(separator: " / "), directDepthMax) : "",
            ] as [String: Any],
            "loop": [
                "mode": c.frac.loop.rawValue, "running": f.loopKind, "next": c.frac.loopNext.rawValue, "depth": c.frac.loopDepth,
                "fade": c.frac.loopFade, "phase": f.loopPhase, "loops": f.loops, "end_depth": r2(f.loopEnd), "note": f.loopNote,
            ] as [String: Any],
        ] as [String: Any]
        func layerDict(_ li: Int, _ l: LayerInfo) -> [String: Any] {
            let L = c.layers[li]
            let fx = L.fx.dict(mod: li < r.layerMod.count ? r.layerMod[li] : 0, angle: li < r.layerAngle.count ? r.layerAngle[li] : 0)
            var tr = fx.transform
            tr["scale_shown"] = li < r.layerScale.count ? (r.layerScale[li] * 1000).rounded() / 1000 : 1.0
            let n = layerNum(li), isBG = li == bgIndex
            let here = isBG ? r.fractalLayerShown == 0 && r.bgSource == .fractal : r.fractalLayerShown == n
            var note = ""
            if isBG {
                if L.source == .fractal && r.bgSource != .fractal {
                    note = "the fractal is on L\(c.fractalLayer): BG shows its own clip instead (" + (L.slot > 0 ? "\(L.bank).\(L.slot)" : "none = black") + "). Pick Clip or Gen for BG, or send the fractal back to BG"
                } else if L.source != .fractal && c.fractalLayer == 0 { note = "the fractal is not shown anywhere: BG shows its \(L.source.rawValue)" }
                else if here { note = "fractal on BG" }
            } else if L.source == .fractal {
                note = here ? "fractal on this layer" : (c.fractalLayer == n ? "fractal is on the base layer (DEEP/NOISE test content)"
                    : (c.fractalLayer == 0 ? "the fractal is on BG: this layer shows nothing until Fractal is re-selected"
                    : "the fractal is on layer \(c.fractalLayer): this layer shows nothing until Fractal is re-selected"))
            }
            return ["transform": tr, "fx": fx.fx, "mod": fx.mod, "n": n, "bank": L.bank, "slot": L.slot, "name": l.name, "opacity": r2(l.opacity), "blend": l.blend,
             "playing": l.playing, "position": r2(l.position), "duration": r2(l.duration), "fps_decoded": r2(l.fpsDecoded),
             "clip_fps": l.clipFps, "transition": l.transition, "fade": r2(l.fade), "speed": l.speed, "playmode": l.playmode,
             "decoders": l.decoders, "preroll_ms": r2(l.prerollMs), "crossfades_done": l.fadesDone,
             "autopilot": L.autopilot.rawValue, "autopilot_every_s": L.apEvery, "autopilot_beats": L.apBeats,
             "source": L.source.rawValue, "source_shown": isBG ? r.bgSource.rawValue : L.source.rawValue, "gen": L.gen.dict,
             "fx_look": L.fx.look, "gen_look": L.genLook,    // the looks that stand on this layer ("" = none / changed by hand): the GUIs light their buttons
             "overlay": L.overlay.dict.merging(["drawn": r.overlaysDrawn & (1 << li) != 0]) { a, _ in a },
             "fractal_here": here, "fractal_note": note,
             "ndi": gNDIIn.layerStatus(li, want: L.ndiName, bw: L.ndiBandwidth)]   // ndiin.swift: name, source, connected, fps, width, height, age_ms, dropped, note
        }
        out["layers"] = r.layers.enumerated().map { (i, l) in layerDict(i, l) }
        out["bg"] = layerDict(bgIndex, r.bgLayer)            // BG = L0, a full layer (same keys as layers[], n 0)
        let cl = c.color, sm = gColorShown.with { $0 }
        out["color_link"] = ["r": r2(cl.r), "g": r2(cl.g), "b": r2(cl.b), "amount": r2(cl.amount), "mode": cl.mode.rawValue,
                             "target": cl.target.rawValue, "amount_shown": r2(sm.w), "rgb_shown": [r2(sm.x), r2(sm.y), r2(sm.z)],
                             "hex": String(format: "#%02x%02x%02x", Int(cl.r * 255), Int(cl.g * 255), Int(cl.b * 255))] as [String: Any]
        let pb = gPlayback.with { $0 }
        let lkd = pb.link
        out["tempo"] = ["bpm": r2(pb.bpm), "source": pb.bpmSource, "beat": r2(pb.beat), "taps": pb.taps,
                        "phase": r2(pb.beat.truncatingRemainder(dividingBy: 4)), "bar_beat": Int(floor(pb.beat)) % 4 + 1,
                        "setting": pb.setting, "peers": lkd["peers"] ?? 0, "playing": lkd["playing"] ?? false,
                        "link_age_ms": lkd["age_ms"] ?? -1, "link": lkd, "forward": pb.forward] as [String: Any]
        out["autopilot"] = pb.autopilot
        out["audio"] = gAudio.statusDict(routes: c.audioRoutes, preset: c.audioPreset, shown: r.audioShown)
        out["scene"] = gScenes.status()
        out["analysis"] = gAnalysis.statusDict(dest: c.analysisOut)
        out["master_fx"] = c.masterFX.dict.merging(["active": r.masterFXOn]) { a, _ in a }
        out["fx_info"] = ["types": FXType.names, "mod_targets": ModTarget.names, "mod_shapes": ModShape.names,
                          "mod_beats": modBeatValues, "presets": FXPresets.shared.names, "master_presets": FXPresets.shared.masterNames, "presets_error": FXPresets.shared.statusError,
                          "trails_history_allocated": r.fxHist, "kernel": r.fxKernel,
                          "layers_drawn": (0..<compCount).filter { r.layersDrawn & (1 << $0) != 0 }.map { layerNum($0) }] as [String: Any]
        out["fractal_layer"] = ["opacity": r.fractalOpacity, "drawn": r.fractalOpacity > 0 && r.fractalLayerShown == 0 && r.bgSource == .fractal,
                                "fractal_on": r.fractalLayerShown, "bg_source": c.layers[bgIndex].source.rawValue, "bg_shown": r.bgSource.rawValue,
                                "note": r.fractalLayerShown != 0 ? "fractal on layer \(r.fractalLayerShown): BG shows its own clip / gen (black if none)"
                                    : (r.bgSource == .fractal ? "fractal on the base layer 0 (BG)" : "BG shows its \(r.bgSource.rawValue): the fractal is not shown")] as [String: Any]
        out["edge_info"] = ["shapes": EdgeShape.allCases.map { $0.rawValue }, "spinfill": SpinFill.allCases.map { $0.rawValue },
                            "dmx": "OSC / GUI only (Layer FX 24 ch 23-24 are generator speed / thickness)"] as [String: Any]
        out["test_content"] = ["choices": ["normal", "deep", "noise", "test", "ndi"], "set": c.content.short, "shown": r.content.short] as [String: Any]
        out["gen_info"] = ["types": GenType.names, "colormodes": GenColorMode.allCases.map { $0.rawValue }, "sources": LayerSource.allCases.map { $0.rawValue },
                           "textures_allocated": r.genAllocated, "max_elements": 48, "min_line_px": 3,
                           "overlay_blends": OverlayBlend.allCases.map { $0.rawValue },
                           "overlay_dmx": "none (no free channels): OSC / GUI / scenes only"] as [String: Any]
        out["ndi_sources"] = gNDIIn.sourcesStatus()          // ndiin.swift: [{slot, name, short, url, age_s, live, pinned, layers}], slots stable (A-Z / ndi_order.json)
        out["ndi_in"] = gNDIIn.status()
        out["library"] = gLibrary.summary
        out["preview"] = gPreview.statusDict()
        out["render"] = gGPUStages.statusDict(gpuMsLast: r.gpuMs)
        out["output"] = gOutput.statusDict()
        out["record"] = gRecorder.statusDict()          // recorder.swift: on, path, size, frames, dropped, seconds, bytes, free_gb
        out["screens"] = gOutput.screensList()
        out["mapping"] = gMapping.statusDict()          // mapping.swift: canvas, slices per display, cabinet, presets
        out["snapshot"] = [
            "count": snap.count,
            "last_unix": snap.lastUnix,
            "mean_luma": r2(snap.meanLuma),
            "path": snap.path,
            "ms": r2(snap.ms),
        ] as [String: Any]
        return out
    }

    /// JSONSerialization raises (not throws) on NaN/Inf: replace any non-finite number with 0.
    private func sanitize(_ v: Any) -> Any {
        if let d = v as? Double { return d.isFinite ? d : 0.0 }
        if let a = v as? [Any] { return a.map(sanitize) }
        if let m = v as? [String: Any] { return m.mapValues(sanitize) }
        return v
    }

    func writeJSON() {
        let d = sanitize(dict())
        guard let data = try? JSONSerialization.data(withJSONObject: d, options: [.sortedKeys]) else { return }
        let dir = cfg.logDir
        let tmp = (dir as NSString).appendingPathComponent(".status.json.tmp")
        let final = (dir as NSString).appendingPathComponent("status.json")
        if FileManager.default.createFile(atPath: tmp, contents: data) { _ = rename(tmp, final) }
    }
}
