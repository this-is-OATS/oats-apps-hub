import Foundation
import Darwin

// sACN / E1.31 receiver on UDP 5568 (unicast; optional multicast join). Offsets per ANSI E1.31-2018.
// Sources are tracked by CID; highest priority wins, equal priority = most recently started source.
// A source is lost after 2.5 s of silence or on stream-terminated. With no live source: hold the last look.

struct E131Packet {
    let cid: [UInt8]
    let sourceName: String
    let priority: Int
    let syncAddress: Int
    let sequence: UInt8
    let options: UInt8
    let universe: Int
    let startCode: UInt8
    let slots: ArraySlice<UInt8>
}

enum E131Result {
    case data(E131Packet)
    case ignore(String)        // valid-looking but not for us (extended packet, etc.)
    case bad(String)           // malformed
}

private let acnId: [UInt8] = Array("ASC-E1.17".utf8) + [0, 0, 0]

@inline(__always) private func be16(_ b: [UInt8], _ i: Int) -> Int { Int(b[i]) << 8 | Int(b[i + 1]) }
@inline(__always) private func be32(_ b: [UInt8], _ i: Int) -> UInt32 {
    UInt32(b[i]) << 24 | UInt32(b[i + 1]) << 16 | UInt32(b[i + 2]) << 8 | UInt32(b[i + 3])
}

func e131Parse(_ b: [UInt8], _ n: Int) -> E131Result {
    guard n <= b.count else { return .bad("length") }
    guard n >= 16 else { return .bad("short packet (\(n) bytes)") }
    guard be16(b, 0) == 0x0010 else { return .bad("preamble size") }
    guard be16(b, 2) == 0x0000 else { return .bad("post-amble size") }
    guard Array(b[4..<16]) == acnId else { return .bad("ACN packet identifier") }
    guard n >= 22 else { return .bad("short root layer") }
    let rootVector = be32(b, 18)
    if rootVector == 0x0000_0008 { return .ignore("extended packet (sync/discovery)") }
    guard rootVector == 0x0000_0004 else { return .bad(String(format: "root vector 0x%08x", rootVector)) }
    guard n >= 126 else { return .bad("short data packet (\(n) bytes)") }
    let cid = Array(b[22..<38])
    guard be32(b, 40) == 0x0000_0002 else { return .bad(String(format: "framing vector 0x%08x", be32(b, 40))) }
    var z = 44
    while z < 108 && b[z] != 0 { z += 1 }
    let name = String(decoding: b[44..<z], as: UTF8.self)
    let priority = Int(b[108])
    guard priority <= 200 else { return .bad("priority \(priority) > 200") }
    let sync = be16(b, 109)
    let seq = b[111]
    let options = b[112]
    let universe = be16(b, 113)
    guard universe >= 1 && universe <= 63999 else { return .bad("universe \(universe)") }
    guard b[117] == 0x02 else { return .bad(String(format: "DMP vector 0x%02x", b[117])) }
    guard b[118] == 0xa1 else { return .bad(String(format: "address/data type 0x%02x", b[118])) }
    guard be16(b, 119) == 0 else { return .bad("first property address") }
    guard be16(b, 121) == 1 else { return .bad("address increment") }
    let count = be16(b, 123)
    guard count >= 1 && count <= 513 else { return .bad("property count \(count)") }
    guard n >= 125 + count else { return .bad("truncated: count \(count) but \(n) bytes") }
    // Flags (high nibble 0x7) and PDU lengths of the root (16), framing (38) and DMP (115) layers must agree
    // with the property count: lengths run from each length field to the end of the packet (125 + count).
    func pduLen(_ i: Int) -> Int { be16(b, i) & 0x0fff }
    guard b[16] & 0xf0 == 0x70, b[38] & 0xf0 == 0x70, b[115] & 0xf0 == 0x70 else { return .bad("PDU flags") }
    guard pduLen(16) == 109 + count, pduLen(38) == 87 + count, pduLen(115) == 10 + count else {
        return .bad("PDU length vs property count \(count) (root \(pduLen(16)), framing \(pduLen(38)), DMP \(pduLen(115)))")
    }
    let start = b[125]
    return .data(E131Packet(cid: cid, sourceName: name, priority: priority, syncAddress: sync, sequence: seq,
                            options: options, universe: universe, startCode: start, slots: b[126..<(125 + count)]))
}

func cidHex(_ c: [UInt8]) -> String { c.map { String(format: "%02x", $0) }.joined() }

struct DMXSource {
    let cid: [UInt8]
    var name: String
    var ip: String
    var priority: Int
    var lastSeq: UInt8
    var firstTicks: UInt64
    var lastTicks: UInt64
    var packets: Int64 = 0
    var packetsAtLastRate: Int64 = 0
    var pps: Double = 0
    var droppedSeq: Int64 = 0
    var short: String { String(cidHex(cid).prefix(8)) }
}

struct DMXSummary {
    var live = false
    var winnerName = ""
    var winnerCID = ""
    var winnerIP = ""
    var winnerPriority = 0
    var winnerPPS = 0.0
    var sources: [[String: Any]] = []
    var packets: Int64 = 0
    var bad: Int64 = 0
    var ignored: Int64 = 0
    var otherUniverse: Int64 = 0
    var preview: Int64 = 0
    var seqDropped: Int64 = 0
    var rejected: Int64 = 0            // packets from a source that is not on an allowed network
    var channels: [Int] = []
    var map = "v0"
    var master: [String: Any] = [:]    // v0 decoded values (status.json dmx.master / dmx.fractal)
    var fractal: [String: Any] = [:]
    var layers: [[String: Any]] = []    // v0 Layer 16 fixtures (status.json dmx.layers)
    var color: [String: Any] = [:]      // v0 Color 8 fixture (status.json dmx.color)
    var layerFX: [[String: Any]] = []   // v0 Layer FX 24 fixtures (status.json dmx.layer_fx)
}

final class SACNReceiver {
    private var fd: Int32 = -1                              // --sacn-multicast-if only: the 0.0.0.0 socket multicast needs
    private var socks: BoundSockets? = nil                  // otherwise: en0's address only, re-bound when it changes
    let cfg: Config
    let filter: SourceFilter
    private let rejects: RejectLog
    private let lock = NSLock()
    private var sources: [[UInt8]: DMXSource] = [:]
    private var winner: [UInt8]? = nil
    private var everLive = false
    private var summary = DMXSummary()
    private var lastRateTicks = nowTicks()
    private let limiter = LogLimiter(perSecond: 10)
    private let capLimiter = LogLimiter(perSecond: 2)       // own limit, so a malformed-packet flood can't hide it
    // debounce for ch3 (palette) and ch5 (content): act only when 2 consecutive packets agree
    private var deb3 = (raw: -1, count: 0)
    private var deb5 = (raw: -1, count: 0)
    private var lastChannels: [Int] = [0, 0, 0, 0, 0]
    private let v0 = V0Decoder()
    private var ltpM0 = LTPWatch()                          // m0 map: last value seen per channel (LTP)

    init?(cfg: Config, filter: SourceFilter) {
        // grandMA3 onPC on this Mac also holds *:5568, and macOS hands each unicast packet to only one
        // wildcard socket. Binding en0's own address makes ours the more specific match, so unicast always
        // reaches the player. Multicast needs the wildcard bind, so --sacn-multicast-if keeps 0.0.0.0.
        // No 0.0.0.0 fallback: with no en0 address yet the receiver retries en0 every 5 s (logged) and listens nowhere.
        var bound = "0.0.0.0"
        if cfg.sacnMulticastIf == nil {
            let bs = BoundSockets(port: 5568, what: "sACN", key: "sacn", loopback: false, tcp: false, reusePort: true, rcvTimeoutMs: 100)
            _ = bs.open()
            socks = bs
            bound = bs.boundText.isEmpty ? "(nothing yet: waiting for en0)" : bs.boundText.joined(separator: ", ")
        } else {
            fd = udpBind(port: 5568, reusePort: true, rcvTimeoutMs: 100, what: "sACN")
            guard fd >= 0 else { return nil }
            gListen.set("sacn", ["0.0.0.0:5568 (--sacn-multicast-if)"])
        }
        self.cfg = cfg
        self.filter = filter
        self.rejects = RejectLog("sACN", key: "dmx.rejected", filter: filter)
        olog("sACN listening on \(bound) (UDP, SO_REUSEADDR+SO_REUSEPORT), universe \(cfg.universe), start address 1, DMX map " +
             (cfg.dmxMap == .v0 ? "v0 (OATS VIZ Master 16 at 1-16, Fractal 24 at 17-40, Layer 16 x4 at 41/57/73/89; gdtf/OATS@OATS VIZ.gdtf)" : "m0 (old 5-channel M0 map)"))
        if let ifip = cfg.sacnMulticastIf { joinMulticast(ifip) }
    }

    private func joinMulticast(_ ifip: String) {
        let hi = (cfg.universe >> 8) & 0xff, lo = cfg.universe & 0xff
        let group = "239.255.\(hi).\(lo)"
        var mreq = ip_mreq()
        mreq.imr_multiaddr.s_addr = inet_addr(group)
        mreq.imr_interface.s_addr = inet_addr(ifip)
        if mreq.imr_interface.s_addr == INADDR_NONE {
            olog("sACN multicast: bad interface address '\(ifip)', not joining"); return
        }
        let r = setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, socklen_t(MemoryLayout<ip_mreq>.size))
        if r == 0 { olog("sACN multicast: joined \(group) on interface \(ifip)") }
        else { olog("sACN multicast: join \(group) on \(ifip) FAILED: \(String(cString: strerror(errno)))") }
    }

    var isLive: Bool { lock.lock(); defer { lock.unlock() }; return winner != nil }

    func currentSummary() -> DMXSummary { lock.lock(); defer { lock.unlock() }; return summary }

    func start() {
        let t = Thread { [self] in self.run() }
        t.name = "sacn"
        t.qualityOfService = .userInitiated
        t.start()
    }

    private func run() {
        var buf = [UInt8](repeating: 0, count: 2048)
        while true {
            var from = sockaddr_in()
            if let bs = socks {
                let (n, _) = bs.recv(&buf, &from)
                if n >= 0 { handlePacket(buf, n, from: from, now: nowTicks()) }
            } else {
                var flen = socklen_t(MemoryLayout<sockaddr_in>.size)
                let n = buf.withUnsafeMutableBytes { raw in
                    withUnsafeMutablePointer(to: &from) {
                        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { recvfrom(fd, raw.baseAddress, raw.count, 0, $0, &flen) }
                    }
                }
                if n >= 0 { handlePacket(buf, n, from: from, now: nowTicks()) }
                else if !(errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) { usleep(10_000) }
            }
            housekeeping(now: nowTicks())
        }
    }

    private func handlePacket(_ b: [UInt8], _ n: Int, from: sockaddr_in, now: UInt64) {
        if !filter.allows(from.sin_addr) {
            lock.lock(); summary.rejected += 1; lock.unlock()
            rejects.note(from.sin_addr, "first packet from \(sockaddrString(from)), \(n) bytes")
            return
        }
        let ip = sockaddrIP(from)
        switch e131Parse(b, n) {
        case .bad(let why):
            lock.lock(); summary.bad += 1; lock.unlock()
            limiter.log("sACN \(ip) malformed packet (\(n) bytes): \(why)")
        case .ignore(let why):
            lock.lock(); summary.ignored += 1; lock.unlock()
            limiter.log("sACN \(ip) ignored: \(why)")
        case .data(let p):
            lock.lock(); defer { lock.unlock() }
            summary.packets += 1
            if p.universe != cfg.universe { summary.otherUniverse += 1; return }
            if p.options & 0x80 != 0 { summary.preview += 1; return }            // preview data: ignore
            if p.options & 0x40 != 0 {                                             // stream terminated: drop now, whatever the start code
                if let s = sources[p.cid] {
                    sources[p.cid] = nil
                    olog("DMX source DROPPED (stream terminated): '\(s.name)' cid=\(s.short) ip=\(s.ip) prio=\(s.priority)")
                    electWinner(now: now, reason: "terminated")
                }
                return
            }
            if p.startCode != 0x00 { summary.ignored += 1; return }              // only DMX null start code (0xDD etc. ignored)
            if var s = sources[p.cid] {
                let d = Int8(bitPattern: p.sequence &- s.lastSeq)
                if d <= 0 && d > -20 {
                    s.droppedSeq += 1; summary.seqDropped += 1
                    sources[p.cid] = s
                    return
                }
                s.lastSeq = p.sequence
                s.lastTicks = now
                s.packets += 1
                s.ip = ip
                if s.name != p.sourceName { s.name = p.sourceName }
                if s.priority != p.priority {
                    olog("DMX source '\(s.name)' cid=\(s.short) priority \(s.priority) -> \(p.priority)")
                    s.priority = p.priority
                    sources[p.cid] = s
                    electWinner(now: now, reason: "priority change")
                } else {
                    sources[p.cid] = s
                }
            } else {
                guard sources.count < 64 else {                                   // bounded: a flood of random CIDs must not grow the table
                    summary.ignored += 1
                    capLimiter.log("sACN \(ip) ignored new source cid=\(String(cidHex(p.cid).prefix(8))): 64 sources already tracked")
                    return
                }
                let s = DMXSource(cid: p.cid, name: p.sourceName, ip: ip, priority: p.priority, lastSeq: p.sequence,
                                  firstTicks: now, lastTicks: now, packets: 1)
                sources[p.cid] = s
                olog("DMX source ADDED: '\(s.name)' cid=\(s.short) ip=\(ip) prio=\(p.priority) universe=\(p.universe)" +
                     (p.syncAddress != 0 ? " (sync address \(p.syncAddress) ignored)" : ""))
                electWinner(now: now, reason: "new source")
            }
            if let w = winner, w == p.cid {
                if cfg.dmxMap == .m0 { applyM0(p.slots) }
                else {
                    let changes = v0.apply(p.slots, now: now)
                    if !changes.isEmpty { olog("DMX -> " + changes.joined(separator: ", ")) }
                }
            }
        }
    }

    /// Highest priority wins; equal priority: most recently started source wins. Caller holds the lock.
    private func electWinner(now: UInt64, reason: String) {
        let best = sources.values.max { a, b in
            a.priority != b.priority ? a.priority < b.priority : a.firstTicks < b.firstTicks
        }
        let newW = best?.cid
        if newW == winner { return }
        let old = winner.flatMap { sources[$0] }
        winner = newW
        deb3 = (-1, 0); deb5 = (-1, 0)
        if cfg.dmxMap == .v0 { if newW == nil { v0.lost() } else { v0.reset() } }
        if let b = best {
            let ties = sources.values.filter { $0.priority == b.priority && $0.cid != b.cid }
            var line = "DMX winner: '\(b.name)' cid=\(b.short) ip=\(b.ip) prio=\(b.priority) (\(reason))"
            if !ties.isEmpty { line += "; equal priority \(b.priority): most recently started source wins over " + ties.map { "'\($0.name)' cid=\($0.short)" }.joined(separator: ", ") }
            if let o = old { line += "; was '\(o.name)' cid=\(o.short)" }
            olog(line)
            if !everLive { everLive = true }
        } else {
            olog("DMX lost, holding last look (\(reason))")
        }
        refreshSummary()
    }

    /// Applies the M0 channel map (PLAN 13.1 Part C, --dmx-map m0) from start address 1. Caller holds the lock.
    private func applyM0(_ slots: ArraySlice<UInt8>) {
        func ch(_ i: Int) -> Int? { let k = slots.startIndex + i - 1; return k < slots.endIndex ? Int(slots[k]) : nil }
        var newVals = lastChannels
        for i in 1...5 { if let v = ch(i) { newVals[i - 1] = v } }
        lastChannels = newVals
        let dim = ch(1).map { Double($0) / 255.0 }
        let zs: Double? = ch(2).map(dmxZoomSpeed)
        let ps = ch(4).map { Double($0) / 255.0 * 0.5 }
        var pal: Int? = nil, content: Content? = nil
        if let v = ch(3) {
            if v == deb3.raw { deb3.count += 1 } else { deb3 = (v, 1) }
            if deb3.count >= 2 { pal = min(5, v * 5 / 256 + 1) }
        }
        if let v = ch(5) {
            if v == deb5.raw { deb5.count += 1 } else { deb5 = (v, 1) }
            if deb5.count >= 2 { content = v < 85 ? .normal : (v <= 170 ? .deep : .noise) }
        }
        var changes: [String] = []
        gControl.with { c in
            var taken: [String] = []
            if let d = dim, c.ltpDMX(.dimmer, [ltpM0.check("1", ch(1))], taken: &taken) { c.dimmer = d }
            if let z = zs {
                let k = [ltpM0.check("2", ch(2))]
                if c.ltpDMX(.zoomspeed, k, taken: &taken) && c.ltpDMX(.depth, k, taken: &taken) { c.zoomSpeed = z }
            }
            if let s = ps, c.ltpDMX(.palette_speed, [ltpM0.check("4", ch(4))], taken: &taken) { c.paletteSpeed = s }
            if c.ltpDMX(.palette, [ltpM0.check("3", pal == nil ? nil : deb3.raw)], taken: &taken), let p = pal, p != c.palette {
                c.palette = p; changes.append("palette=\(p) \(paletteNames[p])")
            }
            if c.ltpDMX(.content, [ltpM0.check("5", content == nil ? nil : deb5.raw)], taken: &taken), let ct = content, ct != c.content {
                c.content = ct; changes.append("content=\(ct.rawValue)")
            }
            if !taken.isEmpty { changes.append("DMX retakes " + taken.joined(separator: ", ") + " (console moved)") }
        }
        if !changes.isEmpty { olog("DMX -> " + changes.joined(separator: ", ")) }
    }

    private func housekeeping(now: UInt64) {
        lock.lock(); defer { lock.unlock() }
        var lost: [DMXSource] = []
        for (k, s) in sources where ticksToSec(now &- s.lastTicks) > 2.5 { lost.append(s); sources[k] = nil }
        for s in lost { olog("DMX source DROPPED (2.5 s silence): '\(s.name)' cid=\(s.short) ip=\(s.ip) prio=\(s.priority)") }
        if !lost.isEmpty { electWinner(now: now, reason: "timeout") }
        let dt = ticksToSec(now &- lastRateTicks)
        if dt >= 1.0 {
            for (k, var s) in sources {
                s.pps = Double(s.packets - s.packetsAtLastRate) / dt
                s.packetsAtLastRate = s.packets
                sources[k] = s
            }
            lastRateTicks = now
            refreshSummary()
        }
    }

    /// Caller holds the lock.
    private func refreshSummary() {
        summary.live = winner != nil
        if let w = winner, let s = sources[w] {
            summary.winnerName = s.name; summary.winnerCID = s.short; summary.winnerIP = s.ip
            summary.winnerPriority = s.priority; summary.winnerPPS = s.pps
        } else {
            summary.winnerName = ""; summary.winnerCID = ""; summary.winnerIP = ""; summary.winnerPriority = 0; summary.winnerPPS = 0
        }
        summary.sources = sources.values.sorted { $0.firstTicks < $1.firstTicks }.map {
            ["name": $0.name, "cid": $0.short, "ip": $0.ip, "priority": $0.priority,
             "pps": ($0.pps * 10).rounded() / 10, "packets": $0.packets, "seq_dropped": $0.droppedSeq,
             "winner": $0.cid == winner]
        }
        summary.map = cfg.dmxMap.rawValue
        if cfg.dmxMap == .v0 {
            summary.channels = v0.raw
            summary.master = v0.statusMaster()
            summary.fractal = v0.statusFractal()
            summary.layers = v0.statusLayers()
            summary.color = v0.statusColor()
            summary.layerFX = v0.statusLayerFX()
        } else {
            summary.channels = lastChannels
        }
    }
}
