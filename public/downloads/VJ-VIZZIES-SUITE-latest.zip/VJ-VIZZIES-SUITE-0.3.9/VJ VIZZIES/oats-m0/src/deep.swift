import Foundation
import Metal

// Deep zoom for the "normal" content (PLAN 9, tier C): perturbation with rebasing.
//  - Centres are decimal strings, parsed into double-double (hi + lo, about 32 significant digits).
//  - One reference orbit Z_n per centre, computed in double-double on the "ref-orbit" thread, stored as
//    float32 (re, im) in a shared MTLBuffer; extended (not restarted) when the iteration count grows.
//  - The GPU iterates each pixel's difference dz from the reference in float32 (shaders.swift mandel_pert).
//  - A governor lowers the fractal's internal resolution (then its iterations) when GPU time per frame is high.
// Limit of this version: zoom 1e28 (double-double reference precision; float32 deltas reach ~1e-38).

// MARK: - double-double

struct DD: Equatable {
    var hi: Double
    var lo: Double
    init(_ hi: Double, _ lo: Double = 0) { self.hi = hi; self.lo = lo }
    var double: Double { hi + lo }
}

@inline(__always) func twoSum(_ a: Double, _ b: Double) -> (Double, Double) {      // Knuth: s + e == a + b exactly
    let s = a + b
    let bb = s - a
    return (s, (a - (s - bb)) + (b - bb))
}
@inline(__always) func quickTwoSum(_ a: Double, _ b: Double) -> (Double, Double) { // Dekker, needs |a| >= |b|
    let s = a + b
    return (s, b - (s - a))
}
@inline(__always) func twoProd(_ a: Double, _ b: Double) -> (Double, Double) {     // p + e == a * b exactly (fma)
    let p = a * b
    return (p, fma(a, b, -p))
}

extension DD {
    @inline(__always) static func + (a: DD, b: DD) -> DD {
        let (s, e) = twoSum(a.hi, b.hi)
        let (t, f) = twoSum(a.lo, b.lo)
        let (s2, e2) = quickTwoSum(s, e + t)
        let (h, l) = quickTwoSum(s2, e2 + f)
        return DD(h, l)
    }
    @inline(__always) static prefix func - (a: DD) -> DD { DD(-a.hi, -a.lo) }
    @inline(__always) static func - (a: DD, b: DD) -> DD { a + (-b) }
    @inline(__always) static func * (a: DD, b: DD) -> DD {
        let (p, e) = twoProd(a.hi, b.hi)
        let (h, l) = quickTwoSum(p, e + (a.hi * b.lo + a.lo * b.hi))
        return DD(h, l)
    }
    @inline(__always) static func * (a: DD, b: Double) -> DD {
        let (p, e) = twoProd(a.hi, b)
        let (h, l) = quickTwoSum(p, e + a.lo * b)
        return DD(h, l)
    }
    @inline(__always) static func / (a: DD, b: Double) -> DD {
        let q1 = a.hi / b
        let (p, e) = twoProd(q1, b)
        let (s, t) = twoSum(a.hi, -p)
        let r = (s + ((t - e) + a.lo)) / b
        let (h, l) = quickTwoSum(q1, r)
        return DD(h, l)
    }
    @inline(__always) func sqr() -> DD {
        let (p, e) = twoProd(hi, hi)
        let (h, l) = quickTwoSum(p, e + 2 * hi * lo)
        return DD(h, l)
    }
    @inline(__always) func times2() -> DD { DD(hi * 2, lo * 2) }
}

private let exactPow10: [Double] = [1e0, 1e1, 1e2, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13, 1e14, 1e15,
                                    1e16, 1e17, 1e18, 1e19, 1e20, 1e21, 1e22]

/// Parses a decimal string ("-0.7756...", "+1.5e-3", ".25") into a double-double. Uses the first 45 significant
/// digits (three exact 15-digit chunks); the result is good to about 1e-32 relative. nil if it is not a plain
/// decimal number or its magnitude is 1e6 or more.
func parseDD(_ text: String) -> DD? {
    var s = Substring(text.trimmingCharacters(in: .whitespaces))
    var neg = false
    if s.hasPrefix("-") { neg = true; s = s.dropFirst() } else if s.hasPrefix("+") { s = s.dropFirst() }
    var exp10 = 0
    if let ei = s.firstIndex(where: { $0 == "e" || $0 == "E" }) {
        guard let e = Int(s[s.index(after: ei)...]), abs(e) < 1000 else { return nil }
        exp10 = e
        s = s[..<ei]
    }
    var digits: [Int] = []
    var point: Int? = nil
    for ch in s {
        if ch == "." { guard point == nil else { return nil }; point = digits.count }
        else if ch.isASCII, let d = ch.wholeNumberValue { digits.append(d) }
        else { return nil }
    }
    guard !digits.isEmpty, digits.count <= 4000 else { return nil }
    let intDigits = point ?? digits.count
    guard let lead = digits.firstIndex(where: { $0 != 0 }) else { return DD(0) }
    let sig = Array(digits[lead...])
    let e = intDigits - lead + exp10                    // value = 0.sig x 10^e
    guard e <= 6 else { return nil }
    if e < -300 { return DD(0) }
    var v = DD(0)
    for j in 0..<3 {
        let from = j * 15
        if from >= sig.count { break }
        var chunk = 0.0                                 // exact integer < 1e15
        for k in from..<(from + 15) { chunk = chunk * 10 + Double(k < sig.count ? sig[k] : 0) }
        var t = DD(chunk)
        for _ in 0...j { t = t / 1e15 }
        v = v + t
    }
    if e > 0 { v = v * exactPow10[e] }
    var down = -e
    while down > 0 { let k = min(down, 22); v = v / exactPow10[k]; down -= k }
    return neg ? -v : v
}

// MARK: - zoom targets

/// A zoom target: a centre with at least 40 significant digits (computed with tests/refine_targets.py:
/// Newton's method in Python decimal at 70 digits, then checked against a plain-iteration render).
struct ZoomTarget {
    let name: String
    let re: String
    let im: String
    let desc: String
    var period: Int = 0     // > 0: a minibrot nucleus of this period (the Minibrot loop can come round to depth 0 on it)
}

let zoomTargets: [ZoomTarget] = [
    // TARGETS-BEGIN (generated by tests/refine_targets.py --swift)
    ZoomTarget(name: "SEAHORSE", re: "-0.74329189085243020293162432597251075717634855812078",
               im: "0.13124055230879760477084590658147814307711415115858",
               desc: "seahorse valley, Misiurewicz M24,2 next to the M0 centre: seahorse spirals at every depth"),   // M(24,2) |multiplier| 1.1532 arg +0.473, Newton 4 steps
    ZoomTarget(name: "SPIRAL", re: "-0.77568376800905379746948350393474104572824650461580",
               im: "0.13646736829469012473327440961784876519777211159247",
               desc: "seahorse valley, Misiurewicz M24,1: a tight double spiral that turns forever"),   // M(24,1) |multiplier| 1.0387 arg +3.012, Newton 4 steps
    ZoomTarget(name: "JULIA", re: "-0.10109636384562216102578544573862256546380544282625",
               im: "0.95628651080914150077109605772997743580983333651053",
               desc: "1/3 limb branch point, Misiurewicz M4,1: three-armed dendrite that looks like its own Julia set"),   // M(4,1) |multiplier| 1.3283 arg +2.087, Newton 3 steps
    ZoomTarget(name: "VOID", re: "-0.77556125374667219568090245853059091432620263418416",
               im: "0.13742658335490263695409854856859035179050891582161",
               desc: "deep minibrot, period 55, size 1.7e-27, by the seahorse-valley point M21,4: spirals, a cross, a 16-armed star, then a small copy of the set at depth ~27 (black inside)", period: 55),   // nucleus period 55, size 1.714e-27, 1.08 r from the seed, Newton 8 steps
    ZoomTarget(name: "ELEPHANT", re: "0.29207386191445391799971751769220573408040189143315",
               im: "0.015770917211390118082469028230338337682600488632339",
               desc: "elephant valley, Misiurewicz M31,1: rows of elephant trunks curling into one spiral"),   // M(31,1) |multiplier| 1.1537 arg -0.370, Newton 4 steps
    ZoomTarget(name: "STAR", re: "-0.56220262152303721274496959626296192623233605875869",
               im: "0.64281714907277524889962465662783094147299739773593",
               desc: "2/5 limb branch point, Misiurewicz M6,1: five-armed star of stars"),   // M(6,1) |multiplier| 1.1394 arg +2.514, Newton 4 steps
    ZoomTarget(name: "SEAMINI", re: "-0.74329189040803791345847807205338425740799090936882",
               im: "0.13124056046331678583248500323756672970870403803793",
               desc: "seahorse-valley minibrot, period 201, size 4.8e-16, by SEAHORSE's M24,2: seahorse spirals, then a copy of the set at depth ~15 (Minibrot loop target)", period: 201),   // nucleus period 201, size 4.766e-16, 0.69 r from the seed, Newton 12 steps
    ZoomTarget(name: "STARMINI", re: "-0.56220253310766240448319821199962255717229057544249",
               im: "0.64281716591542517100178419987414889726197824708214",
               desc: "minibrot by STAR's M6,1, period 107, size 1.4e-14: five-armed stars, then a copy of the set at depth ~14 (Minibrot loop target)", period: 107),   // nucleus period 107, size 1.429e-14, 0.52 r from the seed, Newton 8 steps
    // TARGETS-END
]

/// What the render loop draws around: a target or a custom centre.
struct CentreSpec: Equatable {
    var key: String        // identity for the reference orbit
    var name: String       // target name, or CUSTOM
    var index: Int         // 1-based target index, 0 = custom
    var reText: String
    var imText: String
    var re: DD
    var im: DD

    static func target(_ i: Int) -> CentreSpec {
        let t = zoomTargets[i]
        return CentreSpec(key: "T:" + t.name, name: t.name, index: i + 1, reText: t.re, imText: t.im,
                          re: parseDD(t.re) ?? DD(0), im: parseDD(t.im) ?? DD(0))
    }
    static func custom(re: String, im: String) -> CentreSpec? {
        guard let r = parseDD(re), let i = parseDD(im), abs(r.hi) <= 4, abs(i.hi) <= 4 else { return nil }
        return CentreSpec(key: "C:" + re + "," + im, name: "CUSTOM", index: 0, reText: re, imText: im, re: r, im: i)
    }
}

/// Finds a target by 1-based index ("3") or name (case-insensitive).
func findTarget(_ s: String) -> Int? {
    if let n = Int(s.trimmingCharacters(in: .whitespaces)) { return (1...zoomTargets.count).contains(n) ? n - 1 : nil }
    return zoomTargets.firstIndex { $0.name.caseInsensitiveCompare(s.trimmingCharacters(in: .whitespaces)) == .orderedSame }
}

// MARK: - zoom limits and iterations

let zoomDepthMax = 28.0                                // log10 zoom; zoom = 3.0 / view width
let maxIterLimit = 60000

/// Max iterations from depth (log10 zoom): 400 + 600 per decade, 500 ... 60000.
func autoIterations(depth: Double) -> Int { Int(min(Double(maxIterLimit), max(500, 400 + 600 * depth)).rounded()) }

// MARK: - formulas (z -> F(z) + c), deep-zoom safe through perturbation (shaders.swift fractal_pert2)

/// The iteration formula. Every one has an exact perturbation form (Burning Ship / Celtic with the |a + d| - |a|
/// sign cases, Tricorn with the conjugate, Multibrot n with the binomial expansion), so all of them keep deep zoom.
enum Formula: Int, CaseIterable {
    case mandelbrot = 0, burningShip, tricorn, power3, power4, power5, celtic
    var name: String { ["Mandelbrot", "Burning Ship", "Tricorn", "Multibrot 3", "Multibrot 4", "Multibrot 5", "Celtic"][rawValue] }
    var key: String { ["mandelbrot", "burningship", "tricorn", "power3", "power4", "power5", "celtic"][rawValue] }
    var power: Int { [2, 2, 2, 3, 4, 5, 2][rawValue] }
    static let names = Formula.allCases.map { $0.name }
    /// "mandelbrot", "burning ship", "burningship", "ship", "tricorn", "power3", "multibrot 3", "mb3", "celtic", or 0..6.
    static func parse(_ s: String) -> Formula? {
        let k = s.lowercased().filter { $0.isLetter || $0.isNumber }
        if let n = Int(k) { return Formula(rawValue: n) }
        switch k {
        case "mandelbrot", "mandel", "m": return .mandelbrot
        case "burningship", "ship", "bs", "burning": return .burningShip
        case "tricorn", "mandelbar", "tri": return .tricorn
        case "power3", "multibrot3", "mb3", "p3", "cubic": return .power3
        case "power4", "multibrot4", "mb4", "p4": return .power4
        case "power5", "multibrot5", "mb5", "p5": return .power5
        case "celtic": return .celtic
        default: return nil
        }
    }
}

@inline(__always) func ddAbs(_ a: DD) -> DD { a.hi < 0 || (a.hi == 0 && a.lo < 0) ? -a : a }

/// F(Z) for one reference step in double-double (without + C).
@inline(__always) func formulaStepDD(_ f: Formula, _ a: DD, _ b: DD) -> (DD, DD) {
    switch f {
    case .mandelbrot:
        return (a.sqr() - b.sqr(), (a * b).times2())
    case .burningShip:
        let x = ddAbs(a), y = ddAbs(b)
        return (x.sqr() - y.sqr(), (x * y).times2())
    case .tricorn:
        return (a.sqr() - b.sqr(), -((a * b).times2()))
    case .celtic:
        return (ddAbs(a.sqr() - b.sqr()), (a * b).times2())
    case .power3, .power4, .power5:
        var x = a, y = b
        for _ in 1..<f.power { (x, y) = (x * a - y * b, x * b + y * a) }
        return (x, y)
    }
}

// MARK: - minibrot loop (engine.swift): the minibrot at a nucleus target, mapped onto the full set

/// A minibrot nucleus c0 of period p looks like the whole set under c = c0 + lambda w (w = the full set's own
/// coordinate). lambda = 1 / (b l^2) (C. Heiland-Allen's size estimate, complex: |lambda| is the size, arg its
/// turn). The Minibrot loop zooms in to view width 3 |lambda| (depth -log10 |lambda|), centred on c0 + lambda c0,
/// turned by -arg lambda: that frame is the depth-0 view of the same target, so it can switch to depth 0 there.
/// colourK: mu_mini ~ p mu_full + K (escape counts near the minibrot), for the palette match (median of 8 samples).
struct MiniInfo {
    let period: Int
    let lamRe: Double, lamIm: Double
    let endDepth: Double            // -log10 |lambda|
    let argDeg: Double              // arg lambda in degrees
    let colourK: Double             // NaN if no sample escaped
    let offRe: Double, offIm: Double   // lambda c0 (complex units): the view-centre shift that matches depth 0
}

/// Smooth escape count as the kernels compute it (bailout 256, i = 0-based loop index): nil if it never escapes.
private func muDouble(_ cr: Double, _ ci: Double, maxIter: Int) -> Double? {
    var x = 0.0, y = 0.0
    for i in 0..<maxIter {
        (x, y) = (x * x - y * y + cr, 2 * x * y + ci)
        let r2 = x * x + y * y
        if r2 > 65536 { return Double(i) + 1 - log2(log(r2.squareRoot())) }
    }
    return nil
}
private func muDD(_ cr: DD, _ ci: DD, maxIter: Int) -> Double? {
    var a = DD(0), b = DD(0)
    for i in 0..<maxIter {
        let a2 = a.sqr(), b2 = b.sqr(), ab = a * b
        a = (a2 - b2) + cr
        b = ab.times2() + ci
        let r2 = a.hi * a.hi + b.hi * b.hi
        if r2 > 65536 { return Double(i) + 1 - log2(log(r2.squareRoot())) }
    }
    return nil
}

func minibrotInfo(_ c: CentreSpec, period p: Int) -> MiniInfo {
    var zr = DD(0), zi = DD(0)
    var lr = 1.0, li = 0.0, br = 1.0, bi = 0.0
    for _ in 1..<max(2, p) {
        let a2 = zr.sqr(), b2 = zi.sqr(), ab = zr * zi
        zr = (a2 - b2) + c.re
        zi = ab.times2() + c.im
        let x = 2 * zr.double, y = 2 * zi.double
        (lr, li) = (x * lr - y * li, x * li + y * lr)
        let d = lr * lr + li * li
        br += lr / d; bi -= li / d
    }
    let l2r = lr * lr - li * li, l2i = 2 * lr * li
    let dr = br * l2r - bi * l2i, di = br * l2i + bi * l2r
    let dd = dr * dr + di * di
    let lam = (dr / dd, -di / dd)
    let mag = (lam.0 * lam.0 + lam.1 * lam.1).squareRoot()
    var ks: [Double] = []
    for j in 0..<8 {
        let a = 0.3 + Double(j) * .pi / 4
        let w = (1.8 * cos(a), 1.8 * sin(a))
        guard let mf = muDouble(w.0, w.1, maxIter: 2000) else { continue }
        let o = (lam.0 * w.0 - lam.1 * w.1, lam.0 * w.1 + lam.1 * w.0)
        guard let mm = muDD(c.re + DD(o.0), c.im + DD(o.1), maxIter: maxIterLimit) else { continue }
        ks.append(mm - Double(p) * mf)
    }
    ks.sort()
    let c0 = (c.re.double, c.im.double)
    return MiniInfo(period: p, lamRe: lam.0, lamIm: lam.1, endDepth: -log10(mag), argDeg: atan2(lam.1, lam.0) * 180 / .pi,
                    colourK: ks.isEmpty ? .nan : ks[ks.count / 2],
                    offRe: lam.0 * c0.0 - lam.1 * c0.1, offIm: lam.0 * c0.1 + lam.1 * c0.0)
}

/// Computes MiniInfo off the render thread (a few ms of double-double per target), once per centre key.
final class MiniCache {
    private let lock = NSLock()
    private var done: [String: MiniInfo] = [:]
    private var busy: Set<String> = []
    func get(_ c: CentreSpec, period: Int) -> MiniInfo? {
        lock.lock(); defer { lock.unlock() }
        if let m = done[c.key] { return m }
        if !busy.contains(c.key) {
            busy.insert(c.key)
            DispatchQueue.global(qos: .utility).async { [self] in
                let t0 = nowTicks()
                let m = minibrotInfo(c, period: period)
                lock.lock(); done[c.key] = m; busy.remove(c.key); lock.unlock()
                olog(String(format: "minibrot loop: %@ period %d, lambda %.4e at %.2f deg, end depth %.3f, colour K %.1f (%.0f ms)",
                            c.name, period, (m.lamRe * m.lamRe + m.lamIm * m.lamIm).squareRoot(), m.argDeg, m.endDepth, m.colourK,
                            ticksToSec(nowTicks() &- t0) * 1000))
            }
        }
        return nil
    }
}

// MARK: - reference orbit (double-double on the CPU, float32 for the GPU)

/// One reference orbit as the render thread sees it.
struct OrbitSlot {
    let buf: MTLBuffer
    let id: Int
    let centre: CentreSpec
    let formula: Formula    // the reference orbit iterates this formula (the kernel must use the same one)
    var len: Int            // entries Z_0 ... Z_{len-1} are valid
    var escaped: Bool       // the reference escaped at Z_{len-1}: the orbit will not grow
    var ms: Double          // CPU time spent on it so far
}

/// The "ref-orbit" thread. The render thread calls use() once per frame: it says which centre and how many
/// iterations it wants, and gets the newest finished orbit (which may still be for the previous centre: then
/// the render thread keeps drawing that one). Three buffers: the active one (read by the GPU), a finished one
/// waiting for the render thread, and one being computed. A buffer goes back to the pool only when the render
/// thread swaps it out, which happens in encode(), when no command buffer is in flight.
final class OrbitWorker {
    static let capacity = maxIterLimit + 2
    private let cond = NSCondition()
    private var free: [MTLBuffer] = []
    private var want: CentreSpec
    private var wantIter: Int
    private var wantFormula = Formula.mandelbrot
    private var active: OrbitSlot? = nil
    private var ready: OrbitSlot? = nil
    // worker-private: the newest orbit it produced (active or ready) and the double-double state at its end
    private var cur: OrbitSlot? = nil
    private var zr = DD(0), zi = DD(0)
    private var nextId = 1
    private var computed = 0                            // orbits started (status)
    let buffers: [MTLBuffer]                            // all three (engine.swift: residency set)

    init?(device: MTLDevice, first: CentreSpec, iterations: Int) {
        var all: [MTLBuffer] = []
        for _ in 0..<3 {
            guard let b = device.makeBuffer(length: OrbitWorker.capacity * 8, options: .storageModeShared) else { return nil }
            free.append(b); all.append(b)
        }
        buffers = all
        want = first
        wantIter = iterations
        let t = Thread { [self] in self.run() }
        t.name = "ref-orbit"
        t.qualityOfService = .userInitiated
        t.stackSize = 1 << 20
        t.start()
    }

    /// Blocks until the first orbit exists (start-up only), at most `timeout` seconds.
    func waitFirst(timeout: Double) -> Bool {
        let end = Date().addingTimeInterval(timeout)
        cond.lock(); defer { cond.unlock() }
        while active == nil && ready == nil { if !cond.wait(until: end) { break } }
        if active == nil, let r = ready { active = r; ready = nil }
        return active != nil
    }

    /// Render thread, once per frame.
    func use(_ centre: CentreSpec, iterations: Int, formula: Formula = .mandelbrot) -> OrbitSlot? {
        cond.lock(); defer { cond.unlock() }
        var signal = false
        if centre.key != want.key { want = centre; signal = true }
        if formula != wantFormula { wantFormula = formula; signal = true }
        if iterations != wantIter { wantIter = iterations; signal = true }
        if let r = ready {
            if let a = active { free.append(a.buf) }
            active = r
            ready = nil
            signal = true
        }
        if signal { cond.signal() }
        return active
    }

    /// For status: what is asked for, and how many orbits were started so far.
    func info() -> (wantKey: String, wantIter: Int, computed: Int) { cond.lock(); defer { cond.unlock() }; return (want.key, wantIter, computed) }

    private func publishLen(id: Int, len: Int, escaped: Bool, ms: Double) {
        if active?.id == id { active!.len = len; active!.escaped = escaped; active!.ms = ms }
        if ready?.id == id { ready!.len = len; ready!.escaped = escaped; ready!.ms = ms }
        if cur?.id == id { cur!.len = len; cur!.escaped = escaped; cur!.ms = ms }
    }

    /// Iterates Z_{n+1} = F(Z_n) + C in double-double from index `from` (zr, zi hold Z_{from-1}) up to `to`
    /// (exclusive) into buf. Returns the new length and whether the reference escaped (|Z|^2 > 65536).
    private func iterate(buf: MTLBuffer, c: CentreSpec, formula f: Formula, from: Int, to: Int) -> (Int, Bool) {
        let p = buf.contents().bindMemory(to: Float.self, capacity: OrbitWorker.capacity * 2)
        var n = from
        var a = zr, b = zi
        let cr = c.re, ci = c.im
        while n < to {
            (a, b) = formulaStepDD(f, a, b)
            a = a + cr
            b = b + ci
            p[2 * n] = Float(a.hi)
            p[2 * n + 1] = Float(b.hi)
            n += 1
            if a.hi * a.hi + b.hi * b.hi > 65536 { zr = a; zi = b; return (n, true) }
        }
        zr = a; zi = b
        return (n, false)
    }

    private func run() {
        let chunk = 4096
        cond.lock()
        while true {
            let needNew = cur == nil || cur!.centre.key != want.key || cur!.formula != wantFormula
            let needExt = !needNew && !cur!.escaped && cur!.len < min(OrbitWorker.capacity, wantIter + 2)
            if !needNew && !needExt { cond.wait(); continue }
            if needNew {
                // a buffer: from the pool, or the finished-but-unused one (a newer request supersedes it)
                var buf: MTLBuffer? = free.popLast()
                if buf == nil, let r = ready { buf = r.buf; ready = nil }
                guard let b = buf else { cond.wait(); continue }
                let c = want, fo = wantFormula
                let target = min(OrbitWorker.capacity, max(2, min(wantIter + 2, chunk)))
                let id = nextId; nextId += 1; computed += 1
                cond.unlock()
                let t0 = nowTicks()
                let p = b.contents().bindMemory(to: Float.self, capacity: OrbitWorker.capacity * 2)
                p[0] = 0; p[1] = 0                         // Z_0 = 0
                zr = DD(0); zi = DD(0)
                let (len, esc) = iterate(buf: b, c: c, formula: fo, from: 1, to: target)
                let ms = ticksToSec(nowTicks() &- t0) * 1000
                cond.lock()
                if let r = ready { free.append(r.buf) }      // only if the render thread hasn't taken the last one yet
                let slot = OrbitSlot(buf: b, id: id, centre: c, formula: fo, len: len, escaped: esc, ms: ms)
                ready = slot
                cur = slot
                cond.broadcast()
            } else if let c0 = cur {
                let from = c0.len
                let to = min(OrbitWorker.capacity, wantIter + 2, from + chunk)
                cond.unlock()
                let t0 = nowTicks()
                let (len, esc) = iterate(buf: c0.buf, c: c0.centre, formula: c0.formula, from: from, to: to)
                let ms = c0.ms + ticksToSec(nowTicks() &- t0) * 1000
                cond.lock()
                publishLen(id: c0.id, len: len, escaped: esc, ms: ms)
            }
        }
    }
}

// MARK: - GPU time governor

/// Keeps the frame under the frame budget (gFrameBudgetMs, default 15.2 ms; --frame-budget-ms; status budget_ms).
/// The GPU time is the whole frame's command buffer (fractal, layers, FX, pack, NDI copy). GPU p95 over the last second
/// above the budget (or one frame over 1.65 x budget) lowers the cost to about 0.6 x budget in one go: the internal
/// resolution first (1920x1080 ... 640x360, upscaled bilinear to 1080p), then the iterations (down to x0.05). Under
/// 0.4 x budget for half a second it steps back up, iterations first, as far as the predicted cost stays under
/// 0.7 x budget (hysteresis: it settles well inside the budget). At 15.2 ms: trip 15.2, goal 9.1, up to 10.6, low 6.1, panic 25.1.
/// Jumps (another target, a depth jump of a decade or more, an override change) are guarded before the frame is
/// drawn: the worst case (pixels x max iterations) of the first frame is kept under 1.2e10, about 0.4 s even if
/// every pixel were inside the set, so a jump can never trip the 1 s watchdog.
struct Governor {
    // internal resolutions: the canvas x 1, 5/6, 2/3, 1/2, 1/3 (1920x1080 ... 640x360 on the default canvas); set in main
    static var levels: [(w: Int, h: Int)] = makeLevels(w: 1920, h: 1080)
    static func makeLevels(w: Int, h: Int) -> [(w: Int, h: Int)] {
        [(6, 6), (5, 6), (4, 6), (3, 6), (2, 6)].map { (n, d) in (max(2, (w * n / d) & ~1), max(2, (h * n / d) & ~1)) }
    }
    static var hiMs: Double { gFrameBudgetMs }
    static var loMs: Double { gFrameBudgetMs * 0.4 }
    static var panicMs: Double { gFrameBudgetMs * 1.65 }
    static var goalMs: Double { gFrameBudgetMs * 0.6 }
    static var upPredictMs: Double { gFrameBudgetMs * 0.7 }
    static let jumpWork = 1.2e10            // worst-case pixel-iterations for the first frame after a jump
    static let fixedWork = 1.5e10           // the same, every frame, while the resolution is fixed by override
    var level = 0
    var iterScale = 1.0
    private var win: [Double] = []          // GPU ms since the last change (<= 60)
    private var recent: [Double] = []       // last 60 frames (status)
    private var since = 0
    var changes = 0

    static func pct(_ a: [Double], _ q: Double) -> Double {
        if a.isEmpty { return 0 }
        let s = a.sorted()
        return s[min(s.count - 1, max(0, Int((Double(s.count) * q).rounded(.up)) - 1))]
    }
    static func area(_ l: Int) -> Double { Double(levels[l].w * levels[l].h) }
    var p95: Double { Governor.pct(recent, 0.95) }
    var size: (w: Int, h: Int) { Governor.levels[level] }
    private var text: String { "\(size.w)x\(size.h)" + (iterScale < 1 ? String(format: ", iterations x%.2f", iterScale) : "") }

    /// Lowers the cost by about `factor`: resolution steps first, then the iteration scale. false = nothing left.
    private mutating func reduce(_ factor: Double) -> Bool {
        let l0 = level, s0 = iterScale
        var need = factor
        while need > 1.02 && level < Governor.levels.count - 1 {
            need /= Governor.area(level) / Governor.area(level + 1)
            level += 1
        }
        if need > 1.02 { iterScale = max(0.05, iterScale / need) }
        if level == l0 && iterScale == s0 { return false }
        win.removeAll(); since = 0; changes += 1
        return true
    }

    /// Before drawing the first frame after a jump: keep its worst case under jumpWork.
    mutating func jump(iterations: Int, why: String) -> String? {
        let w = Governor.area(level) * Double(iterations) * iterScale
        guard w > Governor.jumpWork, reduce(w / Governor.jumpWork) else { return nil }
        return String(format: "governor: %@, worst case %.1e pixel-iterations -> %@", why, w, text)
    }

    /// After each normal-content frame. fixed: the resolution override level (nil = auto).
    mutating func add(_ ms: Double, fixed: Int?) -> String? {
        recent.append(ms); if recent.count > 60 { recent.removeFirst() }
        win.append(ms); if win.count > 60 { win.removeFirst() }
        since += 1
        if let f = fixed {
            if level != f || iterScale != 1 {
                level = f; iterScale = 1; win.removeAll(); since = 0; changes += 1
                return "governor off (resolution override): \(size.w)x\(size.h)"
            }
            return nil
        }
        let p = Governor.pct(win, 0.95)
        let panic = since >= 3 && ms > Governor.panicMs
        if panic || (since >= 20 && p > Governor.hiMs) {
            let worst = panic ? max(ms, p) : p
            guard reduce(worst / Governor.goalMs) else { win.removeAll(); since = 0; return nil }
            return String(format: "governor: %@ -> %@", panic ? String(format: "frame %.1f ms > %.1f ms", ms, Governor.panicMs)
                                                                 : String(format: "GPU p95 %.1f ms > budget %.1f ms", p, Governor.hiMs), text)
        }
        if since >= 30 && p < Governor.loMs {
            // up as far as the prediction (cost ~ pixels x iterations, an upper bound) stays under 0.7 x budget
            let l0 = level, s0 = iterScale
            if iterScale < 1 {
                iterScale = min(1, iterScale * min(4, Governor.upPredictMs / max(p, 0.5)))
            } else {
                while level > 0 && p * Governor.area(level - 1) / Governor.area(l0) <= Governor.upPredictMs { level -= 1 }
            }
            if level == l0 && iterScale == s0 { return nil }
            win.removeAll(); since = 0; changes += 1
            return String(format: "governor: GPU p95 %.1f ms < %.1f ms -> %@", p, Governor.loMs, text)
        }
        return nil
    }
}

// MARK: - command-line check of the double-double path

/// --orbit-check NAME|INDEX [N]: prints the parsed centre and Z_n (double-double) as JSON lines, for
/// tests/refine_targets.py --check-orbit (compares with Python decimal). No Metal, no NDI.
func orbitCheck(_ args: [String]) -> Int32 {
    guard let a0 = args.first, let ti = findTarget(a0) else { print("usage: --orbit-check NAME|INDEX [N]"); return 64 }
    let n = args.count > 1 ? (Int(args[1]) ?? 1000) : 1000
    let c = CentreSpec.target(ti)
    func j(_ d: DD) -> String { String(format: "[%.17g, %.17g]", d.hi, d.lo) }
    print("{\"name\": \"\(c.name)\", \"re\": \(j(c.re)), \"im\": \(j(c.im)), \"re_text\": \"\(c.reText)\", \"im_text\": \"\(c.imText)\"}")
    var a = DD(0), b = DD(0)
    let t0 = nowTicks()
    var esc = -1
    for k in 1...max(1, n) {
        let a2 = a.sqr(), b2 = b.sqr(), ab = a * b
        a = (a2 - b2) + c.re
        b = ab.times2() + c.im
        if k <= 4 || k % 100 == 0 || k == n { print("{\"n\": \(k), \"re\": \(j(a)), \"im\": \(j(b))}") }
        if a.hi * a.hi + b.hi * b.hi > 65536 { esc = k; break }
    }
    let ms = ticksToSec(nowTicks() &- t0) * 1000
    print(String(format: "{\"escaped_at\": %d, \"ms\": %.3f}", esc, ms))
    return 0
}
