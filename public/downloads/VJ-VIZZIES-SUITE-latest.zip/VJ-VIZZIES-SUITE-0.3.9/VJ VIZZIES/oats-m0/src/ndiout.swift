import Foundation
import Metal
import Darwin

// NDI output of the native player (2026-10-22). The show feed is the HDMI output window (output.swift); NDI is optional
// (Vision previs). The renderer copies each finished UYVY frame into the shared frame ring (ndiring.swift) on the GPU and
// publishes it; it never calls NDI and never waits for it. Modes (--ndi, OSC /oats/ndi/mode s, status ndi.mode):
//   off          no NDI copy at all
//   helper       the x86_64 helper bin/oats-ndi (Rosetta) sends: libndi 6.3.2 x86_64 does not freeze (m0.sh / the app run it)
//   native       a thread in this process sends with the arm64 libndi (6.3.2 arm64 freezes ~4 s every ~4 s on 1-pixel detail)
//   native-soft  native, plus a soft pass on the NDI copy only (--ndi-soft half = 2x2 box to 960x540, the default;
//                blur = 3x3 tent at 1920x1080); HDMI and the preview never get it
//   auto         helper when Rosetta is installed, else native-soft
// Quality (2026-10-23; --ndi-quality, OSC /oats/ndi/quality s, status ndi.quality): NDI is previs only (the show is HDMI).
//   previs       the default: 960x540 at half the frame rate (30/1 at 60): the 2x2 box pass on the GPU into the ring,
//                every 2nd frame, NDI frame rate 30/1. About a quarter of the helper's encode work.
//   full         1920x1080 at the output rate (native-soft keeps its soft pass)
// No receiver (the sender's NDIlib_send_get_no_connections is 0): no ring copy and no send, except one frame a second
// (keep-alive, so the source stays fresh in discovery and a receiver that connects gets a picture at once).
// A stuck send never touches the render loop: in helper mode a send call stuck for 3 s gets the helper killed (the
// supervisor restarts it); in native mode it is reported (alarms), the renderer and HDMI keep going.

enum NDIMode: String, CaseIterable {
    case off, native, nativeSoft = "native-soft", helper, auto
    static func parse(_ s: String) -> NDIMode? {
        let k = s.lowercased().trimmingCharacters(in: .whitespaces)
        if k == "soft" || k == "nativesoft" || k == "native_soft" { return .nativeSoft }
        if k == "none" || k == "0" { return .off }
        return NDIMode(rawValue: k)
    }
}
enum NDISoft: String, CaseIterable { case half, blur }
enum NDIQuality: String, CaseIterable {
    case full, previs
    static func parse(_ s: String) -> NDIQuality? {
        let k = s.lowercased().trimmingCharacters(in: .whitespaces)
        if k == "low" || k == "half" || k == "preview" { return .previs }
        if k == "high" || k == "1080" || k == "1080p" { return .full }
        return NDIQuality(rawValue: k)
    }
}

/// Rosetta 2 installed (the helper can run).
func rosettaInstalled() -> Bool { FileManager.default.fileExists(atPath: "/Library/Apple/usr/libexec/oah/libRosettaRuntime") }

final class NDIOut {
    let cfg: Config
    let key: String
    let rosetta = rosettaInstalled()
    private(set) var ring: FrameRing? = nil
    private(set) var ringErr = ""
    private var ringBuf: MTLBuffer? = nil
    private var helperSem: RingSemaphore? = nil
    private let lock = NSLock()
    private var requested: NDIMode
    private var effective: NDIMode = .off            // never .auto; what the render thread follows
    private var soft: NDISoft
    private var quality: NDIQuality
    private var frameNo: UInt64 = 0                  // render thread: frames asked for (previs sends the even ones)
    private var lastKeepAlive: UInt64 = 0            // render thread: last idle keep-alive frame (monoNs)
    private var skipIdle: Int64 = 0, skipPrevis: Int64 = 0
    private var applying = ""
    private let modeQueue = DispatchQueue(label: "ndi-mode", qos: .userInitiated)
    // native consumer (in this process)
    private var nativeLib: NDILib? = nil
    private var nativeErr = ""
    private var native: NDIConsumer? = nil
    private let nativeSem = DispatchSemaphore(value: 0)
    // producer counters (render thread writes; status reads under lock)
    private var seq: UInt64 = 0
    private var dropNoSlot: Int64 = 0, dropUnsent: Int64 = 0, published: Int64 = 0
    // monitor (status thread)
    private var killed: [pid_t] = []
    // NDI receivers per peer (2026-10-23): the sender process's established TCP sockets on its NDI listen ports, by remote
    // IP, scanned at 1 Hz (libproc, a few dozen fds). A peer counts as gone only after 5 s without a connection.
    private var peerSeen: [String: (last: UInt64, conns: Int)] = [:]
    private var peerScanNs: UInt64 = 0, peerZeroSince: UInt64 = 0
    private var kills = 0
    private var lastStalls: [UInt64] = [0, 0]
    private var lastOver1s: [UInt64] = [0, 0]
    private var lastAlarmNs: UInt64 = 0
    private var stuckWarned: UInt64 = 0

    init(cfg: Config) {
        self.cfg = cfg
        key = String(cfg.oscPort)
        requested = cfg.ndiMode
        soft = cfg.ndiSoft
        quality = cfg.ndiQuality
        let (r, e) = FrameRing.open(key: key)
        ring = r; ringErr = e
        if let r = r {
            helperSem = RingSemaphore(name: r.semName)
            r.store(RG.want, 0)
            r.add(RG.gen, 1)
            r.store(RG.latest, 0)
            r.store(RG.prodPid, UInt64(getpid()))
            r.store(RG.fps, NDIOut.fpsWord(cfg, quality))
            r.store(RG.noMeta, cfg.noNdiMeta ? 1 : 0)
            r.setString(RG.nameOff, RG.nameMax, cfg.name)
            r.setString(RG.groupsOff, RG.groupsMax, cfg.groups)
            r.add(RG.cfgSeq, 1)
            olog("NDI ring \(r.shmName) (\(ringTotalBytes / 1048576) MB, \(ringSlots) slots, generation \(r.load(RG.gen))), semaphore \(r.semName)\(helperSem == nil ? " (sem_open FAILED: the helper polls 4x/s)" : "")")
        } else {
            olog("NDI ring: \(e): NDI is OFF (HDMI output and preview are not affected)")
        }
        olog("NDI: Rosetta 2 \(rosetta ? "installed" : "not installed") (helper mode \(rosetta ? "available" : "unavailable")); requested mode \(requested.rawValue), quality \(quality.rawValue) (\(qualityText(quality)))")
    }

    /// Maps the ring for the GPU (one buffer over the whole shared memory; slots at their offsets). Before the render loop.
    func attach(dev: MTLDevice) {
        guard let r = ring else { return }
        ringBuf = dev.makeBuffer(bytesNoCopy: r.base, length: ringTotalBytes, options: .storageModeShared, deallocator: nil)
        if ringBuf == nil { ringErr = "makeBuffer(bytesNoCopy:) over the ring failed"; olog("NDI ring: \(ringErr): NDI is OFF"); ring = nil }
        setMode(requested, why: "start")
    }

    func resolve(_ m: NDIMode) -> NDIMode { m == .auto ? (rosetta ? .helper : .nativeSoft) : m }

    /// OSC / start: switch the mode (async: loading libndi or waiting for the helper to let go never blocks the caller).
    @discardableResult
    func setMode(_ m: NDIMode, why: String) -> String {
        let eff = resolve(m)
        lock.lock(); requested = m; applying = eff.rawValue; lock.unlock()
        modeQueue.async { [self] in self.apply(eff, why: why) }
        var note = "NDI mode \(m.rawValue)" + (m == .auto ? " -> \(eff.rawValue) (Rosetta \(rosetta ? "installed" : "not installed"))" : "")
        if eff == .helper && !rosetta { note += " (Rosetta is not installed: the helper cannot run; NDI stays dark)" }
        return note
    }

    func setSoft(_ s: NDISoft) { lock.lock(); soft = s; lock.unlock() }

    /// The NDI frame rate word for the ring: previs = half the output rate (60/1 -> 30/1, 60000/1001 -> 30000/1001).
    static func fpsWord(_ cfg: Config, _ q: NDIQuality) -> UInt64 {
        var n = cfg.fpsN, d = cfg.fpsD
        if q == .previs { if n % 2 == 0 { n /= 2 } else { d *= 2 } }
        return UInt64(UInt32(bitPattern: n)) << 32 | UInt64(UInt32(bitPattern: d))
    }
    func qualityText(_ q: NDIQuality) -> String {
        let w = NDIOut.fpsWord(cfg, q), n = Double(UInt32(w >> 32)), d = Double(UInt32(w & 0xffff_ffff))
        return q == .previs ? String(format: "960x540 @ %.4g fps", n / d) : String(format: "1920x1080 @ %.4g fps", n / d)
    }

    /// OSC /oats/ndi/quality s full|previs: takes effect on the next frame (the sender follows the size and rate per frame).
    func setQuality(_ q: NDIQuality) -> String {
        lock.lock(); quality = q; lock.unlock()
        ring?.store(RG.fps, NDIOut.fpsWord(cfg, q))
        return "NDI quality \(q.rawValue): \(qualityText(q))" + (q == .previs ? " (GPU 2x2 box, every 2nd frame)" : "")
    }
    var currentQuality: NDIQuality { lock.lock(); defer { lock.unlock() }; return quality }

    private func apply(_ eff: NDIMode, why: String) {
        guard let r = ring else { return }
        let wasHelper = r.load(RG.want) & wantHelper != 0
        let wasNative = r.load(RG.want) & wantNative != 0
        let wantNow: UInt64 = eff == .helper ? wantHelper : ((eff == .native || eff == .nativeSoft) ? wantNative : 0)
        // the other consumer lets go of the NDI name first (up to 1.5 s), so two senders never announce the same source
        if (wasHelper && wantNow != wantHelper) || (wasNative && wantNow != wantNative) {
            r.store(RG.want, 0)
            helperSem?.post(); nativeSem.signal()
            var i = 0
            while i < 30 && (r.aload(.helper, RingArea.state) == RingState.sending.rawValue && wantNow != wantHelper
                             || r.aload(.native, RingArea.state) == RingState.sending.rawValue && wantNow != wantNative) {
                usleep(50_000); i += 1
            }
        }
        if wantNow == wantNative && native == nil {
            if nativeLib == nil {
                do {
                    let l = try NDILib.load()
                    let (layout, ok) = ndiLayoutCheck()
                    olog("NDI native: libndi path=\(l.path) version: \(l.versionString); \(layout)")
                    if !ok { throw NDILib.LoadError(description: "struct layout mismatch with the NDI 6 ABI") }
                    guard l.initialize() else { throw NDILib.LoadError(description: "NDIlib_initialize failed") }
                    lock.lock(); nativeLib = l; lock.unlock()
                    let v = ndiVersionNumbers(l.versionString)
                    if processArchText().hasPrefix("arm64"), (v.first ?? 6) >= 6 {
                        olog("NDI native: WARNING libndi \(v.map(String.init).joined(separator: ".")) arm64: its send calls block ~4 s about every 4 s on 1-pixel detail (docs/ndi-freeze-tests.md). The renderer and HDMI are not affected (the send runs on its own thread); helper mode avoids it")
                    }
                } catch {
                    lock.lock(); nativeErr = "\(error)"; lock.unlock()
                    olog("NDI native: \(error): native NDI unavailable (install NDI Tools / the NDI 6 runtime); HDMI is not affected")
                }
            }
            if let l = nativeLib {
                let sem = nativeSem
                let c = NDIConsumer(ring: r, area: .native, lib: l, staleSec: 5, waitFrame: { _ = sem.wait(timeout: .now() + 0.25) }, log: { olog($0) })
                c.start(name: "ndi-native")
                lock.lock(); native = c; lock.unlock()
            }
        }
        r.store(RG.want, wantNow)
        helperSem?.post(); nativeSem.signal()
        lock.lock(); effective = eff; applying = ""; let s = soft; lock.unlock()
        olog("NDI mode now \(eff.rawValue)\(eff == .nativeSoft ? " (soft: \(s == .half ? "2x2 box to 960x540" : "3x3 tent at 1920x1080") on the NDI copy only)" : "") (\(why))")
    }

    // MARK: render thread

    /// The slot this frame's NDI copy goes to, and whether it is the soft copy; nil = no copy (off, or every slot is in
    /// use because the sender is behind: that frame is dropped for NDI and counted). Also the producer heartbeat.
    /// previs: only every 2nd frame, at 960x540; no receiver: one keep-alive frame a second (counted as skipped).
    func frameSlot() -> (slot: Int, soft: NDISoft?, buf: MTLBuffer, offset: Int, w: Int, h: Int)? {
        guard let r = ring, let rb = ringBuf else { return nil }
        lock.lock(); let eff = effective, s = soft, q = quality; lock.unlock()
        let now = monoNs()
        r.store(RG.prodBeat, now)
        guard eff != .off, let a = area(for: eff) else { return nil }
        frameNo &+= 1
        if r.aload(a, RingArea.conns) == 0 {
            // nobody watches: 1 frame/s keep-alive only (the sender polls its connection count 2x/s)
            if now &- lastKeepAlive < 1_000_000_000 { lock.lock(); skipIdle += 1; lock.unlock(); return nil }
            lastKeepAlive = now
        } else if q == .previs && frameNo & 1 == 1 {
            lock.lock(); skipPrevis += 1; lock.unlock(); return nil
        }
        let used = r.slotsInUse()
        guard let slot = used.firstIndex(of: false) else {
            lock.lock(); dropNoSlot += 1; lock.unlock()
            return nil
        }
        let sk: NDISoft? = q == .previs ? .half : (eff == .nativeSoft ? s : nil)
        let (w, h) = sk == .half ? (ringMaxW / 2, ringMaxH / 2) : (ringMaxW, ringMaxH)
        return (slot, sk, rb, r.slotOffset(slot), w, h)
    }

    /// After the GPU finished the frame: publish it (one atomic word) and wake the consumer. Never blocks.
    func publish(slot: Int, w: Int, h: Int) {
        guard let r = ring else { return }
        r.store(RG.dim0 + slot, UInt64(w) << 32 | UInt64(h))
        seq += 1
        let nw = seq << 8 | UInt64(slot)
        var old: UInt64
        repeat { old = r.load(RG.latest) } while !r.cas(RG.latest, old, nw)
        lock.lock(); let eff = effective; lock.unlock()
        // a frame replaced before the sender took it is a dropped NDI frame (only while that sender is up: not at start-up)
        let a: RingArea? = eff == .helper ? .helper : ((eff == .native || eff == .nativeSoft) ? .native : nil)
        let unsent = old >> 8 != 0 && old & latestConsumed == 0 && a.map { r.aload($0, RingArea.state) == RingState.sending.rawValue } == true
        lock.lock(); published += 1; if unsent { dropUnsent += 1 }; lock.unlock()
        r.store(RG.prodPublished, UInt64(published))
        if eff == .helper { helperSem?.post() } else { nativeSem.signal() }
    }

    // MARK: status thread

    private func area(for eff: NDIMode) -> RingArea? { eff == .helper ? .helper : ((eff == .native || eff == .nativeSoft) ? .native : nil) }

    /// ~4x/s from the status thread: a stuck helper is killed (the supervisor restarts it), stalls become alarms, and
    /// gNDI (connections, receivers) follows the active sender.
    func monitor() {
        guard let r = ring else { gNDI.set(connections: 0); return }
        lock.lock(); let eff = effective; lock.unlock()
        let now = monoNs()
        func age(_ t: UInt64) -> Double { t == 0 || t >= now ? 0 : Double(now - t) / 1e9 }
        guard let a = area(for: eff) else { gNDI.set(connections: 0); return }
        let ai = a.label == "helper" ? 0 : 1
        let conns = Int(r.aload(a, RingArea.conns))
        gNDI.set(connections: conns)
        if now &- peerScanNs >= 1_000_000_000 {
            peerScanNs = now
            let pid = eff == .helper ? pid_t(truncatingIfNeeded: r.aload(.helper, RingArea.pid)) : getpid()
            let scan = pid > 1 && (eff != .helper || isHelperProcess(pid)) ? ndiPeerScan(pid) : [:]
            lock.lock()
            for (ip, n) in scan { peerSeen[ip] = (now, n) }
            for (ip, v) in peerSeen where scan[ip] == nil {
                if now &- v.last > 5_000_000_000 { peerSeen[ip] = nil } else { peerSeen[ip] = (v.last, 0) }
            }
            lock.unlock()
        }
        for p in r.areaString(a, RingArea.sProducts).split(separator: "\n") { gNDI.add(product: String(p)) }
        let st50 = r.aload(a, RingArea.stalls50), o1 = r.aload(a, RingArea.over1s)
        if st50 > lastStalls[ai] {
            let n = st50 - lastStalls[ai]
            gStats.with { $0.alarmsSend += Int(n) }
            if now &- lastAlarmNs > 5_000_000_000 {
                lastAlarmNs = now
                gStats.with { $0.pendingAlarms.append(String(format: "ALARM NDI %@: %llu send call(s) > 50 ms (longest so far %.1f ms); renderer and HDMI not affected", a.label, n, Double(r.aload(a, RingArea.maxSendUs)) / 1000)) }
            }
        }
        lastStalls[ai] = st50
        if o1 > lastOver1s[ai] { lastOver1s[ai] = o1 }
        let since = r.aload(a, RingArea.sendSince)
        if since != 0 && age(since) > 1 && stuckWarned != since {
            stuckWarned = since
            gStats.with { $0.pendingAlarms.append(String(format: "ALARM NDI %@: send call in progress for %.1f s (NDI frozen); renderer and HDMI keep running", a.label, age(since))) }
        }
        // a helper stuck in one send call, or silent (it beats 4x/s even when idle), for 3 s is killed; the supervisor restarts it
        let hb = r.aload(.helper, RingArea.beat)
        let loading = r.aload(.helper, RingArea.state) == RingState.loading.rawValue   // dlopen + NDIlib_initialize: no beats meanwhile
        if eff == .helper && ((since != 0 && age(since) > 3) || (!loading && hb != 0 && age(hb) > 3)) {
            let pid = pid_t(truncatingIfNeeded: r.aload(.helper, RingArea.pid))
            if pid > 1 && !killed.contains(pid) && isHelperProcess(pid) {
                killed.append(pid); kills += 1
                kill(pid, SIGKILL)
                r.astore(.helper, RingArea.sendSince, 0); r.astore(.helper, RingArea.busy, 0); r.astore(.helper, RingArea.held, 0)
                r.astore(.helper, RingArea.state, RingState.idle.rawValue)
                let why = since != 0 && age(since) > 3 ? String(format: "one send call stuck %.1f s", age(since)) : String(format: "silent for %.1f s", age(hb))
                gStats.with { $0.pendingAlarms.append(String(format: "ALARM NDI helper %@: killed oats-ndi pid %d (the supervisor restarts it, about 5 s until Vision sees it again); renderer and HDMI not affected", why, pid)) }
            }
        }
    }

    private func isHelperProcess(_ pid: pid_t) -> Bool {
        var buf = [CChar](repeating: 0, count: 4096)
        guard proc_pidpath(pid, &buf, UInt32(buf.count)) > 0 else { return false }
        return (String(cString: buf) as NSString).lastPathComponent.hasPrefix("oats-ndi")   // bin/oats-ndi (or a test build oats-ndi.new)
    }

    func statusDict() -> [String: Any] {
        lock.lock()
        let (req, eff, s, app, dn, du, pub) = (requested, effective, soft, applying, dropNoSlot, dropUnsent, published)
        let (q, si, sp) = (quality, skipIdle, skipPrevis)
        let (hasNative, nativeErr) = (native != nil || nativeLib != nil, self.nativeErr)
        lock.unlock()
        func r2(_ v: Double) -> Double { (v * 100).rounded() / 100 }
        var d: [String: Any] = ["mode": eff.rawValue, "requested": req.rawValue, "switching_to": app, "rosetta": rosetta,
                                "soft": eff == .nativeSoft ? (s == .half ? "half 960x540" : "blur 3x3 1920x1080") : "",
                                "soft_kind": s.rawValue, "frames_published": pub, "dropped_no_slot": dn, "dropped_unsent": du,
                                "dropped": dn + du, "ring": ring?.shmName ?? "", "ring_error": ringErr, "helper_kills": kills,
                                "native_error": nativeErr, "modes": NDIMode.allCases.map { $0.rawValue },
                                "quality": q.rawValue, "qualities": NDIQuality.allCases.map { $0.rawValue }, "send_format": qualityText(q),
                                "skipped_no_receiver": si, "skipped_previs": sp]
        guard let r = ring else {
            d["note"] = "NDI off: \(ringErr)"; d["sending"] = false; d["connections"] = 0
            return d
        }
        let now = monoNs()
        func ageMs(_ t: UInt64) -> Double { t == 0 ? -1 : (t >= now ? 0 : r2(Double(now - t) / 1e6)) }
        func areaDict(_ a: RingArea) -> [String: Any] {
            let st = r.aload(a, RingArea.state)
            let sent = r.aload(a, RingArea.sent), tot = r.aload(a, RingArea.totalSendUs)
            return ["state": ["idle", "sending", "error", "loading"][Int(min(3, st))], "pid": Int(r.aload(a, RingArea.pid)),
                    "heartbeat_age_ms": ageMs(r.aload(a, RingArea.beat)), "sent": sent,
                    "send_ms_last": r2(Double(r.aload(a, RingArea.lastSendUs)) / 1000),
                    "send_ms_mean": sent > 0 ? r2(Double(tot) / Double(sent) / 1000) : 0,
                    "send_ms_max": r2(Double(r.aload(a, RingArea.maxSendUs)) / 1000),
                    "send_in_progress_ms": ageMs(r.aload(a, RingArea.sendSince)) < 0 ? 0 : ageMs(r.aload(a, RingArea.sendSince)),
                    "stalls_over_50ms": r.aload(a, RingArea.stalls50), "stalls_over_100ms": r.aload(a, RingArea.stalls100),
                    "stalls_over_1s": r.aload(a, RingArea.over1s), "connections": Int(r.aload(a, RingArea.conns)),
                    "libndi_version": r.areaString(a, RingArea.sVersion), "arch": r.areaString(a, RingArea.sArch),
                    "error": r.areaString(a, RingArea.sError),
                    "receivers": r.areaString(a, RingArea.sProducts).split(separator: "\n").map(String.init)]
        }
        lock.lock(); let ps = peerSeen; lock.unlock()
        d["peers"] = ps.keys.sorted().map { ip -> [String: Any] in
            ["ip": ip, "host": ndiPeerName(ip), "conns": ps[ip]!.conns, "seen_s_ago": r2(Double(now &- ps[ip]!.last) / 1e9)] }
        d["peer_count"] = ps.count                           // distinct receivers (held 5 s), not raw connections
        let h = areaDict(.helper)
        let hAge = h["heartbeat_age_ms"] as? Double ?? -1
        var hd = h; hd["alive"] = hAge >= 0 && hAge < 1500
        d["helper"] = hd
        if hasNative { d["native"] = areaDict(.native) }
        if let a = area(for: eff) {
            let ad = a.label == "helper" ? h : areaDict(.native)
            d["sending"] = (ad["state"] as? String) == "sending"
            d["connections"] = ad["connections"]; d["receivers"] = ad["receivers"]
            d["libndi_version"] = ad["libndi_version"]; d["libndi_arch"] = ad["arch"]
            d["send_ms_max"] = ad["send_ms_max"]; d["stalls_over_50ms"] = ad["stalls_over_50ms"]; d["stalls_over_1s"] = ad["stalls_over_1s"]
            d["idle"] = (ad["connections"] as? Int ?? 0) == 0      // no receiver: 1 keep-alive frame a second, nothing else
        } else { d["sending"] = false; d["connections"] = 0 }
        var note = ""
        switch eff {
        case .off: note = "NDI off: HDMI output only"
        case .helper:
            if !rosetta { note = "helper mode needs Rosetta 2 (not installed): NDI is dark. Use native-soft, or install Rosetta" }
            else if !(hd["alive"] as? Bool ?? false) { note = "NDI helper (bin/oats-ndi) not running: m0.sh / the app starts it; NDI is dark until it does (HDMI not affected)" }
            else { note = "helper: x86_64 libndi under Rosetta (freeze-free); the renderer is native arm64" }
        case .native: note = "native arm64 libndi: 6.3.2 freezes on 1-pixel detail (NDI only; HDMI not affected). Helper mode avoids it" + (nativeErr.isEmpty ? "" : "; \(nativeErr)")
        case .nativeSoft: note = "native arm64 libndi with a soft NDI copy (\(s == .half ? "960x540" : "3x3 blur"))" + (nativeErr.isEmpty ? "" : "; \(nativeErr)")
        case .auto: break
        }
        d["note"] = note
        return d
    }

    /// Shutdown: the native sender flushes and is destroyed (up to `timeout`); the helper keeps its sender (a restart
    /// keeps Vision connected; it ends it after 15 s without frames, or when the supervisor stops it).
    func shutdown(timeout: Double) -> Bool {
        lock.lock(); let cn = native; lock.unlock()
        guard let c = cn else { return true }
        c.stopping = true; nativeSem.signal()
        let ok = c.done.wait(timeout: .now() + timeout) == .success
        if ok { nativeLib?.destroy() }
        return ok
    }

    var effectiveMode: NDIMode { lock.lock(); defer { lock.unlock() }; return effective }
}

var gNDIOut: NDIOut! = nil

// MARK: - NDI receivers per peer (libproc)

/// Remote IPv4 -> established TCP connections of `pid` whose local port is one of its NDI listen ports (5960...6199).
func ndiPeerScan(_ pid: pid_t) -> [String: Int] {
    let need = proc_pidinfo(pid, PROC_PIDLISTFDS, 0, nil, 0)
    guard need > 0 else { return [:] }
    let n = Int(need) / MemoryLayout<proc_fdinfo>.stride + 16
    var fds = [proc_fdinfo](repeating: proc_fdinfo(), count: n)
    let got = fds.withUnsafeMutableBytes { proc_pidinfo(pid, PROC_PIDLISTFDS, 0, $0.baseAddress, Int32($0.count)) }
    guard got > 0 else { return [:] }
    var listen = Set<Int>(), est: [(lport: Int, ip: String)] = []
    for f in fds.prefix(Int(got) / MemoryLayout<proc_fdinfo>.stride) where f.proc_fdtype == UInt32(PROX_FDTYPE_SOCKET) {
        var si = socket_fdinfo()
        let sz = Int32(MemoryLayout<socket_fdinfo>.size)
        guard proc_pidfdinfo(pid, f.proc_fd, PROC_PIDFDSOCKETINFO, &si, sz) == sz, si.psi.soi_kind == Int32(SOCKINFO_TCP) else { continue }
        let tcp = si.psi.soi_proto.pri_tcp, ini = tcp.tcpsi_ini
        let lport = Int(UInt16(bigEndian: UInt16(truncatingIfNeeded: ini.insi_lport)))
        guard lport >= 5960 && lport < 6200 else { continue }
        if tcp.tcpsi_state == Int32(TSI_S_LISTEN) { listen.insert(lport); continue }
        guard tcp.tcpsi_state == Int32(TSI_S_ESTABLISHED), ini.insi_vflag & UInt8(INI_IPV4) != 0 else { continue }
        var a = ini.insi_faddr.ina_46.i46a_addr4
        var buf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        guard inet_ntop(AF_INET, &a, &buf, socklen_t(buf.count)) != nil else { continue }
        est.append((lport, String(cString: buf)))
    }
    var out: [String: Int] = [:]
    for e in est where listen.contains(e.lport) { out[e.ip, default: 0] += 1 }
    return out
}

/// Known NDI receivers by IP (the previs PC runs Vision); else the IP itself (no blocking DNS on the status thread).
func ndiPeerName(_ ip: String) -> String {
    if ip == (ProcessInfo.processInfo.environment["OATS_PC_IP"] ?? "192.168.1.141") { return "PC (Vision)" }
    if ip.hasPrefix("127.") { return "this Mac" }
    return ip
}
