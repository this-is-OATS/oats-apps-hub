import Foundation

// Metal kernels, compiled at runtime from source (no `xcrun metal` with the Command Line Tools).
// mandel, noise and to_uyvy are copied from ndi-bench/src/sender.swift (mandel now draws only DEEP; normal
// content uses mandel_pert + upscale, below). Changes:
//  - mandel takes a palette id and density (palette 0 is the bench's own cosine palette, used by DEEP);
//  - to_uyvy multiplies RGB by the master dimmer (blackout = dimmer 0 = Y16 U128 V128);
//  - the parameter block is OatsParams from ndi_min.h (48 bytes).
// noise is unchanged: hashed per-pixel noise, amplitude p.scale, new every frame via p.phase.

/// 10 reference stops each, sampled evenly from matplotlib's colormaps (same values as plotly's
/// px.colors.sequential lists). The shader interpolates linearly between them.
let paletteStops: [(name: String, hex: [String])] = [
    ("Viridis", ["440154", "482878", "3e4989", "31688e", "26828e", "1f9e89", "35b779", "6ece58", "b5de2b", "fde725"]),
    ("Magma",   ["000004", "180f3d", "440f76", "721f81", "9e2f7f", "cd4071", "f1605d", "fd9668", "feca8d", "fcfdbf"]),
    ("Inferno", ["000004", "1b0c41", "4a0c6b", "781c6d", "a52c60", "cf4446", "ed6925", "fb9b06", "f7d13d", "fcffa4"]),
    ("Plasma",  ["0d0887", "46039f", "7201a8", "9c179e", "bd3786", "d8576b", "ed7953", "fb9f3a", "fdca26", "f0f921"]),
]

/// 1-based palette names (index 0 unused).
let paletteNames = ["(bench)", "OATS Navy", "Viridis", "Magma", "Inferno", "Plasma"]

private func lutMSL() -> String {
    func f3(_ h: String) -> String {
        let v = UInt32(h, radix: 16) ?? 0
        let r = Double((v >> 16) & 0xff) / 255, g = Double((v >> 8) & 0xff) / 255, b = Double(v & 0xff) / 255
        return String(format: "float3(%.6f, %.6f, %.6f)", r, g, b)
    }
    let rows = paletteStops.enumerated().map { (i, p) in
        "    { " + p.hex.map(f3).joined(separator: ", ") + " }" + (i < paletteStops.count - 1 ? "," : "") + "   // \(p.name)"
    }
    return "constant float3 LUT[\(paletteStops.count)][10] = {\n" + rows.joined(separator: "\n") + "\n};\n"
}

let shaderSource: String = """
#include <metal_stdlib>
using namespace metal;

struct P { float cx; float cy; float scale; float phase; uint maxIter; uint w; uint h; uint use2020;
           uint pal; float density; float dimmer; float flash; };

\(lutMSL())
// Bench palette (DEEP content): 0.5 + 0.5 cos(2 pi (t + (0, .33, .67))).
inline float3 pal(float t) { return 0.5 + 0.5 * cos(6.2831853 * (t + float3(0.0, 0.33, 0.67))); }

inline float3 palette(uint id, float t) {
    if (id == 0u) return pal(t);
    if (id == 1u) return float3(40.0, 80.0, 120.0) / 255.0 * pal(t);     // OATS Navy: the prototype's navy scale
    uint k = min(id - 2u, 3u);
    float x = fract(t);
    x = 1.0 - abs(2.0 * x - 1.0);                                          // ping-pong through the map: no seam
    float f = x * 9.0;
    uint i = min(uint(f), 8u);
    return mix(LUT[k][i], LUT[k][i + 1u], f - float(i));
}

kernel void mandel(texture2d<float, access::write> outTex [[texture(0)]],
                   constant P& p [[buffer(0)]],
                   uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= p.w || gid.y >= p.h) return;
    float2 uv = (float2(gid) + 0.5 - 0.5 * float2(float(p.w), float(p.h))) * p.scale;   // square pixels: correct aspect
    float2 c = float2(p.cx + uv.x, p.cy - uv.y);                                        // y axis up
    float2 d = c - float2(0.25, 0.0);
    float q = dot(d, d);
    float2 e = c + float2(1.0, 0.0);
    if (q * (q + d.x) <= 0.25 * c.y * c.y || dot(e, e) <= 0.0625) {   // main cardioid / period-2 bulb
        outTex.write(float4(0.0, 0.0, 0.0, 1.0), gid);
        return;
    }
    float2 z = float2(0.0);
    uint i = 0;
    for (; i < p.maxIter; ++i) {
        z = float2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y) + c;
        if (dot(z, z) > 65536.0) break;                 // bailout R=256 for clean smooth colouring
    }
    float3 col = float3(0.0);                           // interior black
    if (i < p.maxIter) {
        float mu = float(i) + 1.0 - log2(log(length(z))); // continuous escape count
        col = palette(p.pal, mu * p.density + p.phase);
    }
    outTex.write(float4(col, 1.0), gid);
}

// Deep zoom (normal content): perturbation against one reference orbit Z_m (float32 copy of a double-double
// orbit, deep.swift). Per pixel: dc = pixel offset from the centre x scale; dz' = 2 Z_m dz + dz^2 + dc,
// z = Z_{m+1} + dz. Rebasing (Zhuoran 2021): when |z| < |dz| or the orbit ends, dz = z and m = 0. Same
// bailout (R = 256), smooth colouring, palettes and black interior as mandel. Renders rw x rh (the governor's
// internal resolution) into the top-left of its texture.
struct PP { float scale; float phase; float density; float cx; float cy; uint maxIter; uint rw; uint rh;
            uint orbLen; uint pal; uint cardioid; float rotC; float rotS; float offX; float offY; float crisp; };
// Smooth colouring with the spread macro's crispness: 0 = continuous escape count, 1 = whole iterations (crisp bands).
inline float muCrisp(uint i, float s, float crisp) { return float(i) + mix(s, -1.97, clamp(crisp, 0.0, 1.0)); }

kernel void mandel_pert(texture2d<float, access::write> outTex [[texture(0)]],
                        constant PP& p [[buffer(0)]],
                        device const float2* orb [[buffer(1)]],
                        uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= p.rw || gid.y >= p.rh) return;
    float2 uv = (float2(gid) + 0.5 - 0.5 * float2(float(p.rw), float(p.rh))) * p.scale;   // square pixels
    float2 s = float2(uv.x, -uv.y);                                                    // y axis up
    float2 dc = float2(p.rotC * s.x - p.rotS * s.y, p.rotS * s.x + p.rotC * s.y) + float2(p.offX, p.offY);   // rotation, offset
    if (p.cardioid != 0u) {                     // shallow views only (float32 c is exact enough there)
        float2 c = float2(p.cx, p.cy) + dc;
        float2 d = c - float2(0.25, 0.0);
        float q = dot(d, d);
        float2 e = c + float2(1.0, 0.0);
        if (q * (q + d.x) <= 0.25 * c.y * c.y || dot(e, e) <= 0.0625) {
            outTex.write(float4(0.0, 0.0, 0.0, 1.0), gid);
            return;
        }
    }
    float2 dz = float2(0.0);
    float2 Z = orb[0];
    float2 z = float2(0.0);
    uint m = 0u;
    uint last = max(p.orbLen, 2u) - 1u;
    uint i = 0u;
    for (; i < p.maxIter; ++i) {
        float2 t = 2.0 * Z + dz;
        dz = float2(t.x * dz.x - t.y * dz.y, t.x * dz.y + t.y * dz.x) + dc;
        ++m;
        Z = orb[m];
        z = Z + dz;
        float zz = dot(z, z);
        if (zz > 65536.0) break;                        // bailout R=256, as mandel
        if (zz < dot(dz, dz) || m >= last) { dz = z; m = 0u; Z = orb[0]; }
    }
    float3 col = float3(0.0);                           // interior black
    if (i < p.maxIter) {
        float mu = p.crisp > 0.0 ? muCrisp(i, 1.0 - log2(log(length(z))), p.crisp) : float(i) + 1.0 - log2(log(length(z)));
        col = palette(p.pal, mu * p.density + p.phase);
    }
    outTex.write(float4(col, 1.0), gid);
}

// Formula modifiers (deep.swift Formula, state.swift FractalMods). X (buffer 2) = 12 float4 (X[10] = kaleido twist: cos t, sin t, on; X[11] = power):
//  X[0] = (formula 0..6, log2 power, bailout^2, trap 0 off 1 point 2 circle 3 line 4 cross 5 star)
//  X[1] = (trap mix, trap size, clean fold N of c (0 = off; 1 = one mirror axis), its mirror)
//  X[2] = (wild fold N of z (0 = off), its mirror, Julia amount, warp k)       (direct path only)
//  X[3] = (Julia c re, Julia c im, cos s, sin s) with s = 2 pi / fold N; X[4..9] = (cos, sin)(-k s), k = 0..11
// fractal_pert2: the perturbation path for every formula, orbit traps, fold c and bailout (deep-zoom safe: fold c
// is a coordinate map applied to dc once, traps read the full z). fractal_direct: plain float32 iteration of the
// full z, for what has no perturbation form (a fold of z inside every iteration, the Julia morph, the warp term):
// usable to about 1e4-1e5 zoom (engine.swift caps the depth while it runs). mandel_pert above stays the classic path.
inline float2 cmulf(float2 a, float2 b) { return float2(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x); }
inline float diffabs(float c, float d) {                     // |c + d| - |c|, exact sign cases
    float cd = c + d;
    if (c >= 0.0) return cd >= 0.0 ? d : -(2.0 * c + d);
    return cd > 0.0 ? 2.0 * c + d : -d;
}
inline float2 kfold(float2 z, float n, bool mir) {           // N-fold angular fold (+ mirror inside each sector)
    if (dot(z, z) == 0.0) return z;                          // atan2(0, 0) is NaN under fast math
    float a = atan2(z.y, z.x);
    float s = 6.2831853 / n;
    a -= s * floor(a / s);
    if (mir) a = min(a, s - a);
    return length(z) * float2(cos(a), sin(a));
}
inline float trapDist(uint t, float2 z, float s) {
    switch (t) {
        case 1u: return length(z);                           // point (the origin)
        case 2u: return abs(length(z) - s);                  // circle, radius = size
        case 3u: return abs(z.y);                            // line (the real axis)
        case 4u: return min(abs(z.x), abs(z.y));             // cross
        default: {                                           // five-armed star
            float a = atan2(z.y, z.x) + 1.5707963;
            const float k = 1.2566371;
            a -= k * floor(a / k);
            a = min(a, k - a);
            return length(z) * sin(min(a, 1.5707963));
        }
    }
}
inline float3 fracColour(uint i, uint maxIter, float2 z, float lp, float dens, float phase, uint pal,
                         uint trap, float dmin, float tmix, float tsize, float crisp) {
    float3 col = float3(0.0);
    if (i < maxIter) {
        float mu = muCrisp(i, 1.0 - log2(log(length(z))) / lp, crisp);
        col = palette(pal, mu * dens + phase);
    }
    if (trap != 0u) {
        float q = dmin / max(tsize, 1e-4);
        float f = exp(-q);
        float3 tc = palette(pal, 0.18 * log(1.0 + q) + phase + 0.5) * (0.12 + 0.88 * f);
        col = mix(col, tc, clamp(tmix, 0.0, 1.0));
    }
    return col;
}
// The per-iteration fold ("Wild" twist, direct path): one atan2, then a rotation by -k s from the table X[4..9] ((cos, sin)
// pairs, k = 0..N-1). With the mirror the angle inside the sector is reflected with a SMOOTH abs (sqrt(x^2 + e^2), e = 4 %
// of the sector), so the fold has no razor crease and the escape counts stay continuous across it (no speckle).
inline float2 kfoldL(float2 z, float n, bool mir, constant float4* X) {
    float r2 = dot(z, z);
    if (r2 == 0.0) return z;
    float s = 6.2831853 / n;
    float at = atan2(z.y, z.x);
    float kf = floor(at / s);
    if (mir) {
        float ph = at - kf * s, h = 0.5 * s, e = 0.04 * s;
        float q = h - sqrt((ph - h) * (ph - h) + e * e) + e;         // smooth min(ph, s - ph), = ph near 0
        return sqrt(r2) * float2(cos(q), sin(q));
    }
    int ni = int(n + 0.5), k = int(kf) % ni;
    if (k < 0) k += ni;
    float4 q4 = X[4 + k / 2];
    float2 cs = (k & 1) != 0 ? q4.zw : q4.xy;
    return float2(cs.x * z.x - cs.y * z.y, cs.y * z.x + cs.x * z.y);
}
// "Clean" twist (2026-10-23, the default): a true kaleidoscope. The pixel's c is folded ONCE (a coordinate map, so it is
// deep-zoom safe) into N angular sectors around the view centre (the set centre at depth 0, engine.swift framing); with the
// mirror every other sector is reflected, so the edges meet without a seam; N = 1 + mirror = one mirror axis. Without the
// mirror the seams are blended over a 2.5 px band: dc2 = the neighbouring sector's wedge continued across the seam, w its
// weight (0 outside the band). X[1].zw = (N (0 = off), mirror); X[10] = the kaleido twist phaser.
inline float2 viewDCx(constant PP& p, float2 pix, constant float4* X, thread float2& dc2, thread float& w) {
    float2 uv = (pix - 0.5 * float2(float(p.rw), float(p.rh))) * p.scale;
    float2 s = float2(uv.x, -uv.y);
    float2 r = float2(p.rotC * s.x - p.rotS * s.y, p.rotS * s.x + p.rotC * s.y);
    float2 off = float2(p.offX, p.offY);
    w = 0.0; dc2 = r + off;
    float n = X[1].z;
    if (n < 1.0 || dot(r, r) == 0.0) return r + off;
    bool tw = X[10].z > 0.5;
    float2 cs = X[10].xy;
    if (tw) r = float2(cs.x * r.x - cs.y * r.y, cs.y * r.x + cs.x * r.y);
    float sec = 6.2831853 / n, rl = length(r);
    float at = atan2(r.y, r.x);
    float ph = at - sec * floor(at / sec);
    float ph2 = ph;
    if (X[1].w > 0.5) ph = min(ph, sec - ph);
    else {
        float d = min(ph, sec - ph) * rl / max(p.scale, 1e-30);   // px to the nearest seam
        if (d < 2.5) { w = 0.5 * (1.0 - d / 2.5); ph2 = ph < 0.5 * sec ? ph + sec : ph - sec; }
    }
    float2 a = rl * float2(cos(ph), sin(ph)), b = rl * float2(cos(ph2), sin(ph2));
    if (tw) {
        a = float2(cs.x * a.x + cs.y * a.y, -cs.y * a.x + cs.x * a.y);
        b = float2(cs.x * b.x + cs.y * b.y, -cs.y * b.x + cs.x * b.y);
    }
    dc2 = b + off;
    return a + off;
}
// One perturbation step dz -> F(Z + dz) - F(Z) + dc, per formula (F compile-time).
template <int F>
inline float2 pstep(float2 Z, float2 dz, float2 dc) {
    if (F == 0) { float2 t = 2.0 * Z + dz; return cmulf(t, dz) + dc; }
    if (F == 2) { float2 t = cmulf(2.0 * Z + dz, dz); return float2(t.x, -t.y) + dc; }
    if (F == 1) {
        float x = (2.0 * Z.x + dz.x) * dz.x - (2.0 * Z.y + dz.y) * dz.y;
        float y = 2.0 * diffabs(Z.x * Z.y, Z.x * dz.y + dz.x * (Z.y + dz.y));
        return float2(x, y) + dc;
    }
    if (F == 6) {
        float x = diffabs(Z.x * Z.x - Z.y * Z.y, (2.0 * Z.x + dz.x) * dz.x - (2.0 * Z.y + dz.y) * dz.y);
        float y = 2.0 * (Z.x * dz.y + dz.x * (Z.y + dz.y));
        return float2(x, y) + dc;
    }
    float2 Z2 = cmulf(Z, Z);
    if (F == 3) return cmulf(3.0 * Z2 + cmulf(3.0 * Z + dz, dz), dz) + dc;
    float2 Z3 = cmulf(Z2, Z);
    if (F == 4) return cmulf(4.0 * Z3 + cmulf(6.0 * Z2 + cmulf(4.0 * Z + dz, dz), dz), dz) + dc;
    float2 Z4 = cmulf(Z3, Z);
    return cmulf(5.0 * Z4 + cmulf(10.0 * Z3 + cmulf(10.0 * Z2 + cmulf(5.0 * Z + dz, dz), dz), dz), dz) + dc;
}
template <int F>
inline uint pertLoop(constant PP& p, device const float2* orb, float2 dc, float bail2, uint trap, float tsize,
                     thread float2& zo, thread float& dmin) {
    float2 dz = float2(0.0), Z = orb[0], z = float2(0.0);
    uint m = 0u, last = max(p.orbLen, 2u) - 1u, i = 0u;
    for (; i < p.maxIter; ++i) {
        dz = pstep<F>(Z, dz, dc);
        ++m;
        Z = orb[m];
        z = Z + dz;
        float zz = dot(z, z);
        if (trap != 0u) dmin = min(dmin, trapDist(trap, z, tsize));
        if (zz > bail2) break;
        if (zz < dot(dz, dz) || m >= last) { dz = z; m = 0u; Z = orb[0]; }
    }
    zo = z;
    return i;
}
inline float3 pert2Shade(constant PP& p, device const float2* orb, constant float4* X, float2 dc) {
    uint f = uint(X[0].x + 0.5), trap = uint(X[0].w + 0.5);
    float bail2 = X[0].z, tsize = X[1].y;
    if (p.cardioid != 0u && f == 0u && trap == 0u) {
        float2 c = float2(p.cx, p.cy) + dc;
        float2 d = c - float2(0.25, 0.0);
        float q = dot(d, d);
        float2 e = c + float2(1.0, 0.0);
        if (q * (q + d.x) <= 0.25 * c.y * c.y || dot(e, e) <= 0.0625) return float3(0.0);
    }
    float2 z;
    float dmin = 1e20;
    uint i;
    switch (f) {
        case 1u: i = pertLoop<1>(p, orb, dc, bail2, trap, tsize, z, dmin); break;
        case 2u: i = pertLoop<2>(p, orb, dc, bail2, trap, tsize, z, dmin); break;
        case 3u: i = pertLoop<3>(p, orb, dc, bail2, trap, tsize, z, dmin); break;
        case 4u: i = pertLoop<4>(p, orb, dc, bail2, trap, tsize, z, dmin); break;
        case 5u: i = pertLoop<5>(p, orb, dc, bail2, trap, tsize, z, dmin); break;
        case 6u: i = pertLoop<6>(p, orb, dc, bail2, trap, tsize, z, dmin); break;
        default: i = pertLoop<0>(p, orb, dc, bail2, trap, tsize, z, dmin); break;
    }
    return fracColour(i, p.maxIter, z, X[0].y, p.density, p.phase, p.pal, trap, dmin, X[1].x, tsize, p.crisp);
}
kernel void fractal_pert2(texture2d<float, access::write> outTex [[texture(0)]],
                          constant PP& p [[buffer(0)]],
                          device const float2* orb [[buffer(1)]],
                          constant float4* X [[buffer(2)]],
                          uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= p.rw || gid.y >= p.rh) return;
    float2 dc2; float w;
    float2 dc = viewDCx(p, float2(gid) + 0.5, X, dc2, w);
    float3 col = pert2Shade(p, orb, X, dc);
    if (w > 0.0) col = mix(col, pert2Shade(p, orb, X, dc2), w);          // clean kaleido: seam band
    outTex.write(float4(col, 1.0), gid);
}
inline float2 dstep(uint f, float2 z) {                      // F(z), without + c
    switch (f) {
        case 1u: { float2 a = abs(z); return float2(a.x * a.x - a.y * a.y, 2.0 * a.x * a.y); }
        case 2u: return float2(z.x * z.x - z.y * z.y, -2.0 * z.x * z.y);
        case 3u: return cmulf(cmulf(z, z), z);
        case 4u: { float2 q = cmulf(z, z); return cmulf(q, q); }
        case 5u: { float2 q = cmulf(z, z); return cmulf(cmulf(q, q), z); }
        case 6u: return float2(abs(z.x * z.x - z.y * z.y), 2.0 * z.x * z.y);
        default: return float2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y);
    }
}
// Branches (2026-10-23): F(z) with a real power p in polar form, z^p = |z|^p (cos p arg z, sin p arg z) (principal branch:
// a non-integer p shows the classic seam along the negative real axis). Same formula variants as dstep: Burning Ship takes
// |re|, |im| first, Tricorn the conjugate, Celtic |re| after. X[11] = (p, on, -, -).
inline float2 dstepP(uint f, float2 z, float pw) {
    if (f == 1u) z = abs(z);
    else if (f == 2u) z.y = -z.y;
    float r2 = dot(z, z);
    if (r2 == 0.0) return float2(0.0);
    float a = atan2(z.y, z.x) * pw, r = pow(r2, 0.5 * pw);
    float2 o = r * float2(cos(a), sin(a));
    if (f == 6u) o.x = abs(o.x);
    return o;
}
inline float3 directShade(constant PP& p, constant float4* X, float2 cp) {
    uint f = uint(X[0].x + 0.5), trap = uint(X[0].w + 0.5);
    float bail2 = X[0].z, tsize = X[1].y;
    float fn = X[2].x, wk = X[2].w, ja = clamp(X[2].z, 0.0, 1.0);
    bool fm = X[2].y > 0.5;
    float2 z = ja * cp;                                        // Julia morph: z0 = a p, c = mix(p, J, a)
    float2 c = mix(cp, X[3].xy, ja);
    float dmin = 1e20;
    uint i = 0u;
    for (; i < p.maxIter; ++i) {
        if (fn >= 1.0) {                                       // Wild twist: the kaleidoscope inside the numbers
            if (X[10].z > 0.5) {                               // kaleido twist (phaser): seams turned by t
                float2 cs = X[10].xy;
                z = float2(cs.x * z.x - cs.y * z.y, cs.y * z.x + cs.x * z.y);
                z = kfoldL(z, fn, fm, X);
                z = float2(cs.x * z.x + cs.y * z.y, -cs.y * z.x + cs.x * z.y);
            } else z = kfoldL(z, fn, fm, X);
        }
        float2 nz = (X[11].y > 0.5 ? dstepP(f, z, X[11].x) : dstep(f, z)) + c;
        if (wk != 0.0) nz += wk * float2(sin(z.x) * cosh(z.y), cos(z.x) * sinh(z.y));
        z = nz;
        if (trap != 0u) dmin = min(dmin, trapDist(trap, z, tsize));
        if (dot(z, z) > bail2) break;
    }
    // Wild: continuous escape count (crisp bands off), so the bands do not break where the fold folds them
    return fracColour(i, p.maxIter, z, X[0].y, p.density, p.phase, p.pal, trap, dmin, X[1].x, tsize, fn >= 1.0 ? 0.0 : p.crisp);
}
// X[11].z = supersampling (1 = off, 2 = 1x2, 4 = 2x2: Wild twist, engine.swift picks it against the frame budget)
kernel void fractal_direct(texture2d<float, access::write> outTex [[texture(0)]],
                           constant PP& p [[buffer(0)]],
                           constant float4* X [[buffer(2)]],
                           uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= p.rw || gid.y >= p.rh) return;
    uint ss = uint(X[11].z + 0.5);
    uint n = ss >= 4u ? 4u : (ss >= 2u ? 2u : 1u);
    float3 acc = float3(0.0);
    for (uint k = 0u; k < n; ++k) {
        float2 o = n == 4u ? float2(0.25 + 0.5 * float(k & 1u), 0.25 + 0.5 * float(k >> 1u))
                           : (n == 2u ? float2(0.5, 0.25 + 0.5 * float(k)) : float2(0.5));
        float2 dc2; float w;
        float2 dc = viewDCx(p, float2(gid) + o, X, dc2, w);
        float3 col = directShade(p, X, float2(p.cx, p.cy) + dc);
        if (w > 0.0) col = mix(col, directShade(p, X, float2(p.cx, p.cy) + dc2), w);
        acc += col;
    }
    outTex.write(float4(acc / float(n), 1.0), gid);
}
// Loop crossfade (engine.swift): the frozen last frame over the new dive, a = 0 frozen .. 1 live.
kernel void loop_fade(texture2d<float, access::read> live [[texture(0)]],
                      texture2d<float, access::read> frozen [[texture(1)]],
                      texture2d<float, access::write> outTex [[texture(2)]],
                      constant float& a [[buffer(0)]],
                      uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= outTex.get_width() || gid.y >= outTex.get_height()) return;
    float k = clamp(a, 0.0, 1.0);
    k = k * k * (3.0 - 2.0 * k);
    outTex.write(float4(mix(frozen.read(gid).rgb, live.read(gid).rgb, k), 1.0), gid);
}

// Governor upscale: bilinear from the top-left q.x x q.y of src to the full q.z x q.w output.
kernel void upscale(texture2d<float, access::sample> src [[texture(0)]],
                    texture2d<float, access::write> dst [[texture(1)]],
                    constant uint4& q [[buffer(0)]],
                    uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= q.z || gid.y >= q.w) return;
    constexpr sampler s(coord::normalized, filter::linear, address::clamp_to_edge);
    float2 sz = float2(float(q.x), float(q.y));
    float2 px = clamp((float2(gid) + 0.5) * sz / float2(float(q.z), float(q.w)), float2(0.5), sz - 0.5);
    float2 uv = px / float2(float(src.get_width()), float(src.get_height()));
    dst.write(float4(src.sample(s, uv).rgb, 1.0), gid);
}

// Content-entropy test: per-pixel hashed noise, amplitude p.scale around mid-grey, reseeded every frame via p.phase.
kernel void noise(texture2d<float, access::write> outTex [[texture(0)]],
                  constant P& p [[buffer(0)]],
                  uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= p.w || gid.y >= p.h) return;
    uint s = gid.x * 1973u + gid.y * 9277u + uint(p.phase * 1000.0) * 26699u;
    s = (s ^ 61u) ^ (s >> 16); s *= 9u; s = s ^ (s >> 4); s *= 0x27d4eb2du; s = s ^ (s >> 15);
    float3 r = float3(float(s & 1023u), float((s >> 10) & 1023u), float((s >> 20) & 1023u)) / 1023.0;
    outTex.write(float4(0.5 + (r - 0.5) * p.scale, 1.0), gid);
}

// M2a compositing (layers.swift). Canvas: rgba16Float. p[0] = (base fractal opacity, -, -, -); per layer i (0..3,
// bottom-up): p[1+2i] = (opacity, mix A->B, alpha A, alpha B), p[2+2i] = (blend mode, source kind 0 clip 1 fractal 2 gen, fit, overlay blend + 1 or 0).
// A layer's source texture can carry alpha (generators: premultiplied, transparent background). Clip textures: clips[2i] = A,
// clips[2i+1] = B (a 1x1 dummy when empty), scaled to cover the output (keep aspect, crop the overflow).
// W3C compositing with an opaque backdrop: Cr = mix(Cb, B(Cb, Cs), alpha_s x opacity), in display (gamma) space.
inline float3 blendMode(uint m, float3 cb, float3 cs) {
    switch (m) {
        case 1u: return min(cb + cs, float3(1.0));                                   // Add (clamped)
        case 2u: return cb + cs - cb * cs;                                           // Screen
        case 3u: return cb * cs;                                                     // Multiply
        case 4u: return abs(cb - cs);                                                // Difference
        case 5u: return max(cb, cs);                                                 // Lighten
        case 6u: return min(cb, cs);                                                 // Darken
        case 7u: {                                                                   // Overlay = HardLight(Cs, Cb)
            float3 d = 2.0 * cb - 1.0;
            return select(cs + d - cs * d, 2.0 * cb * cs, cb <= 0.5);
        }
        default: return cs;                                                          // Alpha (normal)
    }
}

// Layer overlay (gen.swift): O premultiplied over the premultiplied layer source S with separable blend mode m (W3C:
// (1 - Sa) O + (1 - Oa) S + Oa Sa B(Sc, Oc); alpha Sa + Oa - Sa Oa). m = BlendMode raw value (0 alpha 1 add 2 screen ...).
inline float4 ovMix(float4 S, float4 O, uint m) {
    if (O.a <= 0.0) return S;
    float3 sc = clamp(S.rgb / max(S.a, 1e-4), 0.0, 1.0), oc = clamp(O.rgb / max(O.a, 1e-4), 0.0, 1.0);
    float3 rgb = (1.0 - S.a) * O.rgb + (1.0 - O.a) * S.rgb + O.a * S.a * blendMode(m, sc, oc);
    return float4(rgb, S.a + O.a - S.a * O.a);
}

// Returns rgba: clips (BGRA video) and the fractal have alpha 1; generator textures are premultiplied with alpha.
// fit (mapping.swift layer_fit): the whole texture inside the canvas, transparent outside (a 1-px soft edge).
inline float4 coverSample(texture2d<float, access::sample> t, float2 px, float2 outSz, bool fit = false) {
    constexpr sampler s(coord::normalized, filter::linear, address::clamp_to_edge);
    float2 sz = float2(float(t.get_width()), float(t.get_height()));
    float k = fit ? min(outSz.x / sz.x, outSz.y / sz.y) : max(outSz.x / sz.x, outSz.y / sz.y);
    float2 uv = ((px - 0.5 * outSz) / k + 0.5 * sz) / sz;
    if (!fit) return t.sample(s, uv);
    float2 e = min(uv, 1.0 - uv) * sz * k;                     // distance to the clip's edge in canvas px
    return t.sample(s, uv) * clamp(min(e.x, e.y) + 0.5, 0.0, 1.0);
}
// Colour link per layer source: target 0 all, 1 clips (= every layer that is not the fractal), 2 fractal only.
inline bool linkOn(uint ctgt, uint kind) { return ctgt == 0u || (ctgt == 1u && kind != 1u) || (ctgt == 2u && kind == 1u); }

// Lights -> VJ colour link. k = (r, g, b, amount), m.x = mode (0 tint: multiply toward the colour, 1 hue: rotate the hue
// toward the colour's hue, 2 replace: colorize the luminance). The colour is normalised to its brightest component,
// so a dim console colour still tints at full strength (the amount is the strength).
inline float3 rgb2hsv(float3 c) {
    float4 K = float4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    float4 p = mix(float4(c.bg, K.wz), float4(c.gb, K.xy), step(c.b, c.g));
    float4 q = mix(float4(p.xyw, c.r), float4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    return float3(abs(q.z + (q.w - q.y) / (6.0 * d + 1e-10)), d / (q.x + 1e-10), q.x);
}
inline float3 hsv2rgb(float3 c) {
    float3 p = abs(fract(c.xxx + float3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(float3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}
inline float3 colorLink(float3 c, float4 k, uint mode) {
    if (k.w <= 0.0) return c;
    float mx = max(max(k.r, k.g), k.b);
    float3 col = mx > 0.001 ? k.rgb / mx : float3(0.0);
    float3 o;
    if (mode == 1u) {
        float3 h = rgb2hsv(c), t = rgb2hsv(col);
        float dh = t.x - h.x; dh -= rint(dh);                      // shortest way round
        o = hsv2rgb(float3(fract(h.x + dh * k.w + 1.0), max(h.y, t.y * k.w), h.z));
        return o;                                                  // amount already used as the rotation fraction
    } else if (mode == 2u) {
        float y = dot(c, float3(0.2126, 0.7152, 0.0722));
        o = col * y / max(0.2126 * col.r + 0.7152 * col.g + 0.0722 * col.b, 0.05) ;
        o = min(o, float3(1.0));
    } else {
        o = c * col;
    }
    return mix(c, o, k.w);
}

// BG as a full layer (2026-10-23): 5 layer slots, i = 4 is BG (L0) and is drawn first, over black, then L1..L4.
// Textures: clips[2i], clips[2i+1] (0..9), canvas 10, Trails history read 11..15 / write 16..20, overlays 21..25.
// p[0] unused; p[1+2i], p[2+2i] per layer; p[11] colour link, p[12] (mode, target); composite_fx: p[13+6i ..] layer FX.
#define NLAYERS 5u
#define LORDER(j) (((j) + 4u) % 5u)
kernel void composite(array<texture2d<float, access::sample>, 10> clips [[texture(0)]],
                      texture2d<float, access::write> canvas [[texture(10)]],
                      array<texture2d<float, access::sample>, 5> ovl [[texture(21)]],
                      constant float4* p [[buffer(0)]],
                      uint2 gid [[thread_position_in_grid]]) {
    uint w = canvas.get_width(), h = canvas.get_height();
    if (gid.x >= w || gid.y >= h) return;
    float2 outSz = float2(float(w), float(h));
    float2 px = float2(gid) + 0.5;
    float4 ck = p[11];                                                             // colour link (r, g, b, amount)
    uint cmode = uint(p[12].x + 0.5), ctgt = uint(p[12].y + 0.5);                  // target 0 all, 1 clips, 2 fractal
    float3 cb = float3(0.0);                                                       // black under BG
    for (uint j = 0u; j < NLAYERS; ++j) {
        uint i = LORDER(j);
        float4 l = p[1u + 2u * i];
        float aA = l.z * (1.0 - l.y), aB = l.w * l.y;
        float a = aA + aB;
        if (a <= 0.0 || l.x <= 0.0) continue;
        float4 sv = float4(0.0);
        bool fit = p[2u + 2u * i].z > 0.5;
        if (aA > 0.0) sv += coverSample(clips[2u * i], px, outSz, fit) * aA;
        if (aB > 0.0) sv += coverSample(clips[2u * i + 1u], px, outSz, fit) * aB;
        sv /= a;
        float4 bk = p[2u + 2u * i];
        if (bk.w > 0.5) sv = ovMix(sv, ovl[i].read(gid), uint(bk.w - 0.5));        // layer overlay (clip / fractal source)
        float cov = clamp(sv.a, 0.0, 1.0);
        if (cov <= 0.0) continue;
        float3 cs = clamp(sv.rgb / max(sv.a, 1e-4), 0.0, 1.0);
        if (linkOn(ctgt, uint(bk.y + 0.5))) cs = colorLink(cs, ck, cmode);
        uint m = uint(bk.x + 0.5);
        cb = mix(cb, blendMode(m, cb, cs), clamp(a * l.x * cov, 0.0, 1.0));
    }
    canvas.write(float4(cb, 1.0), gid);
}

\(fxMSL)
\(genMSL)
\(testcardMSL)
// FX composite (used while any layer has a transform, FX or beat mod; all neutral = `composite` above, unchanged).
// Same p[0..10] as composite, plus p[11+6i .. 16+6i] layer i FX (src/fx.swift FXRuntime.layer): transform x0, x1,
// slot 1, slot 2, (duotone rgb, history valid), edge (feather, shape). Function constants drop the FX stages no layer uses this frame
// (fewer registers, more threads in flight); the engine keeps all 16 variants compiled.
constant bool kUV [[function_constant(0)]];
constant bool kTap [[function_constant(1)]];
constant bool kColor [[function_constant(2)]];
constant bool kTrails [[function_constant(3)]];
kernel void composite_fx(array<texture2d<float, access::sample>, 10> clips [[texture(0)]],
                         texture2d<float, access::write> canvas [[texture(10)]],
                         array<texture2d<float, access::sample>, 5> histR [[texture(11)]],
                         array<texture2d<float, access::write>, 5> histW [[texture(16)]],
                         array<texture2d<float, access::sample>, 5> ovl [[texture(21)]],
                         constant float4* p [[buffer(0)]],
                         uint2 gid [[thread_position_in_grid]]) {
    uint w = canvas.get_width(), h = canvas.get_height();
    if (gid.x >= w || gid.y >= h) return;
    float2 outSz = float2(float(w), float(h));
    float2 fs = (float2(gid) + 0.5) / outSz;
    float4 ck = p[11];
    uint cmode = uint(p[12].x + 0.5), ctgt = uint(p[12].y + 0.5);
    float3 cb = float3(0.0);
    for (uint j = 0u; j < NLAYERS; ++j) {
        uint i = LORDER(j);
        float4 l = p[1u + 2u * i];
        float aA = l.z * (1.0 - l.y), aB = l.w * l.y;
        float a = aA + aB;
        if (a <= 0.0 || l.x <= 0.0) continue;
        uint q = 13u + 6u * i;
        float4 x0 = p[q], x1 = p[q + 1u], f1 = p[q + 2u], f2 = p[q + 3u], ed = p[q + 5u];
        uint t1 = uint(f1.x + 0.5), t2 = uint(f2.x + 0.5);
        float2 fu = fs;
        if (kUV) {
            if (fxIsUV(t1)) fu = fxUV(t1, f1.y, f1.z, fu, outSz);
            if (fxIsUV(t2)) fu = fxUV(t2, f2.y, f2.z, fu, outSz);
        }
        float4 s;
        float om = p[2u + 2u * i].w;                                                // overlay blend + 1 (0 = none)
        if (kTap) s = L_tap(clips[2u * i], clips[2u * i + 1u], aA, aB, x0, x1, ed, outSz, ovl[i], om, fxIsTap(t1) ? f1 : (fxIsTap(t2) ? f2 : float4(0.0)), fu);
        else s = L_base(clips[2u * i], clips[2u * i + 1u], aA, aB, x0, x1, ed, outSz, ovl[i], om, fu);
        if (kColor || kTrails) {
            float4 e = p[q + 4u];
            bool hdone = false;                                                     // one history per layer: the first feedback slot
            for (uint k = 0u; k < 2u; ++k) {
                float4 fx = k == 0u ? f1 : f2;
                uint t = k == 0u ? t1 : t2;
                if (kColor && fxIsColor(t)) s = fxColor(t, fx.y, fx.z, s, e.xyz);
                else if (kTrails && t == 17u && !hdone) {                           // Trails: max with the faded history
                    constexpr sampler hs(coord::normalized, filter::linear, address::clamp_to_edge);
                    float4 hh = e.w > 0.5 ? histR[i].sample(hs, fs) : float4(0.0);
                    s = max(s, hh * pow(0.985 * pow(fx.y, 0.3), max(fx.w, 0.05)));
                    if ((gid.x & 1u) == 0u && (gid.y & 1u) == 0u) histW[i].write(s, gid / 2u);
                    hdone = true;
                } else if (kTrails && fxIsLongExp(t) && !hdone) {                   // Star/Warp/SpiralTrails: full-res history,
                    if (e.w > 0.5) s = max(s, fxLongExp(histR[i], fx, fs, 0.5 + 0.5 * x0.xy, outSz));   // around the layer centre
                    if (gid.x < histW[i].get_width() && gid.y < histW[i].get_height()) histW[i].write(s, gid);
                    hdone = true;
                }
            }
        }
        float cov = clamp(s.a, 0.0, 1.0);
        if (cov <= 0.0) continue;
        float3 cs = clamp(s.rgb / max(s.a, 1e-4), 0.0, 1.0);
        float4 bk = p[2u + 2u * i];
        if (linkOn(ctgt, uint(bk.y + 0.5))) cs = colorLink(cs, ck, cmode);
        uint m = uint(bk.x + 0.5);
        cb = mix(cb, blendMode(m, cb, cs), clamp(a * l.x * cov, 0.0, 1.0));
    }
    canvas.write(float4(cb, 1.0), gid);
}

// Dominant-colour analysis (analysis.swift): box average of the canvas down to q.z x q.w float4 (x dimmer).
kernel void analyze_down(texture2d<float, access::read> src [[texture(0)]],
                         device float4* dst [[buffer(0)]],
                         constant uint4& q [[buffer(1)]],
                         constant float& dim [[buffer(2)]],
                         uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= q.z || gid.y >= q.w) return;
    uint x0 = gid.x * q.x / q.z, x1 = (gid.x + 1u) * q.x / q.z, y0 = gid.y * q.y / q.w, y1 = (gid.y + 1u) * q.y / q.w;
    float3 acc = float3(0.0);
    for (uint y = y0; y < y1; y += 2u) for (uint x = x0; x < x1; x += 2u) acc += clamp(src.read(uint2(x, y)).rgb, 0.0, 1.0);
    float n = float(((x1 - x0 + 1u) / 2u) * ((y1 - y0 + 1u) / 2u));
    dst[gid.y * q.z + gid.x] = float4(acc / max(n, 1.0) * clamp(dim, 0.0, 1.0), 1.0);
}

// One thread = 2 pixels -> one UYVY macropixel (bytes U Y0 V Y1), video range. RGB x dimmer first.
kernel void to_uyvy(texture2d<float, access::read> src [[texture(0)]],
                    device uint* dst [[buffer(0)]],
                    constant P& p [[buffer(1)]],
                    uint2 gid [[thread_position_in_grid]]) {
    uint pw = p.w / 2;
    if (gid.x >= pw || gid.y >= p.h) return;
    float dim = clamp(p.dimmer, 0.0, 1.0);
    float3 a = clamp(src.read(uint2(gid.x * 2, gid.y)).rgb, 0.0, 1.0) * dim;
    float3 b = clamp(src.read(uint2(gid.x * 2 + 1, gid.y)).rgb, 0.0, 1.0) * dim;
    float fl = clamp(p.flash, 0.0, 1.0);                 // audio strobe flash: toward white, still x dimmer (0 = unchanged)
    a = mix(a, float3(dim), fl); b = mix(b, float3(dim), fl);
    float kr = (p.use2020 != 0) ? 0.2627 : 0.2126;    // BT.2020 above 1080p, BT.709 for HD
    float kb = (p.use2020 != 0) ? 0.0593 : 0.0722;
    float kg = 1.0 - kr - kb;
    float ya = kr * a.r + kg * a.g + kb * a.b;
    float yb = kr * b.r + kg * b.g + kb * b.b;
    float3 m = 0.5 * (a + b);
    float ym = 0.5 * (ya + yb);
    float cb = (m.b - ym) / (2.0 * (1.0 - kb));
    float cr = (m.r - ym) / (2.0 * (1.0 - kr));
    uint Y0 = uint(rint(clamp(16.0 + 219.0 * ya, 16.0, 235.0)));
    uint Y1 = uint(rint(clamp(16.0 + 219.0 * yb, 16.0, 235.0)));
    uint U  = uint(rint(clamp(128.0 + 224.0 * cb, 16.0, 240.0)));
    uint V  = uint(rint(clamp(128.0 + 224.0 * cr, 16.0, 240.0)));
    dst[gid.y * pw + gid.x] = U | (Y0 << 8) | (V << 16) | (Y1 << 24);
}

// NDI copy, native-soft (ndiout.swift): from the UYVY output (after dimmer / blackout, exactly what HDMI shows) into a
// ring slot. uyvy_half: 2x2 box average to w/2 x h/2 (one thread = one output macropixel). uyvy_blur: 3x3 tent at
// full size (luma per pixel, chroma per macropixel). Averaging Y'CbCr is the same as averaging R'G'B' (linear map).
inline float uY0(uint m) { return float((m >> 8) & 0xffu); }
inline float uY1(uint m) { return float(m >> 24); }
inline float uU(uint m) { return float(m & 0xffu); }
inline float uV(uint m) { return float((m >> 16) & 0xffu); }
inline uint uPack(float y0, float y1, float u, float v) {
    return uint(rint(clamp(u, 16.0, 240.0))) | (uint(rint(clamp(y0, 16.0, 235.0))) << 8)
         | (uint(rint(clamp(v, 16.0, 240.0))) << 16) | (uint(rint(clamp(y1, 16.0, 235.0))) << 24);
}
kernel void uyvy_half(device const uint* src [[buffer(0)]],
                      device uint* dst [[buffer(1)]],
                      constant uint4& q [[buffer(2)]],
                      uint2 gid [[thread_position_in_grid]]) {
    uint spw = q.x / 2u, opw = q.x / 4u, oh = q.y / 2u;
    if (gid.x >= opw || gid.y >= oh) return;
    uint r0 = 2u * gid.y * spw, r1 = r0 + spw, c = 2u * gid.x;
    uint a0 = src[r0 + c], a1 = src[r0 + c + 1u], b0 = src[r1 + c], b1 = src[r1 + c + 1u];
    float y0 = 0.25 * (uY0(a0) + uY1(a0) + uY0(b0) + uY1(b0));
    float y1 = 0.25 * (uY0(a1) + uY1(a1) + uY0(b1) + uY1(b1));
    float u = 0.25 * (uU(a0) + uU(a1) + uU(b0) + uU(b1)), v = 0.25 * (uV(a0) + uV(a1) + uV(b0) + uV(b1));
    dst[gid.y * opw + gid.x] = uPack(y0, y1, u, v);
}
kernel void uyvy_blur(device const uint* src [[buffer(0)]],
                      device uint* dst [[buffer(1)]],
                      constant uint4& q [[buffer(2)]],
                      uint2 gid [[thread_position_in_grid]]) {
    uint pw = q.x / 2u, h = q.y;
    if (gid.x >= pw || gid.y >= h) return;
    float ya = 0.0, yb = 0.0, u = 0.0, v = 0.0;
    uint xl = gid.x > 0u ? gid.x - 1u : 0u, xr = min(gid.x + 1u, pw - 1u);
    for (int dy = -1; dy <= 1; ++dy) {
        uint row = uint(clamp(int(gid.y) + dy, 0, int(h) - 1)) * pw;
        float wy = dy == 0 ? 2.0 : 1.0;
        uint mL = src[row + xl], m = src[row + gid.x], mR = src[row + xr];
        ya += wy * (uY1(mL) + 2.0 * uY0(m) + uY1(m));
        yb += wy * (uY0(m) + 2.0 * uY1(m) + uY0(mR));
        u += wy * (uU(mL) + 2.0 * uU(m) + uU(mR));
        v += wy * (uV(mL) + 2.0 * uV(m) + uV(mR));
    }
    dst[gid.y * pw + gid.x] = uPack(ya / 16.0, yb / 16.0, u / 16.0, v / 16.0);
}

// NDI copy on a canvas other than 1920x1080 (mapping.swift): the UYVY output letterboxed into q.z x q.w (1920x1080 or
// 960x540; NDI receivers stay 16:9), box-averaged over up to 4x4 source pixels per output pixel. One thread = one output
// macropixel. Outside the picture: black (Y 16, U V 128).
inline float3 uyvyAt(device const uint* src, uint pw, uint x, uint y) {
    uint m = src[y * pw + (x >> 1)];
    return float3((x & 1u) != 0u ? uY1(m) : uY0(m), uU(m), uV(m));
}
kernel void uyvy_fit(device const uint* src [[buffer(0)]],
                     device uint* dst [[buffer(1)]],
                     constant uint4& q [[buffer(2)]],
                     uint2 gid [[thread_position_in_grid]]) {
    uint opw = q.z / 2u;
    if (gid.x >= opw || gid.y >= q.w) return;
    float sw = float(q.x), sh = float(q.y), dw = float(q.z), dh = float(q.w);
    float s = min(dw / sw, dh / sh);
    float ox = 0.5 * (dw - sw * s), oy = 0.5 * (dh - sh * s);
    int k = clamp(int(ceil(1.0 / s)), 1, 4);
    uint spw = q.x / 2u;
    float y2[2] = { 16.0, 16.0 };
    float u = 0.0, v = 0.0, n = 0.0;
    for (uint e = 0u; e < 2u; ++e) {
        float dx = float(gid.x * 2u + e) + 0.5, dy = float(gid.y) + 0.5;
        float sx = (dx - ox) / s, sy = (dy - oy) / s;
        if (sx < 0.0 || sy < 0.0 || sx >= sw || sy >= sh) continue;
        float acc = 0.0, cnt = 0.0;
        for (int j = 0; j < k; ++j) for (int i = 0; i < k; ++i) {
            uint x = uint(clamp(sx + (float(i) - 0.5 * float(k - 1)) / s / float(k), 0.0, sw - 1.0));
            uint y = uint(clamp(sy + (float(j) - 0.5 * float(k - 1)) / s / float(k), 0.0, sh - 1.0));
            float3 t = uyvyAt(src, spw, x, y);
            acc += t.x; u += t.y; v += t.z; cnt += 1.0; n += 1.0;
        }
        y2[e] = acc / cnt;
    }
    dst[gid.y * opw + gid.x] = n > 0.0 ? uPack(y2[0], y2[1], u / n, v / n) : uPack(16.0, 16.0, 128.0, 128.0);
}

// GUI preview: box filter of the UYVY output (exactly what NDI sends, after dimmer/blackout) down to q.z x q.w
// BGRA8 (bytes B G R A). q = (src w, src h, dst w, dst h). Averages Y, U, V, then BT.709 video range -> RGB.
// lb = the picture's rect inside the preview (x, y, w, h): the whole frame on a 16:9 canvas, letterboxed otherwise.
kernel void preview_down(device const uint* src [[buffer(0)]],
                         device uchar4* dst [[buffer(1)]],
                         constant uint4& q [[buffer(2)]],
                         constant uint4& lb [[buffer(3)]],
                         uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= q.z || gid.y >= q.w) return;
    if (gid.x < lb.x || gid.y < lb.y || gid.x >= lb.x + lb.z || gid.y >= lb.y + lb.w) { dst[gid.y * q.z + gid.x] = uchar4(0, 0, 0, 255); return; }
    uint gx = gid.x - lb.x, gy = gid.y - lb.y;
    uint x0 = gx * q.x / lb.z, x1 = max(x0 + 1u, (gx + 1u) * q.x / lb.z);
    uint y0 = gy * q.y / lb.w, y1 = max(y0 + 1u, (gy + 1u) * q.y / lb.w);
    uint pw = q.x / 2u;
    float3 acc = float3(0.0);
    for (uint y = y0; y < y1; ++y) {
        device const uint* row = src + y * pw;
        for (uint x = x0; x < x1; ++x) {
            uint m = row[x >> 1];
            float Y = float((x & 1u) != 0u ? (m >> 24) : ((m >> 8) & 0xffu));
            acc += float3(Y, float(m & 0xffu), float((m >> 16) & 0xffu));
        }
    }
    acc /= float((x1 - x0) * (y1 - y0));
    float yy = 1.164383 * (acc.x - 16.0), u = acc.y - 128.0, v = acc.z - 128.0;
    float3 rgb = clamp(float3(yy + 1.792741 * v, yy - 0.213249 * u - 0.532909 * v, yy + 2.112402 * u), 0.0, 255.0);
    dst[gid.y * q.z + gid.x] = uchar4(uchar(rint(rgb.b)), uchar(rint(rgb.g)), uchar(rint(rgb.r)), uchar(255));
}

// GUI PREVIEW monitor (preview.swift ?layer=n): ONE layer by itself, over black, before its opacity and blend: its source
// texture(s) exactly as the composite samples them (clip A/B crossfade, cover or fit, the layer overlay; generators
// already carry their own motion), box-filtered into q.z x q.w BGRA8: 2x2 bilinear taps per preview pixel (= an exact
// 4x4 box at 480 wide from 1920, 4 of 6 px at 320).
// q = (canvas w, canvas h, dst w, dst h); lb = the picture's rect in the preview; lp[0] = (opacity, k, alpha A, alpha B),
// lp[1] = (blend, kind, fit, overlay mode + 1) = the composite's p[1 + 2i], p[2 + 2i].
kernel void preview_solo(texture2d<float, access::sample> ta [[texture(0)]],
                         texture2d<float, access::sample> tb [[texture(1)]],
                         texture2d<float, access::sample> ov [[texture(2)]],
                         device uchar4* dst [[buffer(0)]],
                         constant uint4& q [[buffer(1)]],
                         constant uint4& lb [[buffer(2)]],
                         constant float4* lp [[buffer(3)]],
                         uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= q.z || gid.y >= q.w) return;
    uint o = gid.y * q.z + gid.x;
    float4 l = lp[0], bk = lp[1];
    float aA = l.z * (1.0 - l.y), aB = l.w * l.y, a = aA + aB;
    if (a <= 0.0 || gid.x < lb.x || gid.y < lb.y || gid.x >= lb.x + lb.z || gid.y >= lb.y + lb.w) { dst[o] = uchar4(0, 0, 0, 255); return; }
    float2 outSz = float2(float(q.x), float(q.y));
    float2 st = outSz / float2(float(lb.z), float(lb.w));            // canvas px per preview px
    float2 g = float2(float(gid.x - lb.x), float(gid.y - lb.y));
    bool fit = bk.z > 0.5;
    uint om = uint(max(bk.w, 0.0) + 0.5);
    float3 acc = float3(0.0);
    for (uint j = 0u; j < 2u; ++j) for (uint i = 0u; i < 2u; ++i) {
        float2 px = (g + (float2(float(i), float(j)) + 0.5) / 2.0) * st;
        float4 sv = float4(0.0);
        if (aA > 0.0) sv += coverSample(ta, px, outSz, fit) * aA;
        if (aB > 0.0) sv += coverSample(tb, px, outSz, fit) * aB;
        sv /= a;
        if (om > 0u) sv = ovMix(sv, ov.read(uint2(clamp(px, float2(0.0), outSz - 1.0))), om - 1u);
        acc += clamp(sv.rgb, 0.0, 1.0);                                  // premultiplied = over black
    }
    float3 rgb = clamp(acc / 4.0, 0.0, 1.0) * 255.0;
    dst[o] = uchar4(uchar(rint(rgb.b)), uchar(rint(rgb.g)), uchar(rint(rgb.r)), uchar(255));
}
"""
