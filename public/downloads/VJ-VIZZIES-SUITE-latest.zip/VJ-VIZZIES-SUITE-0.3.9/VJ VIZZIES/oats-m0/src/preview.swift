import Foundation
import Metal
import CoreGraphics
import ImageIO
import Darwin

// Live preview for the GUI: MJPEG over HTTP on TCP 8091 (GET /preview.mjpg, GET /preview.jpg).
//
// Render side (Engine.encode): while at least one client wants frames, every Nth rendered frame (N = output fps /
// fastest client fps, so 2 at 60 fps for 30 fps) adds one small compute dispatch per requested size to the frame's
// own command buffer: preview_down box-filters the UYVY output (exactly what NDI gets, after dimmer and blackout)
// to 160x90, 256x144 or 320x180 BGRA8 in one of 3 shared buffers per size. No waits are added: the command
// buffer's completion handler hands the slot to the preview thread, or drops the frame if that thread is still busy.
// With no client the render loop does one atomic load per frame and nothing else.
// Preview thread: wraps the buffer in a CGImage, encodes JPEG (ImageIO, quality 0.6), publishes it.
// Server thread: owns every socket (poll, non-blocking writes). A client whose socket can't take a frame misses it.
// None of the three paths takes a lock the render thread waits on for longer than a few field copies, and the
// watchdog watches only the render and send heartbeats, so a slow or stuck preview cannot trip it.

var previewPort: UInt16 = 8091                 // --preview-port (app.swift)
let previewWidths = [160, 256, 320, 640, 960, 1920]   // height = w * 9 / 16; 640 = a monitor ~320-640 px wide on a Retina screen; 960 / 1920 = HD / Full
// (6 program + 2 solo sizes = the 8 bits of the demand word's size mask)
/// GUI PREVIEW monitor (?layer=n): one layer by itself (preview_solo, shaders.swift), 320 or 480 wide. These sizes
/// follow previewWidths in the size mask / buffers / latest frames (indices previewWidths.count ...).
let previewSoloWidths = [320, 480]
let previewAllWidths = previewWidths + previewSoloWidths
let previewSoloBase = previewWidths.count
let previewDefaultSizeIndex = 1               // 256x144
let previewMaxClients = 8
let previewSlots = 3

@inline(__always) func previewHeight(_ w: Int) -> Int { w * 9 / 16 }

final class PreviewHub {
    /// Atomic demand word, written by the server thread, read by the render loop every frame:
    /// bits 0..7 = size mask (bit i = previewAllWidths[i]), bits 8..15 = N (render frames per preview frame),
    /// bits 16..23 = solo layer mask (bit 0 = BG, bits 1..4 = layers 1..4) wanted by PREVIEW monitor clients. Two GUI
    /// windows on different layers take turns: each preview frame shows the next wanted layer (round robin).
    let demand: UnsafeMutablePointer<UInt64>
    private(set) var bufs: [[MTLBuffer]] = []     // [size][slot], set once by Engine.init before the render loop runs

    private let lock = NSLock()
    private var slotState = [Int](repeating: 0, count: previewSlots)   // 0 free, 1 on the GPU, 2 with the preview thread
    private var nextSlot = 0
    private var encoding = false
    private let jobSem = DispatchSemaphore(value: 0)
    private var latest: [(gen: Int64, data: Data, ticks: UInt64)?] = Array(repeating: nil, count: previewAllWidths.count)
    private var latestLayer = [Int](repeating: -1, count: previewAllWidths.count)   // solo sizes: the layer each frame shows
    private var job: (slot: Int, mask: Int, layer: Int)? = nil
    private var gen: Int64 = 0
    // stats
    private var jobsTotal: Int64 = 0
    private var droppedBusy: Int64 = 0
    private var droppedSlow: Int64 = 0
    private var rejected: Int64 = 0              // connections from a source that is not on an allowed network
    private var encSum = 0.0, encN = 0
    private var clients = 0
    private var sizeMask = 0
    private var soloMask = 0
    private var soloRR = 0                        // render thread only: the layer the last solo frame showed
    private var sampleTicks: UInt64 = 0, sampleJobs: Int64 = 0, sampleFps = 0.0
    private var wakeFd: Int32 = -1
    private(set) var listening = false

    init() { demand = .allocate(capacity: 1); demand.initialize(to: 0) }

    func attach(bufs b: [[MTLBuffer]]) { bufs = b }

    // MARK: render thread + Metal completion handler

    /// Render thread, every frame: the layers PREVIEW monitor clients want (bit 0 = BG, bits 1..4), or 0. One atomic load.
    @inline(__always) func soloWanted() -> Int {
        let d = oats_load_u64(demand)
        return Int(d & 0xff) >> previewSoloBase == 0 ? 0 : Int((d >> 16) & 0x1f)
    }

    /// Render thread, once per encoded frame: the slot to downsample into, the size mask and the solo layer, or nil.
    @inline(__always) func renderBegin(frame: Int64) -> (slot: Int, mask: Int, layer: Int)? {
        let d = oats_load_u64(demand)
        let mask = Int(d & 0xff)
        if mask == 0 || bufs.isEmpty { return nil }
        let n = max(1, Int((d >> 8) & 0xff))
        if frame % Int64(n) != 0 { return nil }
        lock.lock(); defer { lock.unlock() }
        for k in 0..<previewSlots {
            let s = (nextSlot + k) % previewSlots
            if slotState[s] == 0 {
                slotState[s] = 1; nextSlot = (s + 1) % previewSlots
                let lm = Int((d >> 16) & 0x1f)
                var layer = -1
                if mask >> previewSoloBase != 0 && lm != 0 {
                    for k in 1...5 { let l = (soloRR + k) % 5; if lm & (1 << l) != 0 { layer = l; break } }
                    soloRR = max(0, layer)
                }
                return (s, mask, layer)
            }
        }
        droppedBusy += 1
        return nil
    }

    /// Metal completion handler of a frame that carried a preview dispatch. Never waits.
    func gpuDone(slot: Int, mask: Int, layer: Int, ok: Bool) {
        lock.lock()
        if !ok || encoding || job != nil {
            slotState[slot] = 0
            if ok { droppedBusy += 1 }
            lock.unlock()
            return
        }
        slotState[slot] = 2
        job = (slot, mask, layer)
        lock.unlock()
        jobSem.signal()
    }

    // MARK: preview thread

    func startEncoder() {
        let t = Thread { [self] in self.encodeLoop() }
        t.name = "preview-jpeg"
        t.qualityOfService = .utility                 // below the render (user-interactive) and status threads
        t.start()
    }

    private func encodeLoop() {
        let cs = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        let info = CGBitmapInfo(rawValue: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.noneSkipFirst.rawValue)  // bytes B G R A
        let props = [kCGImageDestinationLossyCompressionQuality as String: 0.6] as CFDictionary
        func jpeg(_ p: UnsafeMutableRawPointer, _ w: Int, _ h: Int) -> Data? {
            guard let provider = CGDataProvider(dataInfo: nil, data: p, size: w * h * 4, releaseData: { _, _, _ in }),
                  let img = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4, space: cs,
                                    bitmapInfo: info, provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent) else { return nil }
            let out = NSMutableData()
            guard let dst = CGImageDestinationCreateWithData(out as CFMutableData, "public.jpeg" as CFString, 1, nil) else { return nil }
            CGImageDestinationAddImage(dst, img, props)
            return CGImageDestinationFinalize(dst) ? out as Data : nil
        }
        // Warm ImageIO's JPEG encoder once here (first use loads its plugin), not when the first client connects.
        let warm = UnsafeMutableRawPointer.allocate(byteCount: 16 * 9 * 4, alignment: 16)
        memset(warm, 0, 16 * 9 * 4)
        let tw = nowTicks()
        _ = jpeg(warm, 16, 9)
        warm.deallocate()
        olog(String(format: "preview: JPEG encoder warmed in %.1f ms", ticksToSec(nowTicks() &- tw) * 1000))

        while true {
            if jobSem.wait(timeout: .now() + 1) == .timedOut { continue }
            lock.lock()
            guard let j = job else { lock.unlock(); continue }
            job = nil
            encoding = true
            lock.unlock()

            var results: [Data?] = Array(repeating: nil, count: previewAllWidths.count)
            let t0 = nowTicks()
            for si in 0..<previewAllWidths.count where j.mask & (1 << si) != 0 {
                let w = previewAllWidths[si]
                results[si] = jpeg(bufs[si][j.slot].contents(), w, previewHeight(w))
            }
            let ms = ticksToSec(nowTicks() &- t0) * 1000
            let now = nowTicks()

            lock.lock()
            encoding = false
            slotState[j.slot] = 0
            gen += 1
            for si in 0..<results.count { if let d = results[si] { latest[si] = (gen, d, now); latestLayer[si] = si >= previewSoloBase ? j.layer : -1 } }
            jobsTotal += 1
            encSum += ms; encN += 1
            let wfd = wakeFd
            lock.unlock()
            if wfd >= 0 { var b: UInt8 = 1; _ = write(wfd, &b, 1) }   // non-blocking pipe: a full pipe already means "wake"
        }
    }

    // MARK: server thread

    func setWake(_ fd: Int32) { lock.lock(); wakeFd = fd; listening = true; lock.unlock() }

    func latestFrames() -> [(gen: Int64, data: Data, ticks: UInt64)?] { lock.lock(); defer { lock.unlock() }; return latest }
    func latestLayers() -> [Int] { lock.lock(); defer { lock.unlock() }; return latestLayer }

    func addDroppedSlow() { lock.lock(); droppedSlow += 1; lock.unlock() }

    /// Server thread, whenever its clients change.
    func setDemand(mask: Int, maxFps: Double, outFps: Double, streamClients: Int, solo: Int) {
        let n = mask == 0 ? 0 : max(1, min(255, Int((outFps / max(1, maxFps)).rounded())))
        let sm = mask >> previewSoloBase == 0 ? 0 : solo & 0x1f
        lock.lock(); clients = streamClients; sizeMask = mask; soloMask = sm; lock.unlock()
        oats_store_u64(demand, UInt64(mask & 0xff) | (UInt64(n) << 8) | (UInt64(sm) << 16))
    }

    // MARK: status

    /// For status.json (status thread, about once per second): fps is measured since the previous call.
    func statusDict() -> [String: Any] {
        lock.lock()
        let now = nowTicks()
        let dt = sampleTicks == 0 ? 0 : ticksToSec(now &- sampleTicks)
        if dt > 0.2 { sampleFps = Double(jobsTotal - sampleJobs) / dt }
        if sampleTicks == 0 || dt > 0.2 { sampleTicks = now; sampleJobs = jobsTotal }
        let fps = sampleFps
        let avg = encN > 0 ? encSum / Double(encN) : 0
        if encN >= 30 { encSum = avg; encN = 1 }           // keep it a recent average (about the last second)
        let d = oats_load_u64(demand)
        let out: [String: Any] = [
            "listening": listening,
            "port": Int(previewPort),
            "clients": clients,
            "clients_max": previewMaxClients,
            "fps": (fps * 10).rounded() / 10,
            "size": previewWidths.indices.filter { sizeMask & (1 << $0) != 0 }.map { "\(previewWidths[$0])x\(previewHeight(previewWidths[$0]))" }.joined(separator: ","),
            "solo_layers": (0..<5).filter { soloMask & (1 << $0) != 0 },   // the GUI's PREVIEW monitors (?layer=n): 0 = BG, 1..4
            "solo_size": previewSoloWidths.indices.filter { sizeMask & (1 << (previewSoloBase + $0)) != 0 }.map { "\(previewSoloWidths[$0])x\(previewHeight(previewSoloWidths[$0]))" }.joined(separator: ","),
            "every_nth_frame": Int((d >> 8) & 0xff),
            "encode_ms_avg": (avg * 100).rounded() / 100,
            "frames": jobsTotal,
            "dropped": droppedBusy + droppedSlow,
            "dropped_busy": droppedBusy,
            "dropped_slow_client": droppedSlow,
            "rejected": rejected,
        ]
        lock.unlock()
        return out
    }

    func addRejected() { lock.lock(); rejected += 1; lock.unlock() }
}

let gPreview = PreviewHub()

// MARK: - HTTP server (BSD sockets, one thread, poll)

final class PreviewServer {
    private final class Client {
        enum State { case reading, streaming, waitingFrame, sending }
        let fd: Int32
        let peer: String
        var state = State.reading
        var inBuf = [UInt8]()
        var out = Data()
        var outOff = 0
        var closeWhenFlushed = false
        var size = previewDefaultSizeIndex
        var layer = -1                                // ?layer=n: the PREVIEW monitor (one layer by itself), else -1 = program
        var fps = 30.0
        var cors = ""                                 // "Access-Control-Allow-Origin: <the GUI page>\r\nVary: Origin\r\n" or ""
        var credit = 1.0
        var lastFrameTicks: UInt64 = 0
        var lastGen: Int64 = 0
        var opened = nowTicks()
        var lastProgress = nowTicks()
        var frames: Int64 = 0
        var dropped: Int64 = 0
        init(fd: Int32, peer: String) { self.fd = fd; self.peer = peer }
    }

    private let outFps: Double
    private var socks: BoundSockets! = nil                // 127.0.0.1 + en0's address (never 0.0.0.0), re-bound when en0 changes
    private var wakeR: Int32 = -1
    private var clients: [Client] = []
    private let filter: SourceFilter
    private let rejects: RejectLog
    private let limiterHost = LogLimiter(perSecond: 2)

    init(outFps: Double, filter: SourceFilter) {
        self.outFps = outFps
        self.filter = filter
        rejects = RejectLog("preview", key: "preview.rejected", filter: filter)
    }

    /// Binds 127.0.0.1:8091 and en0's address:8091 and starts the thread. On failure it logs and the player runs
    /// without a preview.
    func start() {
        socks = BoundSockets(port: Int(previewPort), what: "preview", key: "preview", loopback: true, tcp: true)
        guard socks.open() else {
            olog("preview: cannot listen on TCP 127.0.0.1:\(previewPort): preview disabled, the player runs on")
            return
        }
        var p: [Int32] = [-1, -1]
        guard pipe(&p) == 0 else { olog("preview: pipe() failed: preview disabled"); return }
        for f in p { _ = fcntl(f, F_SETFL, fcntl(f, F_GETFL) | O_NONBLOCK) }
        wakeR = p[0]
        gPreview.setWake(p[1])
        gPreview.startEncoder()
        let t = Thread { [self] in self.run() }
        t.name = "preview-http"
        t.qualityOfService = .utility
        t.start()
        olog("preview: MJPEG on \(socks.boundText.map { "http://" + $0 }.joined(separator: ", ")) /preview.mjpg (?w=160|256|320|640|960|1920, ?fps=10..30 (960/1920 capped at 20); default 256x144 at 30 fps), /preview.jpg; max \(previewMaxClients) stream clients")
    }

    private var streamCount: Int { clients.reduce(0) { $0 + ($1.state == .streaming ? 1 : 0) } }

    private func updateDemand() {
        var mask = 0, maxFps = 0.0, solo = 0
        for c in clients where c.state == .streaming || c.state == .waitingFrame {
            mask |= 1 << c.size
            maxFps = max(maxFps, c.state == .waitingFrame ? 30 : c.fps)
            if c.layer >= 0 { solo |= 1 << c.layer }  // every layer a PREVIEW client wants (they take turns)
        }
        gPreview.setDemand(mask: mask, maxFps: maxFps, outFps: outFps, streamClients: streamCount, solo: solo)
    }

    private func drop(_ c: Client, _ why: String) {
        close(c.fd)
        clients.removeAll { $0 === c }
        if c.state == .streaming {
            olog("preview client disconnected \(c.peer) (\(why); \(c.frames) frames sent, \(c.dropped) dropped) (stream clients \(streamCount))")
        }
        updateDemand()
    }

    private func run() {
        var fds: [pollfd] = []
        while true {
            socks.refresh()                                   // en0 appeared / changed: re-bind (at most every 5 s)
            let lfds = socks.fds
            fds.removeAll(keepingCapacity: true)
            fds.append(pollfd(fd: wakeR, events: Int16(POLLIN), revents: 0))
            for l in lfds { fds.append(pollfd(fd: l, events: Int16(POLLIN), revents: 0)) }
            let base = 1 + lfds.count
            for c in clients {
                var ev = Int16(POLLIN)
                if c.outOff < c.out.count { ev |= Int16(POLLOUT) }
                fds.append(pollfd(fd: c.fd, events: ev, revents: 0))
            }
            let n = poll(&fds, nfds_t(fds.count), 100)
            if n < 0 && errno != EINTR { usleep(50_000); continue }
            let snapshot = clients                                // fds[base...] follow this order
            if fds[0].revents != 0 {
                var junk = [UInt8](repeating: 0, count: 64)
                while read(wakeR, &junk, junk.count) > 0 {}
                distribute()
            }
            for (i, c) in snapshot.enumerated() {
                guard clients.contains(where: { $0 === c }) else { continue }
                let re = fds[i + base].revents
                if re & Int16(POLLIN | POLLHUP | POLLERR) != 0 { readFrom(c) }
                guard clients.contains(where: { $0 === c }) else { continue }
                if re & Int16(POLLOUT) != 0 { flush(c) }
            }
            for (k, l) in lfds.enumerated() where fds[1 + k].revents & Int16(POLLIN) != 0 { acceptAll(l) }
            housekeeping()
        }
    }

    private func acceptAll(_ listenFd: Int32) {
        while true {
            var sa = sockaddr_in()
            var len = socklen_t(MemoryLayout<sockaddr_in>.size)
            let fd = withUnsafeMutablePointer(to: &sa) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { accept(listenFd, $0, &len) } }
            if fd < 0 { return }
            if !filter.allows(sa.sin_addr) {                  // not on an allowed network: minimal 403, then close
                gPreview.addRejected()
                rejects.note(sa.sin_addr, "first connection from \(sockaddrString(sa))")
                var one: Int32 = 1
                setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, socklen_t(MemoryLayout<Int32>.size))
                _ = fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK)
                let body = "VJ VIZZIES preview is only available on the lighting network\n"
                let msg = Array(("HTTP/1.1 403 Forbidden\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: \(body.utf8.count)\r\n" +
                                 "Connection: close\r\n\r\n" + body).utf8)
                _ = msg.withUnsafeBytes { write(fd, $0.baseAddress, $0.count) }   // fresh socket: fits the send buffer
                close(fd)
                continue
            }
            if clients.count >= 16 { close(fd); continue }   // connection flood: refuse outright
            _ = fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK)
            var one: Int32 = 1
            setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, socklen_t(MemoryLayout<Int32>.size))
            setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, socklen_t(MemoryLayout<Int32>.size))
            var sndbuf: Int32 = 1024 * 1024                   // a whole frame fits (a 1080p JPEG too): partial writes stay rare
            setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, socklen_t(MemoryLayout<Int32>.size))
            clients.append(Client(fd: fd, peer: sockaddrString(sa)))
        }
    }

    private func readFrom(_ c: Client) {
        var buf = [UInt8](repeating: 0, count: 4096)
        let r = read(c.fd, &buf, buf.count)
        if r == 0 { drop(c, "closed by client"); return }
        if r < 0 {
            if errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR { return }
            drop(c, "read error: \(String(cString: strerror(errno)))"); return
        }
        guard c.state == .reading else { return }             // after the request: ignore what the client sends
        c.inBuf.append(contentsOf: buf[0..<r])
        if c.inBuf.count > 8192 { reply(c, "431 Request Header Fields Too Large", "request too large\n"); return }
        let crlf2: [UInt8] = [13, 10, 13, 10]
        guard c.inBuf.count >= 4, (0...(c.inBuf.count - 4)).contains(where: { Array(c.inBuf[$0..<($0 + 4)]) == crlf2 }) else { return }
        handleRequest(c)
    }

    private func handleRequest(_ c: Client) {
        let head = String(decoding: c.inBuf, as: UTF8.self)
        let line = head.split(separator: "\r\n", maxSplits: 1, omittingEmptySubsequences: false).first.map(String.init) ?? ""
        let parts = line.split(separator: " ").map(String.init)
        guard parts.count >= 2 else { reply(c, "400 Bad Request", "bad request\n"); return }
        guard parts[0] == "GET" else { reply(c, "405 Method Not Allowed", "GET only\n"); return }
        var hostHdr: String? = nil, originHdr: String? = nil
        for l in head.split(separator: "\r\n").dropFirst() {
            guard let ci = l.firstIndex(of: ":") else { continue }
            let k = l[..<ci].trimmingCharacters(in: .whitespaces).lowercased(), v = l[l.index(after: ci)...].trimmingCharacters(in: .whitespaces)
            if k == "host" { hostHdr = v } else if k == "origin" { originHdr = v }
        }
        // DNS rebinding: only requests that name this Mac (localhost, 127.0.0.1, en0's address, <name>.local)
        guard HostCheck.shared.allowsHost(hostHdr, port: Int(previewPort)) else {
            gPreview.addRejected()
            limiterHost.log("preview: 403 for Host '\(String((hostHdr ?? "(none)").prefix(80)))' from \(c.peer) (allowed: \(HostCheck.shared.namesText))")
            reply(c, "403 Forbidden", "wrong Host header\n"); return
        }
        if let o = HostCheck.shared.allowedOrigin(originHdr) { c.cors = "Access-Control-Allow-Origin: \(o)\r\nVary: Origin\r\n" }
        let target = parts[1]
        let path = String(target.split(separator: "?", maxSplits: 1).first ?? "")
        var q: [String: String] = [:]
        if let qi = target.firstIndex(of: "?") {
            for kv in target[target.index(after: qi)...].split(separator: "&") {
                let p = kv.split(separator: "=", maxSplits: 1).map(String.init)
                if p.count == 2 { q[p[0]] = p[1] }
            }
        }
        if let ws = q["w"], let w = Int(ws) {                 // nearest supported width
            c.size = previewWidths.indices.min(by: { abs(previewWidths[$0] - w) < abs(previewWidths[$1] - w) }) ?? previewDefaultSizeIndex
        }
        if let ls = q["layer"], let l = Int(ls), (0...4).contains(l) {   // PREVIEW monitor: layer l by itself, 320 or 480 wide
            c.layer = l
            let w = Int(q["w"] ?? "") ?? 320
            c.size = previewSoloBase + (previewSoloWidths.indices.min(by: { abs(previewSoloWidths[$0] - w) < abs(previewSoloWidths[$1] - w) }) ?? 0)
        }
        if let fs = q["fps"], let f = Double(fs), f.isFinite { c.fps = min(30, max(10, f)) }
        if previewAllWidths[c.size] >= 960 { c.fps = min(c.fps, 20) }   // big JPEGs: cap the encode cost (utility thread)
        let w = previewAllWidths[c.size], h = previewHeight(w)
        switch path {
        case "/audio.json":                                    // audio react meter for the GUI (audio.swift; polled <= 30 Hz)
            let body = gAudio.meterJSON()
            let wasDemand = c.state == .streaming || c.state == .waitingFrame
            c.state = .sending
            c.closeWhenFlushed = true
            queue(c, Data(("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: \(body.utf8.count)\r\nCache-Control: no-cache\r\n" +
                           c.cors + "Connection: close\r\n\r\n" + body).utf8))
            if wasDemand { updateDemand() }
        case "/preview.mjpg":
            if streamCount >= previewMaxClients {
                reply(c, "503 Service Unavailable", "too many preview clients (max \(previewMaxClients))\n"); return
            }
            c.state = .streaming
            c.lastGen = gPreview.latestFrames()[c.size]?.gen ?? 0  // start with the next fresh frame
            queue(c, Data(("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=oatsframe\r\n" +
                           "Cache-Control: no-cache\r\nPragma: no-cache\r\n" + c.cors + "Connection: close\r\n\r\n").utf8))
            updateDemand()
            olog("preview client connected \(c.peer) \(target.count > 80 ? String(target.prefix(80)) : target) -> \(w)x\(h) at up to \(Int(c.fps)) fps (stream clients \(streamCount))")
        case "/preview.jpg":
            if let f = gPreview.latestFrames()[c.size], ticksToSec(nowTicks() &- f.ticks) < 0.1, gPreview.latestLayers()[c.size] == c.layer || c.layer < 0 {
                sendJPEG(c, f.data)
            } else {
                c.state = .waitingFrame
                c.lastGen = gPreview.latestFrames()[c.size]?.gen ?? 0
                c.opened = nowTicks()
                updateDemand()
            }
        default:
            reply(c, "404 Not Found", "oats-m0 preview: GET /preview.mjpg[?w=160|256|320|640|960|1920&fps=10..30] or /preview.jpg[?w=...]; one layer by itself: ?layer=0..4&w=320|480\n")
        }
    }

    private func sendJPEG(_ c: Client, _ d: Data) {
        let wasWaiting = c.state == .waitingFrame
        c.state = .sending
        var o = Data(("HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nContent-Length: \(d.count)\r\nCache-Control: no-cache\r\n" +
                      c.cors + "Connection: close\r\n\r\n").utf8)
        o.append(d)
        c.closeWhenFlushed = true
        queue(c, o)
        if wasWaiting { updateDemand() }
    }

    private func reply(_ c: Client, _ status: String, _ body: String) {
        let wasDemand = c.state == .streaming || c.state == .waitingFrame
        c.state = .sending
        c.closeWhenFlushed = true
        queue(c, Data(("HTTP/1.1 \(status)\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: \(body.utf8.count)\r\n" +
                       c.cors + "Connection: close\r\n\r\n" + body).utf8))
        if wasDemand { updateDemand() }
    }

    private func queue(_ c: Client, _ d: Data) {
        if c.outOff >= c.out.count { c.out = d; c.outOff = 0 } else { c.out.append(d) }
        c.lastProgress = nowTicks()
        flush(c)
    }

    private func flush(_ c: Client) {
        while c.outOff < c.out.count {
            let off = c.outOff, cnt = c.out.count - c.outOff
            let r = c.out.withUnsafeBytes { p in write(c.fd, p.baseAddress! + off, cnt) }
            if r > 0 { c.outOff += r; c.lastProgress = nowTicks(); continue }
            if r < 0 && errno == EINTR { continue }
            if r < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) { return }
            drop(c, "write error: \(String(cString: strerror(errno)))"); return
        }
        c.out = Data(); c.outOff = 0
        if c.closeWhenFlushed { drop(c, "done") }
    }

    /// New JPEGs from the preview thread: one part per stream client (unless its socket still holds the last one).
    private func distribute() {
        let frames = gPreview.latestFrames(), layers = gPreview.latestLayers()
        let now = nowTicks()
        for c in clients {
            guard let f = frames[c.size], f.gen > c.lastGen else { continue }
            if c.layer >= 0 && layers[c.size] != c.layer { continue }   // a solo frame of another layer (just switched)
            switch c.state {
            case .waitingFrame:
                c.lastGen = f.gen
                sendJPEG(c, f.data)
            case .streaming:
                c.lastGen = f.gen
                c.credit = c.lastFrameTicks == 0 ? 1 : min(2, c.credit + ticksToSec(now &- c.lastFrameTicks) * c.fps)
                c.lastFrameTicks = now
                if c.credit < 0.9 { continue }                // client asked for fewer fps than we produce
                if c.outOff < c.out.count { c.dropped += 1; gPreview.addDroppedSlow(); continue }
                c.credit -= 1
                c.frames += 1
                var o = Data("--oatsframe\r\nContent-Type: image/jpeg\r\nContent-Length: \(f.data.count)\r\n\r\n".utf8)
                o.append(f.data)
                o.append(contentsOf: [13, 10])
                queue(c, o)
            default:
                continue
            }
        }
    }

    private func housekeeping() {
        let now = nowTicks()
        for c in clients {
            switch c.state {
            case .reading where ticksToSec(now &- c.opened) > 5:
                drop(c, "no request in 5 s")
            case .waitingFrame where ticksToSec(now &- c.opened) > 2:
                reply(c, "503 Service Unavailable", "no preview frame within 2 s\n")
            default:
                if c.outOff < c.out.count && ticksToSec(now &- c.lastProgress) > 5 { drop(c, "stalled: socket took nothing for 5 s") }
            }
        }
    }
}
