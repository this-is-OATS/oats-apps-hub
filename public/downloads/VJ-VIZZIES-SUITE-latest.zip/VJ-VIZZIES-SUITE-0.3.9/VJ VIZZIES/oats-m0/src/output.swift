import Foundation
import AppKit
import Metal
import QuartzCore
import CoreText
import ImageIO

// Output window (2026-10-22): a borderless full-screen window on one NSScreen (HDMI to an LED processor or a
// projector, next to NDI). It shows the very frame NDI gets: the render loop hands over the index of the UYVY
// buffer it is about to send (one lock + one semaphore signal, nothing else on the render thread), and the
// "output" thread decodes that buffer with a cheap scale pass (fill / fit / 1:1) into a CAMetalLayer drawable
// and presents it with displaySyncEnabled. It never waits for the screen: when a newer frame arrives first, or
// two presents are still queued, or no drawable is free, that present is skipped and counted (status.json output).
// The window exists only while a display is set; the process runs NSApp in accessory mode (no Dock icon).
//
// Screens are numbered 1..n in NSScreen order (1 = the main display, with the menu bar). The main display is
// excluded while another display is connected, so the output can never cover the operator's desktop by mistake;
// when it is the only display it can be used (the smoke test does that for 2 s).

struct OutScreen {
    var index = 0, name = "", w = 0, h = 0, hz = 0, main = false, scale = 1.0
    var dict: [String: Any] { ["index": index, "name": name, "resolution": "\(w)x\(h)", "hz": hz, "main": main, "scale": scale] }
}

enum OutFit: String, CaseIterable { case fill, fit, one = "1:1" }

private let outputShaderSource = """
#include <metal_stdlib>
using namespace metal;
// One instance per slice (mapping.swift): a quad at the slice's destination rect (drawable px); the fragment maps its
// local position (flip, then rotation) into the slice's source rect on the canvas and samples there.
struct SliceG { float4 dst; float4 src; float4 m; };   // m: rot (0..3 = 0/90/180/270 cw), flip h, flip v, 0
struct OutP { float4 a; };                             // a: canvas w, canvas h, mode (0 frame, 1 display test, 2 canvas test), 0
struct VOut { float4 pos [[position]]; float2 uv; float4 src; float4 m; };
vertex VOut out_vs(uint vid [[vertex_id]], uint iid [[instance_id]], constant SliceG* S [[buffer(0)]], constant float4& D [[buffer(1)]]) {
    float2 c = float2((vid == 1u || vid == 2u || vid == 4u) ? 1.0 : 0.0, (vid == 2u || vid == 4u || vid == 5u) ? 1.0 : 0.0);
    SliceG g = S[iid];
    float2 px = g.dst.xy + c * g.dst.zw;
    VOut o; o.pos = float4(px.x / D.x * 2.0 - 1.0, 1.0 - px.y / D.y * 2.0, 0.0, 1.0);
    o.uv = c; o.src = g.src; o.m = g.m; return o;
}
static float3 uyvy(const device uchar4* buf, int x, int y, int w, int h) {
    x = clamp(x, 0, w - 1); y = clamp(y, 0, h - 1);
    uchar4 q = buf[y * (w / 2) + x / 2];
    float Y = (x & 1) ? float(q.w) : float(q.y);
    float U = float(q.x) - 128.0, V = float(q.z) - 128.0;
    float yy = 1.164383 * (Y - 16.0);                        // BT.709 video range, as the snapshot decodes it
    return saturate(float3(yy + 1.792741 * V, yy - 0.213249 * U - 0.532909 * V, yy + 2.112402 * U) / 255.0);
}
fragment float4 out_fs(VOut in [[stage_in]], const device uchar4* buf [[buffer(0)]], constant OutP& P [[buffer(1)]],
                       texture2d<float, access::read> tt [[texture(0)]], texture2d<float, access::sample> ct [[texture(1)]]) {
    uint mode = uint(P.a.z + 0.5);
    if (mode == 1u) {                                        // display test pattern: drawable pixels, no mapping
        uint2 ip = uint2(in.pos.xy);
        if (ip.x >= tt.get_width() || ip.y >= tt.get_height()) return float4(0, 0, 0, 1);
        return float4(tt.read(ip).rgb, 1.0);
    }
    float2 u = clamp(in.uv, 0.0, 1.0);
    if (in.m.y > 0.5) u.x = 1.0 - u.x;
    if (in.m.z > 0.5) u.y = 1.0 - u.y;
    uint r = uint(in.m.x + 0.5) & 3u;
    float2 st = r == 0u ? u : (r == 1u ? float2(u.y, 1.0 - u.x) : (r == 2u ? 1.0 - u : float2(1.0 - u.y, u.x)));
    float2 sp = in.src.xy + st * in.src.zw;                  // canvas px
    if (sp.x < 0.0 || sp.y < 0.0 || sp.x >= P.a.x || sp.y >= P.a.y) return float4(0, 0, 0, 1);
    if (mode == 2u) {                                        // cabinet test pattern, in canvas px
        constexpr sampler s(coord::pixel, filter::linear, address::clamp_to_edge);
        return float4(ct.sample(s, sp).rgb, 1.0);
    }
    int w = int(P.a.x), h = int(P.a.y);
    float2 c = sp - 0.5;
    int2 i = int2(floor(c));
    float2 f = c - floor(c);
    float3 a = mix(uyvy(buf, i.x, i.y, w, h), uyvy(buf, i.x + 1, i.y, w, h), f.x);
    float3 b = mix(uyvy(buf, i.x, i.y + 1, w, h), uyvy(buf, i.x + 1, i.y + 1, w, h), f.x);
    return float4(mix(a, b, f.y), 1.0);
}
"""

final class OutputWindow {
    private let lock = NSLock()
    // requested state (OSC / --output-display), read on the main thread
    private var requested = 0
    private var fit: OutFit = .fit
    private var test = 0                               // 0 off, 1 display test pattern, 2 cabinet grid (canvas, through the slices)
    private var snapReq = false                        // /oats/output/snapshot: the next presented frame also goes to a PNG
    private var snapInfo: [String: Any] = [:]
    // shown state
    private var screens: [OutScreen] = []
    private var shown = 0                              // display index on air (0 = off)
    private var size = (0, 0)                          // drawable pixels
    private var hz = 0
    private var presented: Int64 = 0, skipped: Int64 = 0
    private var note = "off"
    private var active = false                         // a layer is on screen: the render loop hands frames over
    private var pending = -1                           // UYVY buffer index waiting for the output thread
    private var queued = 0                             // presents scheduled, not yet on screen
    private var layer: CAMetalLayer? = nil
    private var layerGen = 0                           // bumps when the layer, its size or the screen change
    private let sem = DispatchSemaphore(value: 0)
    // Metal (set by attach)
    private var dev: MTLDevice? = nil
    private var bufs: [MTLBuffer] = []
    private var srcW = 1920, srcH = 1080
    // main thread only
    private var window: NSWindow? = nil
    private var observing = false

    // MARK: render thread (cheap)

    /// The UYVY buffer `bi` is complete and is being sent to NDI now.
    @inline(__always) func frameReady(_ bi: Int) {
        lock.lock()
        if !active { lock.unlock(); return }
        if pending >= 0 { skipped += 1 }               // the output thread had not taken the previous one
        pending = bi
        lock.unlock()
        sem.signal()
    }

    // MARK: setup

    func attach(dev: MTLDevice, bufs: [MTLBuffer], w: Int, h: Int) {
        self.dev = dev; self.bufs = bufs; srcW = w; srcH = h
        let t = Thread { [self] in self.run() }
        t.name = "output"
        t.qualityOfService = .userInitiated              // below the render thread (user-interactive)
        t.start()
    }

    /// Main thread, once NSApp is set up.
    func startMain(initial: Int) {
        if !observing {
            observing = true
            NotificationCenter.default.addObserver(forName: NSApplication.didChangeScreenParametersNotification, object: nil, queue: .main) { [weak self] _ in
                olog("output: screen configuration changed")
                self?.apply()
            }
        }
        lock.lock(); requested = initial; lock.unlock()
        apply()
    }

    // MARK: OSC (any thread)

    func setDisplay(_ n: Int) -> String {
        lock.lock(); requested = max(0, n); lock.unlock()
        DispatchQueue.main.async { self.apply() }
        return n <= 0 ? "output window off" : "output window -> display \(n)"
    }
    func setFit(_ f: OutFit) -> String {
        lock.lock(); fit = f; layerGen += 1; lock.unlock()
        return "output fit \(f.rawValue)"
    }
    func setTest(_ v: Int) -> String {
        let t = min(2, max(0, v))
        lock.lock(); test = t; layerGen += 1; lock.unlock()
        return t == 0 ? "output test pattern off" : (t == 1 ? "output test pattern ON (display grid)" : "output test pattern ON (cabinet grid through the slices)")
    }
    func requestSnapshot() -> String {
        lock.lock(); let on = shown > 0; if on { snapReq = true }; lock.unlock()
        return on ? "output window snapshot requested (logs/output-snapshot.png)" : "output window is off: no snapshot"
    }
    /// The drawable size on air (0 x 0 = off) and the fit (mapping.swift: the default slice).
    func sizeAndFit() -> (w: Int, h: Int, fit: OutFit, display: Int) {
        lock.lock(); defer { lock.unlock() }
        return (shown > 0 ? size.0 : 0, shown > 0 ? size.1 : 0, fit, shown > 0 ? shown : requested)
    }

    func statusDict() -> [String: Any] {
        lock.lock()
        let disp = shown > 0 ? shown : requested, sz = size, f = fit, scr = screens
        var d: [String: Any] = ["display": shown, "requested": requested, "size": shown > 0 ? "\(size.0)x\(size.1)" : "", "hz": shown > 0 ? hz : 0,
                "fit": fit.rawValue, "test": test, "presented": presented, "skipped": skipped, "note": note,
                "fits": OutFit.allCases.map { $0.rawValue }, "snapshot": snapInfo]
        lock.unlock()
        let aw = gAwake.dict
        d["awake"] = aw.0
        if !aw.1.isEmpty { d["awake_error"] = aw.1 }
        let explicit = disp > 0 ? gMapping.slices(display: disp) : []
        var dw = sz.0, dh = sz.1
        if sz.0 == 0 || d["display"] as? Int == 0, disp > 0, disp <= scr.count { dw = scr[disp - 1].w; dh = scr[disp - 1].h }
        let eff = explicit.isEmpty ? (dw > 0 ? [MappingStore.defaultSlice(dispW: dw, dispH: dh, fit: f)] : []) : explicit
        d["slices"] = eff.map { $0.dict }
        d["slices_default"] = explicit.isEmpty
        d["canvas"] = "\(gCanvasW)x\(gCanvasH)"
        return d
    }
    func screensList() -> [[String: Any]] { lock.lock(); defer { lock.unlock() }; return screens.map { $0.dict } }

    // MARK: main thread: window

    private func readScreens() -> [OutScreen] {
        let main = NSScreen.screens.first
        return NSScreen.screens.enumerated().map { (i, s) in
            let sc = Double(s.backingScaleFactor)
            var o = OutScreen()
            o.index = i + 1; o.name = s.localizedName; o.scale = sc; o.main = s == main
            o.w = Int((Double(s.frame.width) * sc).rounded()); o.h = Int((Double(s.frame.height) * sc).rounded())
            if #available(macOS 12.0, *) { o.hz = s.maximumFramesPerSecond }
            return o
        }
    }

    private func apply() {
        let list = readScreens()
        lock.lock(); let req = requested; let wasShown = shown; screens = list; lock.unlock()
        gAwake.set(req > 0, why: "display \(req)")             // no display sleep / idle sleep while an output display is set
        func off(_ why: String) {
            window?.orderOut(nil)
            lock.lock(); active = false; layer = nil; pending = -1; shown = 0; note = why; layerGen += 1; lock.unlock()
            if wasShown != 0 { olog("output window hidden (\(why))") }
        }
        if req == 0 { off("off"); return }
        guard req <= list.count else { off("display \(req) is not connected (\(list.count) screen\(list.count == 1 ? "" : "s"))"); return }
        let info = list[req - 1]
        if info.main && list.count > 1 { off("display \(req) is the main display (menu bar): excluded while another display is connected"); return }
        let scr = NSScreen.screens[req - 1]
        guard let d = dev else { off("no Metal device"); return }
        let win: NSWindow
        let ml: CAMetalLayer
        if let w = window, let l = w.contentView?.layer as? CAMetalLayer {
            win = w; ml = l
            win.setFrame(scr.frame, display: false)
        } else {
            win = NSWindow(contentRect: scr.frame, styleMask: [.borderless], backing: .buffered, defer: false)
            win.setFrame(scr.frame, display: false)
            win.title = "VJ VIZZIES Output"
            win.level = .screenSaver
            win.collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle, .fullScreenAuxiliary]
            win.isOpaque = true; win.backgroundColor = .black; win.hasShadow = false
            win.ignoresMouseEvents = true; win.isReleasedWhenClosed = false; win.animationBehavior = .none
            let v = NSView(frame: NSRect(origin: .zero, size: scr.frame.size))
            ml = CAMetalLayer()
            ml.device = d; ml.pixelFormat = .bgra8Unorm; ml.framebufferOnly = true
            ml.displaySyncEnabled = true; ml.maximumDrawableCount = 3; ml.allowsNextDrawableTimeout = true
            ml.isOpaque = true; ml.backgroundColor = CGColor(gray: 0, alpha: 1)
            v.layer = ml; v.wantsLayer = true
            win.contentView = v
            window = win
        }
        ml.contentsScale = scr.backingScaleFactor
        ml.drawableSize = CGSize(width: info.w, height: info.h)
        win.orderFrontRegardless()
        lock.lock()
        let changed = shown != req
        if changed { presented = 0; skipped = 0 }
        layer = ml; active = true; shown = req; size = (info.w, info.h); hz = info.hz; layerGen += 1; queued = 0
        note = "on display \(req) \(info.name) \(info.w)x\(info.h)"
        lock.unlock()
        if changed { olog("output window on display \(req) '\(info.name)' \(info.w)x\(info.h)@\(info.hz)Hz\(info.main ? " (main display: the only screen)" : "")") }
    }

    // MARK: output thread

    private func run() {
        guard let d = dev, let q = d.makeCommandQueue() else { olog("output: no command queue: output window disabled"); return }
        let pipe: MTLRenderPipelineState
        do {
            let lib = try d.makeLibrary(source: outputShaderSource, options: nil)
            let pd = MTLRenderPipelineDescriptor()
            pd.vertexFunction = lib.makeFunction(name: "out_vs")
            pd.fragmentFunction = lib.makeFunction(name: "out_fs")
            pd.colorAttachments[0].pixelFormat = .bgra8Unorm
            pipe = try d.makeRenderPipelineState(descriptor: pd)
        } catch { olog("output: shader FAILED: \(error): output window disabled"); return }
        let dd = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .bgra8Unorm, width: 1, height: 1, mipmapped: false)
        guard let dummy = d.makeTexture(descriptor: dd) else { return }
        var testTex: MTLTexture? = nil, testKey = ""
        var cabTex: MTLTexture? = nil, cabKey = ""
        while true {
            sem.wait()
            lock.lock()
            let idx = pending; pending = -1
            let l = layer, f = fit, tst = test, sz = size, disp = shown, qd = queued
            let name = disp > 0 && disp <= screens.count ? screens[disp - 1].name : "", rate = hz
            var snap = false
            if snapReq { snapReq = false; snap = true }
            lock.unlock()
            guard idx >= 0, idx < bufs.count, let ml = l, sz.0 > 0 else { continue }
            if qd >= 2 { lock.lock(); skipped += 1; lock.unlock(); continue }
            // slices (mapping.swift): the display's list, or the default one (whole canvas, output fit)
            let explicit = gMapping.slices(display: disp)
            let sl = (explicit.isEmpty ? [MappingStore.defaultSlice(dispW: sz.0, dispH: sz.1, fit: f)] : explicit).filter { $0.on }
            var tt: MTLTexture = dummy, ct: MTLTexture = dummy
            if tst == 1 {
                let key = "\(disp) \(sz.0)x\(sz.1) \(f.rawValue)"
                if key != testKey || testTex == nil {
                    testTex = makeTestPattern(d, w: sz.0, h: sz.1, screen: disp, name: name, hz: rate, fit: f)
                    testKey = key
                }
                if let t = testTex { tt = t }
            } else if tst == 2 {
                let cab = gMapping.cabinetSize
                let key = "\(disp) \(cab.0)x\(cab.1) " + sl.map { "\($0.src.array)\($0.name)" }.joined(separator: ";")
                if key != cabKey || cabTex == nil {
                    cabTex = makeCabinetPattern(d, cab: cab, slices: sl)
                    cabKey = key
                }
                if let t = cabTex { ct = t }
            }
            guard let drawable = ml.nextDrawable() else { lock.lock(); skipped += 1; lock.unlock(); continue }
            let dw = Float(drawable.texture.width), dh = Float(drawable.texture.height)
            var geo: [SIMD4<Float>] = []
            if tst == 1 {
                geo = [SIMD4<Float>(0, 0, dw, dh), SIMD4<Float>(0, 0, 1, 1), SIMD4<Float>(0, 0, 0, 0)]
            } else {
                for s in sl {
                    geo.append(SIMD4<Float>(Float(s.dst.x), Float(s.dst.y), Float(s.dst.w), Float(s.dst.h)))
                    geo.append(SIMD4<Float>(Float(s.src.x), Float(s.src.y), Float(s.src.w), Float(s.src.h)))
                    geo.append(SIMD4<Float>(Float(s.rot / 90), s.flipH ? 1 : 0, s.flipV ? 1 : 0, 0))
                }
            }
            var p = SIMD4<Float>(Float(srcW), Float(srcH), Float(tst), 0)
            var dsz = SIMD4<Float>(dw, dh, 0, 0)
            guard let cb = q.makeCommandBuffer() else { continue }
            func encodePass(_ target: MTLTexture) -> Bool {
                let rp = MTLRenderPassDescriptor()
                rp.colorAttachments[0].texture = target
                rp.colorAttachments[0].loadAction = .clear                       // black outside the slices
                rp.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 1)
                rp.colorAttachments[0].storeAction = .store
                guard let enc = cb.makeRenderCommandEncoder(descriptor: rp) else { return false }
                if !geo.isEmpty {
                    enc.setRenderPipelineState(pipe)
                    enc.setVertexBytes(geo, length: MemoryLayout<SIMD4<Float>>.stride * geo.count, index: 0)
                    enc.setVertexBytes(&dsz, length: MemoryLayout<SIMD4<Float>>.stride, index: 1)
                    enc.setFragmentBuffer(bufs[idx], offset: 0, index: 0)
                    enc.setFragmentBytes(&p, length: MemoryLayout<SIMD4<Float>>.stride, index: 1)
                    enc.setFragmentTexture(tt, index: 0)
                    enc.setFragmentTexture(ct, index: 1)
                    enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 6, instanceCount: geo.count / 3)
                }
                enc.endEncoding()
                return true
            }
            guard encodePass(drawable.texture) else { continue }
            if snap { encodeSnapshot(d, cb, w: Int(dw), h: Int(dh), disp: disp, slices: sl.count, encodePass) }
            lock.lock(); queued += 1; lock.unlock()
            // Count it off when the GPU has finished the frame. The drawable's presented handler never fired on
            // this accessory-app window, so `queued` stuck at 2 and every later frame was skipped (a frozen still).
            cb.addCompletedHandler { [weak self] _ in
                guard let self = self else { return }
                self.lock.lock(); self.queued = max(0, self.queued - 1); self.presented += 1; self.lock.unlock()
            }
            cb.present(drawable)
            cb.commit()
        }
    }

    /// /oats/output/snapshot: the same pass into an offscreen texture, copied to a shared buffer, written as
    /// logs/output-snapshot.png off the output thread (the drawable itself is framebuffer-only).
    private func encodeSnapshot(_ d: MTLDevice, _ cb: MTLCommandBuffer, w: Int, h: Int, disp: Int, slices: Int, _ pass: (MTLTexture) -> Bool) {
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .bgra8Unorm, width: w, height: h, mipmapped: false)
        td.usage = [.renderTarget]; td.storageMode = .private
        guard let t = d.makeTexture(descriptor: td), let buf = d.makeBuffer(length: w * h * 4, options: .storageModeShared), pass(t),
              let blit = cb.makeBlitCommandEncoder() else { olog("output snapshot: allocation failed"); return }
        blit.copy(from: t, sourceSlice: 0, sourceLevel: 0, sourceOrigin: MTLOrigin(x: 0, y: 0, z: 0), sourceSize: MTLSize(width: w, height: h, depth: 1),
                  to: buf, destinationOffset: 0, destinationBytesPerRow: w * 4, destinationBytesPerImage: w * h * 4)
        blit.endEncoding()
        let dir = gLogDir
        cb.addCompletedHandler { [weak self] _ in
            DispatchQueue.global(qos: .utility).async {
                let final = (dir as NSString).appendingPathComponent("output-snapshot.png"), tmp = final + ".tmp.png"
                var ok = false
                if let prov = CGDataProvider(data: Data(bytes: buf.contents(), count: w * h * 4) as CFData),
                   let img = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                     bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue),
                                     provider: prov, decode: nil, shouldInterpolate: false, intent: .defaultIntent),
                   let dst = CGImageDestinationCreateWithURL(URL(fileURLWithPath: tmp) as CFURL, "public.png" as CFString, 1, nil) {
                    CGImageDestinationAddImage(dst, img, nil)
                    ok = CGImageDestinationFinalize(dst) && rename(tmp, final) == 0
                }
                olog(ok ? "output snapshot written \(final) (\(w)x\(h), display \(disp), \(slices) slice(s))" : "output snapshot FAILED writing \(final)")
                guard let self = self else { return }
                self.lock.lock(); self.snapInfo = ["path": final, "unix": Date().timeIntervalSince1970, "ok": ok, "size": "\(w)x\(h)"]; self.lock.unlock()
            }
        }
    }

    /// Output test 2: the cabinet grid in canvas pixels (it goes through the slices like the show): cabinets numbered
    /// column-row from the canvas top-left, alternating colours, a diagonal top-left -> bottom-right per cabinet, the
    /// slice source outlines with their numbers. Drawn once per cabinet size / slice change with CoreGraphics.
    private func makeCabinetPattern(_ d: MTLDevice, cab: (Int, Int), slices: [Slice]) -> MTLTexture? {
        let w = srcW, h = srcH
        let cs = CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4, space: cs,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else { return nil }
        let t0 = nowTicks()
        ctx.translateBy(x: 0, y: CGFloat(h)); ctx.scaleBy(x: 1, y: -1)             // y down, like the canvas
        ctx.textMatrix = CGAffineTransform(scaleX: 1, y: -1)
        let cw = CGFloat(cab.0), ch = CGFloat(cab.1)
        let cols = Int((CGFloat(w) / cw).rounded(.up)), rows = Int((CGFloat(h) / ch).rounded(.up))
        let colA = CGColor(red: 0.10, green: 0.17, blue: 0.45, alpha: 1), colB = CGColor(red: 0.40, green: 0.11, blue: 0.42, alpha: 1)
        let fs = max(9, min(cw, ch) * 0.24)
        let font = CTFontCreateWithName("Helvetica-Bold" as CFString, fs, nil)
        for r in 0..<rows {
            for c in 0..<cols {
                let rc = CGRect(x: CGFloat(c) * cw, y: CGFloat(r) * ch, width: cw, height: ch)
                ctx.setFillColor((r + c) % 2 == 0 ? colA : colB); ctx.fill(rc)
            }
        }
        ctx.setLineWidth(2)
        ctx.setStrokeColor(CGColor(gray: 0.85, alpha: 0.9))
        for c in 1..<max(2, cols) { let x = CGFloat(c) * cw; ctx.move(to: CGPoint(x: x, y: 0)); ctx.addLine(to: CGPoint(x: x, y: CGFloat(h))) }
        for r in 1..<max(2, rows) { let y = CGFloat(r) * ch; ctx.move(to: CGPoint(x: 0, y: y)); ctx.addLine(to: CGPoint(x: CGFloat(w), y: y)) }
        ctx.strokePath()
        ctx.setStrokeColor(CGColor(red: 1, green: 0.85, blue: 0.15, alpha: 0.85))
        for r in 0..<rows { for c in 0..<cols {
            ctx.move(to: CGPoint(x: CGFloat(c) * cw + 3, y: CGFloat(r) * ch + 3)); ctx.addLine(to: CGPoint(x: CGFloat(c + 1) * cw - 3, y: CGFloat(r + 1) * ch - 3))
        } }
        ctx.strokePath()
        func label(_ s: String, _ x: CGFloat, _ y: CGFloat, _ f: CTFont, _ col: CGColor, bg: CGColor?) {
            let attr: [NSAttributedString.Key: Any] = [kCTFontAttributeName as NSAttributedString.Key: f, kCTForegroundColorAttributeName as NSAttributedString.Key: col]
            let line = CTLineCreateWithAttributedString(NSAttributedString(string: s, attributes: attr))
            var asc: CGFloat = 0, desc: CGFloat = 0, lead: CGFloat = 0
            let wd = CGFloat(CTLineGetTypographicBounds(line, &asc, &desc, &lead))
            if let b = bg { ctx.setFillColor(b); ctx.fill(CGRect(x: x - wd / 2 - 4, y: y - asc / 2 - 3, width: wd + 8, height: asc + desc + 6)) }
            ctx.textPosition = CGPoint(x: x - wd / 2, y: y + asc / 2)
            CTLineDraw(line, ctx)
        }
        for r in 0..<rows { for c in 0..<cols {
            label("\(c + 1)-\(r + 1)", CGFloat(c) * cw + cw / 2, CGFloat(r) * ch + ch / 2, font, CGColor(gray: 1, alpha: 1), bg: CGColor(gray: 0, alpha: 0.45))
        } }
        // the top-left corner marker of each cabinet (orientation: a diagonal alone looks the same turned 180 degrees)
        ctx.setFillColor(CGColor(red: 1, green: 0.85, blue: 0.15, alpha: 1))
        let mk = max(6, min(cw, ch) * 0.16)
        for r in 0..<rows { for c in 0..<cols {
            let x = CGFloat(c) * cw + 2, y = CGFloat(r) * ch + 2
            ctx.move(to: CGPoint(x: x, y: y)); ctx.addLine(to: CGPoint(x: x + mk, y: y)); ctx.addLine(to: CGPoint(x: x, y: y + mk)); ctx.closePath()
        } }
        ctx.fillPath()
        let outline: [CGColor] = [CGColor(red: 0.1, green: 0.95, blue: 1, alpha: 1), CGColor(red: 1, green: 0.55, blue: 0.1, alpha: 1),
                                  CGColor(red: 0.3, green: 1, blue: 0.35, alpha: 1), CGColor(red: 1, green: 0.3, blue: 0.75, alpha: 1)]
        let lf = CTFontCreateWithName("Helvetica-Bold" as CFString, max(14, min(CGFloat(h) * 0.04, 48)), nil)
        for (i, s) in slices.enumerated() {
            let col = outline[i % outline.count]
            ctx.setStrokeColor(col); ctx.setLineWidth(6)
            ctx.stroke(CGRect(x: s.src.x + 3, y: s.src.y + 3, width: max(1, s.src.w - 6), height: max(1, s.src.h - 6)))
            let t = "SLICE \(i + 1)" + (s.name.isEmpty || s.name == "default" ? "" : " · \(s.name)") + (s.rot != 0 ? " · rot \(s.rot)" : "") + (s.flipText.isEmpty ? "" : " · flip \(s.flipText)")
            label(t, CGFloat(s.src.x + s.src.w / 2), CGFloat(s.src.y) + CTFontGetSize(lf) * 1.1, lf, col, bg: CGColor(gray: 0, alpha: 0.8))
        }
        guard let data = ctx.data else { return nil }
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .bgra8Unorm, width: w, height: h, mipmapped: false)
        td.usage = [.shaderRead]
        guard let t = d.makeTexture(descriptor: td) else { return nil }
        t.replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0, withBytes: data, bytesPerRow: w * 4)
        olog(String(format: "output: cabinet test pattern %dx%d px cabinets on the %dx%d canvas (%d x %d), %d slice outline(s), drawn in %.0f ms",
                    cab.0, cab.1, w, h, cols, rows, slices.count, ticksToSec(nowTicks() &- t0) * 1000))
        return t
    }

    /// Grid, colour bars, screen number and resolution, drawn once per screen / size with CoreGraphics.
    private func makeTestPattern(_ d: MTLDevice, w: Int, h: Int, screen: Int, name: String, hz: Int, fit: OutFit) -> MTLTexture? {
        let cs = CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4, space: cs,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else { return nil }
        let W = CGFloat(w), H = CGFloat(h)
        ctx.setFillColor(CGColor(gray: 0.06, alpha: 1)); ctx.fill(CGRect(x: 0, y: 0, width: W, height: H))
        // colour bars (75 %) across the middle third
        let bars: [(CGFloat, CGFloat, CGFloat)] = [(0.75, 0.75, 0.75), (0.75, 0.75, 0), (0, 0.75, 0.75), (0, 0.75, 0), (0.75, 0, 0.75), (0.75, 0, 0), (0, 0, 0.75), (0, 0, 0)]
        let bw = W / CGFloat(bars.count)
        for (i, c) in bars.enumerated() {
            ctx.setFillColor(CGColor(red: c.0, green: c.1, blue: c.2, alpha: 1))
            ctx.fill(CGRect(x: CGFloat(i) * bw, y: H / 3, width: bw + 1, height: H / 3))
        }
        // grey ramp under the bars
        for i in 0..<16 {
            let g = CGFloat(i) / 15
            ctx.setFillColor(CGColor(gray: g, alpha: 1))
            ctx.fill(CGRect(x: CGFloat(i) * W / 16, y: H / 3 - H / 12, width: W / 16 + 1, height: H / 12))
        }
        // grid: 16 x 9 cells, border, centre cross and circle
        ctx.setStrokeColor(CGColor(gray: 1, alpha: 0.55)); ctx.setLineWidth(max(1, H / 540))
        for i in 1..<16 { let x = (CGFloat(i) * W / 16).rounded() + 0.5; ctx.move(to: CGPoint(x: x, y: 0)); ctx.addLine(to: CGPoint(x: x, y: H)) }
        for i in 1..<9 { let y = (CGFloat(i) * H / 9).rounded() + 0.5; ctx.move(to: CGPoint(x: 0, y: y)); ctx.addLine(to: CGPoint(x: W, y: y)) }
        ctx.strokePath()
        ctx.setStrokeColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1)); ctx.setLineWidth(max(2, H / 270))
        ctx.stroke(CGRect(x: 1, y: 1, width: W - 2, height: H - 2))
        ctx.strokeEllipse(in: CGRect(x: W / 2 - H * 0.42, y: H * 0.08, width: H * 0.84, height: H * 0.84))
        ctx.move(to: CGPoint(x: W / 2, y: H * 0.45)); ctx.addLine(to: CGPoint(x: W / 2, y: H * 0.55))
        ctx.move(to: CGPoint(x: W / 2 - H * 0.05, y: H / 2)); ctx.addLine(to: CGPoint(x: W / 2 + H * 0.05, y: H / 2))
        ctx.strokePath()
        func text(_ s: String, _ size: CGFloat, _ y: CGFloat, bold: Bool, color: CGColor) {
            let font = CTFontCreateWithName((bold ? "Helvetica-Bold" : "Helvetica") as CFString, size, nil)
            let attr: [NSAttributedString.Key: Any] = [kCTFontAttributeName as NSAttributedString.Key: font, kCTForegroundColorAttributeName as NSAttributedString.Key: color]
            let line = CTLineCreateWithAttributedString(NSAttributedString(string: s, attributes: attr))
            let wdt = CTLineGetTypographicBounds(line, nil, nil, nil)
            ctx.setFillColor(CGColor(gray: 0, alpha: 0.7))
            ctx.fill(CGRect(x: (W - CGFloat(wdt)) / 2 - size * 0.4, y: y - size * 0.3, width: CGFloat(wdt) + size * 0.8, height: size * 1.3))
            ctx.textPosition = CGPoint(x: (W - CGFloat(wdt)) / 2, y: y)
            CTLineDraw(line, ctx)
        }
        text("VJ VIZZIES  ·  SCREEN \(screen)", H * 0.085, H * 0.74, bold: true, color: CGColor(red: 0.65, green: 0.55, blue: 0.98, alpha: 1))
        text("\(w) × \(h)\(hz > 0 ? " @ \(hz) Hz" : "")  ·  \(name)  ·  fit \(fit.rawValue)", H * 0.04, H * 0.16, bold: false, color: CGColor(gray: 1, alpha: 1))
        guard let data = ctx.data else { return nil }
        let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .bgra8Unorm, width: w, height: h, mipmapped: false)
        td.usage = [.shaderRead]
        guard let t = d.makeTexture(descriptor: td) else { return nil }
        t.replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0, withBytes: data, bytesPerRow: w * 4)
        return t
    }
}

let gOutput = OutputWindow()

/// --shader-check: the output window's render pipeline compiles (no window, no screen needed).
func outputShaderCheck(_ d: MTLDevice) -> Bool {
    do {
        let lib = try d.makeLibrary(source: outputShaderSource, options: nil)
        let pd = MTLRenderPipelineDescriptor()
        pd.vertexFunction = lib.makeFunction(name: "out_vs")
        pd.fragmentFunction = lib.makeFunction(name: "out_fs")
        pd.colorAttachments[0].pixelFormat = .bgra8Unorm
        _ = try d.makeRenderPipelineState(descriptor: pd)
        return true
    } catch { print("FAIL: output shader: \(error)"); return false }
}
