import Foundation
import Darwin

// oats-ndi: the NDI helper (x86_64, runs under Rosetta 2; libndi 6.3.2's x86_64 slice does not freeze on fine detail,
// docs/ndi-freeze-tests.md). The native arm64 player renders and writes UYVY frames into the shared frame ring
// (ndiring.swift); this process only calls NDI: sender name and groups (from the ring), the adapters pin (NDI_CONFIG_DIR,
// set by the supervisor), receiver metadata and the connection count. It idles (no NDI loaded) until the player asks for
// helper mode, keeps its sender through a player restart (15 s without a producer heartbeat ends it), and exits on SIGTERM.
// A frozen helper cannot stall the player: the player never waits for it, and kills it when one send call passes 3 s.
//
//   oats-ndi --key KEY [--log-dir DIR]     KEY = the player's OSC port (default 7000): shm "/oatsndi.KEY"

let helperUsage = "usage: oats-ndi [--key KEY] [--log-dir DIR]   (KEY = the player's OSC port, default 7000)"

@main
struct OatsNDIHelper {
    static func main() {
        signal(SIGPIPE, SIG_IGN)
        setvbuf(stdout, nil, _IOLBF, 0)
        var key = "7000", logDir = ""
        var a = Array(CommandLine.arguments.dropFirst())
        while !a.isEmpty {
            let k = a.removeFirst()
            switch k {
            case "--key": guard !a.isEmpty else { print(helperUsage); exit(64) }; key = a.removeFirst()
            case "--log-dir": guard !a.isEmpty else { print(helperUsage); exit(64) }; logDir = a.removeFirst()
            case "-h", "--help": print(helperUsage); exit(0)
            default: print("unknown option \(k)\n\(helperUsage)"); exit(64)
            }
        }
        guard key.allSatisfy({ $0.isNumber || $0.isLetter }), key.count <= 12 else { print("--key: letters/digits only"); exit(64) }
        if !logDir.isEmpty && !Logger.shared.open(dir: logDir, prefix: "oats-ndi") { print("cannot open a log in \(logDir)"); exit(78) }
        let activity = ProcessInfo.processInfo.beginActivity(options: [.userInitiated, .latencyCritical], reason: "oats-ndi NDI send")
        _ = activity
        olog("oats-ndi starting pid=\(getpid()) key=\(key) \(processArchText()) NDI_CONFIG_DIR=\(ProcessInfo.processInfo.environment["NDI_CONFIG_DIR"] ?? "(not set: ~/.ndi, NOT pinned)")")
        let (ringOpt, err) = FrameRing.open(key: key)
        guard let ring = ringOpt else { olog("oats-ndi: \(err)"); Logger.shared.sync(); exit(78) }
        guard let sem = RingSemaphore(name: ring.semName) else { olog("oats-ndi: sem_open(\(ring.semName)) failed: \(String(cString: strerror(errno)))"); exit(78) }
        let area = RingArea.helper
        ring.astore(area, RingArea.pid, UInt64(getpid()))
        ring.astore(area, RingArea.busy, 0)
        ring.astore(area, RingArea.held, 0)
        ring.astore(area, RingArea.sendSince, 0)
        ring.astore(area, RingArea.state, RingState.idle.rawValue)
        ring.setAreaString(area, RingArea.sArch, processArchText())
        ring.setAreaString(area, RingArea.sError, "")
        olog("oats-ndi: ring \(ring.shmName) (\(ringTotalBytes / 1048576) MB, \(ringSlots) slots), semaphore \(ring.semName); waiting for the player to ask for helper mode")

        // housekeeping tick: wakes the waiting thread 4x/s (heartbeat, want changes) even when no frames come
        let ticker = Thread { while true { usleep(250_000); sem.post() } }
        ticker.name = "tick"
        ticker.start()

        let consumerBox = ConsumerBox()
        for s in [SIGTERM, SIGINT] {
            signal(s, SIG_IGN)
            let src = DispatchSource.makeSignalSource(signal: s, queue: .main)
            src.setEventHandler {
                olog("oats-ndi: \(s == SIGTERM ? "SIGTERM" : "SIGINT"): flush + NDIlib_send_destroy, exit")
                let back = Thread { usleep(2_000_000); olog("oats-ndi: shutdown hung (NDI call?): _exit(75)"); Logger.shared.sync(); _exit(75) }
                back.start()
                if let c = consumerBox.c {
                    c.stopping = true; sem.post()
                    _ = c.done.wait(timeout: .now() + 1.8)
                    c.lib.destroy()
                }
                olog("oats-ndi exit 0"); Logger.shared.sync(); _exit(0)
            }
            src.resume()
            gHelperSignals.append(src)
        }

        DispatchQueue.global(qos: .userInitiated).async {
            // idle until wanted, then load libndi once and hand the semaphore to the consumer thread
            while true {
                sem.wait()
                ring.astore(area, RingArea.beat, monoNs())
                guard ring.load(RG.want) & wantHelper != 0 else { continue }
                ring.astore(area, RingArea.state, RingState.loading.rawValue)
                let lib: NDILib
                do { lib = try NDILib.load() } catch {
                    ring.astore(area, RingArea.state, RingState.error.rawValue)
                    ring.setAreaString(area, RingArea.sError, "\(error)")
                    olog("oats-ndi: \(error) (install NDI Tools / the NDI 6 runtime, universal); retrying in 10 s")
                    usleep(10_000_000); continue
                }
                let (layout, ok) = ndiLayoutCheck()
                olog("oats-ndi: libndi path=\(lib.path) version: \(lib.versionString); \(layout)")
                if !ok { ring.setAreaString(area, RingArea.sError, "struct layout mismatch with the NDI 6 ABI"); olog("oats-ndi: layout mismatch: exit 78"); Logger.shared.sync(); exit(78) }
                guard lib.initialize() else {
                    ring.astore(area, RingArea.state, RingState.error.rawValue)
                    ring.setAreaString(area, RingArea.sError, "NDIlib_initialize failed")
                    olog("oats-ndi: NDIlib_initialize failed; retrying in 10 s"); usleep(10_000_000); continue
                }
                let c = NDIConsumer(ring: ring, area: area, lib: lib, staleSec: 15, waitFrame: { sem.wait() }, log: { olog($0) })
                consumerBox.c = c
                c.start(name: "ndi-send")
                return
            }
        }
        dispatchMain()
    }
}

final class ConsumerBox {
    private let lock = NSLock()
    private var _c: NDIConsumer? = nil
    var c: NDIConsumer? { get { lock.lock(); defer { lock.unlock() }; return _c } set { lock.lock(); _c = newValue; lock.unlock() } }
}
var gHelperSignals: [DispatchSourceSignal] = []
