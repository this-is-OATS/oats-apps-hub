import Foundation
import IOKit.pwr_mgt

// LED wall output mapping (2026-10-23): the render canvas size, the output window's slices, the cabinet test pattern,
// per-layer clip scaling and the display-sleep guard. Settings live in mapping.json (default <bin>/../mapping.json,
// --mapping FILE); named venue presets in mapping/<name>.json next to it.
//
//   canvas     the composition size the engine renders (--canvas WxH, else mapping.json "canvas", else 1920x1080).
//              Read at start only: /oats/canvas s WxH stores it in mapping.json and status says a restart is needed
//              (the GUI restarts the player only when the user clicks).
//   slices     per output display: [{on, name, src [x,y,w,h] canvas px, dst [x,y,w,h] display px, rot 0|90|180|270,
//              flip ""|h|v|hv}]. An empty list = the default single slice: the whole canvas onto the whole display with
//              the output fit (fill / fit / 1:1). The output window draws each slice as one textured quad (output.swift).
//   cabinet    [w, h] px: the cabinet grid of output test 2 (/oats/output/test i 2), drawn in canvas pixels so it
//              passes through the slices like the show does (numbered column-row, alternating colours, a diagonal per
//              cabinet, the slice source outlines).
//   layer_fit  "cover" (default: fill the canvas, crop) or "fit" (whole clip, transparent bars) per layer 1..4.
// Edits are live (the output window follows at once); /oats/mapping/save writes mapping.json, /oats/mapping/revert
// reads it back. status.json "mapping" (and output.slices) shows the live state, "dirty" while it differs from the file.

struct MapRect: Equatable {
    var x = 0.0, y = 0.0, w = 0.0, h = 0.0
    var array: [Double] { [x, y, w, h].map { ($0 * 100).rounded() / 100 } }
    static func parse(_ a: Any?) -> MapRect? {
        var v: [Double] = []
        if let arr = a as? [Any] { v = arr.compactMap { ($0 as? NSNumber)?.doubleValue } }
        else if let d = a as? [String: Any] { v = ["x", "y", "w", "h"].compactMap { (d[$0] as? NSNumber)?.doubleValue } }
        guard v.count == 4, v.allSatisfy({ $0.isFinite && abs($0) < 100_000 }), v[2] > 0, v[3] > 0 else { return nil }
        return MapRect(x: v[0], y: v[1], w: v[2], h: v[3])
    }
}

struct Slice: Equatable {
    var on = true
    var name = ""
    var src = MapRect()
    var dst = MapRect()
    var rot = 0                         // degrees clockwise: 0, 90, 180, 270
    var flipH = false, flipV = false
    var flipText: String { (flipH ? "h" : "") + (flipV ? "v" : "") }
    var dict: [String: Any] { ["on": on, "name": name, "src": src.array, "dst": dst.array, "rot": rot, "flip": flipText] }
    static func parseFlip(_ s: String) -> (Bool, Bool)? {
        let t = s.lowercased().trimmingCharacters(in: .whitespaces)
        switch t {
        case "", "none", "off", "0": return (false, false)
        case "h", "x", "horizontal": return (true, false)
        case "v", "y", "vertical": return (false, true)
        case "hv", "vh", "both", "xy": return (true, true)
        default: return nil
        }
    }
    static func parseRot(_ v: Double) -> Int? {
        let r = ((Int(v.rounded()) % 360) + 360) % 360
        return [0, 90, 180, 270].contains(r) ? r : nil
    }
    static func from(_ d: [String: Any]) -> Slice? {
        guard let s = MapRect.parse(d["src"]), let t = MapRect.parse(d["dst"]) else { return nil }
        var o = Slice(); o.src = s; o.dst = t
        if let v = d["on"] as? Bool { o.on = v } else if let v = d["on"] as? NSNumber { o.on = v.intValue != 0 }
        o.name = String((d["name"] as? String ?? "").prefix(40))
        if let r = (d["rot"] as? NSNumber)?.doubleValue { guard let rr = parseRot(r) else { return nil }; o.rot = rr }
        if let f = d["flip"] as? String { guard let ff = parseFlip(f) else { return nil }; (o.flipH, o.flipV) = ff }
        if let v = d["flip_h"] as? Bool { o.flipH = v }
        if let v = d["flip_v"] as? Bool { o.flipV = v }
        return o
    }
}

let mappingMaxSlices = 16

/// "3840x1080" -> (3840, 1080): 256..8192 each, even, at most 16.6 M pixels (3840x2160 x 2).
func parseCanvas(_ s: String) -> (Int, Int)? {
    let p = s.lowercased().replacingOccurrences(of: "×", with: "x").split(separator: "x").map { $0.trimmingCharacters(in: .whitespaces) }
    guard p.count == 2, let w = Int(p[0]), let h = Int(p[1]), w >= 256, h >= 256, w <= 8192, h <= 8192, w * h <= 3840 * 2160 * 2 else { return nil }
    return (w & ~1, h & ~1)
}

// The canvas the engine renders this run (set in main before the engine is made; read-only afterwards).
var gCanvasW = 1920, gCanvasH = 1080
var gCanvasSource = "default"           // default | mapping.json | --canvas
var gMappingFileOverride = ""           // --mapping FILE
var gCanvasArg = ""                     // --canvas WxH
var gLogDir = "logs"                    // --log-dir (output-snapshot.png)

final class MappingStore {
    private let lock = NSLock()
    private(set) var path = ""
    private var canvasSaved = "1920x1080"           // in mapping.json (applies at the next start)
    private var cabinet = (128, 128)
    private var layerFit = [Bool](repeating: false, count: layerCount)
    private var displays: [Int: [Slice]] = [:]
    private var saved: [String: Any] = [:]          // the file's content (dirty check / revert)
    private var gen = 0                             // bumps on every change (the output window rebuilds its test texture)
    private var note = ""
    private let limiter = LogLimiter(perSecond: 2)

    var presetsDir: String { ((path as NSString).deletingLastPathComponent as NSString).appendingPathComponent("mapping") }

    /// At start: reads mapping.json (missing = defaults) and decides the canvas (--canvas wins).
    func load() {
        path = gMappingFileOverride.isEmpty ? (m0Dir() as NSString).appendingPathComponent("mapping.json") : gMappingFileOverride
        if let d = FileManager.default.contents(atPath: path), let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
            lock.lock(); apply(j, canvasToo: true); saved = fileDict(); lock.unlock()
            olog("mapping: \(path): canvas \(canvasSaved), cabinet \(cabinet.0)x\(cabinet.1), slices " + displaysText())
        } else {
            lock.lock(); saved = fileDict(); lock.unlock()
            olog("mapping: \(path) not found: defaults (canvas 1920x1080, one full-canvas slice per display)")
        }
        if !gCanvasArg.isEmpty, let c = parseCanvas(gCanvasArg) { (gCanvasW, gCanvasH) = c; gCanvasSource = "--canvas" }
        else if let c = parseCanvas(canvasSaved), c != (1920, 1080) { (gCanvasW, gCanvasH) = c; gCanvasSource = "mapping.json" }
        olog("canvas \(gCanvasW)x\(gCanvasH) (\(gCanvasSource))")
    }

    private func displaysText() -> String {
        displays.isEmpty ? "default" : displays.keys.sorted().map { "display \($0): \(displays[$0]!.count)" }.joined(separator: ", ")
    }

    /// Lock held. Takes the mapping fields of a mapping.json / preset dictionary.
    private func apply(_ j: [String: Any], canvasToo: Bool) {
        if canvasToo, let c = j["canvas"] as? String, let p = parseCanvas(c) { canvasSaved = "\(p.0)x\(p.1)" }
        if let c = j["cabinet"] as? [Any], c.count == 2, let w = (c[0] as? NSNumber)?.intValue, let h = (c[1] as? NSNumber)?.intValue,
           w >= 8, h >= 8, w <= 4096, h <= 4096 { cabinet = (w, h) }
        if let lf = j["layer_fit"] as? [Any] {
            for (i, v) in lf.prefix(layerCount).enumerated() { layerFit[i] = (v as? String)?.lowercased() == "fit" }
        }
        if let ds = j["displays"] as? [String: Any] {
            var out: [Int: [Slice]] = [:]
            for (k, v) in ds {
                guard let n = Int(k), n >= 1, n <= 16 else { continue }
                let arr = ((v as? [String: Any])?["slices"] as? [Any]) ?? (v as? [Any]) ?? []
                let sl = arr.compactMap { ($0 as? [String: Any]).flatMap(Slice.from) }
                if !sl.isEmpty { out[n] = Array(sl.prefix(mappingMaxSlices)) }
            }
            displays = out
        }
        gen += 1
    }

    /// Lock held. What mapping.json holds.
    private func fileDict() -> [String: Any] {
        var ds: [String: Any] = [:]
        for (k, v) in displays where !v.isEmpty { ds[String(k)] = ["slices": v.map { $0.dict }] }
        return ["version": 1, "canvas": canvasSaved, "cabinet": [cabinet.0, cabinet.1],
                "layer_fit": layerFit.map { $0 ? "fit" : "cover" }, "displays": ds]
    }

    private func write(_ d: [String: Any], to p: String) -> String? {
        guard let data = try? JSONSerialization.data(withJSONObject: d, options: [.prettyPrinted, .sortedKeys]) else { return "encode failed" }
        try? FileManager.default.createDirectory(atPath: (p as NSString).deletingLastPathComponent, withIntermediateDirectories: true)
        let tmp = p + ".tmp"
        guard FileManager.default.createFile(atPath: tmp, contents: data), rename(tmp, p) == 0 else { return "cannot write \(p)" }
        return nil
    }

    // MARK: render / output threads

    var changeGen: Int { lock.lock(); defer { lock.unlock() }; return gen }
    var cabinetSize: (Int, Int) { lock.lock(); defer { lock.unlock() }; return cabinet }
    func layerFits() -> [Bool] { lock.lock(); defer { lock.unlock() }; return layerFit }
    func slices(display: Int) -> [Slice] { lock.lock(); defer { lock.unlock() }; return displays[display] ?? [] }

    /// The default slice: the whole canvas onto the display with the output fit.
    static func defaultSlice(dispW: Int, dispH: Int, fit: OutFit) -> Slice {
        let sw = Double(gCanvasW), sh = Double(gCanvasH), dw = Double(dispW), dh = Double(dispH)
        let s: Double
        switch fit {
        case .fill: s = max(dw / sw, dh / sh)
        case .fit: s = min(dw / sw, dh / sh)
        case .one: s = 1
        }
        var o = Slice(); o.name = "default"
        o.src = MapRect(x: 0, y: 0, w: sw, h: sh)
        o.dst = MapRect(x: ((dw - sw * s) / 2).rounded(), y: ((dh - sh * s) / 2).rounded(), w: (sw * s).rounded(), h: (sh * s).rounded())
        return o
    }

    // MARK: OSC

    private func changed(_ what: String) -> String {
        gen += 1
        return what
    }

    /// /oats/canvas, /oats/mapping/*, /oats/output/slices, /oats/output/slice/{n}/*, /oats/output/cabinet,
    /// /oats/layers/{n}/scaling. nil = not ours.
    func osc(_ m: OSCMessage, display: Int) -> (String, Bool)? {
        let a = m.address
        let a0 = m.args.first
        func text(_ x: OSCArg?) -> String? { if case .s(let v)? = x { return v }; return nil }
        func num(_ x: OSCArg?) -> Double? { x?.number.flatMap { $0.isFinite ? $0 : nil } }
        if a == "/oats/canvas" {
            guard let s = text(a0), let c = parseCanvas(s) else { return ("bad args (want s WxH, 256..8192 each, e.g. 3840x1080)", false) }
            lock.lock()
            canvasSaved = "\(c.0)x\(c.1)"
            var d = (FileManager.default.contents(atPath: path)).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] } ?? fileDict()
            d["canvas"] = canvasSaved
            let err = write(d, to: path)
            saved["canvas"] = canvasSaved
            gen += 1
            lock.unlock()
            if let e = err { return ("canvas \(c.0)x\(c.1): \(e)", false) }
            let same = c == (gCanvasW, gCanvasH)
            return ("canvas \(c.0)x\(c.1) stored in mapping.json" + (same ? " (running at that size)" : ": RESTART the player to apply (running \(gCanvasW)x\(gCanvasH))")
                    + (gCanvasSource == "--canvas" ? "; note: --canvas \(gCanvasArg) on the command line wins at start" : ""), true)
        }
        if let n = layerIndex(a, suffix: "scaling") {
            let v = (text(a0) ?? (num(a0).map { $0 != 0 ? "fit" : "cover" }) ?? "").lowercased().trimmingCharacters(in: .whitespaces)
            guard v == "fit" || v == "cover" else { return ("bad args (want s cover|fit)", false) }
            lock.lock(); layerFit[n - 1] = v == "fit"; gen += 1; lock.unlock()
            return ("layer \(n) clip scaling \(v) (unsaved: /oats/mapping/save)", true)
        }
        if a == "/oats/output/cabinet" {
            guard let w = num(a0), let h = num(m.args.count > 1 ? m.args[1] : a0), w >= 8, h >= 8, w <= 4096, h <= 4096 else {
                return ("bad args (want i w i h, 8..4096 px)", false)
            }
            lock.lock(); cabinet = (Int(w.rounded()), Int(h.rounded())); gen += 1; lock.unlock()
            return ("cabinet \(Int(w.rounded()))x\(Int(h.rounded())) px (unsaved: /oats/mapping/save)", true)
        }
        if a == "/oats/output/slices" {
            // s JSON (a list of slices, or {"slices": [...]}) [i display]; "" or "[]" = the default single slice
            guard let s = text(a0) else { return ("bad args (want s JSON slice list [i display])", false) }
            let disp = m.args.count > 1 ? Int(num(m.args[1]) ?? 0) : display
            guard disp >= 1 && disp <= 16 else { return ("no output display set: give the display as 2nd arg (i 1..16)", false) }
            var list: [Slice] = []
            let trimmed = s.trimmingCharacters(in: .whitespaces)
            if !trimmed.isEmpty {
                guard let j = try? JSONSerialization.jsonObject(with: Data(trimmed.utf8)) else { return ("slices: not valid JSON", false) }
                let arr = (j as? [Any]) ?? ((j as? [String: Any])?["slices"] as? [Any]) ?? []
                for (i, e) in arr.enumerated() {
                    guard let d = e as? [String: Any], let sl = Slice.from(d) else { return ("slices: entry \(i + 1) is not a slice {src [x,y,w,h], dst [x,y,w,h], rot, flip, on}", false) }
                    list.append(sl)
                }
                guard list.count <= mappingMaxSlices else { return ("slices: at most \(mappingMaxSlices)", false) }
            }
            lock.lock(); displays[disp] = list.isEmpty ? nil : list; gen += 1; lock.unlock()
            return ("display \(disp): " + (list.isEmpty ? "default slice (whole canvas, output fit)" : "\(list.count) slice(s)") + " (unsaved: /oats/mapping/save)", true)
        }
        if a.hasPrefix("/oats/output/slice/") {
            let parts = a.dropFirst(19).split(separator: "/").map(String.init)
            guard parts.count == 2, let n = Int(parts[0]), n >= 1, n <= mappingMaxSlices else { return ("bad address (want /oats/output/slice/{1..\(mappingMaxSlices)}/{src,dst,rot,flip,on,remove})", false) }
            guard display >= 1 else { return ("no output display set (/oats/output/display i first)", false) }
            lock.lock(); defer { lock.unlock() }
            var list = displays[display] ?? []
            if list.isEmpty { list = [MappingStore.defaultSliceLocked(display)] }
            if n == list.count + 1 && parts[1] != "remove" { var s = list.last!; s.name = ""; list.append(s) }   // the next number adds one
            guard n <= list.count else { return ("display \(display) has \(list.count) slice(s)", false) }
            var s = list[n - 1]
            let nums = m.args.compactMap { num($0) }
            switch parts[1] {
            case "src", "dst":
                guard nums.count == 4, let r = MapRect.parse(nums) else { return ("bad args (want f x f y f w f h, px)", false) }
                if parts[1] == "src" { s.src = r } else { s.dst = r }
            case "rot":
                guard let v = nums.first, let r = Slice.parseRot(v) else { return ("bad args (want i 0|90|180|270)", false) }
                s.rot = r
            case "flip":
                if let t = text(a0) { guard let f = Slice.parseFlip(t) else { return ("bad args (want s none|h|v|hv or i h i v)", false) }; (s.flipH, s.flipV) = f }
                else if nums.count == 2 { s.flipH = nums[0] != 0; s.flipV = nums[1] != 0 }
                else { return ("bad args (want s none|h|v|hv or i h i v)", false) }
            case "on":
                guard let v = nums.first else { return ("bad args (want i 0|1)", false) }
                s.on = v != 0
            case "name":
                s.name = String((text(a0) ?? "").prefix(40))
            case "remove":
                list.remove(at: n - 1)
                displays[display] = list.isEmpty ? nil : list; gen += 1
                return ("display \(display) slice \(n) removed (\(list.count) left)", true)
            default: return ("bad address (want …/slice/{n}/{src,dst,rot,flip,on,name,remove})", false)
            }
            list[n - 1] = s
            displays[display] = list; gen += 1
            return ("display \(display) slice \(n): src \(s.src.array) dst \(s.dst.array) rot \(s.rot) flip \(s.flipText.isEmpty ? "none" : s.flipText) \(s.on ? "on" : "off")", true)
        }
        guard a.hasPrefix("/oats/mapping/") else { return nil }
        let cmd = String(a.dropFirst(14))
        switch cmd {
        case "save":
            lock.lock()
            let d = fileDict()
            let name = text(a0).map(MappingStore.safeName) ?? ""
            if let t = text(a0), !t.trimmingCharacters(in: .whitespaces).isEmpty {
                guard !name.isEmpty else { lock.unlock(); return ("bad preset name (letters, digits, space, - _ .)", false) }
                let err = write(d, to: (presetsDir as NSString).appendingPathComponent(name + ".json"))
                lock.unlock()
                return err.map { ("preset \(name): \($0)", false) } ?? ("mapping preset '\(name)' saved in \(presetsDir)", true)
            }
            var full = (FileManager.default.contents(atPath: path)).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] } ?? [:]
            for (k, v) in d where k != "canvas" { full[k] = v }
            if full["canvas"] == nil { full["canvas"] = canvasSaved }
            let err = write(full, to: path)
            if err == nil { saved = fileDict() }
            lock.unlock()
            return err.map { ("save: \($0)", false) } ?? ("mapping saved: \(path)", true)
        case "revert":
            lock.lock()
            let j = (FileManager.default.contents(atPath: path)).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] } ?? [:]
            displays = [:]; cabinet = (128, 128); layerFit = [Bool](repeating: false, count: layerCount)
            apply(j, canvasToo: true); saved = fileDict()
            lock.unlock()
            return ("mapping reverted to \(path)", true)
        case "load":
            guard let t = text(a0) else { return ("bad args (want s preset name)", false) }
            let name = MappingStore.safeName(t)
            let p = (presetsDir as NSString).appendingPathComponent(name + ".json")
            guard !name.isEmpty, let d = FileManager.default.contents(atPath: p), let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else {
                return ("no mapping preset '\(t)' in \(presetsDir)", false)
            }
            lock.lock()
            displays = [:]
            apply(j, canvasToo: false)
            let pc = (j["canvas"] as? String).flatMap(parseCanvas)
            lock.unlock()
            var r = "mapping preset '\(name)' loaded (unsaved: /oats/mapping/save to keep it)"
            if let c = pc, c != (gCanvasW, gCanvasH) { r += "; its canvas is \(c.0)x\(c.1): /oats/canvas s \(c.0)x\(c.1) + restart to use it" }
            return (r, true)
        case "delete":
            guard let t = text(a0), !MappingStore.safeName(t).isEmpty else { return ("bad args (want s preset name)", false) }
            let p = (presetsDir as NSString).appendingPathComponent(MappingStore.safeName(t) + ".json")
            guard (try? FileManager.default.removeItem(atPath: p)) != nil else { return ("no mapping preset '\(t)'", false) }
            return ("mapping preset '\(t)' deleted", true)
        case "reload":                                   // after a show-pack import rewrote mapping.json
            lock.lock()
            let j = (FileManager.default.contents(atPath: path)).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] } ?? [:]
            displays = [:]; apply(j, canvasToo: true); saved = fileDict()
            lock.unlock()
            return ("mapping reloaded from \(path)", true)
        default:
            return ("unhandled (mapping: save [s name] | revert | load s name | delete s name | reload)", false)
        }
    }

    /// Lock held: the default slice for a display that is on air (from the output window's size and fit).
    private static func defaultSliceLocked(_ display: Int) -> Slice {
        let o = gOutput.sizeAndFit()
        return defaultSlice(dispW: o.w > 0 ? o.w : gCanvasW, dispH: o.h > 0 ? o.h : gCanvasH, fit: o.fit)
    }

    static func safeName(_ s: String) -> String {
        let t = s.trimmingCharacters(in: .whitespaces)
        guard !t.isEmpty, t.count <= 60, !t.hasPrefix("."),
              t.unicodeScalars.allSatisfy({ CharacterSet.alphanumerics.contains($0) || " -_.".unicodeScalars.contains($0) }) else { return "" }
        return t
    }

    private func layerIndex(_ a: String, suffix: String) -> Int? {
        for pre in ["/oats/layers/", "/oats/layer/"] where a.hasPrefix(pre) {
            let p = a.dropFirst(pre.count).split(separator: "/")
            if p.count == 2, p[1] == suffix, let n = Int(p[0]), n >= 1, n <= layerCount { return n }
        }
        return nil
    }

    func presets() -> [String] {
        ((try? FileManager.default.contentsOfDirectory(atPath: presetsDir)) ?? []).filter { $0.hasSuffix(".json") && !$0.hasPrefix(".") }
            .map { String($0.dropLast(5)) }.sorted { $0.lowercased() < $1.lowercased() }
    }

    func statusDict() -> [String: Any] {
        lock.lock()
        let cur = fileDict()
        let dirty = !NSDictionary(dictionary: cur.filter { $0.key != "canvas" }).isEqual(to: saved.filter { $0.key != "canvas" })
        var ds: [String: Any] = [:]
        for (k, v) in displays { ds[String(k)] = v.map { $0.dict } }
        let d: [String: Any] = ["file": path, "canvas": "\(gCanvasW)x\(gCanvasH)", "canvas_source": gCanvasSource,
                                "canvas_saved": canvasSaved,
                                "restart_needed": parseCanvas(canvasSaved).map { $0 != (gCanvasW, gCanvasH) } ?? false && gCanvasSource != "--canvas",
                                "cabinet": [cabinet.0, cabinet.1], "layer_fit": layerFit.map { $0 ? "fit" : "cover" },
                                "displays": ds, "dirty": dirty, "max_slices": mappingMaxSlices, "presets_dir": presetsDir]
        lock.unlock()
        var out = d
        out["presets"] = presets()
        return out
    }
}

let gMapping = MappingStore()

// MARK: - display sleep guard

/// While an output display is set, the Mac must not sleep the display or idle-sleep (a dark LED wall mid-show:
/// 2026-10-23 06:10 the display turned off while the player ran). kIOPMAssertionTypePreventUserIdleDisplaySleep also
/// keeps the system awake. A locked screen does not stop the output window; display sleep does.
final class AwakeGuard {
    private let lock = NSLock()
    private var id: IOPMAssertionID = 0
    private var held = false
    private var err = ""
    func set(_ on: Bool, why: String) {
        lock.lock(); defer { lock.unlock() }
        if on == held { return }
        if on {
            var a: IOPMAssertionID = 0
            let r = IOPMAssertionCreateWithName(kIOPMAssertionTypePreventUserIdleDisplaySleep as CFString,
                                                IOPMAssertionLevel(kIOPMAssertionLevelOn), "VJ VIZZIES output window (\(why))" as CFString, &a)
            if r == kIOReturnSuccess { id = a; held = true; err = ""; olog("display sleep: prevented while the output window is on (IOPM assertion \(a))") }
            else { err = String(format: "IOPMAssertionCreateWithName failed 0x%x", r); olog("display sleep: WARNING: \(err): the display may sleep mid-show") }
        } else {
            IOPMAssertionRelease(id); id = 0; held = false
            olog("display sleep: allowed again (output window off)")
        }
    }
    var dict: (Bool, String) { lock.lock(); defer { lock.unlock() }; return (held, err) }
}
let gAwake = AwakeGuard()
