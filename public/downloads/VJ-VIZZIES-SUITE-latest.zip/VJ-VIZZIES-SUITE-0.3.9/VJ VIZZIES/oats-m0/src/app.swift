import Foundation
import AppKit
import Darwin

// oats-m0: the player (docs/PLAN.md 13.1), native arm64 since 2026-10-22 (m0.sh build --x86 for the old Rosetta build):
// Metal fractal + layers -> UYVY -> output window (HDMI, the show feed) + live preview + the NDI frame ring (ndiout.swift:
// sent by the x86_64 helper oats-ndi, or natively, or off), OSC on UDP 7000, sACN on UDP 5568, watchdog.

let usage = """
usage: oats-m0 [--name S] [--groups S] [--universe N] [--osc-port N] [--sacn-multicast-if IPv4]
               [--fps 60] [--log-dir DIR] [--debug] [--content normal|deep|noise] [--no-ndi-meta]
               [--allow-net CIDR[,CIDR...]] [--allow-any] [--no-sacn] [--dmx-map v0|m0] [--media DIR]
               [--analysis-out host:port] [--output-display N]
               [--preview-port N] [--scenes FILE] [--presets-dir DIR] [--library FILE]
               [--ndi off|native|native-soft|helper|auto] [--ndi-soft half|blur] [--ndi-quality previs|full]
               [--frame-budget-ms MS] [--canvas WxH] [--mapping FILE]
               [--startup-card test|ndi|off] [--startup-card-secs S] [--restart]
       oats-m0 --orbit-check NAME|INDEX [N]
       oats-m0 --dmx-table [--media DIR]
       oats-m0 --selftest-dmx [--media DIR]
       oats-m0 --shader-check
  --ndi      NDI mode (default auto; OSC /oats/ndi/mode s; status ndi.mode). HDMI (the output window) never depends on it.
             helper: the x86_64 helper bin/oats-ndi sends (Rosetta; libndi 6.3.2 x86_64 does not freeze; m0.sh runs it)
             native: this process sends with the arm64 libndi (6.3.2 arm64 freezes ~4 s every ~4 s on 1-pixel detail)
             native-soft: native + a soft pass on the NDI copy only (--ndi-soft half = 960x540, default; blur = 3x3 at 1080p)
             auto: helper when Rosetta 2 is installed, else native-soft.   off: no NDI
  --ndi-quality  previs (default): 960x540 at half the output rate (30/1 at 60), downscaled on the GPU, every 2nd frame;
             full: 1920x1080 at the output rate. OSC /oats/ndi/quality s; status ndi.quality. With no NDI receiver
             connected nothing is copied or sent except one keep-alive frame a second (either quality)
  --startup-card  what a COLD start shows until the first control input (OSC from a person / the GUI, a DMX change
             after the first packet, a scene go): standby (default since 2026-11-02, the VJ VIZZIES logo card) | test (the test card) | ndi (NDI setup card) | off
  --startup-card-secs S  also end the startup card after S seconds (default 0 = only on input)
  --restart  a restart by the supervisor (m0.sh loop, the app: watchdog exit 75, crash, restart request): no startup card
  --gui-port N  the controls web page port shown on the NDI card (default 8090)
  --content  also test (test card) | ndi (NDI setup card)
  --frame-budget-ms MS  frame budget the governor and the late-frame alarm aim at (default 15.2; 5..33)
  --name     NDI source name (default "OATS VIZ Program", kept for receivers subscribed by name). NDI sources as LAYER
             sources (cameras etc., src/ndiin.swift): OSC /oats/layers/{n}/source s ndi, /oats/layers/{n}/ndi s NAME,
             /oats/layers/{n}/ndi/bandwidth s full|proxy, /oats/ndi/sources; DMX Layer ch 14 = 30-39 + ch 3 = slot;
             status.json ndi_sources[] (slots A-Z, ndi_order.json pins). The player's own sender is never listed
  --groups   NDI groups (default empty = Public, NULL to NDI; tests use "oatsbench")
  --universe sACN universe (default 5)         --osc-port OSC UDP port (default 7000)
  --dmx-map  v0 (default): OATS VIZ Master 16 at ch 1-16 + Fractal 24 at ch 17-40 (gdtf/OATS_VIZ.gdtf);
             m0: the old 5-channel M0 map (1 dimmer, 2 zoom speed, 3 palette, 4 cycle, 5 test content)
  --sacn-multicast-if  also join 239.255.<hi>.<lo> on that interface address
  --log-dir  where oats-m0-<stamp>.log, status.json and snapshot.png go (default ./logs)
  --debug    enable /oats/debug/* OSC addresses
  --no-ndi-meta  A/B test: no ndi-meta thread (no NDIlib_send_capture); the render loop polls connections
  --allow-net  control (OSC, sACN, preview) only from these networks + 127.0.0.0/8 (default: en0's network)
  --allow-any  no source filter on OSC, sACN and preview
  --media      clip library folder with library.json (default <bin>/../../media = ~/Developer/oats-viz/media)
  --analysis-out host:port  send the 3 dominant output colours as OSC (/oats/analysis/colors, ~10 Hz; default off;
               also /oats/analysis/out s host:port|off)
  --output-display N  output window (HDMI to an LED processor / projector) full screen on display N at start
               (0 = off, the default; 1..n = status.json "screens"; the main display only when it is the only one).
               Also OSC /oats/output/display i, /oats/output/fit s fill|fit|1:1, /oats/output/test i
  --canvas WxH  render canvas (default: mapping.json "canvas", else 1920x1080; any aspect, e.g. 3840x1080, 1080x1920;
               256..8192 each). OSC /oats/canvas s WxH stores it in mapping.json for the next start. NDI stays 16:9:
               the canvas is letterboxed into 1920x1080 (full) / 960x540 (previs); the preview is letterboxed too
  --mapping FILE  output mapping settings (default <bin>/../mapping.json; presets in mapping/ next to it): canvas,
               slices per output display, cabinet size, clip scaling per layer (src/mapping.swift)
  --preview-port N  MJPEG preview TCP port (default 8091)
  --scenes FILE     scenes file (default <bin>/../scenes.json)
  --presets-dir DIR fx_presets.json + fractal_presets.json (default <bin>/../tools)
  --library FILE    clip library file (default <media>/library.json; clip paths are relative to --media)
  --no-sacn    no sACN receiver (for a test instance next to the live one: use another --osc-port too)
  --orbit-check  print a zoom target's double-double centre and reference orbit as JSON lines, then exit
  --dmx-table    print the v0 DMX channel table as JSON, then exit (tools/make_gdtf.py --check uses it; Layer 16
                 bank/slot names come from the library, so give --media first if it is not the default)
  --selftest-dmx feed crafted v0 packets (Layer 16 fixtures) to the decoder, print PASS/FAIL, exit 0/1 (no network)
  --selftest-phasers check that off / preset off / HOLD / Cycle 0 / effect speed 0 stop the phaser offsets, exit 0/1
  --shader-check compile the Metal shaders and run each layer generator once at 1920x1080 (GPU ms), exit 0/1 (no NDI)
"""

func fail(_ msg: String, code: Int32) -> Never {
    let line = "oats-m0: " + msg
    if Logger.shared.path.isEmpty { FileHandle.standardError.write((line + "\n").data(using: .utf8)!) } else { olog(line) }
    Logger.shared.sync()
    _exit(code)                                 // the log uses write(2); no atexit / libndi static destructors with threads running
}

func parseArgs() -> Config {
    var c = Config()
    var a = Array(CommandLine.arguments.dropFirst())
    func value(_ k: String) -> String {
        guard !a.isEmpty else { fail("missing value for \(k)\n\(usage)", code: 64) }
        return a.removeFirst()
    }
    while !a.isEmpty {
        let k = a.removeFirst()
        switch k {
        case "--name": c.name = value(k)
        case "--groups": c.groups = value(k)
        case "--universe":
            guard let u = Int(value(k)), u >= 1, u <= 63999 else { fail("--universe must be 1..63999", code: 64) }
            c.universe = u
        case "--osc-port":
            guard let p = Int(value(k)), p > 0, p < 65536 else { fail("--osc-port must be 1..65535", code: 64) }
            c.oscPort = p
        case "--sacn-multicast-if": c.sacnMulticastIf = value(k)
        case "--fps":
            guard let f = Double(value(k)), f >= 1, f <= 240 else { fail("--fps must be 1..240", code: 64) }
            c.fps = f
        case "--log-dir": c.logDir = value(k)
        case "--debug": c.debug = true
        case "--no-ndi-meta": c.noNdiMeta = true
        case "--allow-net":
            let v = value(k)
            let parts = v.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
            let nets = parts.compactMap(IPv4Net.parse)
            guard !parts.isEmpty, nets.count == parts.count else { fail("--allow-net wants CIDR[,CIDR...], e.g. 192.168.1.0/24 (got '\(v)')", code: 64) }
            c.allowNets = (c.allowNets ?? []) + nets
        case "--allow-any": c.allowAny = true
        case "--media": c.mediaDir = value(k)
        case "--analysis-out":
            let v = value(k)
            guard parseHostPort(v) != nil else { fail("--analysis-out wants host:port\n\(usage)", code: 64) }
            c.analysisOut = v
        case "--no-sacn": c.noSacn = true
        case "--preview-port":
            guard let p = UInt16(value(k)), p > 0 else { fail("--preview-port must be 1..65535", code: 64) }
            previewPort = p
        case "--scenes": gScenesFileOverride = (value(k) as NSString).expandingTildeInPath
        case "--presets-dir": gPresetsDirOverride = (value(k) as NSString).expandingTildeInPath
        case "--library": gLibraryFileOverride = (value(k) as NSString).expandingTildeInPath
        case "--ndi":
            let v = value(k)
            guard let m = NDIMode.parse(v) else { fail("--ndi must be off|native|native-soft|helper|auto (got '\(v)')", code: 64) }
            c.ndiMode = m
        case "--ndi-soft":
            let v = value(k)
            guard let m = NDISoft(rawValue: v.lowercased()) else { fail("--ndi-soft must be half|blur (got '\(v)')", code: 64) }
            c.ndiSoft = m
        case "--ndi-quality":
            let v = value(k)
            guard let q = NDIQuality.parse(v) else { fail("--ndi-quality must be full|previs (got '\(v)')", code: 64) }
            c.ndiQuality = q
        case "--frame-budget-ms":
            guard let f = Double(value(k)), f.isFinite, f >= 5, f <= 33 else { fail("--frame-budget-ms must be 5..33", code: 64) }
            gFrameBudgetMs = f
        case "--canvas":
            let v = value(k)
            guard parseCanvas(v) != nil else { fail("--canvas wants WxH, 256..8192 each, e.g. 3840x1080 (got '\(v)')", code: 64) }
            gCanvasArg = v
        case "--mapping": gMappingFileOverride = (value(k) as NSString).expandingTildeInPath
        case "--output-display":
            guard let n = Int(value(k)), n >= 0, n <= 16 else { fail("--output-display must be 0..16", code: 64) }
            c.outputDisplay = n
        case "--orbit-check": exit(orbitCheck(a))
        case "--dmx-table": print(dmxTableJSON(Library(dir: mediaDirFor(c), quiet: true))); exit(0)
        case "--selftest-dmx": exit(dmxSelfTest(mediaDir: mediaDirFor(c)))
        case "--shader-check": exit(shaderCheck())
        case "--selftest-phasers": exit(phaserSelfTest())
        case "--dmx-map":
            guard let m = DMXMap(rawValue: value(k).lowercased()) else { fail("--dmx-map must be v0|m0", code: 64) }
            c.dmxMap = m
        case "--content":
            guard let ct = Content.parse(value(k)) else { fail("--content must be normal|deep|noise|test|ndi", code: 64) }
            c.startContent = ct
        case "--startup-card":
            let v = value(k).lowercased()
            guard let ct = Content.parse(v), ct == .normal || ct.isCard else { fail("--startup-card must be test|ndi|standby|off", code: 64) }
            c.startupCard = ct
        case "--startup-card-secs":
            guard let v = Double(value(k)), v.isFinite, v >= 0, v <= 86400 else { fail("--startup-card-secs must be 0..86400 (0 = until the first control input)", code: 64) }
            c.startupCardSecs = v
        case "--restart": c.restart = true
        case "--gui-port":
            guard let p = Int(value(k)), p > 0, p < 65536 else { fail("--gui-port must be 1..65535", code: 64) }
            c.guiPort = p
        case "-h", "--help": print(usage); exit(0)
        default: fail("unknown option \(k)\n\(usage)", code: 64)
        }
    }
    return c
}

/// The clip library folder: --media, else <bin>/../../media (= ~/Developer/oats-viz/media).
func mediaDirFor(_ cfg: Config) -> String {
    cfg.mediaDir.isEmpty
        ? URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath().deletingLastPathComponent()
            .deletingLastPathComponent().deletingLastPathComponent().appendingPathComponent("media").standardizedFileURL.path
        : (cfg.mediaDir as NSString).expandingTildeInPath
}

func processArch() -> (String, Bool) {
    #if arch(x86_64)
    let a = "x86_64"
    #elseif arch(arm64)
    let a = "arm64"
    #else
    let a = "unknown"
    #endif
    var translated: Int32 = 0
    var size = MemoryLayout<Int32>.size
    if sysctlbyname("sysctl.proc_translated", &translated, &size, nil, 0) != 0 { translated = 0 }
    return (a, translated == 1)
}

func localIPv4() -> [(String, String)] {
    var out: [(String, String)] = []
    var ifa: UnsafeMutablePointer<ifaddrs>? = nil
    guard getifaddrs(&ifa) == 0, let first = ifa else { return out }
    var p: UnsafeMutablePointer<ifaddrs>? = first
    while let cur = p {
        if let sa = cur.pointee.ifa_addr, sa.pointee.sa_family == UInt8(AF_INET) {
            let ip = sa.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { sockaddrIP($0.pointee) }
            out.append((String(cString: cur.pointee.ifa_name), ip))
        }
        p = cur.pointee.ifa_next
    }
    freeifaddrs(first)
    return out
}

/// Reads NDI_CONFIG_DIR and the config file's ndi.adapters.allowed (array or comma-separated string).
func ndiConfigInfo() -> (String, [String], String) {
    guard let dir = ProcessInfo.processInfo.environment["NDI_CONFIG_DIR"], !dir.isEmpty else {
        return ("", [], "NDI_CONFIG_DIR not set: libndi uses ~/.ndi/ndi-config.v1.json (NOT pinned to the cable; start with m0.sh)")
    }
    let path = (dir as NSString).appendingPathComponent("ndi-config.v1.json")
    guard let data = FileManager.default.contents(atPath: path) else { return (dir, [], "NDI_CONFIG_DIR=\(dir) but \(path) is missing") }
    guard let j = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
          let ndi = j["ndi"] as? [String: Any] else { return (dir, [], "NDI_CONFIG_DIR=\(dir): \(path) is not valid JSON with an \"ndi\" object") }
    var allowed: [String] = []
    if let ad = ndi["adapters"] as? [String: Any] {
        if let arr = ad["allowed"] as? [Any] { allowed = arr.compactMap { $0 as? String } }
        else if let s = ad["allowed"] as? String { allowed = s.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty } }
    }
    return (dir, allowed, "NDI_CONFIG_DIR=\(dir) adapters.allowed=\(allowed.isEmpty ? "(empty: all adapters)" : allowed.joined(separator: ","))")
}

var gSignalSources: [DispatchSourceSignal] = []

/// Filled in as the parts come up, so the OSC server can be bound first (before NDI and sACN).
final class Holder {
    var sacn: SACNReceiver? = nil
    var status: StatusReporter? = nil
}

@main
struct OatsM0 {
    static func main() {
        signal(SIGPIPE, SIG_IGN)               // libndi writes to sockets whose peer may have closed
        setvbuf(stdout, nil, _IOLBF, 0)
        _ = gStartTicks; _ = gStartDate
        let activity = ProcessInfo.processInfo.beginActivity(
            options: [.userInitiated, .latencyCritical, .idleSystemSleepDisabled], reason: "oats-m0 NDI render loop")
        _ = activity
        let cfg = parseArgs()
        if !Logger.shared.open(dir: cfg.logDir) { fail("cannot open a log file in \(cfg.logDir)", code: 78) }
        olog("oats-m0 starting pid=\(getpid()) log=\(Logger.shared.path)")
        // The watchdog runs from here on, so a hang in NDI init, Metal init or the first frame is caught too
        // (no frame sent 30 s after start -> exit 75 and the loop restarts it).
        let watchdog = Watchdog()
        watchdog.start()
        olog("config name='\(cfg.name)' groups=\(cfg.groups.isEmpty ? "(Public: NULL)" : "'\(cfg.groups)'") universe=\(cfg.universe) dmx-map=\(cfg.dmxMap.rawValue) osc-port=\(cfg.oscPort) sacn-multicast-if=\(cfg.sacnMulticastIf ?? "-") fps=\(cfg.fpsN)/\(cfg.fpsD) content=\(cfg.startContent.rawValue) debug=\(cfg.debug) log-dir=\(cfg.logDir)")

        gLogDir = cfg.logDir
        gMapping.load()                        // mapping.swift: canvas size (before the engine), slices, cabinet, clip scaling
        Governor.levels = Governor.makeLevels(w: gCanvasW, h: gCanvasH)
        gStartup.begin(cfg)                    // testcard.swift: cold start -> startup card until the first control input
        // Default layer layout (cold start only: not --restart, and a state restore over OSC overrides it):
        // BG = the fractal, L1-L2 = Clip, L3-L4 = Gen. The two generator layers start at opacity 0, so the first
        // picture is still the fractal alone; the operator fades them in. GUI "Reset all" sends the same layout.
        if !cfg.restart {
            gControl.with { c in
                for li in 2..<min(4, layerCount) { c.layers[li].source = .gen; c.layers[li].opacity = 0 }
                c.fractalLayer = 0
            }
            olog("default layer layout (cold start): BG fractal, L1-L2 clip, L3-L4 gen (opacity 0)")
        }
        let (arch, translated) = processArch()
        olog("process CPU type: \(arch)\(translated ? " (translated by Rosetta 2)" : " (native)")")

        // Ports first: a second instance stops here on EADDRINUSE (OSC is bound without SO_REUSEPORT) before
        // it can take UDP 5568 (shared with SO_REUSEPORT, so unicast would go to only one of the two) or
        // announce a duplicate NDI source.
        // Control sources: 127.0.0.0/8 + en0's network (or --allow-net); NDI is not affected.
        let filter = SourceFilter(cfg: cfg)
        for line in filter.describe(oscPort: cfg.oscPort) { olog(line) }
        let holder = Holder()
        guard let osc = OSCServer(cfg: cfg, filter: filter, statusString: { holder.status?.pongString() ?? "oats-m0 starting" }) else {
            fail("OSC: cannot bind UDP \(cfg.oscPort) (is another oats-m0 running?)", code: 78)
        }
        var sacnOpt: SACNReceiver? = nil
        if cfg.noSacn {
            olog("--no-sacn: no sACN receiver (test instance); DMX is off")
        } else {
            guard let s = SACNReceiver(cfg: cfg, filter: filter) else { fail("sACN: cannot bind UDP 5568", code: 78) }
            sacnOpt = s
        }
        holder.sacn = sacnOpt

        olog(String(format: "frame budget %.1f ms%@ (governor trips at GPU p95 > budget; late-frame alarm over budget)", gFrameBudgetMs,
                    gFrameBudgetMs == defaultFrameBudgetMs ? "" : " (--frame-budget-ms)"))

        let (cfgDir, allowed, ndiCfgLine) = ndiConfigInfo()
        olog(ndiCfgLine)
        let ifs = localIPv4()
        olog("local IPv4: " + ifs.map { "\($0.0)=\($0.1)" }.joined(separator: " "))
        for a in allowed where !ifs.contains(where: { $0.1 == a }) {
            olog("WARNING: adapters.allowed entry \(a) is not an address of this Mac: NDI will not be reachable on the network (pin-check / wrong config)")
        }

        gNDIOut = NDIOut(cfg: cfg)                // the frame ring; the sender is the helper or a native thread (ndiout.swift)

        gLibrary = Library(dir: mediaDirFor(cfg))
        olog("fx: " + FXPresets.shared.load())
        let engine: Engine
        do { engine = try Engine(cfg: cfg) } catch { fail("\(error)", code: 70) }
        gNDIOut.attach(dev: engine.dev)

        let info = StaticInfo(libndiVersion: "", libndiPath: "", arch: arch, rosetta: translated,
                              ndiConfigDir: cfgDir, adaptersAllowed: allowed, logFile: Logger.shared.path)
        let status = StatusReporter(cfg: cfg, info: info, sacn: sacnOpt, filter: filter)
        holder.status = status
        watchdog.onStall = { status.setState("stall-exit"); status.writeJSON() }

        gNDIIn.start(cfg: cfg, dev: engine.dev)   // ndiin.swift: NDI sources as layer sources (finder + receivers, in this process)
        gOutput.attach(dev: engine.dev, bufs: engine.bufs, w: engine.w, h: engine.h)
        gRecorder.attach(dev: engine.dev, bufs: engine.bufs, w: engine.w, h: engine.h, fpsN: Int(cfg.fpsN), fpsD: Int(cfg.fpsD))   // recorder.swift
        engine.start()
        if !cfg.analysisOut.isEmpty { gControl.with { $0.analysisOut = cfg.analysisOut } }
        gScenes.load()
        gScenes.start()
        Playback().start()
        gAudio.start()                            // audio react input supervisor (audio.swift; source off until /oats/audio/source)
        PreviewServer(outFps: Double(cfg.fpsN) / Double(cfg.fpsD), filter: filter).start()   // TCP 8091; on bind failure: logged, no preview
        osc.start()
        sacnOpt?.start()
        status.start()

        func shutdown(_ why: String) {
            if gFlags.stopping {
                olog("\(why) again during shutdown: exiting now")
                Logger.shared.sync()
                _exit(0)
            }
            gFlags.stopping = true                // the watchdog stands down: this thread is the backstop now
            let backstop = Thread {
                usleep(4_500_000)
                olog("shutdown not finished after 4.5 s (NDI teardown hung?): _exit(75)")
                Logger.shared.sync()
                _exit(75)
            }
            backstop.qualityOfService = .userInteractive
            backstop.start()
            status.setState("stopping")
            olog("\(why) received: graceful shutdown (stop rendering; native NDI: flush + NDIlib_send_destroy; the helper keeps its sender)")
            let recStop = gRecorder.stop(why: why)        // recorder.swift: no more frames; the file finishes on its queue meanwhile
            if recStop != "not recording" { olog("recorder: " + recStop) }
            DispatchQueue.global(qos: .userInitiated).async {
                if engine.renderDone.wait(timeout: .now() + 3) == .timedOut {
                    olog("render loop did not stop within 3 s; exiting without NDI teardown (exit 75)")
                    Logger.shared.sync()
                    _exit(75)
                }
                if recStop != "not recording" && !gRecorder.waitIdle(timeout: 2.5) { olog("recorder: the file was not finished within 2.5 s") }
                if !gNDIOut.shutdown(timeout: 1.5) {
                    olog("native NDI sender still inside a send call after 1.5 s: exiting without NDI teardown (exit 75)")
                    Logger.shared.sync()
                    _exit(75)
                }
                status.setState("stopped")
                status.writeJSON()
                olog("oats-m0 exit 0")
                Logger.shared.sync()
                _exit(0)                          // no atexit / C++ static destructors while other threads still run
            }
        }
        for s in [SIGTERM, SIGINT] {
            signal(s, SIG_IGN)
            let src = DispatchSource.makeSignalSource(signal: s, queue: .main)
            let name = s == SIGTERM ? "SIGTERM" : "SIGINT"
            src.setEventHandler { shutdown(name) }
            src.resume()
            gSignalSources.append(src)
        }
        olog("running: NDI '\(cfg.name)' (\(cfg.ndiMode.rawValue)), OSC UDP \(cfg.oscPort), sACN UDP 5568 universe \(cfg.universe)")
        // NSApp run loop on the main thread, for the output window only (accessory: no Dock icon, no menu bar,
        // no window until a display is set). The render, send, OSC, sACN and status threads are unchanged; the
        // signal sources above stay on the main queue, which NSApp's run loop drains.
        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)
        let initialDisplay = cfg.outputDisplay
        DispatchQueue.main.async { gOutput.startMain(initial: initialDisplay) }
        app.run()
    }
}
