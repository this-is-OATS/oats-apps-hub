import Foundation
import Metal
import AVFoundation
import CoreVideo
import CoreMedia

// Program recorder (2026-10-23): PROGRAM to an MP4 on its own path, next to HDMI and NDI, never in front of them.
// The snapshot idea (output.swift encodeSnapshot: the same picture into an offscreen target, written off the output
// thread) extended to a stream of frames. Since 2026-10-24 the frame's command buffer carries ONE blit only: the UYVY
// program buffer (after master FX, dimmer, blackout: exactly what HDMI shows) into a slot of the recorder's own staging
// ring (4 MB, microseconds). When the GPU has finished the frame, a completion handler hands the slot to the recorder
// queue, and everything else happens there: a pixel buffer from the pool (IOSurface-backed BGRA), the UYVY -> BGRA
// compute pass on the recorder's OWN command queue (scaled to 1920x1080 or centre-cropped to 1080x1920; the queue waits
// for it, the render thread never does), the AVAssetWriter append (H.264 hardware, ~24 Mbit/s, BT.709), drop accounting,
// the disk guard and the file finish. With no free staging slot (the recorder queue is behind), no free pixel buffer
// (the encoder holds them all) or the writer not ready, the frame is dropped and counted; the render loop and the
// output never wait for the file. Before 2026-10-24 the compute pass wrote the IOSurface pixel buffer inside the frame's
// own command buffer: a buffer the hardware encoder had not released yet, or the pool/texture-cache work, could then
// land on the render tick (LATE frames with 20-60 ms "encode" while REC was on, restart #17 on 2026-10-23).
// Disk guard: refuses to start under 3 GB free, stops itself at 2 GB free or after 10 minutes; the file is always
// finished (OSC stop, SIGTERM / m0.sh restart, quit).

enum RecSize: String, CaseIterable {
    case p1080 = "1080p", vertical
    var w: Int { self == .p1080 ? 1920 : 1080 }
    var h: Int { self == .p1080 ? 1080 : 1920 }
    var label: String { self == .p1080 ? "16:9 1920x1080" : "9:16 1080x1920 (centre crop)" }
    static func parse(_ s: String) -> RecSize? {
        switch s.lowercased().trimmingCharacters(in: .whitespaces) {
        case "1080p", "16:9", "landscape", "hd", "h", "wide": return .p1080
        case "vertical", "9:16", "portrait", "v", "tall": return .vertical
        default: return nil
        }
    }
}

struct RecRefused: Error, CustomStringConvertible { let description: String }

struct RecPlan {
    var path = "", size = RecSize.p1080
    var w: Int { size.w }
    var h: Int { size.h }
}

final class Recorder {
    static let minStartGB = 3.0, stopGB = 2.0, maxSeconds = 600.0, slotCount = 6, bitrate = 24_000_000
    static let statusEvery = 30                        // frames between size / free-space checks (0.5 s at 60)

    // MARK: pure helpers (self-test: --selftest-dmx)

    static func defaultDir() -> String { (NSHomeDirectory() as NSString).appendingPathComponent("Movies/OATS VIZ/teaser-takes") }

    /// /oats/record/start [s path] [s size]: a string that parses as a size is the size, any other string is the path.
    static func parseArgs(_ args: [OSCArg]) -> (path: String, size: RecSize, bad: String) {
        var path = "", size = RecSize.p1080, bad = ""
        for a in args {
            guard case .s(let s) = a else { continue }
            let t = s.trimmingCharacters(in: .whitespaces)
            if t.isEmpty { continue }
            if let sz = RecSize.parse(t) { size = sz }
            else if t.hasPrefix("/") || t.hasPrefix("~") || t.lowercased().hasSuffix(".mp4") { path = t }
            else { bad = "unknown size '\(t.prefix(40))' (want 1080p | vertical; a path starts with / or ~ or ends .mp4)" }
        }
        return (path, size, bad)
    }

    /// The file to write for a start request, or why not (disk guard, bad path). `path` empty = the default name
    /// in the default folder; a directory (trailing / or an existing folder) gets the default name inside it.
    static func makePlan(path: String, size: RecSize, freeGB: Double, now: Date = Date()) -> Result<RecPlan, RecRefused> {
        guard freeGB >= minStartGB else {
            return .failure(RecRefused(description: String(format: "refused: %.1f GB free, need %.0f GB to start (stops by itself at %.0f GB)", freeGB, minStartGB, stopGB)))
        }
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyyMMdd-HHmmss"
        let name = f.string(from: now) + "-" + size.rawValue + ".mp4"
        var p = path.isEmpty ? defaultDir() : (path as NSString).expandingTildeInPath
        var isDir: ObjCBool = false
        if path.isEmpty || path.hasSuffix("/") || (FileManager.default.fileExists(atPath: p, isDirectory: &isDir) && isDir.boolValue) {
            p = (p as NSString).appendingPathComponent(name)
        } else if !p.lowercased().hasSuffix(".mp4") { p += ".mp4" }
        if FileManager.default.fileExists(atPath: p) { return .failure(RecRefused(description: "refused: \(p) exists")) }
        return .success(RecPlan(path: p, size: size))
    }

    static func freeGB(at path: String) -> Double {
        var dir = path
        while !dir.isEmpty && !FileManager.default.fileExists(atPath: dir) { dir = (dir as NSString).deletingLastPathComponent }
        if dir.isEmpty { dir = NSHomeDirectory() }
        if let v = try? URL(fileURLWithPath: dir).resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let b = v.volumeAvailableCapacityForImportantUsage { return Double(b) / 1e9 }
        if let a = try? FileManager.default.attributesOfFileSystem(forPath: dir), let b = a[.systemFreeSize] as? Int64 { return Double(b) / 1e9 }
        return 0
    }

    /// Where the canvas lands in the output: 1080p = the whole canvas fitted (black bars only for a non-16:9 canvas),
    /// vertical = the centre 9:16 of the canvas scaled to 1080 wide. (cw, ch) canvas px -> (src rect, dst rect).
    static func rects(size: RecSize, cw: Int, ch: Int) -> (src: SIMD4<Float>, dst: SIMD4<Float>) {
        let W = Float(size.w), H = Float(size.h), w = Float(cw), h = Float(ch)
        if size == .p1080 {
            let s = min(W / w, H / h), dw = (w * s).rounded(), dh = (h * s).rounded()
            return (SIMD4<Float>(0, 0, w, h), SIMD4<Float>(((W - dw) / 2).rounded(), ((H - dh) / 2).rounded(), dw, dh))
        }
        let sw = min(w, (h * 9 / 16).rounded()), sh = min(h, (sw * 16 / 9).rounded())
        return (SIMD4<Float>(((w - sw) / 2).rounded(), ((h - sh) / 2).rounded(), sw, sh), SIMD4<Float>(0, 0, W, H))
    }

    // MARK: runtime

    static let stageCount = 4                          // staging ring: UYVY copies of frames waiting for the recorder queue
    private let lock = NSLock()
    private let queue = DispatchQueue(label: "recorder", qos: .utility)
    private var dev: MTLDevice? = nil
    private var bufs: [MTLBuffer] = []
    private var stage: [MTLBuffer] = []                // the ring (shared; written by the frame's blit, read by the recorder's compute)
    private var stageFree: [Int] = []                  // (lock) ring slots not in flight
    private var rq: MTLCommandQueue? = nil             // the recorder's own command queue (its compute pass never rides a frame)
    private var cw = 1920, ch = 1080
    private var fpsN = 60, fpsD = 1
    private var pipe: MTLComputePipelineState? = nil
    private var pipeErr = ""
    // recording state (lock)
    private var on = false
    private var plan = RecPlan()
    private var src = SIMD4<Float>(0, 0, 1920, 1080), dst = SIMD4<Float>(0, 0, 1920, 1080)
    private var startAt = -1.0                           // frame time (engine seconds) of the first frame
    private var startWall = Date()
    private var frames: Int64 = 0, dropped: Int64 = 0
    private var lastPTS = Int64(-1)
    private var bytes: Int64 = 0, free = 0.0, seconds = 0.0
    private var note = "off"
    private var lastPath = "", lastSize = ""
    private var convertMs = 0.0, convertMax = 0.0        // the recorder queue's compute pass (status: convert_ms, convert_ms_max)
    private var tickMax = 0.0                            // render thread only: the longest encode() call this take (status: tick_ms_max)
    // writer + pool (recorder queue only, set by start under queue.sync)
    private var writer: AVAssetWriter? = nil
    private var input: AVAssetWriterInput? = nil
    private var adaptor: AVAssetWriterInputPixelBufferAdaptor? = nil
    private var pool: CVPixelBufferPool? = nil
    private var cache: CVMetalTextureCache? = nil

    func attach(dev: MTLDevice, bufs: [MTLBuffer], w: Int, h: Int, fpsN: Int, fpsD: Int) {
        self.dev = dev; self.bufs = bufs; cw = w; ch = h; self.fpsN = fpsN; self.fpsD = fpsD
        var ring: [MTLBuffer] = []
        for _ in 0..<Recorder.stageCount {
            guard let b = dev.makeBuffer(length: w * 2 * h, options: .storageModeShared) else { break }
            ring.append(b)
        }
        let q = dev.makeCommandQueue()
        q?.label = "recorder"
        lock.lock(); stage = ring; stageFree = Array(0..<ring.count); rq = q; lock.unlock()
        if ring.count < Recorder.stageCount || q == nil {
            lock.lock(); pipeErr = "staging ring / command queue allocation failed"; lock.unlock()
            olog("recorder: \(pipeErr): recording disabled"); return
        }
        queue.async { [self] in                          // the kernel compiles off the start-up path (a few ms)
            do {
                let lib = try dev.makeLibrary(source: recorderShaderSource, options: nil)
                guard let fn = lib.makeFunction(name: "rec_frame") else { throw NSError(domain: "rec", code: 1) }
                let p = try dev.makeComputePipelineState(function: fn)
                lock.lock(); pipe = p; lock.unlock()
            } catch { lock.lock(); pipeErr = "\(error)"; lock.unlock(); olog("recorder: kernel FAILED: \(error): recording disabled") }
        }
    }

    // MARK: OSC (any thread)

    func start(path: String, size: RecSize) -> String {
        guard !gFlags.stopping else { return "refused: shutting down" }
        lock.lock()
        let busy = on, p = pipe, perr = pipeErr, cur = plan.path
        lock.unlock()
        if busy { return "already recording \(cur) (stop first)" }
        guard p != nil, let dev = dev else { return perr.isEmpty ? "refused: recorder not ready yet" : "refused: kernel failed (\(perr))" }
        let dir = path.isEmpty ? Recorder.defaultDir() : ((path as NSString).expandingTildeInPath as NSString).deletingLastPathComponent
        let fr = Recorder.freeGB(at: dir)
        let pl: RecPlan
        switch Recorder.makePlan(path: path, size: size, freeGB: fr) {
        case .failure(let why): return why.description
        case .success(let v): pl = v
        }
        let folder = (pl.path as NSString).deletingLastPathComponent
        do { try FileManager.default.createDirectory(atPath: folder, withIntermediateDirectories: true) } catch { return "refused: cannot create \(folder): \(error.localizedDescription)" }
        // the pool: IOSurface-backed BGRA pixel buffers the kernel writes straight into (zero copy to the encoder)
        var pool: CVPixelBufferPool? = nil
        let attrs: [CFString: Any] = [kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_32BGRA, kCVPixelBufferWidthKey: pl.w, kCVPixelBufferHeightKey: pl.h,
                                      kCVPixelBufferIOSurfacePropertiesKey: [:] as CFDictionary, kCVPixelBufferMetalCompatibilityKey: true]
        guard CVPixelBufferPoolCreate(nil, nil, attrs as CFDictionary, &pool) == kCVReturnSuccess, let pool = pool else { return "refused: no pixel buffer pool" }
        var tc: CVMetalTextureCache? = nil
        guard CVMetalTextureCacheCreate(nil, nil, dev, nil, &tc) == kCVReturnSuccess, let tc = tc else { return "refused: no Metal texture cache" }
        // the writer (H.264 hardware, BT.709 tags, real-time input)
        let url = URL(fileURLWithPath: pl.path)
        let wr: AVAssetWriter
        do { wr = try AVAssetWriter(outputURL: url, fileType: .mp4) } catch { return "refused: \(error.localizedDescription)" }
        let fps = Double(fpsN) / Double(fpsD)
        let settings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: pl.w, AVVideoHeightKey: pl.h,
            AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: Recorder.bitrate, AVVideoExpectedSourceFrameRateKey: Int(fps.rounded()),
                                              AVVideoMaxKeyFrameIntervalKey: Int(fps.rounded()) * 2, AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
                                              AVVideoH264EntropyModeKey: AVVideoH264EntropyModeCABAC] as [String: Any],
            AVVideoColorPropertiesKey: [AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_709_2, AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                                        AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2] as [String: Any],
        ]
        guard wr.canApply(outputSettings: settings, forMediaType: .video) else { return "refused: the writer rejects the H.264 settings" }
        let inp = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        inp.expectsMediaDataInRealTime = true
        let ad = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: inp, sourcePixelBufferAttributes: attrs as [String: Any])
        guard wr.canAdd(inp) else { return "refused: cannot add the video input" }
        wr.add(inp)
        guard wr.startWriting() else { return "refused: \(wr.error?.localizedDescription ?? "startWriting failed")" }
        wr.startSession(atSourceTime: .zero)
        let r = Recorder.rects(size: pl.size, cw: cw, ch: ch)
        // the queue owns the writer and the pool; an earlier finish still running completes first
        queue.sync { [self] in
            writer = wr; input = inp; adaptor = ad; self.pool = pool; cache = tc
            lock.lock()
            plan = pl; src = r.src; dst = r.dst
            startAt = -1; startWall = Date(); frames = 0; dropped = 0; lastPTS = -1; bytes = 0; free = fr; seconds = 0
            convertMs = 0; convertMax = 0
            note = "recording"
            on = true
            lock.unlock()
        }
        let msg = String(format: "recording %@ (%@, H.264 %.0f Mbit/s %d/%d fps, canvas %dx%d, %.1f GB free)", pl.path, pl.size.label, Double(Recorder.bitrate) / 1e6, fpsN, fpsD, cw, ch, fr)
        olog("recorder: " + msg)
        return msg
    }

    /// Stops producing frames at once and finishes the file on the recorder queue (after the frames already queued).
    func stop(why: String) -> String {
        lock.lock()
        guard on else { lock.unlock(); return "not recording" }
        on = false; note = "finishing"
        let p = plan.path
        lock.unlock()
        queue.async { [self] in self.finish(why: why) }
        return "stopping \(p) (\(why))"
    }

    /// Shutdown: stops (if recording) and waits for the queue to drain (the file is finished) up to `timeout`.
    func waitIdle(timeout: Double) -> Bool {
        _ = stop(why: "shutdown")
        let s = DispatchSemaphore(value: 0)
        queue.async { s.signal() }
        return s.wait(timeout: .now() + timeout) == .success
    }

    // MARK: render thread: one blit into the staging ring, nothing else

    /// Called for every frame's command buffer once the program buffer `bufs[bi]` is complete (UYVY, after dimmer).
    /// One lock (a few fields), one blit encoder, one completed handler; the frame is dropped if the ring is full.
    @inline(__always) func encode(_ cb: MTLCommandBuffer, uyvy bi: Int, at t: Double) {
        let te0 = nowTicks()
        defer { tickMax = max(tickMax, ticksToSec(nowTicks() &- te0) * 1000) }
        lock.lock()
        guard on, pipe != nil else { lock.unlock(); return }
        if startAt < 0 { startAt = t; tickMax = 0 }
        guard let k = stageFree.popLast() else { dropped += 1; lock.unlock(); return }   // the recorder queue is behind: not recorded
        let t0 = startAt
        lock.unlock()
        guard let blit = cb.makeBlitCommandEncoder() else { lock.lock(); stageFree.append(k); dropped += 1; lock.unlock(); return }
        blit.copy(from: bufs[bi], sourceOffset: 0, to: stage[k], destinationOffset: 0, size: cw * 2 * ch)
        blit.endEncoding()
        let pts = Int64(((t - t0) * Double(fpsN) / Double(fpsD)).rounded()) * Int64(fpsD)
        cb.addCompletedHandler { [self] done in
            let ok = done.status == .completed
            self.queue.async { self.process(k, pts: pts, ok: ok) }
        }
    }

    // MARK: recorder queue

    /// One staged frame: a pixel buffer from the pool, the UYVY -> BGRA pass on the recorder's own command queue
    /// (waited for here), then the append. Any refusal on the way is a dropped frame; the slot always goes back.
    private func process(_ k: Int, pts: Int64, ok: Bool) {
        defer { lock.lock(); stageFree.append(k); lock.unlock() }
        func drop() { lock.lock(); dropped += 1; lock.unlock() }
        lock.lock()
        let live = on, last = lastPTS, p = pipe, w = plan.w, h = plan.h, s = src, d = dst
        lock.unlock()
        guard live, ok, k < stage.count, let pipe = p, let inp = input, let ad = adaptor, let wr = writer, wr.status == .writing,
              pts > last, inp.isReadyForMoreMediaData, let pool = pool, let tc = cache, let rq = rq else { drop(); return }
        // a pixel buffer: the pool refuses above the threshold (buffers still with the encoder) instead of anyone waiting
        let aux: [CFString: Any] = [kCVPixelBufferPoolAllocationThresholdKey: Recorder.slotCount * 2]
        var pb: CVPixelBuffer? = nil
        guard CVPixelBufferPoolCreatePixelBufferWithAuxAttributes(nil, pool, aux as CFDictionary, &pb) == kCVReturnSuccess, let pb = pb else { drop(); return }
        CVBufferSetAttachment(pb, kCVImageBufferColorPrimariesKey, kCVImageBufferColorPrimaries_ITU_R_709_2, .shouldPropagate)
        CVBufferSetAttachment(pb, kCVImageBufferTransferFunctionKey, kCVImageBufferTransferFunction_ITU_R_709_2, .shouldPropagate)
        CVBufferSetAttachment(pb, kCVImageBufferYCbCrMatrixKey, kCVImageBufferYCbCrMatrix_ITU_R_709_2, .shouldPropagate)
        let tattr: [CFString: Any] = [kCVMetalTextureUsage: MTLTextureUsage([.shaderWrite, .shaderRead]).rawValue]
        var cvt: CVMetalTexture? = nil
        guard CVMetalTextureCacheCreateTextureFromImage(nil, tc, pb, tattr as CFDictionary, .bgra8Unorm, w, h, 0, &cvt) == kCVReturnSuccess,
              let cvt = cvt, let tex = CVMetalTextureGetTexture(cvt) else { drop(); return }
        // the compute pass, on the recorder's queue (the frame's command buffer is long done with the staging slot)
        let tc0 = nowTicks()
        guard let cb = rq.makeCommandBuffer(), let enc = cb.makeComputeCommandEncoder() else { drop(); return }
        var prm = RecParams(a: SIMD4<UInt32>(UInt32(cw), UInt32(ch), UInt32(w), UInt32(h)), src: s, dst: d)
        let tg = MTLSize(width: pipe.threadExecutionWidth, height: max(1, pipe.maxTotalThreadsPerThreadgroup / pipe.threadExecutionWidth), depth: 1)
        enc.setComputePipelineState(pipe)
        enc.setBuffer(stage[k], offset: 0, index: 0)
        enc.setBytes(&prm, length: MemoryLayout<RecParams>.stride, index: 1)
        enc.setTexture(tex, index: 0)
        enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tg)
        enc.endEncoding()
        cb.commit()
        cb.waitUntilCompleted()                          // recorder queue only: never the render thread
        withExtendedLifetime(cvt) {}
        let cms = ticksToSec(nowTicks() &- tc0) * 1000
        guard cb.status == .completed else { drop(); return }
        if ad.append(pb, withPresentationTime: CMTime(value: pts, timescale: CMTimeScale(fpsN))) {
            lock.lock()
            frames += 1; lastPTS = pts; seconds = Date().timeIntervalSince(startWall)
            convertMs = cms; convertMax = max(convertMax, cms)
            let n = frames, path = plan.path
            lock.unlock()
            if n % Int64(Recorder.statusEvery) == 0 { guardCheck(path: path) }
        } else {
            drop()
            if wr.status == .failed {
                olog("recorder: write FAILED: \(wr.error?.localizedDescription ?? "?"): stopping")
                lock.lock(); on = false; note = "failed"; lock.unlock()
                finish(why: "write failed")
            }
        }
    }

    private func guardCheck(path: String) {
        let sz = (try? FileManager.default.attributesOfItem(atPath: path))?[.size] as? Int64 ?? 0
        let fr = Recorder.freeGB(at: (path as NSString).deletingLastPathComponent)
        lock.lock(); bytes = sz; free = fr; let el = Date().timeIntervalSince(startWall); lock.unlock()
        if fr < Recorder.stopGB { olog(String(format: "recorder: %.2f GB free: stopping (disk guard)", fr)); _ = stop(why: String(format: "disk guard: %.1f GB free", fr)) }
        else if el >= Recorder.maxSeconds { olog(String(format: "recorder: %.0f s: stopping (time limit)", el)); _ = stop(why: "10 minute limit") }
    }

    private func finish(why: String) {
        guard let wr = writer, let inp = input else { return }
        writer = nil; input = nil; adaptor = nil
        let t0 = nowTicks()
        if wr.status == .writing { inp.markAsFinished() }
        let s = DispatchSemaphore(value: 0)
        if wr.status == .writing { wr.finishWriting { s.signal() } } else { s.signal() }
        let done = s.wait(timeout: .now() + 8) == .success
        let p = wr.outputURL.path
        let sz = (try? FileManager.default.attributesOfItem(atPath: p))?[.size] as? Int64 ?? 0
        lock.lock()
        let n = frames, dr = dropped, cmax = convertMax, tmax = tickMax
        bytes = sz; seconds = Date().timeIntervalSince(startWall); lastPath = p; lastSize = plan.size.rawValue
        note = wr.status == .completed ? "done" : "failed"
        lock.unlock()
        if let c = cache { CVMetalTextureCacheFlush(c, 0) }
        cache = nil; pool = nil
        let ms = ticksToSec(nowTicks() &- t0) * 1000
        if wr.status == .completed {
            olog(String(format: "recorder: finished %@: %lld frames, %lld dropped, %.1f MB, %.1f s (%@; finish %.0f ms; render tick max %.2f ms, convert pass max %.1f ms on the recorder queue)",
                        p, n, dr, Double(sz) / 1e6, Date().timeIntervalSince(startWall), why, ms, tmax, cmax))
        } else {
            olog("recorder: finish FAILED for \(p) (\(why)): \(wr.error?.localizedDescription ?? "status \(wr.status.rawValue)")\(done ? "" : " (timed out)")")
        }
    }

    // MARK: status.json

    func statusDict() -> [String: Any] {
        lock.lock(); defer { lock.unlock() }
        let live = on
        return ["on": live, "path": live ? plan.path : lastPath, "size": live ? plan.size.rawValue : lastSize,
                "frames": frames, "dropped": dropped, "seconds": (seconds * 10).rounded() / 10, "bytes": bytes,
                "free_gb": (free * 100).rounded() / 100, "note": note, "sizes": RecSize.allCases.map { $0.rawValue },
                "convert_ms": (convertMs * 100).rounded() / 100, "convert_ms_max": (convertMax * 100).rounded() / 100,
                "tick_ms_max": (tickMax * 100).rounded() / 100,
                "dir": Recorder.defaultDir(), "min_start_gb": Recorder.minStartGB, "stop_gb": Recorder.stopGB, "max_seconds": Recorder.maxSeconds] as [String: Any]
    }
}

let gRecorder = Recorder()

struct RecParams { var a: SIMD4<UInt32>; var src: SIMD4<Float>; var dst: SIMD4<Float> }

private let recorderShaderSource = """
#include <metal_stdlib>
using namespace metal;
// Output px -> canvas px through the dst / src rects (fit for 16:9, centre crop for 9:16), bilinear from the UYVY
// program buffer (BT.709 video range, as the output window and the snapshot decode it); black outside the dst rect.
struct RecP { uint4 a; float4 src; float4 dst; };   // a: canvas w, canvas h, out w, out h
static float3 uyvy(const device uchar4* buf, int x, int y, int w, int h) {
    x = clamp(x, 0, w - 1); y = clamp(y, 0, h - 1);
    uchar4 q = buf[y * (w / 2) + x / 2];
    float Y = (x & 1) ? float(q.w) : float(q.y);
    float U = float(q.x) - 128.0, V = float(q.z) - 128.0;
    float yy = 1.164383 * (Y - 16.0);
    return saturate(float3(yy + 1.792741 * V, yy - 0.213249 * U - 0.532909 * V, yy + 2.112402 * U) / 255.0);
}
kernel void rec_frame(const device uchar4* buf [[buffer(0)]], constant RecP& P [[buffer(1)]],
                      texture2d<float, access::write> out [[texture(0)]], uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= P.a.z || gid.y >= P.a.w) return;
    float2 u = (float2(gid) + 0.5 - P.dst.xy) / P.dst.zw;
    if (u.x < 0.0 || u.y < 0.0 || u.x >= 1.0 || u.y >= 1.0) { out.write(float4(0.0, 0.0, 0.0, 1.0), gid); return; }
    float2 sp = P.src.xy + u * P.src.zw;
    int w = int(P.a.x), h = int(P.a.y);
    float2 c = sp - 0.5;
    int2 i = int2(floor(c));
    float2 f = c - floor(c);
    float3 a = mix(uyvy(buf, i.x, i.y, w, h), uyvy(buf, i.x + 1, i.y, w, h), f.x);
    float3 b = mix(uyvy(buf, i.x, i.y + 1, w, h), uyvy(buf, i.x + 1, i.y + 1, w, h), f.x);
    out.write(float4(mix(a, b, f.y), 1.0), gid);
}
"""
