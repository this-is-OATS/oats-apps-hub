import Foundation
import Darwin
import Accelerate
import AVFoundation
import CoreAudio
import AudioToolbox

// Audio react (2026-10-23). Audio in -> analysis -> mod matrix. Nothing here runs on the render thread except
// AudioModRuntime.step (8 routes, a few multiplies) and one lock-protected copy of the features per frame.
//
// INPUT (/oats/audio/source off|ndi|device, default off):
//   ndi     an NDI receiver in this native arm64 process (the arm64 freeze was in SEND only), audio only
//           (bandwidth audio_only, no video pointer), on the first source whose name contains /oats/audio/ndi (case
//           ignored). Its own thread captures with a 100 ms timeout; the supervisor thread recreates the receiver
//           when a capture call is stuck > 1 s (the stuck thread is abandoned: it destroys its receiver if it ever
//           returns), when no audio came for 4 s, or when the name changes. FLTP planar float -> mono (channel mean).
//   device  AVAudioEngine input tap on a CoreAudio device (name substring), channel 0 = mix of all, n = channel n.
//           macOS asks for microphone permission for the process that runs the player (Terminal for m0.sh, the app
//           for the standalone app); without it the tap delivers silence (status audio.mic_permission).
// ANALYSIS (its own lock; runs on the input thread, one hop at a time): FFT 2048 (vDSP, Hann), hop = rate / 93.75
//   (512 at 48 kHz = 10.7 ms, ~94 Hz). 6 bands with settable edges; each a level 0..1 = dB above (AGC reference - 24 dB),
//   the AGC reference following the band's recent peaks (rise 0.3 s, fall 2 dB/s; off = fixed -48...0 dBFS), then
//   attack / release smoothing. Onsets kick / snare / hat: positive log-spectral flux in the kick band / the snare crack
//   band (1.5-5 kHz, with the snare body 150-300 Hz rising >= 3 dB within 3 hops of it) / high + air, adaptive threshold
//   (EMA mean + k x sd over ~1 s, plus a floor), rising edge, hold-off; each a trigger (count) + an envelope 0..1 (tau 150 /
//   130 / 80 ms). KICK PRESENCE (2026-10-23): log flux is level-independent, so a high-pass-filtered kick (DJ filter sweep)
//   kept firing on what leaked through while the AGC pumped the empty band back up. Now the ABSOLUTE (pre-AGC) kick-band
//   dB is held against a slow reference (95th percentile of 100 ms maxima over 10 s; release 6 dB/s while kicks are being
//   accepted, 1 dB/s while none are): a kick hit needs the
//   band within 15 dB of it, its strength = confidence 0..1 between -15 and -6 dB (peak follower, fall 6 dB/s), and after
//   >= 3 s without an accepted kick the hits (and the continuous `kick` level) ease back in over ~1 s (return ramp) so a
//   filter roll-back fades the effect into the scene. The continuous `kick` source = AGC level x confidence; the other
//   bands are untouched. status.json audio.kick_confidence / audio.json "kc". Energy = slow RMS (1.5 s) vs its own slow peak; build = energy
//   slope over the last 8 bars (tempo clock BPM); drop = energy jump vs the 4 bars before, after a build or a quiet
//   section (hold-off 8 bars), envelope tau 1.5 s. Optional: onsets quantised to the beat grid while Link leads.
// MOD MATRIX: 8 routes in Control.audioRoutes (stored in scenes), evaluated per frame in engine.swift on top of the
// current values (like the phasers): base values and owners are never written.

let audioBandNames = ["kick", "bass", "lowmid", "mid", "high", "air"]
let audioBandDefaults: [(Double, Double)] = [(20, 120), (120, 250), (250, 1000), (1000, 4000), (4000, 10000), (10000, 16000)]
/// Snare detector bands (Hz), settable like the bands: /oats/audio/band/snare_body and /oats/audio/band/snare_crack.
let audioSnareBodyDefault: (Double, Double) = (150, 300), audioSnareCrackDefault: (Double, Double) = (1500, 5000)
let audioRouteCount = 8
let audioHitNames = ["kick", "snare", "hat"]

enum AudioSource: String, CaseIterable { case off, ndi, device }

enum AudioModSource: String, CaseIterable {
    case kick, bass, lowmid, mid, high, air, energy, build, kick_hit, snare_hit, hat_hit, drop
    var isTrigger: Bool { self == .kick_hit || self == .snare_hit || self == .hat_hit || self == .drop }
    static func parse(_ s: String) -> AudioModSource? {
        let k = s.lowercased().filter { $0.isLetter || $0.isNumber }
        let alias: [String: AudioModSource] = ["kickhit": .kick_hit, "snarehit": .snare_hit, "hathit": .hat_hit, "snare": .snare_hit,
                                               "hat": .hat_hit, "hihat": .hat_hit, "lowmids": .lowmid, "low": .bass, "rms": .energy]
        return alias[k] ?? AudioModSource.allCases.first { $0.rawValue.filter { $0.isLetter } == k }
    }
}

enum AudioModTarget: String, CaseIterable {
    case opacity, scale, rotation, spin, posx, posy, fx1, fx2, gen_count, gen_thickness, gen_speed, fx1_speed, fx2_speed, overlay_opacity
    case spread, zoom, rotkick, palette, julia, trapsize
    case dimmer, masterfx, masterfx_speed, strobe, scene
    var isLayer: Bool { AudioModTarget.allCases.firstIndex(of: self)! <= AudioModTarget.allCases.firstIndex(of: .overlay_opacity)! }
    var group: String { isLayer ? "layer" : ([.dimmer, .masterfx, .masterfx_speed, .strobe].contains(self) ? "master" : (self == .scene ? "scene" : "fractal")) }
    static func parse(_ s: String) -> AudioModTarget? {
        let k = s.lowercased().filter { $0.isLetter || $0.isNumber }
        let alias: [String: AudioModTarget] = ["x": .posx, "y": .posy, "positionx": .posx, "positiony": .posy, "rot": .rotation,
            "fx1amount": .fx1, "fx2amount": .fx2, "fx1speed": .fx1_speed, "speed1": .fx1_speed, "fx2speed": .fx2_speed, "speed2": .fx2_speed, "count": .gen_count, "gencount": .gen_count, "thickness": .gen_thickness,
            "genthickness": .gen_thickness, "genspeed": .gen_speed, "overlay": .overlay_opacity, "overlayopacity": .overlay_opacity, "ovl": .overlay_opacity, "zoompulse": .zoom, "breathe": .zoom, "rotationkick": .rotkick,
            "kick": .rotkick, "paletteoffset": .palette, "offset": .palette, "juliamorph": .julia, "size": .trapsize,
            "dimmerpulse": .dimmer, "dim": .dimmer, "masterfxamount": .masterfx, "fx": .masterfx, "masterfxspeed": .masterfx_speed, "fxspeed": .masterfx_speed, "strobeflash": .strobe,
            "flash": .strobe, "scenego": .scene, "go": .scene]
        return alias[k] ?? AudioModTarget.allCases.first { $0.rawValue.filter { $0.isLetter || $0.isNumber } == k }
    }
}

enum AudioCurve: String, CaseIterable {
    case linear, soft, hard
    /// soft = ease-out (moves early and gently), hard = cube (only the peaks).
    func apply(_ v: Double) -> Double {
        let x = min(1, max(0, v))
        switch self { case .linear: return x; case .soft: return 1 - (1 - x) * (1 - x); case .hard: return x * x * x }
    }
}

/// One mod-matrix route: source -> target, x amount (signed), curve, one-pole smoothing (seconds).
struct AudioRoute: Equatable {
    var on = false
    var source: AudioModSource = .kick
    var target: AudioModTarget = .scale
    var layer = 1                       // 1..4 for layer targets
    var scene = 0                       // scene target: 1..128, 0 = next stored scene in the bank
    var amount = 0.5                    // -2..2
    var curve: AudioCurve = .linear
    var smooth = 0.05                   // seconds 0..2
    var dict: [String: Any] {
        ["on": on, "source": source.rawValue, "target": target.rawValue, "layer": layer == 0 ? "BG" as Any : layer as Any, "scene": scene,
         "amount": (amount * 1000).rounded() / 1000, "curve": curve.rawValue, "smooth": (smooth * 1000).rounded() / 1000]
    }
    /// From a scene / preset dict; missing keys keep `base`. layer "L" / 0 in a preset = `presetLayer`.
    static func from(_ d: [String: Any], base: AudioRoute = AudioRoute(), presetLayer: Int = 1) -> AudioRoute {
        var r = base
        func num(_ k: String) -> Double? { (d[k] as? NSNumber).map { $0.doubleValue }.flatMap { $0.isFinite ? $0 : nil } }
        if let v = d["on"] as? NSNumber { r.on = v.boolValue }
        if let s = d["source"] as? String, let v = AudioModSource.parse(s) { r.source = v }
        if let s = d["target"] as? String, let v = AudioModTarget.parse(s) { r.target = v }
        if let v = num("layer") { r.layer = v < 1 ? presetLayer : min(layerCount, Int(v.rounded())) }
        else if let s = d["layer"] as? String { r.layer = s.uppercased() == "BG" ? 0 : presetLayer }   // "BG" = the base layer L0
        if let v = num("scene") { r.scene = min(sceneMax, max(0, Int(v.rounded()))) }
        if let v = num("amount") { r.amount = min(2, max(-2, v)) }
        if let s = d["curve"] as? String, let v = AudioCurve(rawValue: s.lowercased()) { r.curve = v }
        if let v = num("smooth") { r.smooth = min(2, max(0, v)) }
        return r
    }
}

/// What the render thread reads each frame.
struct AudioFeatures {
    var levels = [Double](repeating: 0, count: 6)
    var hits = [Double](repeating: 0, count: 3)
    var energy = 0.0, build = 0.0, drop = 0.0
    var kickConf = 0.0                   // kick presence x return ramp (levels[0] already has it applied)
    func value(_ s: AudioModSource) -> Double {
        switch s {
        case .kick: return levels[0]; case .bass: return levels[1]; case .lowmid: return levels[2]
        case .mid: return levels[3]; case .high: return levels[4]; case .air: return levels[5]
        case .energy: return energy; case .build: return build
        case .kick_hit: return hits[0]; case .snare_hit: return hits[1]; case .hat_hit: return hits[2]
        case .drop: return drop
        }
    }
}

// MARK: - libndi receive side (dlopen; the send side stays in ndi.swift / the helper)

struct NDIRecvLib {
    let initialize: fn_initialize
    let version: fn_version
    let find_create_v2: fn_find_create_v2
    let find_get_current_sources: fn_find_get_current
    let recv_create_v3: fn_recv_create_v3
    let recv_destroy: fn_recv_destroy
    let recv_capture: fn_recv_capture_audio_v2
    let recv_free_audio: fn_recv_free_audio_v2
    let recv_connections: fn_recv_get_no_connections

    static func load() throws -> NDIRecvLib {
        let path = ProcessInfo.processInfo.environment["NDI_LIB"] ?? "/usr/local/lib/libndi.dylib"
        guard let h = dlopen(path, RTLD_NOW | RTLD_LOCAL) else { throw NDILib.LoadError(description: "dlopen(\(path)) failed: \(String(cString: dlerror()))") }
        func s<T>(_ n: String) throws -> T {
            guard let p = dlsym(h, n) else { throw NDILib.LoadError(description: "dlsym failed: \(n)") }
            return unsafeBitCast(p, to: T.self)
        }
        return NDIRecvLib(initialize: try s("NDIlib_initialize"), version: try s("NDIlib_version"),
                          find_create_v2: try s("NDIlib_find_create_v2"), find_get_current_sources: try s("NDIlib_find_get_current_sources"),
                          recv_create_v3: try s("NDIlib_recv_create_v3"), recv_destroy: try s("NDIlib_recv_destroy"),
                          recv_capture: try s("NDIlib_recv_capture_v2"), recv_free_audio: try s("NDIlib_recv_free_audio_v2"),
                          recv_connections: try s("NDIlib_recv_get_no_connections"))
    }
}

// MARK: - CoreAudio devices

struct AudioDeviceEntry { let id: AudioDeviceID; let name: String; let inputs: Int; let outputs: Int }

func coreAudioDevices() -> [AudioDeviceEntry] {
    var addr = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyDevices, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
    var size: UInt32 = 0
    let sys = AudioObjectID(kAudioObjectSystemObject)
    guard AudioObjectGetPropertyDataSize(sys, &addr, 0, nil, &size) == noErr, size > 0 else { return [] }
    var ids = [AudioDeviceID](repeating: 0, count: Int(size) / MemoryLayout<AudioDeviceID>.size)
    guard AudioObjectGetPropertyData(sys, &addr, 0, nil, &size, &ids) == noErr else { return [] }
    func channels(_ id: AudioDeviceID, _ scope: AudioObjectPropertyScope) -> Int {
        var a = AudioObjectPropertyAddress(mSelector: kAudioDevicePropertyStreamConfiguration, mScope: scope, mElement: kAudioObjectPropertyElementMain)
        var sz: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(id, &a, 0, nil, &sz) == noErr, sz > 0 else { return 0 }
        let raw = UnsafeMutableRawPointer.allocate(byteCount: Int(sz), alignment: 16)
        defer { raw.deallocate() }
        guard AudioObjectGetPropertyData(id, &a, 0, nil, &sz, raw) == noErr else { return 0 }
        let abl = UnsafeMutableAudioBufferListPointer(raw.assumingMemoryBound(to: AudioBufferList.self))
        return abl.reduce(0) { $0 + Int($1.mNumberChannels) }
    }
    return ids.map { id in
        var a = AudioObjectPropertyAddress(mSelector: kAudioObjectPropertyName, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
        var name: Unmanaged<CFString>? = nil
        var sz = UInt32(MemoryLayout<Unmanaged<CFString>?>.size)
        let n = AudioObjectGetPropertyData(id, &a, 0, nil, &sz, &name) == noErr ? (name?.takeRetainedValue() as String? ?? "?") : "?"
        return AudioDeviceEntry(id: id, name: n, inputs: channels(id, kAudioObjectPropertyScopeInput), outputs: channels(id, kAudioObjectPropertyScopeOutput))
    }
}

func micPermission() -> String {
    switch AVCaptureDevice.authorizationStatus(for: .audio) {
    case .authorized: return "authorized"; case .denied: return "denied"; case .restricted: return "restricted"
    case .notDetermined: return "not_determined"; @unknown default: return "unknown"
    }
}

// MARK: - analysis

final class AudioAnalyzer {
    let n = 2048
    private let log2n: vDSP_Length = 11
    private let fft: FFTSetup
    private var window: [Float]
    private var fifo = [Float](repeating: 0, count: 2048)   // the last n samples (gained), newest at the end
    private var fresh = 0
    private(set) var rate = 48000.0
    private(set) var hop = 512
    private var re: [Float], im: [Float], mag: [Float], lg: [Float], lgPrev: [Float]
    private var ref = [Double](repeating: -60, count: 6)
    private var lvl = [Double](repeating: 0, count: 6)
    private var fluxMean = [Double](repeating: 0, count: 3), fluxVar = [Double](repeating: 0.01, count: 3)
    private var bodyHist = [-120.0, -120.0, -120.0]           // snare body band dB 3, 2, 1 hops ago
    private var lastBodyUp = -10.0, lastCrackUp = -10.0       // last hop where the body rose >= 3 dB / the crack flux crossed its threshold
    private var lastCrackOnlyAt = -10.0
    private(set) var crackOnsets = 0                          // crack-band onsets without a body rise (claps, hats, vocals): status snare_crack_onsets
    private(set) var bodyOnsets = 0                           // body rises (snares, bass notes, kick harmonics): status snare_body_onsets
    private var armed = [true, true, true]
    private var lastHit = [-10.0, -10.0, -10.0]
    private var pending: [Double?] = [nil, nil, nil]          // quantised hit due at this wall time
    private var strength = [1.0, 1.0, 1.0]                    // envelope height of the next fire (kick: confidence)
    private(set) var env = [Double](repeating: 0, count: 3)
    private(set) var counts = [0, 0, 0]
    // kick presence: absolute (pre-AGC) kick-band dB vs a slow reference
    private(set) var kickAbs = -90.0                          // peak follower of the kick band dB (fall 6 dB/s)
    private(set) var kickRef = -60.0                          // 95th percentile of 100 ms maxima over 10 s; release 6 dB/s while kicks are accepted, else 1 dB/s
    private var kickSlots: [Double] = []                      // 100 ms slot maxima (newest last), <= 100
    private var slotMax = -120.0, slotAcc = 0.0
    private var lastKickAccepted = -10.0
    private var inGap = false, gapLow = false                 // >= 3 s without an accepted kick (gapLow: presence fell too)
    private var ramp = 1.0                                    // return ramp 0..1
    private(set) var kickPresence = 0.0                       // 0..1 between ref - 15 and ref - 6 dB
    private(set) var kickConf = 0.0                           // presence x ramp (what the hits and the `kick` level use)
    private var powFast = 0.0, powSlow = 0.0, longRef = -40.0
    private(set) var energy = 0.0, build = 0.0, dropEnv = 0.0, drops = 0
    private var hist: [Double] = []                           // energy at 10 Hz (for build / drop)
    private var buildHist: [Double] = []
    private var histAcc = 0.0
    private var lastDrop = -1e9
    private(set) var t = 0.0                                  // seconds of audio analysed
    var onTrigger: ((AudioModSource) -> Void)? = nil
    var onHop: ((AudioFeatures) -> Void)? = nil

    init() {
        fft = vDSP_create_fftsetup(11, FFTRadix(kFFTRadix2))!
        window = [Float](repeating: 0, count: 2048)
        vDSP_hann_window(&window, vDSP_Length(2048), Int32(vDSP_HANN_NORM))
        re = [Float](repeating: 0, count: 1024); im = re; mag = re; lg = re; lgPrev = re
    }

    func reset(rate r: Double) {
        rate = r > 1000 ? r : 48000
        hop = max(128, Int((rate / 93.75).rounded()))
        for i in 0..<fifo.count { fifo[i] = 0 }
        fresh = 0
        for i in 0..<lgPrev.count { lgPrev[i] = -10 }
        lvl = [Double](repeating: 0, count: 6); ref = [Double](repeating: -60, count: 6)
        env = [0, 0, 0]; pending = [nil, nil, nil]; armed = [true, true, true]; strength = [1, 1, 1]
        hist = []; buildHist = []; histAcc = 0; powFast = 0; powSlow = 0; energy = 0; build = 0; dropEnv = 0
        kickAbs = -90; kickRef = -60; kickSlots = []; slotMax = -120; slotAcc = 0
        lastKickAccepted = t - 10; inGap = false; gapLow = false; ramp = 1; kickPresence = 0; kickConf = 0
        bodyHist = [-120, -120, -120]; lastBodyUp = t - 10; lastCrackUp = t - 10; lastCrackOnlyAt = t - 10
    }

    /// Mono samples (already gained). Runs every complete hop.
    func feed(_ p: UnsafePointer<Float>, _ count: Int, _ s: AudioSettings) {
        var i = 0
        while i < count {
            let take = min(count - i, hop - fresh)
            // shift left by `take`, append
            fifo.withUnsafeMutableBufferPointer { b in
                let base = b.baseAddress!
                memmove(base, base + take, (n - take) * MemoryLayout<Float>.size)
                memcpy(base + (n - take), p + i, take * MemoryLayout<Float>.size)
            }
            fresh += take; i += take
            if fresh >= hop { fresh = 0; process(s) }
        }
    }

    private func process(_ s: AudioSettings) {
        let dt = Double(hop) / rate
        t += dt
        // RMS of this hop (the newest hop samples)
        var ms: Float = 0
        let hn = min(hop, n)
        fifo.withUnsafeBufferPointer { b in vDSP_measqv(b.baseAddress! + (n - hn), 1, &ms, vDSP_Length(hn)) }
        // FFT
        var buf = [Float](repeating: 0, count: n)
        vDSP_vmul(fifo, 1, window, 1, &buf, 1, vDSP_Length(n))
        re.withUnsafeMutableBufferPointer { rp in
            im.withUnsafeMutableBufferPointer { ip in
                var sc = DSPSplitComplex(realp: rp.baseAddress!, imagp: ip.baseAddress!)
                buf.withUnsafeBufferPointer { bp in
                    bp.baseAddress!.withMemoryRebound(to: DSPComplex.self, capacity: n / 2) { vDSP_ctoz($0, 2, &sc, 1, vDSP_Length(n / 2)) }
                }
                vDSP_fft_zrip(fft, &sc, 1, log2n, FFTDirection(FFT_FORWARD))
                ip[0] = 0                                     // packed Nyquist: ignored
                vDSP_zvmags(&sc, 1, &mag, 1, vDSP_Length(n / 2))
            }
        }
        // full-scale sine (Hann, zrip x2) ~ 0 dB per band
        var k: Float = 1 / Float(Double(n) * Double(n) / 4)
        vDSP_vsmul(mag, 1, &k, &mag, 1, vDSP_Length(n / 2))
        for j in 0..<(n / 2) { lg[j] = log10f(mag[j] + 1e-10) }
        let binHz = rate / Double(n)
        func bins(_ lo: Double, _ hi: Double) -> Range<Int> {
            let a = max(1, Int((lo / binHz).rounded(.down))), b = min(n / 2 - 1, max(a + 1, Int((hi / binHz).rounded(.up))))
            return a..<b
        }
        // band levels: AGC reference follows recent peaks, level = dB above (ref - 24)
        let aA = s.attack <= 0 ? 1.0 : 1 - exp(-dt / s.attack), aR = s.release <= 0 ? 1.0 : 1 - exp(-dt / s.release)
        var kickDB = -120.0
        for b in 0..<6 {
            let r = bins(s.bands[b].0, s.bands[b].1)
            var e: Float = 0
            mag.withUnsafeBufferPointer { mp in vDSP_sve(mp.baseAddress! + r.lowerBound, 1, &e, vDSP_Length(r.count)) }
            let dB = 10 * log10(Double(e) + 1e-12)
            if b == 0 { kickDB = dB }
            var x: Double
            if s.agc {
                if dB > ref[b] { ref[b] += (dB - ref[b]) * (1 - exp(-dt / 0.3)) } else { ref[b] -= 2 * dt }
                ref[b] = max(-70, ref[b])
                x = (dB - (ref[b] - 24)) / 24
            } else {
                x = (dB + 48) / 48
            }
            x = min(1, max(0, x))
            lvl[b] += (x - lvl[b]) * (x > lvl[b] ? aA : aR)
        }
        // Kick presence: the absolute kick-band dB against its own slow reference (95th percentile of the 100 ms maxima
        // of the last 10 s, rising in ~1 s, never below -50 dB). Its release is 6 dB/s while kicks are being accepted (a
        // quieter track or section: re-adapt in a few seconds) and 1 dB/s while none are (the kick filtered out: hold, so
        // the gate stays shut). Presence 0..1 between ref - 15 and ref - 6 dB of a peak follower (fall 6 dB/s: a 1 s
        // kick gap costs 6 dB, still 1; a filtered kick is gone in ~3 s).
        kickAbs = max(kickDB, kickAbs - 6 * dt)
        slotMax = max(slotMax, kickDB); slotAcc += dt
        if slotAcc >= 0.1 {
            slotAcc -= 0.1
            kickSlots.append(slotMax); slotMax = -120
            if kickSlots.count > 100 { kickSlots.removeFirst(kickSlots.count - 100) }
            let sorted = kickSlots.sorted()
            let pct = sorted[min(sorted.count - 1, Int(Double(sorted.count) * 0.95))]
            let release = t - lastKickAccepted < 1.0 ? 0.6 : 0.1                   // dB per 100 ms slot
            if pct > kickRef { kickRef += (pct - kickRef) * (1 - exp(-0.1 / 1.0)) } else { kickRef = max(pct, kickRef - release) }
            kickRef = max(-50, kickRef)
        }
        kickPresence = min(1, max(0, (kickAbs - (kickRef - 15)) / 9))
        // Return ramp: >= 3 s without an accepted kick opens a gap; the ramp fades out (0.5 s) and comes back from 0.2
        // to 1 over 1 s once a kick is accepted again (or the presence rises back through 0.5 after having fallen).
        // 3 s, not 1.5: half-time and breakdown kicks 2 s apart must not keep re-opening the gap (live check 2026-10-24,
        // kc sat at 0 for 30 % of a sparse-kick passage with 1.5 s).
        if !inGap && t - lastKickAccepted >= 3.0 { inGap = true; gapLow = kickPresence < 0.5 }
        if inGap && kickPresence < 0.5 { gapLow = true }
        if inGap && gapLow && kickPresence > 0.5 { inGap = false; ramp = max(ramp, 0.2) }
        ramp = inGap ? max(0, ramp - dt / 0.5) : min(1, ramp + dt / 1.0)
        kickConf = kickPresence * ramp
        // onsets: positive log-spectral flux per detector band (snare: the crack band; its body band is checked below)
        let detBands: [[Range<Int>]] = [[bins(s.bands[0].0, s.bands[0].1)], [bins(s.snareCrack.0, s.snareCrack.1)],
                                         [bins(s.bands[4].0, s.bands[4].1), bins(s.bands[5].0, s.bands[5].1)]]
        let kSd = [1.5, 1.8, 1.8].map { $0 * (1.6 - s.sensitivity) }       // sensitivity 0.6 = these
        let floorF = [0.10, 0.06, 0.05], hold = [0.15, 0.15, 0.07], tau = [0.15, 0.13, 0.08]
        let now = ticksToSec(nowTicks() &- gStartTicks)
        var tot: Float = 0
        mag.withUnsafeBufferPointer { mp in vDSP_sve(mp.baseAddress! + 1, 1, &tot, vDSP_Length(n / 2 - 1)) }
        let totDB = 10 * log10(Double(tot) + 1e-12)
        let relGate = [-60.0, -30.0, -35.0]           // snare / hat band within 30 / 35 dB of the whole spectrum (no kick bleed)
        // pass 1: flux, threshold and loudness per detector (the snare test needs the kick's numbers)
        var fl = [0.0, 0.0, 0.0], th = [0.0, 0.0, 0.0], ld = [false, false, false]
        for d in 0..<3 {
            var f = 0.0, cnt = 0, eSum: Float = 0
            for r in detBands[d] {
                for j in r { f += Double(max(0, lg[j] - lgPrev[j])); eSum += mag[j] }
                cnt += r.count
            }
            fl[d] = f / Double(max(1, cnt))
            let eDB = 10 * log10(Double(eSum) + 1e-12)
            ld[d] = eDB > -65 && eDB > totDB + relGate[d]
            th[d] = fluxMean[d] + kSd[d] * sqrt(max(0, fluxVar[d])) + floorF[d]
        }
        // Snare body (150-300 Hz): the band's energy must have risen >= 3 dB over the last 3 hops (~32 ms at 48 kHz; the
        // 43 ms Hann window spreads a transient over ~4 hops, and the band also carries bass and kick harmonics, so a
        // sharper test missed every snare in a dense mix) and be above -60 dB; a snare needs that AND the crack onset (its
        // flux threshold) within 3 hops of each other. Claps / vocals / hats jump the crack alone, a bass note the body
        // alone. /oats/audio/snarebody 0 turns the body requirement off (crack only, as before 2026-10-23 evening).
        do {
            let r = bins(s.snareBody.0, s.snareBody.1)
            var e: Float = 0
            mag.withUnsafeBufferPointer { mp in vDSP_sve(mp.baseAddress! + r.lowerBound, 1, &e, vDSP_Length(r.count)) }
            let bodyDB = 10 * log10(Double(e) + 1e-12)
            if bodyDB > -60 && bodyDB - bodyHist[0] >= 3 {
                if t - lastBodyUp > hold[1] { bodyOnsets += 1 }
                lastBodyUp = t
            }
            bodyHist = [bodyHist[1], bodyHist[2], bodyDB]
            if fl[1] > th[1] { lastCrackUp = t }
        }
        let within = 3.5 * dt
        let snareTogether = !s.snareBodyGate || (t - lastBodyUp <= within && t - lastCrackUp <= within)
        // Kick gate: the kick must be present (absolute band dB within 15 dB of its reference), else the hit is dropped.
        let kickPresent = kickDB >= kickRef - 15
        // Kick mask: a kick's beater click and body also jump the 1.5-5 kHz snare crack band. Within 60 ms of a kick
        // (or while the kick band is jumping now), a snare only counts when its own jump clearly outweighs the
        // kick's: relative to their thresholds, at least 1.6x, and at least 2x its own threshold.
        let kickNow = fl[0] > th[0] && ld[0] && kickPresent
        let nearKick = kickNow || t - lastHit[0] < 0.06
        for d in 0..<3 {
            let f = fl[d], thr = th[d], loud = ld[d]
            var masked = false
            if d == 1 && nearKick {
                let snareRel = f / max(1e-6, thr), kickRel = fl[0] / max(1e-6, th[0])
                masked = !(snareRel >= 2 && snareRel >= 1.6 * kickRel)
            }
            if d == 1 && !snareTogether {
                if f > thr && loud && !masked && t - lastCrackOnlyAt > hold[1] { lastCrackOnlyAt = t; crackOnsets += 1 }
                masked = true
            }
            if d == 0 && !kickPresent { masked = true }
            if f > thr && armed[d] && loud && !masked && t - lastHit[d] > hold[d] {
                armed[d] = false; lastHit[d] = t
                if d == 0 {
                    if inGap { inGap = false; ramp = max(ramp, 0.2); kickConf = kickPresence * ramp }
                    lastKickAccepted = t
                    strength[0] = kickConf
                }
                hitDetected(d, now: now, q: s.quantize, s: s)
            } else if f < thr * 0.6 { armed[d] = true }
            let a = 1 - exp(-dt / 1.0), dv = f - fluxMean[d]
            fluxMean[d] += a * dv
            fluxVar[d] = (1 - a) * (fluxVar[d] + a * dv * dv)
            if let due = pending[d], now >= due { pending[d] = nil; fire(d) }
            env[d] *= exp(-dt / tau[d])
        }
        swap(&lg, &lgPrev)
        // energy (slow RMS vs its own slow peak), build (slope over 8 bars), drop
        let pw = Double(ms)
        powFast += (pw - powFast) * (1 - exp(-dt / 0.15))
        powSlow += (pw - powSlow) * (1 - exp(-dt / 1.5))
        let slowDB = 10 * log10(powSlow + 1e-12), fastDB = 10 * log10(powFast + 1e-12)
        if s.agc {
            if slowDB > longRef { longRef += (slowDB - longRef) * (1 - exp(-dt / 2)) } else { longRef -= 0.5 * dt }
            longRef = max(-60, longRef)
        } else { longRef = 0 }
        let eMap = { (db: Double) -> Double in min(1, max(0, (db - (self.longRef - 18)) / 18)) }
        energy = eMap(slowDB)
        let eFast = eMap(fastDB)
        dropEnv *= exp(-dt / 1.5)
        histAcc += dt
        if histAcc >= 0.1 {
            histAcc -= 0.1
            hist.append(energy); buildHist.append(build)
            if hist.count > 600 { hist.removeFirst(hist.count - 600); buildHist.removeFirst(buildHist.count - 600) }
            let bpm = gPlayback.with { $0.bpm }
            let bar = 4 * 60 / min(220, max(60, bpm > 0 ? bpm : 120))        // seconds per bar
            let w = min(hist.count, Int(8 * bar * 10))
            if w >= 20 {
                // least-squares slope over the window, as the rise across it
                let ys = hist.suffix(w)
                let mx = Double(w - 1) / 2, my = ys.reduce(0, +) / Double(w)
                var sxy = 0.0, sxx = 0.0
                for (j, y) in ys.enumerated() { let dx = Double(j) - mx; sxy += dx * (y - my); sxx += dx * dx }
                let rise = sxx > 0 ? sxy / sxx * Double(w) : 0
                build += (min(1, max(0, rise / 0.35)) - build) * 0.05
            }
            // drop: fast energy well above the 4 bars before the last half bar, after a build or a quiet section
            let pre = Int(4 * bar * 10), skip = Int(0.5 * bar * 10)
            if hist.count > pre + skip, t - lastDrop > 8 * bar {
                let seg = hist[(hist.count - pre - skip)..<(hist.count - skip)]
                let preMean = seg.reduce(0, +) / Double(seg.count)
                let bSeg = buildHist[(buildHist.count - pre - skip)..<buildHist.count]
                let builtUp = (bSeg.max() ?? 0) > 0.35
                if eFast - preMean > 0.3 && (builtUp || preMean < 0.35) && lvl[0] > 0.4 {
                    lastDrop = t; dropEnv = 1; drops += 1; build = 0
                    onTrigger?(.drop)
                }
            }
        }
        var out = lvl
        out[0] *= kickConf                                    // the continuous `kick` source fades with the kick presence
        onHop?(AudioFeatures(levels: out, hits: env, energy: energy, build: build, drop: dropEnv, kickConf: kickConf))
    }

    private func hitDetected(_ d: Int, now: Double, q: Double, s: AudioSettings) {
        // Snare backbeat gate: in dense music the 1-4 kHz snare band also jumps on claps, vocals, synth stabs and kick
        // clicks. While Link leads the tempo (djay), a snare only counts within an 1/8 beat of beat 2 or 4 of the bar
        // (at the time it really happened, i.e. now minus the measured latency). Without Link: ungated.
        if d == 1 && s.snareBackbeat {
            let pb = gPlayback.with { ($0.beat, $0.at, $0.rate, $0.bpmSource) }
            if pb.3.hasPrefix("link") && pb.2 > 0 {
                let spb = 60 / pb.2
                let bReal = pb.0 + max(0, now - pb.1) / spb - min(max(0, s.latency), 2 * spb) / spb
                let nearest = bReal.rounded()
                let inBar = Int(((nearest.truncatingRemainder(dividingBy: 4)) + 4).truncatingRemainder(dividingBy: 4))
                if abs(bReal - nearest) > 0.125 || inBar % 2 == 0 { return }
            }
        }
        if q > 0 {
            let pb = gPlayback.with { ($0.beat, $0.at, $0.rate, $0.bpmSource) }
            if pb.3.hasPrefix("link") && pb.2 > 0 {
                // The hit was heard `lat` late (NDI + analysis). Find where it really fell on the beat grid, snap it
                // to the nearest grid point there, then fire at that same spot in the bar a whole number of beats
                // later: an off-beat hat stays off-beat, and a kick lands exactly on a beat instead of late.
                let spb = 60 / pb.2
                let bNow = pb.0 + max(0, now - pb.1) / spb
                let lat = min(max(0, s.latency), 2 * spb)
                let g = ((bNow - lat / spb) / q).rounded() * q           // grid point of the real hit
                var due = g
                while due < bNow + 0.02 { due += max(1, q) }            // whole beats keep its place in the bar
                if pending[d] == nil { pending[d] = now + (due - bNow) * spb }
                return
            }
        }
        fire(d)
    }

    private func fire(_ d: Int) {
        env[d] = max(env[d], strength[d]); counts[d] += 1
        onTrigger?([.kick_hit, .snare_hit, .hat_hit][d])
    }

    /// Self-test / offline use: analyse `samples` (mono float, already gained) in hop-sized pieces.
    func analyze(_ samples: [Float], _ s: AudioSettings) {
        samples.withUnsafeBufferPointer { feed($0.baseAddress!, samples.count, s) }
    }
}

/// Settings the analysis reads (copied under the AudioIn lock per feed call).
struct AudioSettings {
    var gainDB = 0.0
    var agc = true
    var attack = 0.005                  // s
    var release = 0.12                  // s
    var bands = audioBandDefaults
    var snareBody = audioSnareBodyDefault    // Hz: the snare's body (150-300) ...
    var snareCrack = audioSnareCrackDefault  // ... and crack (1.5-5 kHz) must rise together within ~30 ms
    var snareBodyGate = true            // require the body rise (/oats/audio/snarebody i); off = crack onset only
    var quantize = 0.0                  // beats (0 = off); only while Link leads the tempo clock
    var latency = 0.0                   // s, input + analysis + NDI transport (set per feed; quantise compensates it)
    var snareBackbeat = true            // snare hits only near beats 2 / 4 while Link leads (/oats/audio/snaregate i)
    var sensitivity = 0.6               // 0..1 (higher = more onsets)
}

// MARK: - input + supervisor

final class AudioIn {
    private let lock = NSLock()
    private var source: AudioSource = .off
    private var ndiName = ""
    private var deviceName = ""
    private var channel = 0
    private var settings = AudioSettings()
    private let ana = AudioAnalyzer()
    private let feedLock = NSLock()                // one feeder at a time (an old NDI thread may still return)
    private var feat = AudioFeatures()
    private var featAt: UInt64 = 0
    // status
    private var connected = false
    private var connName = ""
    private var rate = 0.0
    private var channels = 0
    private var frameSamples = 0
    private var frames: Int64 = 0
    private var dropouts = 0
    private var recreated = 0
    private var note = ""
    private var lastAudio: UInt64 = 0
    private var ageMs = 0.0
    private var ageFloor = Double.nan, ageFloorAt = 0.0      // running floor of (now - NDI timecode) = the two clocks' offset
    private let ndiPathMs = 30.0                               // allowance for the NDI audio path itself (one frame + LAN)
    private var availNDI: [String] = []
    private var availDev: [[String: Any]] = []
    private var listedAt = 0.0
    private var listRequest = false
    // NDI
    private var lib: NDIRecvLib? = nil
    private var libErr = ""
    private var finder: NDIlib_find_instance_t? = nil
    private var gen = 0                             // receiver generation: a worker exits when it is no longer current
    private var workerName = ""
    private var inCallSince: UInt64 = 0             // the current worker's capture call (0 = not in a call)
    private var workerStarted: UInt64 = 0
    private var silentTimeout = 4.0                 // no audio this long -> reconnect; doubles per silent retry (max 30 s)
    // device
    private var engine: AVAudioEngine? = nil
    private var engineDev = ""
    private var tapFrames = 0
    private var deviceRetryAt: UInt64 = 0
    // scene triggers
    private var routes: [AudioRoute] = []
    private var lastSceneGo = [Double](repeating: -1e9, count: audioRouteCount)
    private var contArmed = [Bool](repeating: true, count: audioRouteCount)

    init() {
        ana.onTrigger = { [weak self] k in self?.trigger(k) }
        ana.onHop = { [weak self] f in self?.hop(f) }
    }

    func start() {
        let t = Thread { [self] in self.supervise() }
        t.name = "audio-supervisor"; t.qualityOfService = .utility; t.start()
    }

    /// Per frame, render thread: the latest features (zero when the input is off or stale > 0.5 s).
    func features() -> AudioFeatures {
        lock.lock(); defer { lock.unlock() }
        if featAt == 0 || ticksToSec(nowTicks() &- featAt) > 0.5 { return AudioFeatures() }
        return feat
    }

    // MARK: input threads -> analysis

    private func hop(_ f: AudioFeatures) { lock.lock(); feat = f; featAt = nowTicks(); lock.unlock(); checkContinuous(f) }

    /// Mono float samples from any input thread.
    private func deliver(_ p: UnsafePointer<Float>, _ count: Int, rate r: Double, frameChannels: Int, ndiTimestamp: Int64) {
        lock.lock()
        var s = settings
        let now = nowTicks()
        if lastAudio != 0 && ticksToSec(now &- lastAudio) > 0.15 && connected { dropouts += 1 }
        lastAudio = now; connected = true; frames += 1; frameSamples = count; channels = frameChannels
        if ndiTimestamp > 0 && ndiTimestamp != Int64.max {
            // NDI timecodes are the SENDER's wall clock. Across two Macs "now - timecode" is mostly their clock offset
            // (2.4 s seen 2026-10-24 with djay's Mac), not latency, and it was feeding the beat snap. So the age is
            // measured against its own running floor (the best path seen; it creeps up 2 ms/s so clock drift is followed,
            // and snaps down): what remains is queueing above the best case. A fixed allowance covers the path itself.
            let nowUTC = Date().timeIntervalSince1970 * 1e7
            let a = (nowUTC - Double(ndiTimestamp)) / 1e4
            if a > -60_000 && a < 60_000 {
                let t = nowUTC / 1e7
                if ageFloor.isNaN { ageFloor = a } else { ageFloor = min(a, ageFloor + 2.0 * max(0, t - ageFloorAt)) }
                ageFloorAt = t
                let q = ndiPathMs + max(0, a - ageFloor)
                ageMs += (q - ageMs) * 0.05
            }
        }
        let rateChanged = r != rate
        rate = r
        let transportS = source == .ndi ? max(0, ageMs) / 1000 : 0
        lock.unlock()
        feedLock.lock()
        if rateChanged || ana.rate != r { ana.reset(rate: r) }
        s.latency = (Double(count) + Double(ana.hop) + Double(ana.n) / 8) / max(1, r) + transportS   // same estimate as status latency_ms
        let g = Float(pow(10, s.gainDB / 20))
        if g == 1 { ana.feed(p, count, s) } else {
            var tmp = [Float](repeating: 0, count: count)
            var gg = g
            vDSP_vsmul(p, 1, &gg, &tmp, 1, vDSP_Length(count))
            tmp.withUnsafeBufferPointer { ana.feed($0.baseAddress!, count, s) }
        }
        feedLock.unlock()
    }

    // MARK: supervisor (utility thread, every 100 ms)

    private func supervise() {
        var tick = 0
        while !gFlags.stopping {
            usleep(100_000); tick += 1
            lock.lock()
            let src = source, name = ndiName, dev = deviceName, ch = channel
            let wantList = listRequest || (src == .ndi && tick % 10 == 0)
            listRequest = false
            if lastAudio != 0 && ticksToSec(nowTicks() &- lastAudio) > 1.0 { connected = false }
            lock.unlock()
            if tick % 3 == 0 { let rs = gControl.with { $0.audioRoutes }; lock.lock(); routes = rs; lock.unlock() }
            // NDI
            if src == .ndi || wantList { ensureNDI() }
            if wantList { refreshList() }
            if src == .ndi { superviseNDI(name) } else { stopNDI() }
            // device
            if src == .device { superviseDevice(dev, ch) } else if engine != nil { stopDevice() }
            if src == .off {
                lock.lock(); connected = false; connName = ""; note = ""; lock.unlock()
            }
            if tick % 10 == 0 { gAudioListen.tick() }               // listen monitor: open / close / retry its output, refresh the device name
        }
        stopDevice()
        gAudioListen.set(on: false)
    }

    private func ensureNDI() {
        if lib == nil && libErr.isEmpty {
            do {
                let l = try NDIRecvLib.load()
                guard l.initialize() else { throw NDILib.LoadError(description: "NDIlib_initialize failed") }
                lib = l
                olog("audio: libndi \(l.version().map { String(cString: $0) } ?? "?") loaded for NDI audio receive (arm64, this process; receive only)")
            } catch { libErr = "\(error)"; olog("audio: NDI unavailable: \(libErr)") }
        }
        if let l = lib, finder == nil {
            var fc = NDIlib_find_create_t(show_local_sources: true, p_groups: nil, p_extra_ips: nil)
            finder = l.find_create_v2(&fc)
            if finder == nil { olog("audio: NDIlib_find_create_v2 failed") }
        }
    }

    private func currentSources() -> [(name: String, url: String)] {
        guard let l = lib, let f = finder else { return [] }
        var n: UInt32 = 0
        guard let arr = l.find_get_current_sources(f, &n) else { return [] }
        return (0..<Int(n)).map { i in
            (arr[i].p_ndi_name.map { String(cString: $0) } ?? "", arr[i].p_url_address.map { String(cString: $0) } ?? "")
        }
    }

    private func refreshList() {
        let ndi = currentSources().map { $0.name }
        let devs = coreAudioDevices().map { d -> [String: Any] in ["name": d.name, "inputs": d.inputs, "outputs": d.outputs] }
        lock.lock(); availNDI = ndi; availDev = devs; listedAt = Date().timeIntervalSince1970; lock.unlock()
    }

    private func superviseNDI(_ want: String) {
        guard lib != nil else { lock.lock(); note = "NDI unavailable: \(libErr)"; lock.unlock(); return }
        lock.lock()
        let curName = workerName, since = inCallSince, started = workerStarted, la = lastAudio
        lock.unlock()
        let now = nowTicks()
        if !curName.isEmpty {
            var why = ""
            if want.isEmpty || !curName.lowercased().contains(want.lowercased()) { why = "source name changed" }
            else if since != 0 && ticksToSec(now &- since) > 1.0 { why = "capture call blocked > 1 s" }
            else if ticksToSec(now &- max(started, la)) > silentTimeout { why = String(format: "no audio for %.0f s", silentTimeout) }
            if why.isEmpty { return }
            if why.hasPrefix("no audio") { silentTimeout = min(30, silentTimeout * 2) }   // a silent source: back off
            lock.lock(); gen += 1; workerName = ""; inCallSince = 0; connected = false; ageFloor = .nan; ageMs = ndiPathMs; if why != "source name changed" { recreated += 1 }; lock.unlock()
            olog("audio: NDI receiver on '\(curName)' dropped (\(why)); reconnecting")
        }
        guard !want.isEmpty else { lock.lock(); note = "no NDI source name set (/oats/audio/ndi s NAME)"; lock.unlock(); return }
        let srcs = currentSources()
        guard let s = srcs.first(where: { $0.name.lowercased().contains(want.lowercased()) }) else {
            lock.lock(); note = "searching for an NDI source containing '\(want)' (\(srcs.count) visible)"; connName = ""; lock.unlock()
            return
        }
        lock.lock(); gen += 1; let g = gen; workerName = s.name; workerStarted = now; inCallSince = 0; note = "connecting"; connName = s.name; lock.unlock()
        let t = Thread { [self] in self.ndiWorker(g, s.name, s.url) }
        t.name = "audio-ndi-\(g)"; t.qualityOfService = .userInitiated; t.start()
    }

    private func stopNDI() {
        lock.lock()
        if !workerName.isEmpty { gen += 1; workerName = ""; inCallSince = 0 }
        lock.unlock()
    }

    private func ndiWorker(_ g: Int, _ name: String, _ url: String) {
        guard let l = lib else { return }
        let cn = strdup(name), cu = url.isEmpty ? nil : strdup(url), rn = strdup("VJ VIZZIES audio")
        defer { free(cn); if let u = cu { free(u) }; free(rn) }
        let src = NDIlib_source_t(p_ndi_name: UnsafePointer(cn), p_url_address: cu.map { UnsafePointer($0) })
        var rc = NDIlib_recv_create_v3_t(source_to_connect_to: src, color_format: 100, bandwidth: 10,   // fastest, audio only
                                         allow_video_fields: false, p_ndi_recv_name: UnsafePointer(rn))
        guard let recv = l.recv_create_v3(&rc) else {
            olog("audio: NDIlib_recv_create_v3 failed for '\(name)'")
            lock.lock(); if gen == g { workerName = "" }; lock.unlock(); return
        }
        olog("audio: NDI receiver created on '\(name)' (audio only, generation \(g))")
        var af = NDIlib_audio_frame_v2_t()
        var mono = [Float]()
        var first = true
        while !gFlags.stopping {
            lock.lock(); let cur = gen == g; if cur { inCallSince = nowTicks() }; lock.unlock()
            if !cur { break }
            let ty = l.recv_capture(recv, nil, &af, nil, 100)
            lock.lock(); let still = gen == g; if still { inCallSince = 0 }; lock.unlock()
            if ty == 2 {
                if still, af.no_samples > 0, af.no_channels > 0, af.sample_rate > 1000, let base = af.p_data {
                    let ns = Int(af.no_samples), nc = Int(af.no_channels), stride = Int(af.channel_stride_in_bytes) / MemoryLayout<Float>.size
                    if mono.count < ns { mono = [Float](repeating: 0, count: ns) }
                    mono.withUnsafeMutableBufferPointer { mp in
                        let m = mp.baseAddress!
                        memcpy(m, base, ns * MemoryLayout<Float>.size)
                        if nc > 1 {
                            for c in 1..<nc { vDSP_vadd(m, 1, base + c * stride, 1, m, 1, vDSP_Length(ns)) }
                            var k = 1 / Float(nc)
                            vDSP_vsmul(m, 1, &k, m, 1, vDSP_Length(ns))
                        }
                    }
                    if first {
                        first = false
                        olog("audio: first NDI audio frame from '\(name)': \(af.sample_rate) Hz, \(nc) ch, \(ns) samples/frame (FLTP planar float, stride \(af.channel_stride_in_bytes) B)")
                        lock.lock(); note = ""; silentTimeout = 4; lock.unlock()
                    }
                    mono.withUnsafeBufferPointer { deliver($0.baseAddress!, ns, rate: Double(af.sample_rate), frameChannels: nc, ndiTimestamp: af.timestamp) }
                    gAudioListen.push(frames: ns, channels: nc, rate: Double(af.sample_rate)) { c in UnsafePointer(base + c * stride) }   // listen monitor, all channels
                }
                l.recv_free_audio(recv, &af)
            } else if ty == 4 {
                olog("audio: NDI capture error on '\(name)'"); break
            }
            if !still { break }
        }
        l.recv_destroy(recv)
        lock.lock(); let was = gen == g; if was { workerName = ""; inCallSince = 0 }; lock.unlock()
        olog("audio: NDI receiver on '\(name)' destroyed (generation \(g)\(was ? "" : ", superseded"))")
    }

    // MARK: device input (AVAudioEngine)

    private func superviseDevice(_ want: String, _ ch: Int) {
        let key = want + "#\(ch)"
        if let e = engine, engineDev == key {
            if e.isRunning { return }
            olog("audio: input device stopped by the system (unplugged / format change?): restarting in 2 s")
            stopDevice(); deviceRetryAt = nowTicks() &+ secToTicks(2)
        } else if engine != nil { stopDevice() }
        if engineDev == key && nowTicks() < deviceRetryAt { return }     // not found / failed: retry every 2 s
        deviceRetryAt = nowTicks() &+ secToTicks(2)
        let devs = coreAudioDevices().filter { $0.inputs > 0 }
        guard let d = (want.isEmpty ? devs.first : devs.first { $0.name.lowercased().contains(want.lowercased()) }) else {
            lock.lock(); note = want.isEmpty ? "no audio input device on this Mac" : "no input device containing '\(want)' (\(devs.map { $0.name }.joined(separator: ", ")))"; connName = ""; lock.unlock()
            engineDev = key; engine = nil
            return
        }
        let perm = micPermission()
        if perm == "not_determined" { AVCaptureDevice.requestAccess(for: .audio) { ok in olog("audio: microphone permission \(ok ? "granted" : "refused")") } }
        let eng = AVAudioEngine()
        let input = eng.inputNode
        if let au = input.audioUnit {
            var id = d.id
            let st = AudioUnitSetProperty(au, kAudioOutputUnitProperty_CurrentDevice, kAudioUnitScope_Global, 0, &id, UInt32(MemoryLayout<AudioDeviceID>.size))
            if st != noErr { olog("audio: selecting input device '\(d.name)' failed (\(st))") }
        }
        let fmt = input.inputFormat(forBus: 0)
        guard fmt.sampleRate > 0, fmt.channelCount > 0 else {
            lock.lock(); note = "device '\(d.name)' has no usable input format"; lock.unlock(); engineDev = key; return
        }
        let nch = Int(fmt.channelCount), pick = ch
        var mono = [Float]()
        input.installTap(onBus: 0, bufferSize: 512, format: fmt) { [weak self] buf, _ in
            guard let self = self, let cd = buf.floatChannelData else { return }
            let ns = Int(buf.frameLength)
            guard ns > 0 else { return }
            if mono.count < ns { mono = [Float](repeating: 0, count: ns) }
            mono.withUnsafeMutableBufferPointer { mp in
                let m = mp.baseAddress!
                if pick >= 1 && pick <= nch { memcpy(m, cd[pick - 1], ns * MemoryLayout<Float>.size) }
                else {
                    memcpy(m, cd[0], ns * MemoryLayout<Float>.size)
                    if nch > 1 { for c in 1..<nch { vDSP_vadd(m, 1, cd[c], 1, m, 1, vDSP_Length(ns)) }; var k = 1 / Float(nch); vDSP_vsmul(m, 1, &k, m, 1, vDSP_Length(ns)) }
                }
            }
            self.lock.lock(); self.tapFrames = ns; self.lock.unlock()
            mono.withUnsafeBufferPointer { self.deliver($0.baseAddress!, ns, rate: fmt.sampleRate, frameChannels: nch, ndiTimestamp: 0) }
            gAudioListen.push(frames: ns, channels: nch, rate: fmt.sampleRate) { c in UnsafePointer(cd[c]) }   // listen monitor: the tap's input
        }
        do {
            eng.prepare()
            try eng.start()
            engine = eng; engineDev = key
            lock.lock(); connName = d.name; note = perm == "authorized" ? "" : "microphone permission: \(perm) (silence until macOS allows it)"; lock.unlock()
            olog("audio: input device '\(d.name)' started (\(Int(fmt.sampleRate)) Hz, \(nch) ch, channel \(pick == 0 ? "mix" : String(pick)); mic permission \(perm))")
        } catch {
            input.removeTap(onBus: 0)
            engineDev = key; engine = nil
            lock.lock(); note = "device '\(d.name)' failed to start: \(error.localizedDescription)"; lock.unlock()
            olog("audio: input device '\(d.name)' failed to start: \(error)")
        }
    }

    private func stopDevice() {
        guard let e = engine else { engineDev = ""; return }
        e.inputNode.removeTap(onBus: 0)
        e.stop()
        engine = nil; engineDev = ""
        olog("audio: input device stopped")
    }

    // MARK: scene-go triggers (analysis thread)

    private func trigger(_ k: AudioModSource) {
        lock.lock(); let rs = routes; lock.unlock()
        for (i, r) in rs.enumerated() where r.on && r.target == .scene && r.source == k { sceneGo(i, r) }
    }

    private func sceneGo(_ i: Int, _ r: AudioRoute) {
        let now = ticksToSec(nowTicks() &- gStartTicks)
        lock.lock()
        guard now - lastSceneGo[i] >= 2 else { lock.unlock(); return }      // hold-off 2 s per route
        lastSceneGo[i] = now
        lock.unlock()
        DispatchQueue.global(qos: .utility).async {
            let n = r.scene > 0 ? r.scene : gScenes.step(1)
            guard let sn = n else { olog("audio route \(i + 1): \(r.source.rawValue) -> scene go: no stored scene in this bank"); return }
            olog("audio route \(i + 1): \(r.source.rawValue) -> " + gScenes.go(sn, fade: nil, from: "audio \(r.source.rawValue)"))
        }
    }

    /// Continuous sources on a scene route: go when the value rises through 0.85 (re-armed below 0.5). Analysis thread.
    private func checkContinuous(_ f: AudioFeatures) {
        lock.lock(); let rs = routes; lock.unlock()
        for (i, r) in rs.enumerated() where r.on && r.target == .scene && !r.source.isTrigger {
            let v = f.value(r.source)
            if v > 0.85 && contArmed[i] { contArmed[i] = false; sceneGo(i, r) } else if v < 0.5 { contArmed[i] = true }
        }
    }

    // MARK: OSC

    /// /oats/audio/... Returns (log text, ok) or nil when the address is not an audio one.
    func osc(_ m: OSCMessage) -> (String, Bool)? {
        guard m.address.hasPrefix("/oats/audio/") else { return nil }
        let cmd = String(m.address.dropFirst(12))
        let a0 = m.args.first
        func text(_ a: OSCArg?) -> String? { if case .s(let v)? = a { return v.trimmingCharacters(in: .whitespaces) }; return nil }
        func num(_ a: OSCArg?) -> Double? { a?.number.flatMap { $0.isFinite ? $0 : nil } }
        func flag(_ a: OSCArg?) -> Bool? {
            guard let a = a else { return nil }
            switch a { case .t: return true; case .fls: return false; default: return num(a).map { $0 != 0 } }
        }
        func own() { gControl.with { $0.layerOwners["audio"] = .osc } }
        switch cmd {
        case "source":
            guard let s = text(a0)?.lowercased(), let v = AudioSource(rawValue: s == "none" ? "off" : s) else { return ("bad args (want s off|ndi|device)", false) }
            lock.lock(); source = v; if v != .off { listRequest = true }; let nm = v == .ndi ? ndiName : deviceName; lock.unlock()
            own()
            return ("audio source \(v.rawValue)" + (v == .off ? "" : " ('\(nm.isEmpty ? (v == .ndi ? "no name set" : "first input device") : nm)')"), true)
        case "ndi":
            guard let s = text(a0) else { return ("bad args (want s NDI source name or part of it, e.g. djay)", false) }
            lock.lock(); ndiName = String(s.prefix(200)); listRequest = true; lock.unlock(); own()
            return ("audio NDI source '\(s)' (substring match, case ignored)", true)
        case "device":
            guard let s = text(a0) else { return ("bad args (want s device name or part of it)", false) }
            lock.lock(); deviceName = String(s.prefix(200)); engineDev = "#changed"; lock.unlock(); own()
            return ("audio input device '\(s)'", true)
        case "channel":
            guard let v = num(a0) else { return ("bad args (want i 0 = mix, 1..n = channel)", false) }
            lock.lock(); channel = max(0, min(64, Int(v.rounded()))); let c = channel; lock.unlock(); own()
            return ("audio device channel \(c == 0 ? "mix" : String(c))", true)
        case "gain":
            guard let v = num(a0) else { return ("bad args (want f dB -24..24)", false) }
            lock.lock(); settings.gainDB = min(24, max(-24, v)); let g = settings.gainDB; lock.unlock(); own()
            return (String(format: "audio gain %+.1f dB", g), true)
        case "agc":
            guard let b = flag(a0) else { return ("bad args (want i 0|1)", false) }
            lock.lock(); settings.agc = b; lock.unlock(); own()
            return ("audio AGC \(b ? "on" : "off (fixed -48...0 dBFS)")", true)
        case "attack", "release":
            guard let v = num(a0), v >= 0 else { return ("bad args (want f ms)", false) }
            let s = min(2, v / 1000)
            lock.lock(); if cmd == "attack" { settings.attack = s } else { settings.release = s }; lock.unlock(); own()
            return (String(format: "audio level %@ %.0f ms", cmd, s * 1000), true)
        case "snaregate", "backbeat":
            let on = (num(a0) ?? 1) != 0
            lock.lock(); settings.snareBackbeat = on; lock.unlock(); own()
            return (on ? "snare hits gated to beats 2 / 4 (while Link leads)" : "snare backbeat gate off", true)
        case "snarebody":
            let on = (num(a0) ?? 1) != 0
            lock.lock(); settings.snareBodyGate = on; lock.unlock(); own()
            return (on ? "snare hits need the body (150-300 Hz) rising with the crack" : "snare body requirement off (crack onset only)", true)
        case "quantize", "quantise":
            guard let v = num(a0), v >= 0 else { return ("bad args (want f beats: 0 = off, 0.25, 0.5, 1)", false) }
            let q = v <= 0 ? 0 : min(4, max(0.125, v))
            lock.lock(); settings.quantize = q; lock.unlock(); own()
            return (q == 0 ? "audio onset quantise off" : String(format: "audio onsets quantised to %.3g beat (while Link leads the tempo clock)", q), true)
        case "sensitivity":
            guard let v = num(a0) else { return ("bad args (want f 0..1)", false) }
            lock.lock(); settings.sensitivity = min(1, max(0, v)); lock.unlock(); own()
            return (String(format: "audio onset sensitivity %.2f", min(1, max(0, v))), true)
        case "listen":
            guard let b = flag(a0) else { return ("bad args (want i 0|1)", false) }
            gAudioListen.set(on: b)
            return (b ? "audio listen on (this Mac's default output; not stored, off at the next start)" : "audio listen off", true)
        case "listen/volume":
            guard let v = num(a0) else { return ("bad args (want f 0..1)", false) }
            return (String(format: "audio listen volume %.2f", gAudioListen.set(volume: v)), true)
        case "sources":
            lock.lock(); listRequest = true; lock.unlock()
            return ("audio: listing NDI sources and audio devices into status.json audio.available", true)
        case "preset":
            guard let s = text(a0) else { return ("bad args (want s NAME|off [i layer])", false) }
            let ly = num(m.args.count > 1 ? m.args[1] : nil).map { min(layerCount, max(0, Int($0.rounded()))) } ?? 1   // 0 = BG
            own()
            return (applyAudioPreset(s, layer: ly), true)
        case "routes/clear":
            gControl.with { c in c.audioRoutes = [AudioRoute](repeating: AudioRoute(), count: audioRouteCount); c.audioPreset = "" }
            own()
            return ("audio routes cleared", true)
        default: break
        }
        if cmd.hasPrefix("band/") {
            let b = String(cmd.dropFirst(5))
            let snare = ["snare_body", "snarebody", "snare_crack", "snarecrack"].contains(b)
            guard snare || audioBandNames.contains(b), let lo = num(a0), let hi = num(m.args.count > 1 ? m.args[1] : nil), lo > 0, hi > lo else {
                return ("bad address or args (want /oats/audio/band/{\(audioBandNames.joined(separator: ",")),snare_body,snare_crack} f lo f hi, Hz)", false)
            }
            let rng = (min(22000, lo), min(22000, hi))
            lock.lock()
            if let i = audioBandNames.firstIndex(of: b) { settings.bands[i] = rng }
            else if b.hasPrefix("snare_b") || b.hasPrefix("snareb") { settings.snareBody = rng } else { settings.snareCrack = rng }
            lock.unlock(); own()
            return (String(format: "audio band %@ %.0f-%.0f Hz", b, lo, hi), true)
        }
        if cmd.hasPrefix("route/") {
            let parts = cmd.split(separator: "/").map(String.init)
            guard parts.count == 3, let n = Int(parts[1]), (1...audioRouteCount).contains(n) else {
                return ("bad address (want /oats/audio/route/{1..\(audioRouteCount)}/{source,target,layer,scene,amount,curve,smooth,on,clear})", false)
            }
            let k = n - 1
            var err = "", what = ""
            gControl.with { c in
                var r = c.audioRoutes[k]
                switch parts[2] {
                case "source": if let v = text(a0).flatMap(AudioModSource.parse) { r.source = v; what = "source \(v.rawValue)" } else { err = "want s " + AudioModSource.allCases.map { $0.rawValue }.joined(separator: "|") }
                case "target": if let v = text(a0).flatMap(AudioModTarget.parse) { r.target = v; what = "target \(v.rawValue)" } else { err = "want s " + AudioModTarget.allCases.map { $0.rawValue }.joined(separator: "|") }
                case "layer":
                    if let v = num(a0) { r.layer = min(layerCount, max(0, Int(v.rounded()))); what = r.layer == 0 ? "layer BG" : "layer \(r.layer)" }
                    else if text(a0)?.uppercased() == "BG" { r.layer = 0; what = "layer BG" } else { err = "want i 0 (BG) ..\(layerCount)" }
                case "scene": if let v = num(a0) { r.scene = min(sceneMax, max(0, Int(v.rounded()))); what = r.scene == 0 ? "scene next" : "scene \(sceneLabel(r.scene))" } else { err = "want i 1..\(sceneMax) (0 = next)" }
                case "amount": if let v = num(a0) { r.amount = min(2, max(-2, v)); what = String(format: "amount %+.2f", r.amount) } else { err = "want f -2..2" }
                case "curve": if let v = text(a0).flatMap({ AudioCurve(rawValue: $0.lowercased()) }) { r.curve = v; what = "curve \(v.rawValue)" } else { err = "want s linear|soft|hard" }
                case "smooth": if let v = num(a0) { r.smooth = min(2, max(0, v)); what = String(format: "smoothing %.3f s", r.smooth) } else { err = "want f seconds 0..2" }
                case "on": if let b = flag(a0) { r.on = b; what = b ? "on" : "off" } else { err = "want i 0|1" }
                case "clear": r = AudioRoute(); what = "cleared"
                default: err = "unknown route parameter '\(parts[2])'"
                }
                if err.isEmpty { c.audioRoutes[k] = r; c.audioPreset = ""; c.layerOwners["audio"] = .osc }
            }
            return err.isEmpty ? ("audio route \(n) " + what, true) : ("bad args (\(err))", false)
        }
        return ("unknown audio address (source, ndi, device, channel, gain, agc, attack, release, quantize, sensitivity, snaregate, snarebody, listen, listen/volume, sources, preset, routes/clear, band/<name>, route/<n>/<param>)", false)
    }

    // MARK: status

    func statusDict(routes: [AudioRoute], preset: String, shown: [Double]) -> [String: Any] {
        lock.lock(); defer { lock.unlock() }
        func r3(_ v: Double) -> Double { (v * 1000).rounded() / 1000 }
        let fresh = featAt != 0 && ticksToSec(nowTicks() &- featAt) <= 0.5
        let f = fresh ? feat : AudioFeatures()
        let hop = ana.hop, n = ana.n, r = rate > 0 ? rate : 48000
        let frameMs = source == .device ? Double(tapFrames) / r * 1000 : Double(frameSamples) / r * 1000
        let anaMs = (Double(hop) + Double(n) / 8) / r * 1000
        let transport = source == .ndi ? max(0, ageMs) : 0
        var lv: [String: Any] = [:], on: [String: Any] = [:], hv: [String: Any] = [:]
        for (i, b) in audioBandNames.enumerated() { lv[b] = r3(f.levels[i]) }
        for (i, h) in audioHitNames.enumerated() { on[h] = ana.counts[i]; hv[h] = r3(f.hits[i]) }
        var bands: [String: Any] = [:]
        for (i, b) in audioBandNames.enumerated() { bands[b] = [settings.bands[i].0, settings.bands[i].1] }
        bands["snare_body"] = [settings.snareBody.0, settings.snareBody.1]; bands["snare_crack"] = [settings.snareCrack.0, settings.snareCrack.1]
        var d: [String: Any] = [
            "source": source.rawValue, "connected": connected && source != .off, "name": connName,
            "ndi_name": ndiName, "device": deviceName, "channel": channel,
            "rate": Int(rate), "channels": channels, "frame_samples": source == .device ? tapFrames : frameSamples, "frames": frames,
            "levels": lv, "onsets": on, "hits": hv, "energy": r3(f.energy), "build": r3(f.build), "drop": r3(f.drop), "drops": ana.drops,
            "kick_confidence": r3(f.kickConf), "kick_abs_db": r3(ana.kickAbs), "kick_ref_db": r3(ana.kickRef),
            "snare_crack_onsets": ana.crackOnsets, "snare_body_onsets": ana.bodyOnsets, "snare_body_gate": settings.snareBodyGate,
            "latency_ms": r3(frameMs + anaMs + transport),
            "latency": ["frame_ms": r3(frameMs), "analysis_ms": r3(anaMs), "transport_ms": r3(transport),
                        "note": "frame + hop + 1/8 window (+ NDI path: 30 ms allowance + queueing above the best seen; the sender's clock offset is excluded); render adds up to one frame"] as [String: Any],
            "dropouts": dropouts, "recreated": recreated, "note": note,
            "gain_db": settings.gainDB, "agc": settings.agc, "attack_ms": r3(settings.attack * 1000), "release_ms": r3(settings.release * 1000),
            "quantize": settings.quantize, "snare_backbeat": settings.snareBackbeat, "sensitivity": settings.sensitivity, "bands": bands,
            "fft": n, "hop": hop, "update_hz": r3(r / Double(hop)),
            "mic_permission": source == .device ? micPermission() : "",
            "routes": routes.enumerated().map { (k, rt) in rt.dict.merging(["n": k + 1, "value": k < shown.count ? r3(shown[k]) : 0.0]) { a, _ in a } },
            "routes_on": routes.filter { $0.on }.count, "preset": preset, "presets": audioPresetNames(),
            "sources_list": AudioModSource.allCases.map { $0.rawValue }, "targets_list": AudioModTarget.allCases.map { ["key": $0.rawValue, "group": $0.group] },
            "available": ["ndi": availNDI, "devices": availDev, "listed_unix": listedAt] as [String: Any],
        ]
        for (k, v) in gAudioListen.status() { d[k] = v }        // listen, listen_volume, listen_device, listen_note
        return d
    }

    /// GET /audio.json on the preview port (the GUI meter, up to 30 Hz): levels, hit envelopes, energy.
    func meterJSON() -> String {
        lock.lock()
        let fresh = featAt != 0 && ticksToSec(nowTicks() &- featAt) <= 0.5
        let f = fresh ? feat : AudioFeatures()
        let c = connected && source != .off, src = source.rawValue, cnt = ana.counts
        lock.unlock()
        func r(_ v: Double) -> String { String(format: "%.3f", v) }
        return "{\"src\":\"\(src)\",\"c\":\(c ? 1 : 0),\"l\":[\(f.levels.map(r).joined(separator: ","))],\"h\":[\(f.hits.map(r).joined(separator: ","))],"
            + "\"n\":[\(cnt.map(String.init).joined(separator: ","))],\"e\":\(r(f.energy)),\"b\":\(r(f.build)),\"d\":\(r(f.drop)),\"kc\":\(r(f.kickConf))}"
    }

}

let gAudio: AudioIn = {
    let a = AudioIn()
    return a
}()

// MARK: - Listen monitor (2026-10-24): hear the audio the player reacts to, on this Mac's default output

/// Plays the received audio (NDI: every channel of each frame as it arrives; Device: the tap's input) on the Mac's default
/// output device. /oats/audio/listen i 0|1 (default off, never stored: a show must not start with the monitor on),
/// /oats/audio/listen/volume f 0..1 (0.8). AVAudioEngine + AVAudioSourceNode pulling from a planar ring buffer kept in the
/// INPUT format (48 or 44.1 kHz, n channels): the engine's mixer converts rate and channels to the output device. The
/// ring primes ~60 ms before playing; when a burst would let it grow past 2x that, the oldest audio is skipped (logged
/// at most once a minute). The engine is built / torn down on its own serial queue; nothing here touches the render
/// thread or the analysis, and an output that fails to open only sets status audio.listen_note (retry every 5 s).
final class AudioMonitor {
    private let mu: UnsafeMutablePointer<os_unfair_lock> = { let p = UnsafeMutablePointer<os_unfair_lock>.allocate(capacity: 1); p.initialize(to: os_unfair_lock()); return p }()
    private var on = false
    private var volume: Float = 0.8
    // ring (planar, frames): written by the input thread, read by the output IO thread; both under mu for a few µs
    private var ring: [[Float]] = []
    private var cap = 0, wr = 0, fill = 0
    private var ringRate = 0.0, ringCh = 0
    private var primed = false
    private var dropped = 0, droppedTotal = 0, underruns = 0
    private var lastDropLog: UInt64 = 0
    private var deviceName = ""
    private var note = ""
    // engine: the queue only
    private let q = DispatchQueue(label: "oats.audio.listen", qos: .userInitiated)
    private var engine: AVAudioEngine? = nil
    private var node: AVAudioSourceNode? = nil
    private var engRate = 0.0, engCh = 0
    private var retryAt: UInt64 = 0
    let targetSec = 0.06                      // jitter buffer

    private func lock() { os_unfair_lock_lock(mu) }
    private func unlock() { os_unfair_lock_unlock(mu) }

    /// OSC /oats/audio/listen. Returns the state set.
    @discardableResult func set(on v: Bool) -> Bool {
        lock(); on = v; if !v { fill = 0; primed = false }; unlock()
        q.async { [self] in self.reconcile() }
        return v
    }
    /// OSC /oats/audio/listen/volume: clamps 0..1 and returns the value set.
    @discardableResult func set(volume v: Double) -> Double {
        let c = Float(min(1, max(0, v.isFinite ? v : 0.8)))
        lock(); volume = c; unlock()
        return Double(c)
    }
    var isOn: Bool { lock(); defer { unlock() }; return on }
    var volumeValue: Double { lock(); defer { unlock() }; return Double(volume) }

    /// Input threads (NDI worker / device tap): one planar frame in the input's own rate and channel count. Cheap when off.
    func push(frames n: Int, channels nc: Int, rate: Double, plane: (Int) -> UnsafePointer<Float>) {
        guard n > 0, nc > 0, nc <= 64, rate > 1000 else { return }
        lock()
        guard on else { unlock(); return }
        var rebuild = false
        if rate != ringRate || nc != ringCh || ring.count != nc {
            ringRate = rate; ringCh = nc; cap = max(n * 2, Int(rate * targetSec * 4)); wr = 0; fill = 0; primed = false
            ring = [[Float]](repeating: [Float](repeating: 0, count: cap), count: nc)
            rebuild = true
        }
        let want = Int(rate * targetSec)
        if fill + n > cap {                                   // the buffer would grow: skip the oldest, keep ~target after this frame
            let drop = min(fill, fill + n - want)
            fill -= drop; dropped += drop; droppedTotal += drop
        }
        let take = min(n, cap), from = n - take
        let first = min(take, cap - wr), rest = take - first
        for c in 0..<nc {
            let src = plane(c) + from
            ring[c].withUnsafeMutableBufferPointer { rp in
                let base = rp.baseAddress!
                memcpy(base + wr, src, first * MemoryLayout<Float>.size)
                if rest > 0 { memcpy(base, src + first, rest * MemoryLayout<Float>.size) }
            }
        }
        wr = (wr + take) % cap; fill = min(cap, fill + take)
        unlock()
        if rebuild { q.async { [self] in self.reconcile() } }
    }

    /// Output IO thread: the source node asks for `n` frames into the (non-interleaved) buffer list.
    private func render(_ n: Int, _ silence: UnsafeMutablePointer<ObjCBool>, _ abl: UnsafeMutablePointer<AudioBufferList>) -> OSStatus {
        let bufs = UnsafeMutableAudioBufferListPointer(abl)
        lock()
        let ok = on && cap > 0 && (primed || fill >= Int(ringRate * targetSec))
        let avail = ok ? min(fill, n) : 0
        if ok { primed = true }
        if ok && avail < n { underruns += 1; primed = false }    // ran dry: silence, then prime again
        let rd = cap > 0 ? ((wr - fill) % cap + cap) % cap : 0
        var vol = volume
        for (c, b) in bufs.enumerated() {
            guard let dst = b.mData?.assumingMemoryBound(to: Float.self) else { continue }
            let frames = min(n, Int(b.mDataByteSize) / MemoryLayout<Float>.size)
            if c < ringCh && avail > 0 {
                let got = min(avail, frames), first = min(got, cap - rd), rest = got - first
                ring[c].withUnsafeBufferPointer { rp in
                    memcpy(dst, rp.baseAddress! + rd, first * MemoryLayout<Float>.size)
                    if rest > 0 { memcpy(dst + first, rp.baseAddress!, rest * MemoryLayout<Float>.size) }
                }
                if vol != 1 { vDSP_vsmul(dst, 1, &vol, dst, 1, vDSP_Length(got)) }
                if frames > got { memset(dst + got, 0, (frames - got) * MemoryLayout<Float>.size) }
            } else { memset(dst, 0, frames * MemoryLayout<Float>.size) }
        }
        fill -= avail
        unlock()
        silence.pointee = ObjCBool(avail == 0)
        return noErr
    }

    /// Supervisor, about once a second: (re)open the output when wanted, drop the engine when not, refresh the device name.
    func tick() { q.async { [self] in self.reconcile(); self.housekeeping() } }

    private func reconcile() {
        lock(); let want = on, r = ringRate, c = ringCh; unlock()
        if !want {
            if engine != nil { stopEngine(); olog("audio: listen off") }
            lock(); note = ""; unlock()
            return
        }
        guard r > 0, c > 0 else { lock(); if engine == nil { note = "waiting for audio (turn an audio source on)" }; unlock(); return }
        if let e = engine { if engRate == r && engCh == c && e.isRunning { return }; stopEngine(); olog("audio: listen output \(engRate != r || engCh != c ? "format changed" : "stopped by the system"): reopening") }
        if nowTicks() < retryAt { return }
        guard let fmt = AVAudioFormat(standardFormatWithSampleRate: r, channels: AVAudioChannelCount(c)) else {
            retryAt = nowTicks() &+ secToTicks(5); lock(); note = "unsupported input format \(Int(r)) Hz \(c) ch"; unlock(); return
        }
        let eng = AVAudioEngine()
        let src = AVAudioSourceNode(format: fmt) { [weak self] silence, _, n, abl in self?.render(Int(n), silence, abl) ?? noErr }
        eng.attach(src)
        eng.connect(src, to: eng.mainMixerNode, format: fmt)
        eng.connect(eng.mainMixerNode, to: eng.outputNode, format: nil)
        do {
            try eng.start()
            engine = eng; node = src; engRate = r; engCh = c
            let dn = defaultOutputDeviceName(), outRate = eng.outputNode.outputFormat(forBus: 0).sampleRate
            lock(); deviceName = dn; note = ""; primed = false; unlock()
            olog("audio: listen on -> '\(dn)' (in \(Int(r)) Hz \(c) ch, out \(Int(outRate)) Hz; ~\(Int(targetSec * 1000)) ms buffer)")
        } catch {
            retryAt = nowTicks() &+ secToTicks(5)
            lock(); note = "output failed to start: \(error.localizedDescription) (retrying)"; unlock()
            olog("audio: listen output failed to start: \(error)")
        }
    }

    private func stopEngine() {
        guard let e = engine else { return }
        e.stop()
        if let n = node { e.detach(n) }
        engine = nil; node = nil; engRate = 0; engCh = 0
    }

    private func housekeeping() {
        let dn = defaultOutputDeviceName()
        lock()
        deviceName = dn
        let d = dropped, now = nowTicks()
        if d > 0 && (lastDropLog == 0 || ticksToSec(now &- lastDropLog) >= 60) {
            lastDropLog = now; dropped = 0
            let ms = ringRate > 0 ? Double(d) / ringRate * 1000 : 0
            olog(String(format: "audio: listen skipped %.0f ms of audio in the last minute to keep the %d ms buffer (total %d frames, %d underruns)", ms, Int(targetSec * 1000), droppedTotal, underruns))
        }
        unlock()
    }

    /// status.json audio block fields.
    func status() -> [String: Any] {
        lock(); defer { unlock() }
        return ["listen": on, "listen_volume": (Double(volume) * 1000).rounded() / 1000, "listen_device": deviceName, "listen_note": on ? note : ""]
    }
}

func defaultOutputDeviceName() -> String {
    var addr = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyDefaultOutputDevice, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
    var id = AudioDeviceID(0), sz = UInt32(MemoryLayout<AudioDeviceID>.size)
    guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &addr, 0, nil, &sz, &id) == noErr, id != 0 else { return "" }
    var a = AudioObjectPropertyAddress(mSelector: kAudioObjectPropertyName, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
    var name: Unmanaged<CFString>? = nil
    var nsz = UInt32(MemoryLayout<Unmanaged<CFString>?>.size)
    return AudioObjectGetPropertyData(id, &a, 0, nil, &nsz, &name) == noErr ? (name?.takeRetainedValue() as String? ?? "") : ""
}

let gAudioListen = AudioMonitor()

// MARK: - presets (tools/audio_presets.json, read on every /oats/audio/preset)

func audioPresetsPath() -> String {
    if !gPresetsDirOverride.isEmpty { return (gPresetsDirOverride as NSString).appendingPathComponent("audio_presets.json") }
    return URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath().deletingLastPathComponent()
        .deletingLastPathComponent().appendingPathComponent("tools/audio_presets.json").standardizedFileURL.path
}
func loadAudioPresets() -> [[String: Any]] {
    guard let d = FileManager.default.contents(atPath: audioPresetsPath()),
          let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any], let l = j["presets"] as? [[String: Any]] else { return [] }
    return l
}
private let gAudioPresetNamesAtStart: [String] = loadAudioPresets().compactMap { $0["name"] as? String }
func audioPresetNames() -> [String] { gAudioPresetNamesAtStart }

/// All 8 routes from the preset (rows beyond its list are cleared); layer targets go to `layer`. "off" clears them.
func applyAudioPreset(_ name: String, layer: Int) -> String {
    if ["off", "none", "clear", "0"].contains(name.lowercased()) {
        gControl.with { c in c.audioRoutes = [AudioRoute](repeating: AudioRoute(), count: audioRouteCount); c.audioPreset = "" }
        return "audio routes off (cleared)"
    }
    let list = loadAudioPresets()
    let key = name.lowercased().filter { $0.isLetter || $0.isNumber }
    guard let p = list.first(where: { (($0["name"] as? String) ?? "").lowercased().filter { $0.isLetter || $0.isNumber } == key }) else {
        return "no audio preset '\(name)' in \(audioPresetsPath()) (have: " + list.compactMap { $0["name"] as? String }.joined(separator: ", ") + ")"
    }
    let pn = p["name"] as? String ?? name
    let rows = (p["routes"] as? [[String: Any]]) ?? []
    var rs = [AudioRoute](repeating: AudioRoute(), count: audioRouteCount)
    for (k, d) in rows.prefix(audioRouteCount).enumerated() {
        var r = AudioRoute.from(d, presetLayer: layer)
        if d["on"] == nil { r.on = true }
        rs[k] = r
    }
    gControl.with { c in c.audioRoutes = rs; c.audioPreset = pn }
    return "audio preset '\(pn)' on layer \(layer): " + rs.filter { $0.on }.map { r in
        "\(r.source.rawValue) -> \(r.target.rawValue)\(r.target.isLayer ? (r.layer == 0 ? " BG" : " L\(r.layer)") : "")\(r.target == .scene ? " " + (r.scene == 0 ? "next" : sceneLabel(r.scene)) : "") " + String(format: "%+.2f", r.amount)
    }.joined(separator: "; ")
}

// MARK: - render-thread runtime (engine.swift)

struct LayerAudio {
    var opacity = 0.0, scale = 0.0, rotation = 0.0, spin = 0.0, x = 0.0, y = 0.0, fx1 = 0.0, fx2 = 0.0
    var genCount = 0.0, genThick = 0.0, genSpeed = 0.0
    var fx1Speed = 0.0, fx2Speed = 0.0     // FX slot speed offsets (Star/Warp/Spiral trails: speed 0.5 = still, so + spins)
    var overlayOpacity = 0.0             // gen.swift overlay: added to the overlay opacity
    var any = false, gen = false
}
struct AudioMod {
    var layers = [LayerAudio](repeating: LayerAudio(), count: compCount)   // index 4 = BG
    var spread = 0.0, zoom = 0.0, rotation = 0.0, palette = 0.0, julia = 0.0, trapsize = 0.0
    var fractal = false
    var dimMul = 1.0, masterFX = 0.0, masterFXSpeed = 0.0, flash = 0.0
}

/// FX slot speeds with the audio offsets added and clamped to 0...1 (engine.swift, per frame; the stored slots never change).
func audioFXSpeed(_ fx: [FXSlot], _ la: LayerAudio) -> [FXSlot] {
    var f = fx
    if la.fx1Speed != 0, f.count > 0 { f[0].speed = min(1, max(0, f[0].speed + la.fx1Speed)) }
    if la.fx2Speed != 0, f.count > 1 { f[1].speed = min(1, max(0, f[1].speed + la.fx2Speed)) }
    return f
}


/// Evaluates the 8 routes once per frame (render thread). Values are added on top of what is drawn, never stored.
/// Ranges at amount 1 and source 1: opacity +1, scale x2 (x(1 + a)), rotation +90 deg, spin +1 turn/s, pos +1 (frame
/// half-widths), FX 1/2 amount +1, generator count / thickness +1 (0..1 units), generator speed +1, FX 1/2 speed +1 (0..1 units; trails: 0.5 = still), overlay opacity +1; fractal spread +1,
/// zoom pulse +0.5 decade (the phaser breathe unit), rotation kick +45 deg, palette offset +0.5 cycle, Julia morph +0.5,
/// trap size x2; master: dimmer pulse (a > 0: dimmer x (1 - a + a v), dark between hits; a < 0: x (1 - |a| v), ducks
/// on hits), master FX amount +1, master FX speed +1, strobe flash (toward white x dimmer) +1.
final class AudioModRuntime {
    private var sm = [Double](repeating: 0, count: audioRouteCount)
    private(set) var shown = [Double](repeating: 0, count: audioRouteCount)
    private var last = AudioMod()

    func step(_ routes: [AudioRoute], _ f: AudioFeatures, dt: Double, frozen: Bool) -> AudioMod {
        if frozen { return last }
        var m = AudioMod()
        for k in 0..<min(audioRouteCount, routes.count) {
            let r = routes[k]
            let goal = r.on && r.target != .scene ? r.curve.apply(f.value(r.source)) : 0
            let a = r.smooth > 0.0005 ? 1 - exp(-max(0, dt) / r.smooth) : 1
            sm[k] += (goal - sm[k]) * a
            if abs(sm[k]) < 1e-4 && goal == 0 { sm[k] = 0 }
            let v = sm[k]
            shown[k] = r.on ? v * r.amount : 0
            guard v != 0, r.target != .scene else { continue }
            let x = v * r.amount
            if r.target.isLayer {
                let li = layerIndex(min(layerCount, max(0, r.layer)))
                var l = m.layers[li]
                switch r.target {
                case .opacity: l.opacity += x
                case .scale: l.scale += x
                case .rotation: l.rotation += 90 * x
                case .spin: l.spin += x
                case .posx: l.x += x
                case .posy: l.y += x
                case .fx1: l.fx1 += x
                case .fx2: l.fx2 += x
                case .gen_count: l.genCount += x; l.gen = true
                case .gen_thickness: l.genThick += x; l.gen = true
                case .gen_speed: l.genSpeed += x; l.gen = true
                case .fx1_speed: l.fx1Speed += x
                case .fx2_speed: l.fx2Speed += x
                case .overlay_opacity: l.overlayOpacity += x
                default: break
                }
                l.any = true
                m.layers[li] = l
                continue
            }
            switch r.target {
            case .spread: m.spread += x; m.fractal = true
            case .zoom: m.zoom += x; m.fractal = true
            case .rotkick: m.rotation += x; m.fractal = true
            case .palette: m.palette += x; m.fractal = true
            case .julia: m.julia += x; m.fractal = true
            case .trapsize: m.trapsize += x; m.fractal = true
            case .dimmer:
                let a = min(1, max(-1, r.amount))
                m.dimMul *= a >= 0 ? (1 - a + a * v) : (1 + a * v)
            case .masterfx: m.masterFX += x
            case .masterfx_speed: m.masterFXSpeed += x
            case .strobe: m.flash += x
            default: break
            }
        }
        m.dimMul = min(1, max(0, m.dimMul)); m.flash = min(1, max(0, m.flash))
        last = m
        return m
    }
}
