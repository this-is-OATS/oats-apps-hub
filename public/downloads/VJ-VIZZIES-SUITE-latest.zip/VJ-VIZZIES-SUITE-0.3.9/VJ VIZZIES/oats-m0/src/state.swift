import Foundation
import Darwin

// Shared state between threads: control values (OSC + sACN write, render reads), render statistics
// (render writes, status + watchdog read), and lock-free heartbeats.

enum Content: String {
    case normal, deep, noise, testcard, ndicard, standby   // cards (testcard.swift): drawn by the player; standby 2026-11-02
    var isCard: Bool { self == .testcard || self == .ndicard || self == .standby }
    /// "normal", "deep", "noise", "test" | "testcard" | "card", "ndi" | "ndicard", "standby" | "logo" | "hold" (case ignored).
    static func parse(_ s: String) -> Content? {
        let k = s.lowercased().filter { $0.isLetter }
        switch k {
        case "test", "testcard", "card", "bars": return .testcard
        case "ndi", "ndicard", "ndisetup": return .ndicard
        case "standby", "standbycard", "logo", "brand", "hold", "holding": return .standby
        case "off": return .normal
        default: return Content(rawValue: k)
        }
    }
    /// The GUI / OSC short name.
    var short: String { self == .testcard ? "test" : (self == .ndicard ? "ndi" : rawValue) }
}

/// View width limits for normal content, in log10 space: 3.0 (zoom 1) down to 3.0e-28 (zoom 1e28, deep.swift).
let log10WidthMax = log10(3.0)
let log10WidthMin = log10(3.0) - zoomDepthMax

struct Control {
    var zoomSpeed: Double = 0           // decades/s; + = zoom in, - = out, 0 = hold
    var zoomSet: Double? = nil          // pending absolute log10 width (consumed by the render loop)
    var palette: Int = 1                // 1..5
    var paletteSpeed: Double = 0        // cycles/s
    var paletteOffset: Double = 0       // 0..1
    var dimmer: Double = 1              // 0..1
    var effectSpeed: Double = 1         // 0..2, multiplies all motion rates (auto-zoom, palette cycle); DMX Master ch 14
    var blackout = false
    var content: Content = .normal
    var bpm: Double = 0                 // stored + logged only (0 = never set)
    var stallRequest: Double = 0        // --debug: seconds to sleep the render thread
    var snapshotRequest = false
    var targetRequest: Int? = nil       // 0-based zoom target (consumed by the render loop)
    var centerRequest: CentreSpec? = nil // custom centre (consumed by the render loop)
    var keepDepth = false               // target change keeps the depth (default: back to depth 0)
    var diveOnSelect = true             // OSC /oats/fractal/1/target/dive: a target change from OSC / the GUI starts a short dive
    var diveSeq = 0                     // +1 per such target change (the render loop runs the burst once the orbit is ready)
    var iterOverride = 0                // 0 = auto from depth
    var resOverride = 0                 // 0 = governor; 1...5 = fixed internal resolution (Governor.levels[n-1])
    var lastOSCAddress = ""
    var lastOSCTicks: UInt64 = 0
    var oscCount: Int64 = 0
    var oscMalformed: Int64 = 0
    var oscRejected: Int64 = 0          // packets from a source that is not on an allowed network
    // DMX personality v0 only (no OSC addresses yet)
    var offsetX = 0.0                   // view-centre offset in view widths, + = right (Fractal ch 3-4)
    var offsetY = 0.0                   // + = up (Fractal ch 5-6)
    var rotation = 0.0                  // degrees, picture turns counter-clockwise (Fractal ch 21, OSC /oats/fractal/1/rotation)
    var fractalSpin = 0.0               // turns/s -2..2, + = counter-clockwise (Fractal ch 22, OSC /oats/fractal/1/spin); 0 = stop
    var fractalSpinReset = 0            // +1: the render thread zeroes the accumulated spin angle
    var fractalLayer = 0                // gen.swift: the layer the one fractal draws on (0 = base layer under layers 1-4)
    var dmx = DMXDrive()                // what DMX drives right now (dmx.swift)
    var owners: [Param: Owner] = [:]    // latest move wins, per parameter (dmx.swift); missing = default
    // M2a clip layers (layers.swift): 4 layers over the fractal layer
    // + BG (2026-10-23): layers[bgIndex] = the base layer L0, a full layer (source Fractal by default, clip, gen; FX, overlay ...)
    var layers: [LayerCtl] = (0..<compCount).map { i in var l = LayerCtl(); if i == bgIndex { l.source = .fractal }; return l }
    var layerOwners: [String: Owner] = [:]   // "layer1.opacity", "fractal.opacity", "color.amount", ... (OSC/GUI; DMX for layer<n>.*, color.*)
    // clip playback tools (playback.swift): tap tempo, beat resync
    var tapSeq = 0                      // OSC /oats/tempo/tap: +1 per tap (playback thread computes the BPM)
    var resyncSeq = 0                   // beat 1 now (DMX Master ch 5, OSC /oats/tempo/resync)
    var tempoSource = "auto"            // OSC /oats/tempo/source: auto|link (Link leads when fresh) or dmx|tap|osc (Link ignored)
    var tempoForward = ""               // OSC /oats/tempo/forward: "" = off, "host:port" = MA3 OSC /cmd Master 3.1 At BPM <bpm> (Link only)
    // lights -> VJ colour link (DMX "Color 8" at 105, OSC /oats/color/*)
    var color = ColorLink()
    var analysisOut: String = ""        // "" = off; "host:port" = OSC out of the dominant colours (analysis.swift)
    var masterFX = FXSlot()             // fx.swift: one FX slot on the final output (before NDI)
    var frac = FractalMods()            // formula modifiers + endless-zoom loop (OSC /oats/fractal/1/formula ..., DMX Fractal 24)
    var targetDepth: Double? = nil      // with targetRequest: the depth to land at when its orbit is ready (presets)
    var audioRoutes = [AudioRoute](repeating: AudioRoute(), count: audioRouteCount)   // audio react mod matrix (audio.swift; stored in scenes)
    var audioPreset = ""                // last audio preset applied ("" = none / changed since)
    // per-target shape memory (2026-10-23): each zoom target keeps its own shape edits (ShapeMemo)
    var shapeMemoryOn = true            // OSC /oats/fractal/1/shape/memory i 0|1
    var shapeMemory: [String: ShapeMemo] = [:]   // target name -> its saved shape (the current target's live shape is in frac etc.)
    var shapeTarget = 0                 // 0-based target whose shape is live now (follows target requests)
}

/// One target's shape: formula, twist (kaleido fold + mirror, rotation), iterations, Julia, orbit trap and the advanced
/// fold values. With the shape memory on, a target change saves the live shape under the old target and loads the new
/// target's saved one (or the defaults). Stored in scenes and status.json (fractal.shape_memory).
struct ShapeMemo: Equatable {
    var formula: Formula = .mandelbrot
    var fold = 0, foldMirror = false, foldC = 0, foldCMirror = false
    var julia = 0.0, juliaRe = -0.8, juliaIm = 0.156, juliaDrift = 0.0, juliaBeat = false
    var warp = 0.0, bailout = 256.0
    var trap: TrapShape = .off, trapMix = 0.6, trapSize = 0.5
    var rotation = 0.0, iterations = 0
    var power = 2.0                     // Branches (2026-10-23): z^p + c, 1.5...6 (integer 2...5 on a Mandelbrot-family formula = perturbation)
    var foldMode: FoldMode = .clean     // Twist: clean (fold c once, deep-zoom safe) | wild (fold z in every iteration, direct path)
    var isDefault: Bool { self == ShapeMemo() }
    var dict: [String: Any] {
        ["formula": formula.key, "fold": fold, "fold_mirror": foldMirror, "foldc": foldC, "foldc_mirror": foldCMirror,
         "julia": julia, "julia_c": [juliaRe, juliaIm], "julia_drift": juliaDrift, "julia_beat": juliaBeat, "warp": warp,
         "bailout": bailout, "trap": trap.rawValue, "trap_mix": trapMix, "trap_size": trapSize, "rotation": rotation, "iterations": iterations,
         "power": power, "fold_mode": foldMode.rawValue]
    }
    /// From a dict (scene, status, OSC shape/memory/data); missing or bad keys keep the defaults.
    static func from(_ d: [String: Any]) -> ShapeMemo {
        var s = ShapeMemo()
        func num(_ k: String) -> Double? { (d[k] as? NSNumber).map { $0.doubleValue }.flatMap { $0.isFinite ? $0 : nil } }
        func fold(_ v: Double) -> Int { v < 1 ? 0 : min(12, Int(v.rounded())) }   // 1 = one mirror axis (with the mirror)
        if let x = d["formula"] as? String, let f = Formula.parse(x) { s.formula = f } else if let v = num("formula"), let f = Formula(rawValue: Int(v)) { s.formula = f }
        if let v = num("fold") { s.fold = fold(v) }
        if let v = num("fold_mirror") { s.foldMirror = v != 0 }
        if let v = num("foldc") { s.foldC = fold(v) }
        if let v = num("foldc_mirror") { s.foldCMirror = v != 0 }
        if let v = num("julia") { s.julia = min(1, max(0, v)) }
        if let a = d["julia_c"] as? [Any], a.count == 2, let x = (a[0] as? NSNumber)?.doubleValue, let y = (a[1] as? NSNumber)?.doubleValue,
           x.isFinite, y.isFinite { s.juliaRe = min(2, max(-2, x)); s.juliaIm = min(2, max(-2, y)) }
        if let v = num("julia_drift") { s.juliaDrift = min(4, max(-4, v)) }
        if let v = num("julia_beat") { s.juliaBeat = v != 0 }
        if let v = num("warp") { s.warp = min(0.5, max(-0.5, v)) }
        if let v = num("bailout") { s.bailout = min(1024, max(2, v)) }
        if let x = d["trap"] as? String, let t = TrapShape(rawValue: x.lowercased()) { s.trap = t }
        if let v = num("trap_mix") { s.trapMix = min(1, max(0, v)) }
        if let v = num("trap_size") { s.trapSize = min(4, max(0.01, v)) }
        if let v = num("rotation") { var r = v.truncatingRemainder(dividingBy: 360); if r < 0 { r += 360 }; s.rotation = r }
        if let v = num("iterations") { let r = Int(v.rounded()); s.iterations = r <= 0 ? 0 : min(maxIterLimit, max(minIterOverride, r)) }
        s.power = Double(s.formula.power)                       // a shape from before Branches: the formula's own power
        if let v = num("power") { s.power = clampPower(v) }
        if let x = d["fold_mode"] as? String, let m = FoldMode(rawValue: x.lowercased()) { s.foldMode = m }
        else if s.fold >= 2 { s.foldMode = .wild }               // a shape from before Twist modes: the fold it had (inside z)
        return s
    }
}

extension Control {
    /// The BG layer's opacity (= /oats/fractal/opacity, owner key fractal.opacity; kept as an alias of /oats/layers/0/opacity).
    var fractalOpacity: Double {
        get { layers[bgIndex].opacity }
        set { layers[bgIndex].opacity = newValue }
    }
    /// The live shape (frac + rotation + iteration override).
    var shape: ShapeMemo {
        get {
            let m = frac
            return ShapeMemo(formula: m.formula, fold: m.fold, foldMirror: m.foldMirror, foldC: m.foldC, foldCMirror: m.foldCMirror,
                             julia: m.julia, juliaRe: m.juliaRe, juliaIm: m.juliaIm, juliaDrift: m.juliaDrift, juliaBeat: m.juliaBeat,
                             warp: m.warp, bailout: m.bailout, trap: m.trap, trapMix: m.trapMix, trapSize: m.trapSize,
                             rotation: rotation, iterations: iterOverride, power: m.power, foldMode: m.foldMode)
        }
        set {
            if newValue != shape { frac.preset = "" }
            frac.formula = newValue.formula; frac.fold = newValue.fold; frac.foldMirror = newValue.foldMirror
            frac.foldC = newValue.foldC; frac.foldCMirror = newValue.foldCMirror; frac.julia = newValue.julia
            frac.juliaRe = newValue.juliaRe; frac.juliaIm = newValue.juliaIm; frac.juliaDrift = newValue.juliaDrift
            frac.juliaBeat = newValue.juliaBeat; frac.warp = newValue.warp; frac.bailout = newValue.bailout
            frac.trap = newValue.trap; frac.trapMix = newValue.trapMix; frac.trapSize = newValue.trapSize
            rotation = newValue.rotation; iterOverride = newValue.iterations; frac.power = newValue.power; frac.foldMode = newValue.foldMode
        }
    }
    /// A target change (OSC / GUI / MA3 DMX): with the memory on, saves the live shape under the old target and loads the
    /// new target's saved shape (or the defaults). Returns a log note ("" = nothing changed).
    mutating func switchShape(to ti: Int) -> String {
        guard ti >= 0, ti < zoomTargets.count else { return "" }
        let old = shapeTarget
        shapeTarget = ti
        guard shapeMemoryOn, ti != old, old >= 0, old < zoomTargets.count else { return "" }
        shapeMemory[zoomTargets[old].name] = shape
        let next = shapeMemory[zoomTargets[ti].name] ?? ShapeMemo()
        let changed = next != shape
        shape = next
        return changed ? " (shape memory: \(zoomTargets[old].name)'s shape saved, \(zoomTargets[ti].name)'s " + (shapeMemory[zoomTargets[ti].name] == nil ? "defaults" : "saved shape") + " loaded)" : ""
    }
    /// Shape memory as status / scene JSON (target name -> shape dict).
    var shapeMemoryDict: [String: Any] { shapeMemory.mapValues { $0.dict } }
    mutating func setShapeMemory(_ d: [String: Any]) {
        var m: [String: ShapeMemo] = [:]
        for (k, v) in d { if let t = findTarget(k), let sd = v as? [String: Any] { m[zoomTargets[t].name] = ShapeMemo.from(sd) } }
        shapeMemory = m
    }
}

enum TrapShape: String, CaseIterable { case off, point, circle, line, cross, star }
/// Twist mode (2026-10-23): clean = a true kaleidoscope, c folded once into N sectors (deep-zoom safe, crisp, mirror =
/// seamless); wild = the fold of z inside every iteration (direct float32 path, smooth fold + 2x2 supersampling).
enum FoldMode: String, CaseIterable { case clean, wild }
/// A fold is on at N >= 2, or N = 1 with the mirror (one mirror axis).
func foldOn(_ n: Int, _ mirror: Bool) -> Bool { n >= 2 || (n == 1 && mirror) }
enum LoopMode: String, CaseIterable { case off, minibrot, dive }
enum LoopNext: String, CaseIterable { case same, next, random }

/// Formula modifiers inside the iteration (not a screen filter) and the endless-zoom loop. Defaults = classic.
struct FractalMods: Equatable {
    var formula: Formula = .mandelbrot { didSet { power = Double(formula.power) } }   // a formula change resets Branches to its own power
    var fold = 0                        // kaleido fold of z inside every iteration: 0 = off, 2...12 (direct path)
    var foldMirror = false
    var foldMode: FoldMode = .clean     // Twist: clean (the fold above folds c once) | wild (it folds z in every iteration)
    var foldC = 0                       // fold of c (once, around the view centre): 0 = off, 2...12 (deep-zoom safe)
    var foldCMirror = false
    var julia = 0.0                     // Julia morph 0 (Mandelbrot) ... 1 (Julia set of juliaRe + i juliaIm) (direct path)
    var juliaRe = -0.8, juliaIm = 0.156
    var juliaDrift = 0.0                // the constant circles (radius 0.04): cycles/s, or cycles per beat with juliaBeat
    var juliaBeat = false
    var warp = 0.0                      // z^2 + c + k sin(z), k 0 ... 0.5 (direct path)
    var bailout = 256.0                 // escape radius 2 ... 1024
    var trap: TrapShape = .off          // orbit trap colouring, blended with the palette
    var trapMix = 0.6
    var trapSize = 0.5
    var loop: LoopMode = .off           // endless zoom
    var loopNext: LoopNext = .same      // Dive & return: the same target, the next one, or a random one
    var loopDepth = 26.0                // Dive & return: return at this depth (log10 zoom)
    var loopFade = 2.0                  // crossfade seconds (Minibrot loop uses half of it)
    var preset = ""                     // last preset applied (tools/fractal_presets.json), "" = none / changed since
    var spread = 0.0                    // Spread <-> Tighten macro: -1 spread (wider, softer bands) ... 0 as before ... +1 tighten
    var phasers = [Phaser](repeating: Phaser(), count: phaserCount)   // fractal LFOs (engine.swift applies them per frame)
    var phaserPreset = ""               // last phaser preset applied ("" = none / changed since)
    var phaserFree = false              // "Phasers run even when stopped" (OSC /oats/fractal/1/phaser/free): off = HOLD / Cycle 0 pause them
    var power = 2.0                     // Branches: z^p + c, 1.5 ... 6 (= formula.power: perturbation; else the direct path, polar z^p)
    /// The power has no perturbation form: not the formula's own integer power (Multibrot 2...5 keep deep zoom).
    var polarPower: Bool { abs(power - Double(formula.power)) > 0.0005 }
    /// Needs the direct float32 path (no perturbation form): the kaleido fold of z, the Julia morph, the warp term, a real power.
    var direct: Bool { foldZ.n > 0 || julia > 0.0005 || abs(warp) > 0.0005 || polarPower }
    /// The fold of z inside the iteration (Wild twist), N 0 = off.
    var foldZ: (n: Int, mirror: Bool) { foldMode == .wild && foldOn(fold, foldMirror) ? (fold, foldMirror) : (0, false) }
    /// The fold of c (once): the Clean twist, else the advanced Fold c. N 0 = off.
    var foldCEff: (n: Int, mirror: Bool) {
        if foldMode == .clean && foldOn(fold, foldMirror) { return (fold, foldMirror) }
        return foldOn(foldC, foldCMirror) ? (foldC, foldCMirror) : (0, false)
    }
    /// Branches: power p on the current formula. On the Mandelbrot family an integer 2...5 becomes Multibrot p (perturbation,
    /// deep zoom); anything else keeps the family's formula and iterates z^p in polar form on the direct path.
    mutating func setPower(_ v: Double) {
        let p = clampPower(v)
        let fam: Set<Formula> = [.mandelbrot, .power3, .power4, .power5]
        if fam.contains(formula) {
            let r = p.rounded()
            if abs(p - r) < 0.0005, let f = [2: Formula.mandelbrot, 3: .power3, 4: .power4, 5: .power5][Int(r)] { formula = f; power = r; return }
            formula = .mandelbrot
        }
        power = p
    }
}

// MARK: fractal phasers (LFOs on look parameters; engine.swift)

let phaserCount = 3
enum PhaserTarget: String, CaseIterable {
    case spread, palette, zoom, rotation, iterations, julia, orbit, twist, warp, trapsize, trapmix
    var label: String {
        switch self {
        case .spread: return "Spread"; case .palette: return "Palette offset"; case .zoom: return "Zoom breathe"
        case .rotation: return "Rotation wobble"; case .iterations: return "Iterations"; case .julia: return "Julia morph"
        case .orbit: return "Julia orbit"; case .twist: return "Kaleido twist"; case .warp: return "Warp"
        case .trapsize: return "Trap size"; case .trapmix: return "Trap mix"
        }
    }
    static func parse(_ s: String) -> PhaserTarget? {
        let k = s.lowercased().replacingOccurrences(of: "_", with: "").replacingOccurrences(of: " ", with: "")
        let alias: [String: PhaserTarget] = ["paletteoffset": .palette, "offset": .palette, "zoombreathe": .zoom, "breathe": .zoom,
            "depth": .zoom, "rotationwobble": .rotation, "wobble": .rotation, "rot": .rotation, "iter": .iterations,
            "juliamorph": .julia, "juliaorbit": .orbit, "kaleidotwist": .twist, "fold": .twist, "size": .trapsize, "mix": .trapmix]
        return PhaserTarget(rawValue: k) ?? alias[k]
    }
}
enum PhaserShape: String, CaseIterable {
    case sine, triangle, saw, square, random, smooth
    static func parse(_ s: String) -> PhaserShape? {
        let k = s.lowercased().replacingOccurrences(of: " ", with: "")
        let alias: [String: PhaserShape] = ["sin": .sine, "tri": .triangle, "sawtooth": .saw, "ramp": .saw, "sq": .square,
                                            "randomstep": .random, "step": .random, "sh": .random, "smoothrandom": .smooth, "drift": .smooth]
        return PhaserShape(rawValue: k) ?? alias[k]
    }
}
/// One LFO. Rate: `beats` (1/4 ... 32, from the tempo clock: Link / DMX / tap) unless `seconds` > 0 (period in seconds).
/// depth 0...1 scales the target's full range (engine.swift applyPhasers); phase 0...1 offsets the cycle.
struct Phaser: Equatable {
    var on = false
    var target: PhaserTarget = .spread
    var shape: PhaserShape = .sine
    var beats = 4.0
    var seconds = 0.0
    var depth = 0.5
    var phase = 0.0
    var dict: [String: Any] { ["on": on, "target": target.rawValue, "shape": shape.rawValue, "beats": beats, "seconds": seconds, "depth": depth, "phase": phase] }
    /// From a scene / preset dict; missing keys keep `base`.
    static func from(_ d: [String: Any], base: Phaser = Phaser()) -> Phaser {
        var p = base
        func num(_ k: String) -> Double? { (d[k] as? NSNumber).map { $0.doubleValue }.flatMap { $0.isFinite ? $0 : nil } }
        if let v = d["on"] as? NSNumber { p.on = v.boolValue } else if let v = d["on"] as? Bool { p.on = v }
        if let s = d["target"] as? String, let t = PhaserTarget.parse(s) { p.target = t }
        if let s = d["shape"] as? String, let t = PhaserShape.parse(s) { p.shape = t }
        if let v = num("beats") { p.beats = phaserBeats(v); p.seconds = 0 }
        if let v = num("seconds"), v > 0 { p.seconds = min(600, max(0.1, v)) }
        if let v = num("depth") { p.depth = min(1, max(0, v)) }
        if let v = num("phase") { p.phase = v - floor(v) }
        return p
    }
}
func phaserBeats(_ v: Double) -> Double { min(32, max(0.25, v)) }
let phaserBeatValues: [Double] = [0.25, 0.5, 1, 2, 4, 8, 16, 32]

/// The direct path (float32 z) is honest to about 1e4.5 zoom: the depth is capped there while it runs.
let directDepthMax = 4.5
/// Branches range (z^p + c) and the lowest iteration override ("Blob": 12-24 iterations give the soft rounded look).
let powerMin = 1.5, powerMax = 6.0
func clampPower(_ v: Double) -> Double { v.isFinite ? min(powerMax, max(powerMin, v)) : 2 }
let minIterOverride = 8

/// Deep zoom step 1 "Shape" tiles (2026-10-23, OSC /oats/fractal/1/shape s NAME): a formation = formula + power +
/// Julia morph / constant + kaleido fold. Applying one keeps the trap, iterations, drift, warp and everything else.
struct ShapePreset {
    let name: String
    var formula: Formula = .mandelbrot
    var julia = 0.0, jre = -0.8, jim = 0.156
    var fold = 0, mirror = false
    var power: Double { Double(formula.power) }
}
let shapePresets: [ShapePreset] = [
    ShapePreset(name: "Mandelbrot"),
    ShapePreset(name: "Burning Ship", formula: .burningShip),
    ShapePreset(name: "Tricorn", formula: .tricorn),
    ShapePreset(name: "Celtic", formula: .celtic),
    ShapePreset(name: "Flower 3", formula: .power3),
    ShapePreset(name: "Flower 4", formula: .power4),
    ShapePreset(name: "Flower 5", formula: .power5),
    ShapePreset(name: "Julia Dendrite", julia: 1, jre: 0, jim: 1),
    ShapePreset(name: "Julia Rabbit", julia: 1, jre: -0.123, jim: 0.745),
    ShapePreset(name: "Julia Spiral", julia: 1, jre: -0.8, jim: 0.156),
    ShapePreset(name: "Julia Dust", julia: 1, jre: 0.285, jim: 0.01),
    ShapePreset(name: "Kaleido 6", fold: 6, mirror: true),   // Clean twist: c folded once into 6 mirrored sectors (deep-zoom safe)
    ShapePreset(name: "Kaleido 8", fold: 8, mirror: true),
]
func findShapePreset(_ s: String) -> ShapePreset? {
    let k = s.lowercased().filter { $0.isLetter || $0.isNumber }
    return shapePresets.first { $0.name.lowercased().filter { $0.isLetter || $0.isNumber } == k }
}
extension FractalMods {
    mutating func apply(_ sp: ShapePreset) {
        formula = sp.formula                                // resets the power to the formula's own
        fold = sp.fold; foldMirror = sp.mirror
        if sp.fold > 0 { foldMode = .clean }
        julia = sp.julia
        if sp.julia > 0 { juliaRe = sp.jre; juliaIm = sp.jim }
        preset = ""
    }
    /// The shape tile the live values match ("" = none: edited).
    var shapeName: String {
        shapePresets.first { sp in
            sp.formula == formula && abs(sp.power - power) < 0.0005 && sp.fold == (foldOn(fold, foldMirror) ? fold : 0) && (sp.fold < 2 || (sp.mirror == foldMirror && foldMode == .clean))
                && (sp.julia > 0 ? julia > 0.999 && abs(sp.jre - juliaRe) < 0.003 && abs(sp.jim - juliaIm) < 0.003 : julia <= 0.0005)
        }?.name ?? ""
    }
}

enum ColorMode: String, CaseIterable { case tint, hue, replace }        // multiply toward / rotate hue toward / colorize luminance
enum ColorTarget: String, CaseIterable { case all, clips, fractal }     // all layers + fractal / clip layers only / fractal only
struct ColorLink {
    var r = 1.0, g = 1.0, b = 1.0       // 0..1
    var amount = 0.0                    // 0 = off .. 1 = full
    var mode: ColorMode = .tint
    var target: ColorTarget = .all
}

final class ControlState {
    private let lock = NSLock()
    private var c = Control()
    func with<T>(_ body: (inout Control) -> T) -> T {
        lock.lock(); defer { lock.unlock() }
        return body(&c)
    }
    var snapshot: Control { with { $0 } }
}

/// What the render loop publishes for the status line, status.json and the watchdog.
struct RenderInfo {
    var framesSent: Int64 = 0
    var droppedTotal: Int64 = 0
    var alarmsSend = 0                  // send calls > 50 ms
    var alarmsGap = 0                   // sender frame gaps > 100 ms
    var sendOver100 = 0                 // M0 gate (PLAN 13.1): any send call > 100 ms fails Parts D/E
    var gapOver200 = 0                  // M0 gate: any sender frame gap > 200 ms fails Parts D/E
    var gpuErrors = 0                   // Metal command buffers that ended with status .error
    var maxSendAll = 0.0                // ms, whole run
    var maxGapAll = 0.0
    // window (reset by the status thread every 5 s)
    var wFrames: Int64 = 0
    var wDropped: Int64 = 0
    var wMaxSend = 0.0
    var wMaxGap = 0.0
    var wMaxGpu = 0.0
    // current look
    var content: Content = .normal
    var viewWidth = 3.0
    var log10Width = log10(3.0)
    var palette = 1
    var palettePhase = 0.0
    var dimmerOut = 1.0                 // effective dimmer after blackout
    var frozen = false                  // DMX Master control: freeze (frame held)
    var safeLook = false                // DMX Master control: safe look
    var blackoutDMX = false             // DMX Master control: blackout
    var gpuMs = 0.0
    var layersDrawn = 0                 // bit i: layer i+1 drew this frame (opacity > 0 and content); others skip FX / Trails
    var running = false
    var fractal = FractalInfo()
    var layers: [LayerInfo] = []        // M2a clip layers, this frame (L1-L4)
    var bgLayer = LayerInfo()           // BG (L0) clip runtime, this frame
    var bgSource: LayerSource = .fractal   // BG's effective source this frame (Fractal chosen while the fractal is on L1-L4 = clip)
    var fractalOpacity = 1.0
    var fractalLayerShown = 0           // gen.swift: where the fractal was drawn this frame (0 = base)
    var fractalSpinAngle = 0.0          // degrees, accumulated spin shown
    var genAllocated = 0                // generator textures allocated
    var overlaysDrawn = 0               // gen.swift: bit i = layer i+1 drew its overlay this frame
    var layerMod: [Double] = []         // fx.swift: beat-mod LFO value shown per layer (0..1)
    var layerAngle: [Double] = []       // rotation shown (degrees, incl. spin + mod)
    var masterFXOn = false
    var fxHist = 0                      // Trails history pairs allocated
    var fxKernel = "composite"          // which composite kernel drew this frame
    var lateFrames: Int64 = 0           // frames over the budget (GPU time, or the tick's own work + wake-up delay)
    var wLate: Int64 = 0                // ... in the 5 s window
    var heldTicks: Int64 = 0            // ticks that held the last frame because the GPU had not finished the next one (bounded wait)
    var wHeld: Int64 = 0                // ... in the 5 s window
    var phaserShown: [Double] = [0, 0, 0]   // each phaser's value this frame (-1...1, x depth x fade-in)
    var phaserNote = ""                 // why a phaser has no effect (e.g. Julia morph needs a direct-path look)
    var phaserPaused: [String?] = [nil, nil, nil]   // per phaser: "hold" | "cycle" (paused by the zoom on HOLD / Cycle 0) or nil
    var spreadShown = 0.0               // spread macro after the phasers
    var audioShown: [Double] = []       // audio react: each route's value this frame (smoothed source x amount)
    var layerScale: [Double] = []       // scale drawn per layer (transform x beat mod x audio)
    var pendingAlarms: [String] = []    // logged by the watchdog thread
}

/// Deep-zoom state of the normal content, for status.json and the STATUS line.
struct FractalInfo {
    var depth = 0.0                     // log10 zoom
    var target = ""
    var targetIndex = 1
    var centerRe = ""
    var centerIm = ""
    var pending = ""                    // centre requested but its orbit not ready yet ("" = none)
    var iterations = 500                // used this frame (after the governor)
    var iterBase = 500                  // auto or override, before the governor
    var iterScale = 1.0
    var refLen = 0
    var refReady = false
    var refEscaped = false
    var refMs = 0.0
    var refComputed = 0
    var resW = 1920, resH = 1080
    var resAuto = true
    var gpuP95 = 0.0
    var governorChanges = 0
    var offsetX = 0.0, offsetY = 0.0    // view widths
    var rotation = 0.0                  // degrees (incl. spin and the rotation wobble phaser)
    var depthShown = 0.0                // depth drawn (with the zoom breathe phaser)
    // formula + loop (engine.swift)
    var path = "perturbation"           // perturbation (classic kernel) | perturbation+ (fractal_pert2) | direct (float32)
    var formula = "Mandelbrot"          // drawn this frame (the orbit's formula)
    var depthCap = zoomDepthMax
    var wildSS = 1                      // Wild twist supersampling this frame (4 = 2x2, 2 = 1x2, 1 = off)
    var juliaShownRe = 0.0, juliaShownIm = 0.0
    var loopPhase = "off"               // off | dive | fade | wait (new target's orbit) | idle (needs auto-zoom in)
    var loops = 0
    var loopEnd = 0.0                   // depth where the loop comes round
    var loopKind = "off"                // minibrot | dive (what runs: Minibrot loop falls back to dive off a minibrot)
    var loopNote = ""
}

final class RenderStats {
    private let lock = NSLock()
    private var r = RenderInfo()
    func with<T>(_ body: (inout RenderInfo) -> T) -> T {
        lock.lock(); defer { lock.unlock() }
        return body(&r)
    }
}

/// Heartbeats in mach ticks: [0] render loop, [1] last send call returned, [2] send call in progress since (0 = none).
final class Heartbeats {
    let p: UnsafeMutablePointer<UInt64>
    init() { p = .allocate(capacity: 4); p.initialize(repeating: 0, count: 4) }
    var render: UInt64 { get { oats_load_u64(p) } set { oats_store_u64(p, newValue) } }
    var send: UInt64 { get { oats_load_u64(p + 1) } set { oats_store_u64(p + 1, newValue) } }
    var sendInProgress: UInt64 { get { oats_load_u64(p + 2) } set { oats_store_u64(p + 2, newValue) } }
}

/// Process-wide flags.
final class Flags {
    private let lock = NSLock()
    private var _stopping = false
    var stopping: Bool {
        get { lock.lock(); defer { lock.unlock() }; return _stopping }
        set { lock.lock(); _stopping = newValue; lock.unlock() }
    }
}

struct Config {
    var name = "OATS VIZ Program"
    var groups = ""                     // empty = Public (NULL to NDI)
    var universe = 5
    var dmxMap: DMXMap = .v0            // --dmx-map v0 (PLAN 16 personality, default) | m0 (old 5-channel map)
    var oscPort = 7000
    var sacnMulticastIf: String? = nil
    var fps = 60.0
    var logDir = "logs"
    var debug = false
    var startContent: Content = .normal
    var noNdiMeta = false               // --no-ndi-meta: no ndi-meta thread; the render loop polls connections
    var noSacn = false                  // --no-sacn: no sACN receiver (a second, test instance next to the live one)
    var allowNets: [IPv4Net]? = nil     // --allow-net: replaces en0's network (127.0.0.0/8 is always allowed)
    var allowAny = false                // --allow-any: no source filter on OSC, sACN and preview
    var analysisOut = ""                // --analysis-out host:port (dominant colours over OSC; "" = off)
    var mediaDir = ""                   // --media: clip library folder (library.json); default <bin>/../../media
    var outputDisplay = 0               // --output-display N: output window on screen N at start (0 = off; output.swift)
    var ndiMode: NDIMode = .auto        // --ndi off|native|native-soft|helper|auto (ndiout.swift)
    var ndiSoft: NDISoft = .half        // --ndi-soft half|blur: the native-soft pass on the NDI copy
    var ndiQuality: NDIQuality = .previs // --ndi-quality full|previs: previs = 960x540 at half rate (NDI is previs only)
    var startupCard: Content = .standby  // --startup-card standby|test|ndi|off: shown on a cold start until the first control input (standby = the logo card, default since 2026-11-02)
    var startupCardSecs = 0.0           // --startup-card-secs: also end it after this long (0 = only on input)
    var guiPort = 8090                  // --gui-port: the controls URL on the NDI card (the GUI runs as its own process)
    var restart = false                 // --restart: a watchdog / crash / requested restart by the supervisor: no startup card
    var fpsN: Int32 { abs(fps - 59.94) < 0.01 ? 60000 : (abs(fps - 29.97) < 0.01 ? 30000 : Int32(fps.rounded())) }
    var fpsD: Int32 { (abs(fps - 59.94) < 0.01 || abs(fps - 29.97) < 0.01) ? 1001 : 1 }
}

/// The frame budget (ms): the governor and the render loop's late-frame alarm aim at it, so a 60 fps frame keeps
/// headroom. --frame-budget-ms overrides it (status.json budget_ms).
let defaultFrameBudgetMs = 15.2
var gFrameBudgetMs = defaultFrameBudgetMs

// Path overrides from the command line (empty = the defaults next to the binary). Set in parseArgs before first use.
var gScenesFileOverride = ""          // --scenes FILE (default <bin>/../scenes.json)
var gPresetsDirOverride = ""          // --presets-dir DIR with fx_presets.json + fractal_presets.json (default <bin>/../tools)
var gLibraryFileOverride = ""         // --library FILE (default <media>/library.json; clip paths stay relative to --media)

let gControl = ControlState()
let gStats = RenderStats()
let gBeats = Heartbeats()
let gFlags = Flags()
let gStartTicks = nowTicks()
let gStartDate = Date()
