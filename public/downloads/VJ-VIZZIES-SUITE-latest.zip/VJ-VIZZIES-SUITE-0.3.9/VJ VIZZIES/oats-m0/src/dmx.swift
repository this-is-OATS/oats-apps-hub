import Foundation

// DMX personalities (sACN, one universe, start address 1).
//  v0 (default, PLAN 16 adapted to what the player has now): two fixtures, "OATS VIZ" mode "Master 16" at
//     ch 1-16 and mode "Fractal 24" at ch 17-40, plus four fixtures in mode "Layer 16" (one per clip layer) at
//     41, 57, 73, 89 (gdtf/OATS@OATS VIZ.gdtf, made by tools/make_gdtf.py).
//  m0 (--dmx-map m0): the old 5-channel M0 map (PLAN 13.1 Part C), decoded in sacn.swift.
// The channel table below is printed by `oats-m0 --dmx-table` (JSON); `tools/make_gdtf.py --check bin/oats-m0`
// compares it with the GDTF file, so the fixture file and this decoder can't drift apart unnoticed.
// Timing (PLAN 10): continuous values glide linearly over one packet interval (MA3 sends <= 30 Hz, the render
// runs at 60); choice and index channels act only when 2 packets in a row agree. Nothing here is destructive,
// so nothing needs the 3 s hold.

enum DMXMap: String { case v0, m0 }

// MARK: - control policy: latest move wins (LTP), per parameter
// OSC/GUI commands always apply at once and take their parameter (owner "osc"). A DMX channel takes (or
// retakes) its parameter only when its decoded value CHANGES: 16-bit channels beyond a dead band of 0.2% of the
// range (131 steps), 8-bit channels on any step, choice/index channels when the 2-packet debounced value changes.
// Repeated identical packets never overwrite what OSC set later. First appearance / reappearance: the last value
// seen from DMX is kept for the whole run (across losses and source changes). On the very first packet there is
// no last value: it is the baseline, and it is applied only to parameters nobody has set over OSC since start.
// After a loss, a parameter is retaken only if its channel now differs from the last value seen.
// Depth and zoom speed are one group: ch 7-8, ch 9 and Fractal control take both; OSC depth/zoom/zoomspeed take both.

/// One controllable parameter (status.json "owners" keys).
enum Param: String, CaseIterable {
    case dimmer, content, bpm, effect_speed, zoomspeed, depth, target, offsets, palette, palette_speed, palette_offset, iterations, rotation, spin
    case master                 // blackout / freeze / safe look (DMX Master control vs OSC /oats/master/blackout)
}
enum Owner: String { case none = "default", dmx, osc }

/// The DMX side of LTP: the last value seen per channel key (kept for the whole run).
struct LTPWatch {
    enum Kind { case baseline, changed, same }
    private var seen: [String: Int] = [:]
    /// v = the channel's value (nil: not decided yet, e.g. debounce not settled). band = dead band in steps.
    /// zeroIsMode: 0 means something else (auto / no override), so crossing 0 always counts as a change.
    mutating func check(_ key: String, _ v: Int?, band: Int = 0, zeroIsMode: Bool = false) -> Kind {
        guard let v = v else { return .same }
        guard let s = seen[key] else { seen[key] = v; return .baseline }
        if abs(v - s) > band || (zeroIsMode && (v == 0) != (s == 0)) { seen[key] = v; return .changed }
        return .same
    }
    /// While DMX owns the parameter, follow the channel inside the dead band too (so a later slow fade counts
    /// from where the console really is).
    mutating func follow(_ key: String, _ v: Int?) { if let v = v, seen[key] != nil { seen[key] = v } }
}
let ltpBand16 = 131                 // 0.2% of 65535

extension Control {
    func owner(_ p: Param) -> Owner { owners[p] ?? .none }
    /// The DMX decision for one parameter (any of `kinds` decides). Returns true if DMX drives it now.
    /// `taken` collects parameters DMX took over from OSC (for the log).
    mutating func ltpDMX(_ p: Param, _ kinds: [LTPWatch.Kind], taken: inout [String]) -> Bool {
        let o = owner(p)
        if kinds.contains(.changed) || (kinds.contains(.baseline) && o != .osc) {
            if o == .osc { taken.append(p.rawValue) }
            owners[p] = .dmx
        }
        return owners[p] == .dmx
    }
    /// The DMX decision for one layer parameter (owner key "layer<n>.<param>", the same keys OSC takes).
    mutating func ltpLayerDMX(_ k: String, _ kinds: [LTPWatch.Kind], taken: inout [String]) -> Bool {
        let o = layerOwners[k] ?? .none
        if kinds.contains(.changed) || (kinds.contains(.baseline) && o != .osc) {
            if o == .osc { taken.append(k) }
            layerOwners[k] = .dmx
        }
        return layerOwners[k] == .dmx
    }
    /// OSC/GUI takes these parameters (always applies). Clears the DMX drive that would hide the OSC value.
    /// depthMove: an absolute depth/zoom (not a zoom speed): a DMX auto-zoom that was running stops (speed 0).
    mutating func ltpOSC(_ ps: [Param], depthMove: Bool = false) {
        if depthMove && owner(.zoomspeed) == .dmx { zoomSpeed = 0 }
        for p in ps {
            if p == .depth || p == .zoomspeed { dmx.depth = nil; dmx.freezeZoom = false }
            if p == .master { dmx.blackout = false; dmx.freeze = false; dmx.safeLook = false }
            owners[p] = .osc
        }
    }
}

/// What the render loop needs from DMX beyond the plain Control values (v0 only; all off for m0 and without DMX).
struct DMXDrive {
    var smooth = false          // continuous values glide over one packet interval (v0 live)
    var interval = 1.0 / 30     // seconds between the last two packets (clamped 1/120 ... 0.1 s)
    var depth: Double? = nil    // console control of the depth (log10 zoom); nil = auto-zoom or held
    var blackout = false        // Master control 10-19 (OR'd with the OSC blackout)
    var freeze = false          // Master control 20-29: hold the frame
    var safeLook = false        // Master control 30-39: blackout off, normal content, dimmer 100%
    var freezeZoom = false      // Fractal control 20-29: depth held, ch 7-9 ignored
    var resetSeq = 0            // Fractal control 10-19: +1 per command (depth back to 0)
}

// MARK: - channel table (v0)

/// Channel numbers inside each fixture (1-based; 16-bit = this channel coarse, the next one fine).
enum V0 {
    static let masterStart = 1, masterFootprint = 16
    static let fractalStart = 17, fractalFootprint = 24
    static let layerBase = 41, layerFootprint = 16              // Layer n at 41 + 16 (n - 1)
    static func layerStart(_ n: Int) -> Int { layerBase + layerFootprint * (n - 1) }
    static let colorStart = 105, colorFootprint = 8              // "Color 8": lights -> VJ colour link
    static let fxBase = 113, fxFootprint = 24                   // "Layer FX 24": Layer FX n at 113 + 24 (n - 1), after Color 8
    static func fxStart(_ n: Int) -> Int { fxBase + fxFootprint * (n - 1) }
    static let total = 40 + layerCount * layerFootprint + colorFootprint + layerCount * fxFootprint   // 208
    // Master
    static let dimmer = 1, bpm = 2, tap = 4, resync = 5, crossfade = 6, column = 8, deck = 9, fx1 = 10, effectSpeed = 14, test = 15, masterControl = 16
    // Fractal
    static let type = 1, target = 2, offX = 3, offY = 5, depth = 7, autoZoom = 9, iter = 10, juliaRe = 12, juliaIm = 14, power = 16,
               palette = 17, palOffset = 18, palCycle = 19, colouring = 20, rotation = 21, spin = 22, audio = 23, fractalControl = 24
    // Layer
    static let lOpacity = 1, lBank = 2, lSlot = 3, lBlend = 4, lPlaymode = 5, lSpeed = 6, lTransition = 8, lRestart = 9, lCommand = 10, lAutopilot = 11, lApTime = 12, lApBeats = 13, lSource = 14, lGenType = 15, lGenCount = 16
    // Color 8
    static let cR = 1, cG = 2, cB = 3, cAmount = 4, cTarget = 5, cMode = 6, cReserved = 7
    // Layer FX 24
    static let xPosX = 1, xPosY = 3, xScale = 5, xRot = 6, xSpin = 8, xTile = 9, xFX1 = 10, xFX2 = 13,
               xModTarget = 16, xModShape = 17, xModRate = 18, xModDepth = 19, xMaster = 20, xGenSpeed = 23, xGenThickness = 24
}

struct DMXSetDef { let from: Int; let name: String }        // a named value or band, from `from` to the next one - 1
struct DMXChanDef {
    let ch: Int                 // first (coarse) channel, 1-based inside the fixture
    let bytes: Int              // 1 = 8-bit, 2 = 16-bit (coarse, fine)
    let attr: String            // GDTF attribute
    let function: String        // what it does
    let snap: Bool              // choice / index / trigger: no fades through the values in between
    let def: Int                // GDTF default, in this channel's resolution
    let sets: [DMXSetDef]
    var reserved: Bool { function.hasSuffix("(reserved)") }
}
struct DMXModeDef { let name: String; let start: Int; let footprint: Int; let channels: [DMXChanDef] }

private func bands(_ names: [String], width: Int = 10) -> [DMXSetDef] {
    names.enumerated().map { DMXSetDef(from: $0.offset * width, name: $0.element) } + [DMXSetDef(from: names.count * width, name: "Reserved")]
}

/// GDTF ChannelSet name for a clip ("<slot> <name>", at most 32 characters). tools/make_gdtf.py does the same.
func dmxClipSetName(_ slot: Int, _ name: String) -> String {
    var s = String("\(slot) \(name)".prefix(32))
    while s.hasSuffix(" ") { s.removeLast() }
    return s
}

/// Layer 16 (one fixture per clip layer). Bank and slot channel sets are named from the library: banks by their
/// names, slots by the clip names of BANK 1 (other banks play by number). tools/make_gdtf.py reads the same
/// library.json, so --check needs the same media folder.
func layerModeDef(_ lib: Library) -> DMXModeDef {
    var bankSets = [DMXSetDef(from: 0, name: "Empty")]
    let bs = lib.banks.map { $0.bank }.filter { (1...255).contains($0) }.sorted()
    for (i, b) in bs.enumerated() {
        bankSets.append(DMXSetDef(from: b, name: lib.banks.first { $0.bank == b }!.name))
        let next = i + 1 < bs.count ? bs[i + 1] : 256
        if next != b + 1 && b < 255 { bankSets.append(DMXSetDef(from: b + 1, name: "Unused")) }
    }
    if bs.isEmpty { bankSets.append(DMXSetDef(from: 1, name: "Unused")) }
    var slotSets = [DMXSetDef(from: 0, name: "Clear")]
    let clips = (lib.banks.first { $0.bank == 1 }?.clips ?? []).filter { (1...255).contains($0.slot) }.sorted { $0.slot < $1.slot }
    for (i, c) in clips.enumerated() {
        slotSets.append(DMXSetDef(from: c.slot, name: dmxClipSetName(c.slot, c.name)))
        let next = i + 1 < clips.count ? clips[i + 1].slot : 256
        if next != c.slot + 1 && c.slot < 255 { slotSets.append(DMXSetDef(from: c.slot + 1, name: "Slot \(c.slot + 1)+")) }
    }
    if clips.isEmpty { slotSets.append(DMXSetDef(from: 1, name: "Slot 1+")) }
    var chans: [DMXChanDef] = [
        DMXChanDef(ch: V0.lOpacity, bytes: 1, attr: "Dimmer", function: "Opacity", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.lBank, bytes: 1, attr: "MediaFolder1", function: "Bank", snap: true, def: 0, sets: bankSets),
        DMXChanDef(ch: V0.lSlot, bytes: 1, attr: "MediaContent1", function: "Slot", snap: true, def: 0, sets: slotSets),
        DMXChanDef(ch: V0.lBlend, bytes: 1, attr: "OatsBlend", function: "Blend mode", snap: true, def: 0, sets: bands(BlendMode.allCases.map { $0.name })),
        DMXChanDef(ch: V0.lPlaymode, bytes: 1, attr: "OatsPlayMode", function: "Playmode", snap: true, def: 0, sets: bands(["Loop", "Once + hold"])),
        DMXChanDef(ch: V0.lSpeed, bytes: 2, attr: "OatsPlaySpeed", function: "Play speed", snap: false, def: 16384,
                   sets: [DMXSetDef(from: 0, name: "Stopped"), DMXSetDef(from: 1, name: "Slower"), DMXSetDef(from: 16384, name: "Normal"),
                          DMXSetDef(from: 16385, name: "Faster")]),
        DMXChanDef(ch: V0.lTransition, bytes: 1, attr: "OatsTransition", function: "Transition time", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.lRestart, bytes: 1, attr: "OatsRestart", function: "Restart", snap: true, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Off"), DMXSetDef(from: 128, name: "Restart")]),
        DMXChanDef(ch: V0.lCommand, bytes: 1, attr: "OatsClipCommand", function: "Clip command", snap: true, def: 0,
                   sets: bands(["Idle", "Next", "Previous", "Random"])),
        DMXChanDef(ch: V0.lAutopilot, bytes: 1, attr: "OatsAutopilot", function: "Autopilot", snap: true, def: 0,
                   sets: bands(["Off", "Order", "Shuffle"])),
        DMXChanDef(ch: V0.lApTime, bytes: 1, attr: "OatsAutopilotTime", function: "Autopilot interval", snap: false, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Per beats (ch 13)"), DMXSetDef(from: 1, name: "1-255 s")]),
        DMXChanDef(ch: V0.lApBeats, bytes: 1, attr: "OatsAutopilotBeats", function: "Autopilot beats", snap: true, def: 0,
                   sets: bands(apBeatBands.map { $0 == 1 ? "1 beat" : "\(Int($0)) beats" })),
    ]
    chans += [
        DMXChanDef(ch: V0.lSource, bytes: 1, attr: "OatsLayerSource", function: "Source", snap: true, def: 0, sets: bands(["Clip", "Fractal", "Generator", "NDI"])),
        DMXChanDef(ch: V0.lGenType, bytes: 1, attr: "OatsGenType", function: "Generator type", snap: true, def: 0, sets: bands(GenType.names)),
        DMXChanDef(ch: V0.lGenCount, bytes: 1, attr: "OatsGenCount", function: "Generator count", snap: false, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Keep (OSC/GUI)"), DMXSetDef(from: 1, name: "Sparse to dense")]),
    ]
    return DMXModeDef(name: "Layer 16", start: V0.layerBase, footprint: V0.layerFootprint, channels: chans)
}

let apBeatBands: [Double] = [1, 2, 4, 8, 16, 32]

/// Color 8 (lights -> VJ colour link), one fixture at 105.
let colorModeDef = DMXModeDef(name: "Color 8", start: V0.colorStart, footprint: V0.colorFootprint, channels: [
    DMXChanDef(ch: V0.cR, bytes: 1, attr: "ColorAdd_R", function: "Red", snap: false, def: 255, sets: []),
    DMXChanDef(ch: V0.cG, bytes: 1, attr: "ColorAdd_G", function: "Green", snap: false, def: 255, sets: []),
    DMXChanDef(ch: V0.cB, bytes: 1, attr: "ColorAdd_B", function: "Blue", snap: false, def: 255, sets: []),
    DMXChanDef(ch: V0.cAmount, bytes: 1, attr: "OatsColorAmount", function: "Match amount", snap: false, def: 0,
               sets: [DMXSetDef(from: 0, name: "Off"), DMXSetDef(from: 1, name: "Match")]),
    DMXChanDef(ch: V0.cTarget, bytes: 1, attr: "OatsColorTarget", function: "Colour target", snap: true, def: 0,
               sets: bands(["All layers + fractal", "Clips only", "Fractal only"])),
    DMXChanDef(ch: V0.cMode, bytes: 1, attr: "OatsColorMode", function: "Colour mode", snap: true, def: 0,
               sets: bands(["Tint", "Hue shift", "Replace"])),
    DMXChanDef(ch: 7, bytes: 1, attr: "OatsColorCh7", function: "Color ch 7 (reserved)", snap: false, def: 0, sets: []),
    DMXChanDef(ch: 8, bytes: 1, attr: "OatsColorCh8", function: "Color ch 8 (reserved)", snap: false, def: 0, sets: []),
])

/// Layer FX 24 ch 9: flip (4 states) x tile (1, tile 2..8, mirror-tile 2..8 = 15 states) in bands of 4; 240-255 reserved.
func fxTileSetName(_ idx: Int) -> String {
    let fl = idx / 15, ts = idx % 15
    let base = ts == 0 ? "" : (ts <= 7 ? "Tile \(ts + 1)" : "Mirror \(ts - 6)")
    let f = ["", "Flip H", "Flip V", "Flip HV"][fl]
    return base.isEmpty ? (f.isEmpty ? "Normal" : f) : (f.isEmpty ? base : base + " " + f)
}
func v0FXTile(_ v: Int) -> (flipX: Bool, flipY: Bool, tile: Int, mirror: Bool)? {
    let idx = v / 4
    guard idx < 60 else { return nil }
    let fl = idx / 15, ts = idx % 15
    return (fl & 1 != 0, fl & 2 != 0, ts == 0 ? 1 : (ts <= 7 ? ts + 1 : ts - 6), ts >= 8)
}
/// ch 5 scale: 0..128 = 0.1..1x (log), 128..255 = 1..4x (log); 128 = 1x.
func v0FXScale(_ v: Int) -> Double { v <= 128 ? 0.1 * pow(10, Double(v) / 128) : pow(4, Double(v - 128) / 127) }
/// ch 6-7 rotation: 32768 = 0, 0..65535 = -180..+180 deg.
func v0FXRotation(_ v16: Int) -> Double { Double(v16 - 32768) / 32768 * 180 }
/// ch 8 spin: 125-131 stop (128 +- 3), 132-255 0..+2 turns/s, 0-124 -2..0.
func v0FXSpin(_ v: Int) -> Double { abs(v - 128) <= 3 ? 0 : (v > 131 ? 2 * Double(v - 131) / 124 : -2 * Double(125 - v) / 125) }
/// FX speed: 0 = stopped, 128 = 0.5 (default rate), 255 = 1.
func v0FXSpeed(_ v: Int) -> Double { v <= 128 ? 0.5 * Double(v) / 128 : 0.5 + 0.5 * Double(v - 128) / 127 }
func v0FXType(_ v: Int) -> FXType? { v < 10 * FXType.allCases.count ? FXType(rawValue: v / 10) : nil }   // 0-209; 210+ reserved (keep)
func v0ModTarget(_ v: Int) -> ModTarget? { v < 80 ? ModTarget(rawValue: v / 10) : nil }
func v0ModShape(_ v: Int) -> ModShape? { v < 40 ? ModShape(rawValue: v / 10) : nil }
func v0ModRate(_ v: Int) -> Double? { v < 70 ? modBeatValues[v / 10] : nil }

let fxTypeSets = bands(FXType.allCases.map { $0.name })
/// Fractal ch 22 spin and Layer FX ch 23 generator speed: 0 = keep (no DMX value: the OSC/GUI value stays, so an older
/// patch with these channels at 0 changes nothing), 1-124 clockwise / reverse, 125-131 stop, 132-255 counter-clockwise / forward.
let spinSets = [DMXSetDef(from: 0, name: "Keep (OSC/GUI)"), DMXSetDef(from: 1, name: "Spin clockwise"), DMXSetDef(from: 125, name: "Stop"),
                DMXSetDef(from: 132, name: "Spin counter-clockwise")]
let genSpeedSets = [DMXSetDef(from: 0, name: "Keep (OSC/GUI)"), DMXSetDef(from: 1, name: "Reverse"), DMXSetDef(from: 125, name: "Stop"),
                    DMXSetDef(from: 132, name: "Forward")]
/// 0 = nil (keep); 1-124 -max..0, 125-131 0, 132-255 0..+max.
func v0Bipolar(_ v: Int, max mx: Double) -> Double? {
    if v == 0 { return nil }
    if abs(v - 128) <= 3 { return 0 }
    return v > 131 ? mx * Double(v - 131) / 124 : -mx * Double(125 - v) / 124
}
/// Layer ch 14 source: 0-9 clip, 10-19 fractal, 20-29 generator, 30-255 reserved (keep).
func v0Source(_ v: Int) -> LayerSource? { v < 40 ? LayerSource.allCases[v / 10] : nil }   // 30-39 NDI (v0.10)
func v0GenType(_ v: Int) -> GenType? { GenType(rawValue: v / 10) }
/// Layer ch 16 count / Layer FX ch 24 thickness: 0 = keep, 1-255 = 0..1.
func v0Unit(_ v: Int) -> Double? { v == 0 ? nil : Double(v - 1) / 254 }
let fxSpeedSets = [DMXSetDef(from: 0, name: "Stopped"), DMXSetDef(from: 1, name: "Slower"), DMXSetDef(from: 128, name: "Normal"), DMXSetDef(from: 129, name: "Faster")]
let fxAmountSets = [DMXSetDef(from: 0, name: "Off"), DMXSetDef(from: 1, name: "Amount")]

/// Layer FX 24 (one fixture per clip layer, at 113, 137, 161, 185): transform, 2 FX slots, beat mod; ch 20-22 the
/// master FX slot, honoured only from Layer FX 1.
let layerFXModeDef: DMXModeDef = {
    var c: [DMXChanDef] = [
        DMXChanDef(ch: V0.xPosX, bytes: 2, attr: "OatsLayerX", function: "Position X", snap: false, def: 32768,
                   sets: [DMXSetDef(from: 0, name: "Left"), DMXSetDef(from: 32768, name: "Centre"), DMXSetDef(from: 32769, name: "Right")]),
        DMXChanDef(ch: V0.xPosY, bytes: 2, attr: "OatsLayerY", function: "Position Y", snap: false, def: 32768,
                   sets: [DMXSetDef(from: 0, name: "Up"), DMXSetDef(from: 32768, name: "Centre"), DMXSetDef(from: 32769, name: "Down")]),
        DMXChanDef(ch: V0.xScale, bytes: 1, attr: "OatsLayerScale", function: "Scale", snap: false, def: 128,
                   sets: [DMXSetDef(from: 0, name: "Smaller"), DMXSetDef(from: 128, name: "1x (cover)"), DMXSetDef(from: 129, name: "Larger")]),
        DMXChanDef(ch: V0.xRot, bytes: 2, attr: "OatsLayerRot", function: "Rotation", snap: false, def: 32768,
                   sets: [DMXSetDef(from: 0, name: "Clockwise"), DMXSetDef(from: 32768, name: "Upright"), DMXSetDef(from: 32769, name: "Counter-clockwise")]),
        DMXChanDef(ch: V0.xSpin, bytes: 1, attr: "OatsLayerSpin", function: "Spin", snap: false, def: 128,
                   sets: [DMXSetDef(from: 0, name: "Spin clockwise"), DMXSetDef(from: 125, name: "Stop"), DMXSetDef(from: 132, name: "Spin counter-clockwise")]),
        DMXChanDef(ch: V0.xTile, bytes: 1, attr: "OatsLayerTile", function: "Flip / tile", snap: true, def: 0,
                   sets: (0..<60).map { DMXSetDef(from: $0 * 4, name: fxTileSetName($0)) } + [DMXSetDef(from: 240, name: "Reserved")]),
    ]
    for (s, b) in [(1, V0.xFX1), (2, V0.xFX2)] {
        c.append(DMXChanDef(ch: b, bytes: 1, attr: "OatsFX\(s)Type", function: "FX \(s) type", snap: true, def: 0, sets: fxTypeSets))
        c.append(DMXChanDef(ch: b + 1, bytes: 1, attr: "OatsFX\(s)Amount", function: "FX \(s) amount", snap: false, def: 0, sets: fxAmountSets))
        c.append(DMXChanDef(ch: b + 2, bytes: 1, attr: "OatsFX\(s)Speed", function: "FX \(s) speed", snap: false, def: 128, sets: fxSpeedSets))
    }
    c += [
        DMXChanDef(ch: V0.xModTarget, bytes: 1, attr: "OatsModTarget", function: "Beat mod target", snap: true, def: 0,
                   sets: bands(["None", "Rotation", "Scale", "Position X", "Position Y", "FX 1 amount", "FX 2 amount", "Opacity"])),
        DMXChanDef(ch: V0.xModShape, bytes: 1, attr: "OatsModShape", function: "Beat mod shape", snap: true, def: 0,
                   sets: bands(["Sine", "Saw", "Square", "Random step"])),
        DMXChanDef(ch: V0.xModRate, bytes: 1, attr: "OatsModRate", function: "Beat mod rate", snap: true, def: 0,
                   sets: bands(modBeatValues.map { $0 <= 1 ? modBeatName($0) + " beat" : modBeatName($0) + " beats" })),
        DMXChanDef(ch: V0.xModDepth, bytes: 1, attr: "OatsModDepth", function: "Beat mod depth", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.xMaster, bytes: 1, attr: "OatsMstFXType", function: "Master FX type (Layer FX 1 only)", snap: true, def: 0, sets: fxTypeSets),
        DMXChanDef(ch: V0.xMaster + 1, bytes: 1, attr: "OatsMstFXAmount", function: "Master FX amount", snap: false, def: 0, sets: fxAmountSets),
        DMXChanDef(ch: V0.xMaster + 2, bytes: 1, attr: "OatsMstFXSpeed", function: "Master FX speed", snap: false, def: 128, sets: fxSpeedSets),
        DMXChanDef(ch: V0.xGenSpeed, bytes: 1, attr: "OatsGenSpeed", function: "Generator speed", snap: false, def: 0, sets: genSpeedSets),
        DMXChanDef(ch: V0.xGenThickness, bytes: 1, attr: "OatsGenThickness", function: "Generator thickness", snap: false, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Keep (OSC/GUI)"), DMXSetDef(from: 1, name: "Thin to thick")]),
    ]
    return DMXModeDef(name: "Layer FX 24", start: V0.fxBase, footprint: V0.fxFootprint, channels: c)
}()

let dmxTableV0: [DMXModeDef] = [
    DMXModeDef(name: "Master 16", start: V0.masterStart, footprint: V0.masterFootprint, channels: [
        DMXChanDef(ch: V0.dimmer, bytes: 1, attr: "Dimmer", function: "Dimmer", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.bpm, bytes: 2, attr: "OatsBPM", function: "BPM", snap: false, def: 0,
                   sets: [DMXSetDef(from: 0, name: "No override"), DMXSetDef(from: 1, name: "BPM 20-300")]),
        DMXChanDef(ch: V0.tap, bytes: 1, attr: "OatsTap", function: "Tap", snap: true, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Off"), DMXSetDef(from: 128, name: "Tap")]),
        DMXChanDef(ch: V0.resync, bytes: 1, attr: "OatsResync", function: "Resync", snap: true, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Off"), DMXSetDef(from: 128, name: "Resync")]),
        DMXChanDef(ch: V0.crossfade, bytes: 2, attr: "OatsCrossfade", function: "Crossfader (reserved)", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.column, bytes: 1, attr: "OatsColumn", function: "Column", snap: true, def: 0,
                   sets: [DMXSetDef(from: 0, name: "None")] + (1...8).map { DMXSetDef(from: $0, name: "Column \($0)") } + [DMXSetDef(from: 9, name: "Column 9+")]),
        DMXChanDef(ch: V0.deck, bytes: 1, attr: "OatsScene", function: "Scene", snap: true, def: 0,
                   sets: [DMXSetDef(from: 0, name: "None")] + (1...sceneMax).map { DMXSetDef(from: $0, name: "Scene \(sceneLabel($0))") }
                         + [DMXSetDef(from: sceneMax + 1, name: "Reserved")]),
        DMXChanDef(ch: V0.fx1, bytes: 1, attr: "OatsSceneFade", function: "Scene fade", snap: false, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Scene's own"), DMXSetDef(from: 1, name: "Fade 0.1-25.5 s")]),
        DMXChanDef(ch: V0.fx1 + 1, bytes: 1, attr: "OatsMasterFX2", function: "Master FX 2 (reserved)", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.fx1 + 2, bytes: 1, attr: "OatsMasterFX3", function: "Master FX 3 (reserved)", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.fx1 + 3, bytes: 1, attr: "OatsMasterFX4", function: "Master FX 4 (reserved)", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.effectSpeed, bytes: 1, attr: "OatsEffectSpeed", function: "Effect speed", snap: false, def: 128,
                   sets: [DMXSetDef(from: 0, name: "Stopped"), DMXSetDef(from: 1, name: "Slower"), DMXSetDef(from: 128, name: "Normal"),
                          DMXSetDef(from: 129, name: "Faster")]),
        DMXChanDef(ch: V0.test, bytes: 1, attr: "OatsTestContent", function: "Test content", snap: true, def: 0,
                   sets: bands(["Normal", "DEEP test", "NOISE test", "Test card", "NDI card"])),
        DMXChanDef(ch: V0.masterControl, bytes: 1, attr: "OatsMasterControl", function: "Master control", snap: true, def: 0,
                   sets: bands(["Idle", "Blackout", "Freeze", "Safe look"])),
    ]),
    DMXModeDef(name: "Fractal 24", start: V0.fractalStart, footprint: V0.fractalFootprint, channels: [
        DMXChanDef(ch: V0.type, bytes: 1, attr: "OatsFractalType", function: "Fractal type", snap: true, def: 0, sets: bands(Formula.names)),
        DMXChanDef(ch: V0.target, bytes: 1, attr: "OatsTarget", function: "Target", snap: true, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Free (keep)")] + zoomTargets.enumerated().map { DMXSetDef(from: $0.offset + 1, name: $0.element.name) }
                         + [DMXSetDef(from: zoomTargets.count + 1, name: "Reserved")]),
        DMXChanDef(ch: V0.offX, bytes: 2, attr: "OatsOffsetX", function: "Offset X", snap: false, def: 32768,
                   sets: [DMXSetDef(from: 0, name: "Left"), DMXSetDef(from: 32768, name: "On target"), DMXSetDef(from: 32769, name: "Right")]),
        DMXChanDef(ch: V0.offY, bytes: 2, attr: "OatsOffsetY", function: "Offset Y", snap: false, def: 32768,
                   sets: [DMXSetDef(from: 0, name: "Down"), DMXSetDef(from: 32768, name: "On target"), DMXSetDef(from: 32769, name: "Up")]),
        DMXChanDef(ch: V0.depth, bytes: 2, attr: "OatsDepth", function: "Zoom depth", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.autoZoom, bytes: 1, attr: "OatsAutoZoom", function: "Auto-zoom speed", snap: false, def: 128,
                   sets: [DMXSetDef(from: 0, name: "Zoom out"), DMXSetDef(from: 125, name: "Stop"), DMXSetDef(from: 132, name: "Zoom in")]),
        DMXChanDef(ch: V0.iter, bytes: 2, attr: "OatsIterations", function: "Max iterations", snap: false, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Auto"), DMXSetDef(from: 1, name: "Fixed")]),
        DMXChanDef(ch: V0.juliaRe, bytes: 2, attr: "OatsJuliaRe", function: "Julia c real", snap: false, def: 32768, sets: juliaCSets),
        DMXChanDef(ch: V0.juliaIm, bytes: 2, attr: "OatsJuliaIm", function: "Julia c imaginary", snap: false, def: 32768, sets: juliaCSets),
        DMXChanDef(ch: V0.power, bytes: 1, attr: "OatsKaleidoFold", function: "Kaleido fold", snap: true, def: 0, sets: foldSets),
        DMXChanDef(ch: V0.palette, bytes: 1, attr: "OatsPalette", function: "Palette", snap: true, def: 0, sets: bands(Array(paletteNames[1...5]))),
        DMXChanDef(ch: V0.palOffset, bytes: 1, attr: "OatsPaletteOffset", function: "Palette offset", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.palCycle, bytes: 1, attr: "OatsPaletteCycle", function: "Palette cycle speed", snap: false, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Stop"), DMXSetDef(from: 1, name: "Cycle")]),
        DMXChanDef(ch: V0.colouring, bytes: 1, attr: "OatsColouring", function: "Orbit trap", snap: true, def: 0, sets: bands(trapSetNames)),
        DMXChanDef(ch: V0.rotation, bytes: 1, attr: "OatsRotation", function: "Rotation", snap: false, def: 0, sets: []),
        DMXChanDef(ch: V0.spin, bytes: 1, attr: "OatsFractalSpin", function: "Spin", snap: false, def: 0, sets: spinSets),
        DMXChanDef(ch: V0.audio, bytes: 1, attr: "OatsJuliaAmount", function: "Julia morph", snap: false, def: 0,
                   sets: [DMXSetDef(from: 0, name: "Off"), DMXSetDef(from: 1, name: "Mandelbrot to Julia")]),
        DMXChanDef(ch: V0.fractalControl, bytes: 1, attr: "OatsFractalControl", function: "Fractal control", snap: true, def: 0,
                   sets: bands(fractalControlNames)),
    ]),
]

/// `oats-m0 --dmx-table`: the v0 table as JSON (for tools/make_gdtf.py --check). lib: the clip library (Layer 16 names).
func dmxTableJSON(_ lib: Library) -> String {
    let modes: [[String: Any]] = (dmxTableV0 + [layerModeDef(lib), colorModeDef, layerFXModeDef]).map { m in
        ["name": m.name, "start": m.start, "footprint": m.footprint,
         "channels": m.channels.map { c in
            ["ch": c.ch, "offset": c.bytes == 2 ? [c.ch, c.ch + 1] : [c.ch], "attribute": c.attr, "function": c.function,
             "snap": c.snap, "default": c.def, "reserved": c.reserved,
             "sets": c.sets.map { ["from": $0.from, "name": $0.name] }] as [String: Any]
         }] as [String: Any]
    }
    let j: [String: Any] = ["personality": "v0", "fixture": "OATS VIZ", "modes": modes]
    guard let d = try? JSONSerialization.data(withJSONObject: j, options: [.prettyPrinted, .sortedKeys]) else { return "{}" }
    return String(decoding: d, as: UTF8.self)
}

// MARK: - value decoding (v0)

// Fractal 24 formula modifiers (v0.6): ch 1 formula, ch 12-15 Julia c (32768 = keep), ch 16 kaleido fold,
// ch 20 orbit trap, ch 23 Julia morph (Julia c: 0 and 32768 = keep), ch 24 bands 30-69 the endless-zoom loop. All zero = classic, loop off.
let trapSetNames = ["Off (palette)", "Point", "Circle", "Line", "Cross", "Star"]
let fractalControlNames = ["Idle", "Reset to target", "Freeze zoom", "Loop minibrot", "Dive & return", "Dive next target", "Dive random target"]
let juliaCSets = [DMXSetDef(from: 0, name: "Keep (0)"), DMXSetDef(from: 1, name: "Negative"), DMXSetDef(from: 32768, name: "Keep (OSC/GUI)"), DMXSetDef(from: 32769, name: "Positive")]
let foldSets: [DMXSetDef] = [DMXSetDef(from: 0, name: "Off")] + (2...12).map { DMXSetDef(from: 10 * ($0 - 1), name: "Fold \($0)") }
    + (2...12).map { DMXSetDef(from: 120 + 10 * ($0 - 2), name: "Fold \($0) mirror") } + [DMXSetDef(from: 230, name: "Reserved")]
func v0Formula(_ v: Int) -> Formula? { v < 10 * Formula.allCases.count ? Formula(rawValue: v / 10) : nil }   // reserved: keep
func v0Fold(_ v: Int) -> (n: Int, mirror: Bool)? { v < 10 ? (0, false) : v < 120 ? (v / 10 + 1, false) : v < 230 ? ((v - 120) / 10 + 2, true) : nil }
func v0Trap(_ v: Int) -> TrapShape? { v < 60 ? TrapShape.allCases[v / 10] : nil }
func v0JuliaC(_ v16: Int) -> Double? { v16 == 32768 || v16 == 0 ? nil : 2 * Double(v16 - 32768) / 32768 }
/// ch 24: 0-29 loop off (idle / reset / freeze zoom), 30 minibrot, 40 dive same, 50 dive next, 60 dive random, 70+ keep.
func v0Loop(_ v: Int) -> (LoopMode, LoopNext?)? {
    if v < 30 { return (.off, nil) }
    if v < 40 { return (.minibrot, nil) }
    if v < 70 { return (.dive, [LoopNext.same, .next, .random][v / 10 - 4]) }
    return nil
}

/// 8-bit auto-zoom / M0 zoom speed: 125-131 = stop (128 +- 3); 132-255 zoom in up to 0.5 decades/s; 0-124 out.
func dmxZoomSpeed(_ v: Int) -> Double {
    if abs(v - 128) <= 3 { return 0 }
    if v > 131 { return 0.5 * Double(v - 131) / Double(255 - 131) }
    return -0.5 * Double(125 - v) / 125.0
}
func v0BPM(_ v16: Int) -> Double { v16 == 0 ? 0 : 20 + 280 * Double(v16 - 1) / 65534 }
func v0Depth(_ v16: Int) -> Double { zoomDepthMax * Double(v16) / 65535 }
func v0Offset(_ v16: Int) -> Double { Double(v16 - 32768) / 32768 }
func v0Iterations(_ v16: Int) -> Int { v16 == 0 ? 0 : min(maxIterLimit, max(100, v16)) }
/// Master ch 14: 0 = stopped, 128 = 1.0x, 255 = 2.0x (linear 0..1 below 128, 1..2 above). Multiplies all motion rates.
func v0EffectSpeed(_ v: Int) -> Double { v < 128 ? Double(v) / 128 : 1 + Double(v - 128) / 127 }
func v0Palette(_ v: Int) -> Int? { v < 50 ? v / 10 + 1 : nil }                       // reserved: keep the palette
/// Master ch 15: 0 normal, 10 DEEP, 20 NOISE, 30 test card, 40 NDI card (2026-10-23, appended); 50-255 reserved: normal.
func v0TestContent(_ v: Int) -> Content { [Content.normal, .deep, .noise, .testcard, .ndicard][v < 50 ? v / 10 : 0] }
enum MasterCtl: String { case idle, blackout, freeze, safeLook = "safe look" }
func v0MasterControl(_ v: Int) -> MasterCtl { [MasterCtl.idle, .blackout, .freeze, .safeLook][v < 40 ? v / 10 : 0] }
enum FractalCtl: String { case idle, reset = "reset to target", freezeZoom = "freeze zoom" }
func v0FractalControl(_ v: Int) -> FractalCtl { [FractalCtl.idle, .reset, .freezeZoom][v < 30 ? v / 10 : 0] }
/// Layer: ch 4 blend bands of 10 (80-255 reserved: keep), ch 5 playmode (20-255 reserved: keep),
/// ch 6-7 speed 0..4x (16384 = 1.0x), ch 8 transition 0..10 s.
func v0LayerBlend(_ v: Int) -> BlendMode? { v < 80 ? BlendMode(rawValue: v / 10) : nil }
func v0LayerPlaymode(_ v: Int) -> PlayMode? { v < 20 ? (v < 10 ? .loop : .once) : nil }
func v0LayerSpeed(_ v16: Int) -> Double { Double(v16) / 16384 }
func v0LayerTransition(_ v: Int) -> Double { 10 * Double(v) / 255 }
/// Layer ch 10 clip command: 0-9 idle, 10-19 next, 20-29 previous, 30-39 random, 40-255 reserved (idle).
func v0ClipCommand(_ v: Int) -> ClipNav? { v >= 10 && v < 40 ? [ClipNav.next, .prev, .random][v / 10 - 1] : nil }
/// Layer ch 11 autopilot: 0-9 off, 10-19 order, 20-29 shuffle, 30-255 reserved (keep).
func v0Autopilot(_ v: Int) -> Autopilot? { v < 30 ? [Autopilot.off, .order, .shuffle][v / 10] : nil }
/// Layer ch 13 beats per change: bands of 10: 1, 2, 4, 8, 16, 32 beats; 60-255 reserved (keep).
func v0ApBeats(_ v: Int) -> Double? { v < 60 ? apBeatBands[v / 10] : nil }
func v0ColorTarget(_ v: Int) -> ColorTarget? { v < 30 ? ColorTarget.allCases[v / 10] : nil }
func v0ColorMode(_ v: Int) -> ColorMode? { v < 30 ? ColorMode.allCases[v / 10] : nil }

/// A choice / index channel acts only when 2 packets in a row agree.
struct Debounce {
    private var raw = -1, count = 0
    private(set) var stable: Int? = nil
    mutating func feed(_ v: Int) -> Int? {
        if v == raw { count += 1 } else { raw = v; count = 1 }
        if count >= 2 { stable = v }
        return stable
    }
}

/// Decodes v0 packets from the winning source into gControl. Used only by SACNReceiver, under its lock.
final class V0Decoder {
    private var dTest = Debounce(), dMCtl = Debounce(), dType = Debounce(), dTarget = Debounce(), dPal = Debounce(), dFCtl = Debounce()
    private var tapHigh = false, resyncHigh = false
    private var fractalDriven = false
    private var depthConsole = true
    private var latchedDepth = -1
    private var lastFCtl = FractalCtl.idle
    private var lastMCtl = MasterCtl.idle
    private var lastPacket: UInt64 = 0
    private var resetSeq = 0                          // monotonic for the whole run (the render loop compares)
    private var tapTimes: [Double] = []
    private var dColumn = Debounce(), columnGoes = 0, lastColumn = -1
    private var dScene = Debounce(), sceneGoes = 0, lastScene = -1    // Master ch 9 scene (v0.7), ch 10 fade
    private var dCTarget = Debounce(), dCMode = Debounce(), colorDriven = false
    private var ltp = LTPWatch()                      // last value seen per channel: kept for the whole run (LTP)
    private var dFold = Debounce(), dTrap = Debounce()
    // decoded, for status.json
    private(set) var raw = [Int](repeating: 0, count: V0.total)
    private var fxSpeed = 1.0
    private var bpm = 0.0, tapBPM = 0.0, tapCount = 0, resyncCount = 0
    private var test = Content.normal, mctl = MasterCtl.idle
    private var startupBase: [Int]? = nil
    private var typeRaw = 0, target: Int? = nil, offX = 0.0, offY = 0.0, depth = 0.0, speed = 0.0, iter = 0
    private var palette: Int? = nil, palOffset = 0.0, palCycle = 0.0, rotation = 0.0, fctl = FractalCtl.idle
    /// One Layer 16 fixture (clip layer n at 41 + 16 (n - 1)).
    private struct LayerDec {
        var dBank = Debounce(), dSlot = Debounce(), dBlend = Debounce(), dMode = Debounce()
        var restartHigh = false, driven = false
        var dCmd = Debounce(), dAp = Debounce(), dBeats = Debounce(), lastCmd = 0, commands = 0
        var bank = 0, slot = 0, restarts = 0
        var blend: BlendMode? = nil, mode: PlayMode? = nil
        var dSrc = Debounce(), dGT = Debounce()
    }
    private var lay = [LayerDec](repeating: LayerDec(), count: layerCount)
    /// One Layer FX 24 fixture (clip layer n at 113 + 24 (n - 1)).
    private struct FXDec {
        var driven = false
        var dTile = Debounce(), dT1 = Debounce(), dT2 = Debounce(), dMT = Debounce(), dMS = Debounce(), dMR = Debounce(), dMst = Debounce()
    }
    private var fxd = [FXDec](repeating: FXDec(), count: layerCount)

    /// New winner or DMX lost: start the debounce and edge state again (resetSeq and the LTP last-seen values stay).
    func reset() {
        dTest = Debounce(); dMCtl = Debounce(); dType = Debounce(); dTarget = Debounce(); dPal = Debounce(); dFCtl = Debounce()
        dFold = Debounce(); dTrap = Debounce()
        dColumn = Debounce(); dCTarget = Debounce(); dCMode = Debounce(); colorDriven = false
        dScene = Debounce()
        for i in lay.indices { let r = lay[i].restarts, k = lay[i].commands; lay[i] = LayerDec(); lay[i].restarts = r; lay[i].commands = k }
        fxd = [FXDec](repeating: FXDec(), count: layerCount)
        tapHigh = false; resyncHigh = false; fractalDriven = false; depthConsole = true; latchedDepth = -1
        lastFCtl = .idle; lastMCtl = .idle; lastPacket = 0
        mctl = .idle; fctl = .idle
    }

    /// DMX lost: "hold the last look". The DMX control states that OSC can't undo are folded into plain
    /// values (a DMX blackout becomes the OSC blackout, so the GUI can clear it; safe look becomes dimmer 100%,
    /// normal content, blackout off; freeze zoom becomes zoom speed 0); a frame freeze is released.
    func lost() {
        gControl.with { c in
            if c.dmx.blackout { c.blackout = true }
            if c.dmx.safeLook { c.blackout = false; c.content = .normal; c.dimmer = 1 }
            if c.dmx.freezeZoom { c.zoomSpeed = 0 }
            let rs = c.dmx.resetSeq
            c.dmx = DMXDrive()
            c.dmx.resetSeq = rs
        }
        reset()
    }

    /// One packet from the winning source. Returns log fragments for the changes worth a line.
    func apply(_ slots: ArraySlice<UInt8>, now: UInt64) -> [String] {
        for i in 0..<V0.total { let k = slots.startIndex + i; raw[i] = k < slots.endIndex ? Int(slots[k]) : 0 }  // short packet: 0
        if startupBase != nil || gStartup.waiting {      // startup card: the first packet is the baseline, any change after it is input
            if let b = startupBase {
                if b != raw, let ch = raw.indices.first(where: { raw[$0] != b[$0] }) { gStartup.input("DMX change (ch \(ch + 1))"); startupBase = nil }
                else if !gStartup.waiting { startupBase = nil }
            } else { startupBase = raw }
        }
        let mb = V0.masterStart - 1, fb = V0.fractalStart - 1
        func m(_ i: Int) -> Int { raw[mb + i - 1] }
        func m16(_ i: Int) -> Int { m(i) << 8 | m(i + 1) }
        func f(_ i: Int) -> Int { raw[fb + i - 1] }
        func f16(_ i: Int) -> Int { f(i) << 8 | f(i + 1) }
        let tsec = ticksToSec(now &- gStartTicks)
        let interval = lastPacket == 0 ? 1.0 / 30 : min(0.1, max(1.0 / 120, ticksToSec(now &- lastPacket)))
        lastPacket = now
        var log: [String] = []

        // Master
        let dim = Double(m(V0.dimmer)) / 255
        let bpmRaw = m16(V0.bpm)
        bpm = v0BPM(bpmRaw)
        var tapped = false
        let th = m(V0.tap) > 127
        if th && !tapHigh {
            tapCount += 1; tapped = true
            if let last = tapTimes.last, tsec - last > 2 { tapTimes.removeAll() }
            tapTimes.append(tsec); if tapTimes.count > 5 { tapTimes.removeFirst() }
            if tapTimes.count >= 2 { tapBPM = 60 * Double(tapTimes.count - 1) / (tapTimes.last! - tapTimes.first!) }
            log.append(tapTimes.count >= 2 ? String(format: "tap %d (%.1f BPM from %d taps)", tapCount, tapBPM, tapTimes.count) : "tap \(tapCount)")
        }
        tapHigh = th
        let rh = m(V0.resync) > 127
        let resynced = rh && !resyncHigh
        if resynced { resyncCount += 1; log.append("resync \(resyncCount) (beat 1 of the tempo clock)") }
        resyncHigh = rh
        fxSpeed = v0EffectSpeed(m(V0.effectSpeed))
        let testRaw = dTest.feed(m(V0.test))
        if let v = testRaw { test = v0TestContent(v) }
        let mctlRaw = dMCtl.feed(m(V0.masterControl))
        if let v = mctlRaw { mctl = v0MasterControl(v) }
        let colRaw = dColumn.feed(m(V0.column))
        var columnFire = 0
        if let v = colRaw { if lastColumn >= 0 && v != lastColumn && v > 0 { columnFire = v }; lastColumn = v }   // first value = baseline
        var sceneFire = 0                                     // ch 9: fires when the debounced value changes to 1..128; first value = baseline
        if let v = dScene.feed(m(V0.deck)) { if lastScene >= 0 && v != lastScene && v > 0 && v <= sceneMax { sceneFire = v }; lastScene = v }
        let sceneFadeRaw = m(V0.fx1)
        if mctl != lastMCtl { log.append("master control \(mctl.rawValue)" + (mctl == .safeLook ? " (blackout off, normal content, dimmer 100%)" : "")); lastMCtl = mctl }

        // Fractal: a block of 24 zeros is an unpatched fixture (patched, ch 3-6 and 9 rest at 32768/128): OSC keeps it.
        let fdriven = raw[fb..<(fb + V0.fractalFootprint)].contains { $0 != 0 }
        let spRaw = f(V0.autoZoom), dRaw = f16(V0.depth)
        let stop = abs(spRaw - 128) <= 3
        var fctlRaw: Int? = nil, targetRaw: Int? = nil, palRaw: Int? = nil, typeDeb: Int? = nil, foldRaw: Int? = nil, trapRaw: Int? = nil
        if fdriven {
            if !fractalDriven {
                dType = Debounce(); dTarget = Debounce(); dPal = Debounce(); dFCtl = Debounce()
                lastFCtl = .idle
                depthConsole = stop; latchedDepth = dRaw
                log.append("Fractal block live (latest move wins per parameter)" + (stop ? " (depth: console)" : " (auto-zoom)"))
            }
            fctlRaw = dFCtl.feed(f(V0.fractalControl))
            if let v = fctlRaw { fctl = v0FractalControl(v) }
            if fctl != lastFCtl {
                if fctl == .reset { depthConsole = false; latchedDepth = dRaw; resetSeq += 1 }
                log.append("fractal control \(fctl.rawValue)" + (fctl == .reset ? " (depth 0; the next change on ch 7-8 takes the depth again)" : ""))
                lastFCtl = fctl
            }
            if fctl != .freezeZoom {
                if !stop {
                    if depthConsole { log.append(String(format: "auto-zoom %+.3f decades/s drives the depth", dmxZoomSpeed(spRaw))) }
                    depthConsole = false; latchedDepth = dRaw
                } else if !depthConsole && abs(dRaw - latchedDepth) > ltpBand16 {
                    depthConsole = true
                    log.append(String(format: "depth ch 7-8 changed: console controls the depth (%.2f)", v0Depth(dRaw)))
                }
            }
            typeDeb = dType.feed(f(V0.type)); if let v = typeDeb { typeRaw = v }
            foldRaw = dFold.feed(f(V0.power)); trapRaw = dTrap.feed(f(V0.colouring))
            targetRaw = dTarget.feed(f(V0.target))
            if let v = targetRaw { target = (1...zoomTargets.count).contains(v) ? v - 1 : nil }
            palRaw = dPal.feed(f(V0.palette))
            if let v = palRaw, let p = v0Palette(v) { palette = p }
            offX = v0Offset(f16(V0.offX)); offY = v0Offset(f16(V0.offY))
            depth = v0Depth(dRaw); speed = dmxZoomSpeed(spRaw)
            iter = v0Iterations(f16(V0.iter))
            palOffset = Double(f(V0.palOffset)) / 255
            palCycle = Double(f(V0.palCycle)) / 255 * 0.5
            rotation = Double(f(V0.rotation)) / 255 * 360
        } else if fractalDriven {
            log.append("Fractal block all zero (not patched?): DMX no longer drives the fractal")
        }
        fractalDriven = fdriven

        // Layers: a block of 16 zeros is an unpatched fixture (patched, ch 6-7 rest at 16384): OSC keeps it.
        struct LayerIn { var driven = false, bankRaw: Int? = nil, slotRaw: Int? = nil, blendRaw: Int? = nil, modeRaw: Int? = nil
                         var opacity = 0, speed16 = 0, trans = 0, restart = false
                         var command: ClipNav? = nil, apRaw: Int? = nil, apTime = 0, beatsRaw: Int? = nil
                         var srcRaw: Int? = nil, gtRaw: Int? = nil, count = 0 }
        var lin = [LayerIn](repeating: LayerIn(), count: layerCount)
        for li in 0..<layerCount {
            let b = V0.layerStart(li + 1) - 1
            func l(_ i: Int) -> Int { raw[b + i - 1] }
            let driven = raw[b..<(b + V0.layerFootprint)].contains { $0 != 0 }
            if driven != lay[li].driven {
                if driven { let r = lay[li].restarts, k = lay[li].commands; lay[li] = LayerDec(); lay[li].restarts = r; lay[li].commands = k; lay[li].lastCmd = -1 }
                log.append(driven ? "Layer \(li + 1) block live (DMX \(b + 1)-\(b + V0.layerFootprint), latest move wins per parameter)"
                                  : "Layer \(li + 1) block all zero (not patched?): DMX no longer drives layer \(li + 1)")
                lay[li].driven = driven
            }
            guard driven else { continue }
            var x = LayerIn(driven: true)
            x.bankRaw = lay[li].dBank.feed(l(V0.lBank)); if let v = x.bankRaw { lay[li].bank = v }
            x.slotRaw = lay[li].dSlot.feed(l(V0.lSlot)); if let v = x.slotRaw { lay[li].slot = v }
            x.blendRaw = lay[li].dBlend.feed(l(V0.lBlend)); if let v = x.blendRaw, let bm = v0LayerBlend(v) { lay[li].blend = bm }
            x.modeRaw = lay[li].dMode.feed(l(V0.lPlaymode)); if let v = x.modeRaw, let pm = v0LayerPlaymode(v) { lay[li].mode = pm }
            x.opacity = l(V0.lOpacity); x.speed16 = l(V0.lSpeed) << 8 | l(V0.lSpeed + 1); x.trans = l(V0.lTransition)
            let rh = l(V0.lRestart) > 127
            if rh && !lay[li].restartHigh { x.restart = true; lay[li].restarts += 1 }
            // ch 10: a command fires on entering its band (2-packet debounce); ch 11-13: autopilot
            if let v = lay[li].dCmd.feed(l(V0.lCommand)) {
                let band = v < 40 ? v / 10 : 0
                if band != lay[li].lastCmd {
                    if lay[li].lastCmd >= 0, band > 0, let op = v0ClipCommand(v) { x.command = op; lay[li].commands += 1 }   // -1: baseline
                    lay[li].lastCmd = band
                }
            }
            x.apRaw = lay[li].dAp.feed(l(V0.lAutopilot)); x.apTime = l(V0.lApTime); x.beatsRaw = lay[li].dBeats.feed(l(V0.lApBeats))
            x.srcRaw = lay[li].dSrc.feed(l(V0.lSource)); x.gtRaw = lay[li].dGT.feed(l(V0.lGenType)); x.count = l(V0.lGenCount)
            lay[li].restartHigh = rh
            lin[li] = x
        }
        let layDec = lay

        // Color 8 at 105: a block of 8 zeros is an unpatched fixture (patched, ch 1-3 rest at 255): OSC keeps it.
        let cb0 = V0.colorStart - 1
        func cc(_ i: Int) -> Int { raw[cb0 + i - 1] }
        let cdriven = raw[cb0..<(cb0 + V0.colorFootprint)].contains { $0 != 0 }
        if cdriven != colorDriven {
            if cdriven { dCTarget = Debounce(); dCMode = Debounce() }
            log.append(cdriven ? "Color block live (DMX 105-112, latest move wins)" : "Color block all zero (not patched?): DMX no longer drives the colour link")
            colorDriven = cdriven
        }
        let ctRaw = cdriven ? dCTarget.feed(cc(V0.cTarget)) : nil, cmRaw = cdriven ? dCMode.feed(cc(V0.cMode)) : nil

        // Layer FX 24 at 113 + 24 (n - 1): a block of 24 zeros is an unpatched fixture (patched, ch 1-7 rest at
        // 32768/128/32768 and ch 8 at 128): OSC keeps it.
        struct FXIn { var driven = false, x16 = 0, y16 = 0, scale = 0, rot16 = 0, spin = 0, tile: Int? = nil, gs = 0, gt = 0
                      var t1: Int? = nil, a1 = 0, s1 = 0, t2: Int? = nil, a2 = 0, s2 = 0
                      var mt: Int? = nil, ms: Int? = nil, mr: Int? = nil, md = 0, mst: Int? = nil, ma = 0, msp = 0 }
        var fin = [FXIn](repeating: FXIn(), count: layerCount)
        for li in 0..<layerCount {
            let b = V0.fxStart(li + 1) - 1
            func x(_ i: Int) -> Int { raw[b + i - 1] }
            let driven = raw[b..<(b + V0.fxFootprint)].contains { $0 != 0 }
            if driven != fxd[li].driven {
                if driven { fxd[li] = FXDec() }
                log.append(driven ? "Layer FX \(li + 1) block live (DMX \(b + 1)-\(b + V0.fxFootprint), latest move wins per group)"
                                  : "Layer FX \(li + 1) block all zero (not patched?): DMX no longer drives layer \(li + 1) motion / FX")
                fxd[li].driven = driven
            }
            guard driven else { continue }
            var f = FXIn(driven: true)
            f.x16 = x(V0.xPosX) << 8 | x(V0.xPosX + 1); f.y16 = x(V0.xPosY) << 8 | x(V0.xPosY + 1)
            f.scale = x(V0.xScale); f.rot16 = x(V0.xRot) << 8 | x(V0.xRot + 1); f.spin = x(V0.xSpin)
            f.tile = fxd[li].dTile.feed(x(V0.xTile))
            f.t1 = fxd[li].dT1.feed(x(V0.xFX1)); f.a1 = x(V0.xFX1 + 1); f.s1 = x(V0.xFX1 + 2)
            f.t2 = fxd[li].dT2.feed(x(V0.xFX2)); f.a2 = x(V0.xFX2 + 1); f.s2 = x(V0.xFX2 + 2)
            f.mt = fxd[li].dMT.feed(x(V0.xModTarget)); f.ms = fxd[li].dMS.feed(x(V0.xModShape)); f.mr = fxd[li].dMR.feed(x(V0.xModRate)); f.md = x(V0.xModDepth)
            if li == 0 { f.mst = fxd[li].dMst.feed(x(V0.xMaster)); f.ma = x(V0.xMaster + 1); f.msp = x(V0.xMaster + 2) }
            f.gs = x(V0.xGenSpeed); f.gt = x(V0.xGenThickness)
            fin[li] = f
        }

        let shownTarget = gStats.with { $0.fractal.targetIndex }   // read before gControl (lock order)
        let (fz, cons) = (fctl == .freezeZoom, depthConsole)
        let rs = resetSeq
        gControl.with { c in
            var taken: [String] = []
            c.dmx.smooth = true
            c.dmx.interval = interval
            if c.ltpDMX(.dimmer, [ltp.check("dimmer", m(V0.dimmer))], taken: &taken) { c.dimmer = dim }
            if c.ltpDMX(.effect_speed, [ltp.check("fxspeed", m(V0.effectSpeed))], taken: &taken) { c.effectSpeed = fxSpeed }
            let kb = ltp.check("bpm", bpmRaw, band: ltpBand16, zeroIsMode: true)
            if c.ltpDMX(.bpm, [kb, tapped ? .changed : .same], taken: &taken) {
                ltp.follow("bpm", bpmRaw)
                if bpm > 0 { c.bpm = bpm } else if tapped && tapBPM > 0 { c.bpm = tapBPM }
            }
            if resynced { c.resyncSeq += 1 }
            if columnFire > 0 {
                columnGoes += 1
                let done = c.columnGo(columnFire, owner: .dmx, lib: gLibrary)
                log.append("column \(columnFire) go: " + (done.isEmpty ? "no layer's bank has that slot" : done.joined(separator: ", ")))
            }
            if cdriven {
                let rgb = cc(V0.cR) << 16 | cc(V0.cG) << 8 | cc(V0.cB)
                if c.ltpLayerDMX("color.rgb", [ltp.check("color.rgb", rgb)], taken: &taken) {
                    c.color.r = Double(cc(V0.cR)) / 255; c.color.g = Double(cc(V0.cG)) / 255; c.color.b = Double(cc(V0.cB)) / 255
                }
                if c.ltpLayerDMX("color.amount", [ltp.check("color.amount", cc(V0.cAmount))], taken: &taken) { c.color.amount = Double(cc(V0.cAmount)) / 255 }
                if c.ltpLayerDMX("color.target", [ltp.check("color.target", ctRaw)], taken: &taken), let v = ctRaw, let t = v0ColorTarget(v), t != c.color.target {
                    c.color.target = t; log.append("colour target \(t.rawValue)")
                }
                if c.ltpLayerDMX("color.mode", [ltp.check("color.mode", cmRaw)], taken: &taken), let v = cmRaw, let md = v0ColorMode(v), md != c.color.mode {
                    c.color.mode = md; log.append("colour mode \(md.rawValue)")
                }
            }
            if c.ltpDMX(.content, [ltp.check("test", testRaw)], taken: &taken), testRaw != nil, test != c.content {
                log.append("content=\(test.rawValue)"); c.content = test
            }
            if c.ltpDMX(.master, [ltp.check("mctl", mctlRaw)], taken: &taken), mctlRaw != nil {
                c.blackout = false                                          // DMX holds the blackout now (LTP)
                c.dmx.blackout = mctl == .blackout
                c.dmx.freeze = mctl == .freeze
                c.dmx.safeLook = mctl == .safeLook
            }
            if fdriven {
                let kz = [ltp.check("depth", dRaw, band: ltpBand16), ltp.check("autozoom", spRaw), ltp.check("fctl", fctlRaw)]
                let dOwn = c.ltpDMX(.depth, kz, taken: &taken), zOwn = c.ltpDMX(.zoomspeed, kz, taken: &taken)
                if dOwn && zOwn {
                    ltp.follow("depth", dRaw)
                    c.zoomSpeed = fz || cons ? 0 : speed
                    c.dmx.depth = cons ? v0Depth(dRaw) : nil
                    c.dmx.freezeZoom = fz
                    c.dmx.resetSeq = rs
                } else {
                    c.dmx.depth = nil; c.dmx.freezeZoom = false
                }
                let kt = ltp.check("target", targetRaw)
                if c.ltpDMX(.target, [kt], taken: &taken), kt != .same, let ti = target, shownTarget != ti + 1 {
                    c.targetRequest = ti; c.centerRequest = nil
                    log.append("target \(ti + 1) \(zoomTargets[ti].name)" + c.switchShape(to: ti))
                }
                if c.ltpDMX(.palette, [ltp.check("palette", palRaw)], taken: &taken), let p = palette, p != c.palette {
                    log.append("palette=\(p) \(paletteNames[p])"); c.palette = p
                }
                if c.ltpDMX(.palette_offset, [ltp.check("paloffset", f(V0.palOffset))], taken: &taken) { c.paletteOffset = palOffset }
                if c.ltpDMX(.palette_speed, [ltp.check("palcycle", f(V0.palCycle))], taken: &taken) { c.paletteSpeed = palCycle }
                if c.ltpDMX(.rotation, [ltp.check("rotation", f(V0.rotation))], taken: &taken) { c.rotation = rotation }
                let kspin = ltp.check("spin", f(V0.spin))                       // 0 = keep (an older patch leaves it at 0)
                if let sv = v0Bipolar(f(V0.spin), max: 2), c.ltpDMX(.spin, [kspin], taken: &taken) { c.fractalSpin = sv }
                let ox = f16(V0.offX), oy = f16(V0.offY)
                if c.ltpDMX(.offsets, [ltp.check("offx", ox, band: ltpBand16), ltp.check("offy", oy, band: ltpBand16)], taken: &taken) {
                    ltp.follow("offx", ox); ltp.follow("offy", oy)
                    c.offsetX = offX; c.offsetY = offY
                }
                let ir = f16(V0.iter)
                if c.ltpDMX(.iterations, [ltp.check("iter", ir, band: ltpBand16, zeroIsMode: true)], taken: &taken) {
                    ltp.follow("iter", ir); c.iterOverride = iter
                }
                // v0.6 formula modifiers (owner keys fractal.*; latest move wins like the layer keys)
                if c.ltpLayerDMX("fractal.formula", [ltp.check("formula", typeDeb)], taken: &taken), let v = typeDeb, let fo = v0Formula(v), fo != c.frac.formula {
                    c.frac.formula = fo; c.frac.preset = ""; log.append("formula \(fo.name)")
                }
                if c.ltpLayerDMX("fractal.fold", [ltp.check("fold", foldRaw)], taken: &taken), let v = foldRaw, let fd = v0Fold(v),
                   fd.n != c.frac.fold || fd.mirror != c.frac.foldMirror {
                    c.frac.fold = fd.n; c.frac.foldMirror = fd.mirror; c.frac.preset = ""
                    log.append(fd.n == 0 ? "kaleido fold off" : "kaleido fold \(fd.n)" + (fd.mirror ? " mirror" : ""))
                }
                if c.ltpLayerDMX("fractal.trap", [ltp.check("trap", trapRaw)], taken: &taken), let v = trapRaw, let tr = v0Trap(v), tr != c.frac.trap {
                    c.frac.trap = tr; c.frac.preset = ""; log.append("orbit trap \(tr.rawValue)")
                }
                if c.ltpLayerDMX("fractal.julia", [ltp.check("julia", f(V0.audio))], taken: &taken) { c.frac.julia = Double(f(V0.audio)) / 255 }
                let jre = f16(V0.juliaRe), jim = f16(V0.juliaIm)
                if c.ltpLayerDMX("fractal.juliac", [ltp.check("juliare", jre, band: ltpBand16), ltp.check("juliaim", jim, band: ltpBand16)], taken: &taken) {
                    ltp.follow("juliare", jre); ltp.follow("juliaim", jim)
                    if let v = v0JuliaC(jre) { c.frac.juliaRe = v }
                    if let v = v0JuliaC(jim) { c.frac.juliaIm = v }
                }
                let lb = fctlRaw.flatMap { v0Loop($0) }
                if c.ltpLayerDMX("fractal.loop", [ltp.check("loop", fctlRaw.map { $0 < 30 ? 0 : min(7, $0 / 10) })], taken: &taken), let lbv = lb,
                   lbv.0 != c.frac.loop || (lbv.1 != nil && lbv.1! != c.frac.loopNext) {
                    let lm = lbv.0
                    c.frac.loop = lm; if let n = lbv.1 { c.frac.loopNext = n }
                    log.append("loop \(lm.rawValue)" + (lm == .dive ? " (\(c.frac.loopNext.rawValue))" : ""))
                }
            } else {
                c.dmx.depth = nil
                c.dmx.freezeZoom = false
            }
            for li in 0..<layerCount where lin[li].driven {
                let x = lin[li], d = layDec[li], n = li + 1, k = "layer\(n)."
                func lk(_ p: String) -> String { k + p }
                if c.ltpLayerDMX(lk("opacity"), [ltp.check(lk("opacity"), x.opacity)], taken: &taken) { c.layers[li].opacity = Double(x.opacity) / 255 }
                if c.ltpLayerDMX(lk("blend"), [ltp.check(lk("blend"), x.blendRaw)], taken: &taken), x.blendRaw != nil, let bm = d.blend, bm != c.layers[li].blend {
                    c.layers[li].blend = bm; log.append("layer \(n) blend \(bm.name)")
                }
                if c.ltpLayerDMX(lk("playmode"), [ltp.check(lk("playmode"), x.modeRaw)], taken: &taken), x.modeRaw != nil, let pm = d.mode, pm != c.layers[li].playmode {
                    c.layers[li].playmode = pm; log.append("layer \(n) playmode " + (pm == .loop ? "loop" : "once + hold"))
                }
                if c.ltpLayerDMX(lk("speed"), [ltp.check(lk("speed"), x.speed16, band: ltpBand16)], taken: &taken) {
                    ltp.follow(lk("speed"), x.speed16); c.layers[li].speed = min(4, v0LayerSpeed(x.speed16))
                }
                if c.ltpLayerDMX(lk("transition"), [ltp.check(lk("transition"), x.trans)], taken: &taken) { c.layers[li].transition = v0LayerTransition(x.trans) }
                // autopilot: ch 11 mode, ch 12 interval (0 = per beats), ch 13 beats
                let kap = [ltp.check(lk("ap"), x.apRaw), ltp.check(lk("aptime"), x.apTime), ltp.check(lk("apbeats"), x.beatsRaw)]
                if c.ltpLayerDMX(lk("autopilot"), kap, taken: &taken) {
                    let old = (c.layers[li].autopilot, c.layers[li].apEvery, c.layers[li].apBeats)
                    if let v = x.apRaw, let a = v0Autopilot(v) { c.layers[li].autopilot = a }
                    c.layers[li].apEvery = Double(x.apTime)
                    if let v = x.beatsRaw, let b = v0ApBeats(v) { c.layers[li].apBeats = b }
                    let nw = (c.layers[li].autopilot, c.layers[li].apEvery, c.layers[li].apBeats)
                    if nw != old && kap.contains(.changed) {
                        log.append("layer \(n) autopilot \(nw.0.rawValue)" + (nw.0 == .off ? "" : nw.1 > 0 ? " every \(Int(nw.1)) s" : " every \(Int(nw.2)) beats"))
                    }
                }
                // ch 14-16: source (latest move wins for the one fractal), generator type, count (0 = keep)
                let ksrc = ltp.check(lk("source"), x.srcRaw)
                if c.ltpLayerDMX(lk("source"), [ksrc], taken: &taken), let v = x.srcRaw, let sv = v0Source(v),
                   sv != c.layers[li].source || (sv == .fractal && c.fractalLayer != n && ksrc == .changed) {
                    log.append(c.setSource(li, sv))
                }
                // source NDI (v0.10): ch 3 (slot) picks the n-th source of the stable list (status ndi_sources; ndi_order.json pins)
                if c.layers[li].source == .ndi, let sv = x.slotRaw {
                    let kn = ltp.check(lk("ndislot"), sv)
                    if c.ltpLayerDMX(lk("ndi"), [kn, ksrc], taken: &taken), kn != .same || ksrc == .changed {
                        let nm = sv == 0 ? "" : gNDIIn.nameForSlot(sv)
                        if nm != c.layers[li].ndiName {
                            c.layers[li].ndiName = nm
                            log.append("layer \(n) NDI slot \(sv)" + (sv == 0 ? " (none)" : nm.isEmpty ? " (no source in that slot)" : " '\(nm)'"))
                        }
                    }
                }
                if c.ltpLayerDMX(lk("gen.type"), [ltp.check(lk("gen.type"), x.gtRaw)], taken: &taken), let v = x.gtRaw, let gt = v0GenType(v), gt != c.layers[li].gen.type {
                    c.layers[li].gen.type = gt; c.layers[li].genLook = ""; log.append("layer \(n) generator \(gt.name)")
                }
                let kcnt = ltp.check(lk("gen.count"), x.count)
                if let v = v0Unit(x.count), c.ltpLayerDMX(lk("gen.count"), [kcnt], taken: &taken) {
                    if c.layers[li].gen.count != v { c.layers[li].genLook = "" }       // the console moved a gen param: the gen look is no longer "on"
                    c.layers[li].gen.count = v
                }
                if let op = x.command {
                    let r = c.navLayer(li, op, owner: .dmx, lib: gLibrary)
                    log.append("layer \(n) \(op.rawValue): " + (r ?? "bank has no clips"))
                }
                // clip: a bank or slot change plays (bank 0 or slot 0 = clear) with the layer's transition; restart replays
                let kb = ltp.check(lk("bank"), x.bankRaw), ks = ltp.check(lk("slot"), x.slotRaw)
                let moved = kb != .same || ks != .same
                guard c.ltpLayerDMX(lk("clip"), [kb, ks, x.restart ? .changed : .same], taken: &taken) else { continue }
                if moved, x.bankRaw != nil, x.slotRaw != nil {
                    if d.bank == 0 || d.slot == 0 {
                        if c.layers[li].slot != 0 { c.layers[li].slot = 0; c.layers[li].playSeq += 1; log.append("layer \(n) clear") }
                    } else if let clip = gLibrary.clip(bank: d.bank, slot: d.slot) {
                        if kb == .baseline && ks == .baseline && c.layers[li].bank == d.bank && c.layers[li].slot == d.slot { continue }   // already playing it
                        c.layers[li].bank = d.bank; c.layers[li].slot = d.slot; c.layers[li].playSeq += 1
                        log.append("layer \(n) play bank \(d.bank) slot \(d.slot) '\(clip.name)'" + (c.layers[li].transition > 0 ? String(format: " (transition %.2f s)", c.layers[li].transition) : ""))
                    } else {
                        log.append("layer \(n) bank \(d.bank) slot \(d.slot): not in the library (ignored)")
                    }
                } else if x.restart {
                    if c.layers[li].slot != 0 { c.layers[li].playSeq += 1; log.append("layer \(n) restart (restart \(d.restarts))") }
                }
            }
            for li in 0..<layerCount where fin[li].driven {
                let f = fin[li], n = li + 1, k = "layer\(n)."
                func lk(_ p: String) -> String { k + p }
                if c.ltpLayerDMX(lk("pos"), [ltp.check(lk("fx.x"), f.x16, band: ltpBand16), ltp.check(lk("fx.y"), f.y16, band: ltpBand16)], taken: &taken) {
                    ltp.follow(lk("fx.x"), f.x16); ltp.follow(lk("fx.y"), f.y16)
                    c.layers[li].fx.x = v0Offset(f.x16); c.layers[li].fx.y = v0Offset(f.y16)
                }
                if c.ltpLayerDMX(lk("scale"), [ltp.check(lk("fx.scale"), f.scale)], taken: &taken) { c.layers[li].fx.scale = v0FXScale(f.scale) }
                if c.ltpLayerDMX(lk("rotation"), [ltp.check(lk("fx.rot"), f.rot16, band: ltpBand16)], taken: &taken) {
                    ltp.follow(lk("fx.rot"), f.rot16); c.layers[li].fx.rotation = v0FXRotation(f.rot16)
                }
                if c.ltpLayerDMX(lk("spin"), [ltp.check(lk("fx.spin"), f.spin)], taken: &taken) { c.layers[li].fx.spin = v0FXSpin(f.spin) }
                if c.ltpLayerDMX(lk("tile"), [ltp.check(lk("fx.tile"), f.tile)], taken: &taken), let v = f.tile, let tl = v0FXTile(v) {
                    let o = c.layers[li].fx
                    c.layers[li].fx.flipX = tl.flipX; c.layers[li].fx.flipY = tl.flipY; c.layers[li].fx.tile = tl.tile; c.layers[li].fx.mirror = tl.mirror
                    if o.tile != tl.tile || o.mirror != tl.mirror || o.flipX != tl.flipX || o.flipY != tl.flipY { log.append("layer \(n) flip / tile: \(fxTileSetName(v / 4))") }
                }
                for (s, t, a, sp) in [(0, f.t1, f.a1, f.s1), (1, f.t2, f.a2, f.s2)] {
                    let key = lk("fx\(s + 1)")
                    let kk = [ltp.check(key + ".type", t), ltp.check(key + ".amount", a), ltp.check(key + ".speed", sp)]
                    guard c.ltpLayerDMX(key, kk, taken: &taken) else { continue }
                    let was = c.layers[li].fx.fx[s]
                    if let v = t, let ty = v0FXType(v), ty != c.layers[li].fx.fx[s].type { c.layers[li].fx.fx[s].type = ty; log.append("layer \(n) FX\(s + 1) \(ty.name)") }
                    c.layers[li].fx.fx[s].amount = Double(a) / 255; c.layers[li].fx.fx[s].speed = v0FXSpeed(sp)
                    if c.layers[li].fx.fx[s] != was { c.layers[li].fx.look = "" }    // the console moved a slot: the FX look is no longer "on"
                }
                let km = [ltp.check(lk("mod.target"), f.mt), ltp.check(lk("mod.shape"), f.ms), ltp.check(lk("mod.rate"), f.mr), ltp.check(lk("mod.depth"), f.md)]
                if c.ltpLayerDMX(lk("mod"), km, taken: &taken) {
                    let o = c.layers[li].fx
                    if let v = f.mt, let t = v0ModTarget(v) { c.layers[li].fx.modTarget = t }
                    if let v = f.ms, let s = v0ModShape(v) { c.layers[li].fx.modShape = s }
                    if let v = f.mr, let r = v0ModRate(v) { c.layers[li].fx.modBeats = r }
                    c.layers[li].fx.modDepth = Double(f.md) / 255
                    let nw = c.layers[li].fx
                    if nw.modTarget != o.modTarget || nw.modShape != o.modShape || nw.modBeats != o.modBeats {
                        log.append("layer \(n) beat mod \(nw.modTarget.name) \(nw.modShape.name) every \(modBeatName(nw.modBeats))")
                    }
                }
                let kgs = ltp.check(lk("gen.speed"), f.gs), kgt = ltp.check(lk("gen.thickness"), f.gt)
                if let v = v0Bipolar(f.gs, max: 1), c.ltpLayerDMX(lk("gen.speed"), [kgs], taken: &taken) {
                    if c.layers[li].gen.speed != v { c.layers[li].genLook = "" }
                    c.layers[li].gen.speed = v
                }
                if let v = v0Unit(f.gt), c.ltpLayerDMX(lk("gen.thickness"), [kgt], taken: &taken) {
                    if c.layers[li].gen.thickness != v { c.layers[li].genLook = "" }
                    c.layers[li].gen.thickness = v
                }
                if li == 0 {
                    let kk = [ltp.check("master.fx.type", f.mst), ltp.check("master.fx.amount", f.ma), ltp.check("master.fx.speed", f.msp)]
                    if c.ltpLayerDMX("master.fx", kk, taken: &taken) {
                        if let v = f.mst, let ty = v0FXType(v), ty != c.masterFX.type { c.masterFX.type = ty; log.append("master FX \(ty.name)") }
                        c.masterFX.amount = Double(f.ma) / 255; c.masterFX.speed = v0FXSpeed(f.msp)
                    }
                }
            }
            if !taken.isEmpty { log.append("DMX retakes " + taken.joined(separator: ", ") + " (console moved)") }
        }
        if sceneFire > 0 {                                    // outside the gControl lock (the recall takes it)
            sceneGoes += 1
            log.append(gScenes.go(sceneFire, fade: sceneFadeRaw == 0 ? nil : Double(sceneFadeRaw) / 10, from: "DMX ch 9"))
        }
        return log
    }

    func statusMaster() -> [String: Any] {
        func r3(_ v: Double) -> Double { (v * 1000).rounded() / 1000 }
        return ["dimmer": r3(Double(raw[V0.masterStart - 1 + V0.dimmer - 1]) / 255), "bpm": r3(bpm), "tap_count": tapCount,
                "tap_bpm": r3(tapBPM), "resync_count": resyncCount, "test_content": test.rawValue, "control": mctl.rawValue,
                "effect_speed": r3(fxSpeed), "column": max(0, lastColumn), "column_goes": columnGoes,
                "scene": max(0, lastScene), "scene_goes": sceneGoes, "scene_fade_raw": raw[V0.masterStart - 1 + V0.fx1 - 1],
                "reserved_raw": Array(raw[(V0.masterStart - 1 + V0.crossfade - 1)...(V0.masterStart - 1 + V0.fx1 + 2)])]
    }

    func statusLayers() -> [[String: Any]] {
        (0..<layerCount).map { li in
            let b = V0.layerStart(li + 1) - 1, d = lay[li]
            return ["layer": li + 1, "address": b + 1, "driven": d.driven, "bank": d.bank, "slot": d.slot,
                    "blend": d.blend?.name ?? "(not set yet)", "playmode": d.mode?.rawValue ?? "(not set yet)", "restarts": d.restarts,
                    "commands": d.commands,
                    "raw": Array(raw[b..<(b + V0.layerFootprint)])]
        }
    }

    func statusLayerFX() -> [[String: Any]] {
        (0..<layerCount).map { li in
            let b = V0.fxStart(li + 1) - 1
            return ["layer": li + 1, "address": b + 1, "driven": fxd[li].driven, "raw": Array(raw[b..<(b + V0.fxFootprint)])]
        }
    }

    func statusColor() -> [String: Any] {
        let b = V0.colorStart - 1
        return ["address": V0.colorStart, "driven": colorDriven, "raw": Array(raw[b..<(b + V0.colorFootprint)])]
    }

    func statusFractal() -> [String: Any] {
        func r4(_ v: Double) -> Double { (v * 10000).rounded() / 10000 }
        let depthOwner = gControl.with { $0.owner(.depth) }
        let mode: String = !fractalDriven ? "osc (block all zero)" : depthOwner == .osc ? "osc (GUI moved it; the next change on ch 7-8, 9 or 24 takes it back)" : (fctl == .freezeZoom ? "frozen" : (depthConsole ? "console" : (speed != 0 ? "auto-zoom" : "held (auto-zoom stopped; the next change on ch 7-8 takes it)")))
        let fb = V0.fractalStart - 1
        return ["driven": fractalDriven, "type": v0Formula(typeRaw)?.name ?? "reserved (\(typeRaw)): keep",
                "fold_raw": raw[fb + V0.power - 1], "trap_raw": raw[fb + V0.colouring - 1], "julia_raw": raw[fb + V0.audio - 1],
                "julia_c_raw": Array(raw[(fb + V0.juliaRe - 1)...(fb + V0.juliaIm)]),
                "target": target.map { zoomTargets[$0].name } ?? "free (keep)", "offset_x": r4(offX), "offset_y": r4(offY),
                "depth": r4(depth), "depth_control": mode, "auto_zoom_speed": r4(speed),
                "iterations": iter == 0 ? "auto" : "\(iter)", "palette": palette ?? 0,
                "palette_name": palette.map { paletteNames[$0] } ?? "(not set yet)",
                "palette_offset": r4(palOffset), "palette_cycle": r4(palCycle), "rotation_deg": r4(rotation),
                "control": fctl.rawValue,

                "spin_raw": raw[fb + V0.spin - 1], "spin_turns_s": (v0Bipolar(raw[fb + V0.spin - 1], max: 2).map { r4($0) as Any }) ?? ("keep (0)" as Any)]
    }
}

/// Render-loop glide for one DMX value: linear from what is shown to the newest DMX value over one packet
/// interval (PLAN 10: MA3 sends <= 30 Hz, the render runs at 60). wrap > 0: a cyclic value (rotation 360,
/// palette offset 1) takes the short way round. Not smooth (OSC, m0 map, no DMX): the value is used as it is.
struct Glide {
    let wrap: Double
    private var goal = Double.nan, from = 0.0, to = 0.0, t0 = 0.0, dur = 0.0
    private(set) var cur = 0.0
    init(wrap: Double = 0) { self.wrap = wrap }
    mutating func set(_ v: Double) { goal = v; from = v; to = v; cur = v; dur = 0 }
    mutating func step(_ v: Double, t: Double, start: Double, dur d: Double, smooth: Bool) -> Double {
        if !smooth || goal.isNaN { set(v); return v }
        if v != goal {
            goal = v; from = cur
            var delta = v - cur
            if wrap > 0 { delta = remainder(delta, wrap) }
            to = cur + delta; t0 = start; dur = d
        }
        let k = dur > 0 ? min(1, max(0, (t - t0) / dur)) : 1
        cur = from + (to - from) * k
        if k >= 1 { cur = goal; from = goal; to = goal }
        return cur
    }
}

// MARK: - self test (`oats-m0 --selftest-dmx`): crafted v0 packets through V0Decoder, no network

func dmxSelfTest(mediaDir: String) -> Int32 {
    gLibrary = Library(dir: mediaDir, quiet: true)
    let dec = V0Decoder()
    var pk = [UInt8](repeating: 0, count: 512)
    var fails = 0, checks = 0
    func feed(_ times: Int = 2) { for _ in 0..<times { for l in dec.apply(pk[...], now: nowTicks()) { print("    DMX -> " + l) } } }
    func expect(_ what: String, _ ok: Bool) { checks += 1; if !ok { fails += 1 }; print((ok ? "  ok   " : "  FAIL ") + what) }
    func L(_ n: Int, _ ch: Int, _ v: Int) { pk[V0.layerStart(n) - 1 + ch - 1] = UInt8(v) }
    func lay(_ i: Int) -> LayerCtl { gControl.with { $0.layers[i] } }
    func own(_ k: String) -> Owner { gControl.with { $0.layerOwners[k] ?? .none } }
    print("library \(mediaDir): \(gLibrary.banks.map { "bank \($0.bank) \($0.name) \($0.clips.count)" }.joined(separator: ", "))" + (gLibrary.error.isEmpty ? "" : " (\(gLibrary.error))"))
    let haveClip = gLibrary.clip(bank: 1, slot: 2) != nil

    print("1. Layer 1 at 41: opacity 128, bank 1, slot 2, blend Screen, once, speed 16384, transition 51 (2 s); layers 2-4 all zero")
    L(1, V0.lOpacity, 128); L(1, V0.lBank, 1); L(1, V0.lSlot, 2); L(1, V0.lBlend, 25); L(1, V0.lPlaymode, 12)
    L(1, V0.lSpeed, 0x40); L(1, V0.lSpeed + 1, 0); L(1, V0.lTransition, 51)
    feed(1)
    expect("after 1 packet: opacity applied at once (0.502), clip waits for the debounce", abs(lay(0).opacity - 128.0 / 255) < 1e-9 && lay(0).playSeq == 0)
    feed(1)
    let l0 = lay(0)
    expect("after 2 packets: bank 1 slot 2 playing (playSeq 1)", !haveClip || (l0.bank == 1 && l0.slot == 2 && l0.playSeq == 1))
    expect("blend Screen, playmode once, speed 1.0, transition 2.0 s", l0.blend == .screen && l0.playmode == .once && abs(l0.speed - 1) < 1e-9 && abs(l0.transition - 2) < 1e-9)
    expect("owners layer1.opacity/clip/blend/playmode/speed/transition = dmx", ["opacity", "clip", "blend", "playmode", "speed", "transition"].allSatisfy { own("layer1." + $0) == .dmx })
    expect("layer 2 (all zero) untouched: default control, no owner", lay(1).opacity == 1 && lay(1).playSeq == 0 && own("layer2.opacity") == .none)
    feed(3)
    expect("repeated identical packets: no re-trigger", !haveClip || lay(0).playSeq == 1)

    print("2. OSC takes layer1.opacity (0.9), console repeats; then the console moves ch 41")
    gControl.with { c in c.layerOwners["layer1.opacity"] = .osc; c.layers[0].opacity = 0.9 }
    feed(3)
    expect("unchanged DMX keeps the OSC opacity 0.9", lay(0).opacity == 0.9 && own("layer1.opacity") == .osc)
    L(1, V0.lOpacity, 200); feed(1)
    expect("ch 41 moved: DMX retakes opacity (200/255)", abs(lay(0).opacity - 200.0 / 255) < 1e-9 && own("layer1.opacity") == .dmx)

    print("3. Restart ch 49: rising edge above 127")
    let s0 = lay(0).playSeq
    L(1, V0.lRestart, 255); feed(3)
    expect("one restart for one edge (playSeq +1)", !haveClip || lay(0).playSeq == s0 + 1)
    L(1, V0.lRestart, 0); feed(2)

    print("4. One-packet glitch on slot (3) then back to 2: no play")
    let s1 = lay(0).playSeq
    L(1, V0.lSlot, 3); feed(1); L(1, V0.lSlot, 2); feed(2)
    expect("debounce: playSeq unchanged", lay(0).playSeq == s1)

    print("5. Speed 0xC000 (3.0x), transition 255 (10 s), blend 75 (Overlay), blend 200 (reserved: keep)")
    L(1, V0.lSpeed, 0xC0); L(1, V0.lTransition, 255); L(1, V0.lBlend, 75); feed(2)
    expect("speed 3.0, transition 10 s, Overlay", abs(lay(0).speed - 3) < 1e-9 && abs(lay(0).transition - 10) < 1e-9 && lay(0).blend == .overlay)
    L(1, V0.lBlend, 200); feed(2)
    expect("reserved blend keeps Overlay", lay(0).blend == .overlay)

    print("6. Bank 200 (not in the library), then slot 0 (clear)")
    let s2 = lay(0).playSeq
    L(1, V0.lBank, 200); feed(2)
    expect("unknown bank ignored (still bank 1, no trigger)", lay(0).playSeq == s2 && lay(0).bank == 1)
    L(1, V0.lBank, 1); L(1, V0.lSlot, 0); feed(2)
    expect("slot 0 clears the layer", !haveClip || (lay(0).slot == 0 && lay(0).playSeq == s2 + 1))

    print("7. Layer 4 at 89 live: bank 2 slot 1, opacity 255")
    L(4, V0.lOpacity, 255); L(4, V0.lBank, 2); L(4, V0.lSlot, 1); L(4, V0.lSpeed, 0x40); feed(2)
    let l3 = lay(3)
    expect("layer 4 plays bank 2 slot 1 at opacity 1", (gLibrary.clip(bank: 2, slot: 1) == nil || (l3.bank == 2 && l3.slot == 1 && l3.playSeq == 1)) && l3.opacity == 1)
    expect("status dmx.layers: layer 4 address 89 driven", (dec.statusLayers()[3]["address"] as? Int) == 89 && (dec.statusLayers()[3]["driven"] as? Bool) == true)

    print("8. --dmx-table has Master 16, Fractal 24, Layer 16, Color 8, Layer FX 24")
    let tj = (try? JSONSerialization.jsonObject(with: Data(dmxTableJSON(gLibrary).utf8))) as? [String: Any]
    let names = (tj?["modes"] as? [[String: Any]])?.compactMap { $0["name"] as? String } ?? []
    expect("modes \(names)", names == ["Master 16", "Fractal 24", "Layer 16", "Color 8", "Layer FX 24"])
    let fxm = (tj?["modes"] as? [[String: Any]])?.first { $0["name"] as? String == "Layer FX 24" }
    expect("Layer FX 24 at 113, footprint 24, 21 channel entries", fxm?["start"] as? Int == 113 && fxm?["footprint"] as? Int == 24 && (fxm?["channels"] as? [Any])?.count == 21)

    print("9. Layer 4 ch 10 command: next (band 10-19) fires once on entry; autopilot ch 11 shuffle, ch 12 0, ch 13 band 8 beats")
    let n4 = gLibrary.slotNumbers(bank: 2).count
    let q0 = lay(3).playSeq
    L(4, V0.lCommand, 15); feed(3)
    expect("one next for one band entry", n4 < 2 || lay(3).playSeq == q0 + 1)
    L(4, V0.lCommand, 0); feed(2); L(4, V0.lCommand, 25); feed(2)
    expect("previous fires on entering 20-29", n4 < 2 || lay(3).playSeq == q0 + 2)
    L(4, V0.lAutopilot, 22); L(4, V0.lApBeats, 35); feed(2)
    expect("autopilot shuffle, every 8 beats", lay(3).autopilot == .shuffle && lay(3).apEvery == 0 && lay(3).apBeats == 8)
    L(4, V0.lApTime, 3); feed(2)
    expect("ch 12 = 3: every 3 s", lay(3).apEvery == 3)

    print("10. Master ch 8 column: baseline 0, then 1 -> column 1 go")
    let c0 = lay(0).playSeq, c3 = lay(3).playSeq
    pk[V0.column - 1] = 1; feed(2)
    expect("column 1 plays slot 1 on layers with a slot 1", gLibrary.clip(bank: 2, slot: 1) == nil || (lay(3).slot == 1 && lay(3).playSeq == c3 + 1 && lay(0).playSeq >= c0))
    pk[V0.column - 1] = 0; feed(2)

    print("11. Color 8 at 105: 255,0,0 amount 255, target clips (15), mode replace (25)")
    for (i, v) in [255, 0, 0, 255, 15, 25].enumerated() { pk[V0.colorStart - 1 + i] = UInt8(v) }
    feed(2)
    let col = gControl.with { $0.color }
    expect("colour link red, amount 1, clips, replace", col.r == 1 && col.g == 0 && col.amount == 1 && col.target == .clips && col.mode == .replace)

    print("12. Layer FX 1 at 113 all zero: ignored; then patched at neutral defaults (32768/128/32768/128, speeds 128)")
    func X(_ n: Int, _ ch: Int, _ v: Int) { pk[V0.fxStart(n) - 1 + ch - 1] = UInt8(v) }
    func lfx(_ i: Int) -> LayerFX { gControl.with { $0.layers[i].fx } }
    feed(2)
    expect("all-zero Layer FX block: layer 1 fx neutral, no owner", lfx(0).neutral && own("layer1.pos") == .none)
    X(1, V0.xPosX, 128); X(1, V0.xPosY, 128); X(1, V0.xScale, 128); X(1, V0.xRot, 128); X(1, V0.xSpin, 128)
    X(1, V0.xFX1 + 2, 128); X(1, V0.xFX2 + 2, 128); X(1, V0.xMaster + 2, 128)
    feed(2)
    let n0 = lfx(0)
    expect("neutral defaults: centre, 1x, 0 deg, spin stop, no FX, no mod", n0.neutral && abs(n0.scale - 1) < 1e-9 && n0.x == 0 && n0.rotation == 0 && n0.spin == 0)
    expect("FX speeds 128 = 0.5, master FX None", abs(n0.fx[0].speed - 0.5) < 1e-9 && gControl.with { $0.masterFX.type } == .none)
    print("13. pos X 0xC000 (+0.5), scale 255 (4x), rotation 0x4000 (-90), spin 255 (+2), tile band Mirror 3 Flip H (idx 24 -> 96)")
    X(1, V0.xPosX, 0xC0); X(1, V0.xScale, 255); X(1, V0.xRot, 0x40); X(1, V0.xSpin, 255); X(1, V0.xTile, 96)
    feed(2)
    let n1 = lfx(0)
    expect("x 0.5, scale 4, rotation -90, spin 2", abs(n1.x - 0.5) < 1e-9 && abs(n1.scale - 4) < 1e-9 && abs(n1.rotation + 90) < 1e-9 && abs(n1.spin - 2) < 1e-9)
    expect("tile 3 mirror, flip H only (\(fxTileSetName(24)))", n1.tile == 3 && n1.mirror && n1.flipX && !n1.flipY)
    expect("owners layer1.pos/scale/rotation/spin/tile = dmx", ["pos", "scale", "rotation", "spin", "tile"].allSatisfy { own("layer1." + $0) == .dmx })
    print("14. FX1 Kaleido (10) amount 179, FX2 Trails (170) amount 255 speed 0; mod Scale (20) Saw (10) 1 beat (20) depth 255")
    X(1, V0.xFX1, 10); X(1, V0.xFX1 + 1, 179); X(1, V0.xFX2, 170); X(1, V0.xFX2 + 1, 255); X(1, V0.xFX2 + 2, 0)
    X(1, V0.xModTarget, 20); X(1, V0.xModShape, 10); X(1, V0.xModRate, 20); X(1, V0.xModDepth, 255)
    feed(2)
    let n2 = lfx(0)
    expect("FX1 Kaleido 0.70, FX2 Trails 1.0 stopped", n2.fx[0].type == .kaleido && abs(n2.fx[0].amount - 179.0 / 255) < 1e-9 && n2.fx[1].type == .trails && n2.fx[1].amount == 1 && n2.fx[1].speed == 0)
    expect("mod scale saw every 1 beat depth 1", n2.modTarget == .scale && n2.modShape == .saw && n2.modBeats == 1 && n2.modDepth == 1)
    print("15. Master FX on Layer FX 1 ch 20-22: Invert (90) 255; the same on Layer FX 2 is ignored")
    X(1, V0.xMaster, 90); X(1, V0.xMaster + 1, 255); X(2, V0.xPosX, 128); X(2, V0.xMaster, 30); X(2, V0.xMaster + 1, 100)
    feed(2)
    let mf = gControl.with { $0.masterFX }
    expect("master FX Invert 1.0 from Layer FX 1", mf.type == .invert && mf.amount == 1 && own("master.fx") == .dmx)
    print("16. OSC takes layer1.fx1 (Ripple), console repeats: kept; reserved FX type 200 keeps the type")
    gControl.with { c in c.layerOwners["layer1.fx1"] = .osc; c.layers[0].fx.fx[0].type = .ripple }
    feed(3)
    expect("unchanged DMX keeps the OSC FX1 Ripple", lfx(0).fx[0].type == .ripple)
    X(1, V0.xFX1, 230); feed(2)
    expect("ch 122 moved to reserved (230): DMX retakes fx1 but keeps the type", own("layer1.fx1") == .dmx && lfx(0).fx[0].type == .ripple)
    X(1, V0.xFX1, 180); X(1, V0.xFX2, 205); X(1, V0.xMaster, 190); feed(2)
    expect("appended bands: 180 StarTrails, 205 SpiralTrails, master 190 WarpTrails",
           lfx(0).fx[0].type == .starTrails && lfx(0).fx[1].type == .spiralTrails && gControl.with { $0.masterFX.type } == .warpTrails)
    let le = FXRuntime.longExposure(.starTrails, amount: 1, speed: 1, dt: 1)
    expect("StarTrails amount 1 / speed 1: hold forever (fade 1, 2026-10-23 stepped stamping), 90 deg/s clockwise", le.y == 1 && abs(Double(le.z) - .pi / 2) < 1e-6)
    expect("StarTrails speed 0.5 is still", FXRuntime.longExposure(.starTrails, amount: 0.5, speed: 0.5, dt: 1 / 60.0).z == 0)
    X(1, V0.xFX1, 0); X(1, V0.xFX2, 0); X(1, V0.xMaster, 0); feed(2)
    print("17. LFO: sine 1 at the beat, saw falls, square, random steady within a cycle; presets file")
    expect("sine(0) = 1, sine(0.5) = 0", abs(FXRuntime.lfo(.sine, beat: 0, beats: 1) - 1) < 1e-9 && abs(FXRuntime.lfo(.sine, beat: 0.5, beats: 1)) < 1e-9)
    expect("saw(0.25 of 1) = 0.75, square(0.6 of 1) = 0", abs(FXRuntime.lfo(.saw, beat: 0.25, beats: 1) - 0.75) < 1e-9 && FXRuntime.lfo(.square, beat: 0.6, beats: 1) == 0)
    expect("random step holds inside a cycle", FXRuntime.lfo(.random, beat: 4.1, beats: 2) == FXRuntime.lfo(.random, beat: 5.9, beats: 2))
    let pl = FXPresets.shared.load()
    expect("fx_presets.json: \(pl)", FXPresets.shared.names.count >= 12 && FXPresets.shared.find("kaleido bloom") != nil)
    print("18. Layer sources: Layer 2 ch 14 = 15 (Fractal), then Layer 3 ch 14 = 12 (Fractal: latest move wins), Layer 3 = 25 (Generator)")
    func src(_ i: Int) -> LayerSource { gControl.with { $0.layers[i].source } }
    func fl() -> Int { gControl.with { $0.fractalLayer } }
    expect("all-zero Layer 16 ch 14: every layer Clip, fractal on the base layer 0", (0..<layerCount).allSatisfy { src($0) == .clip } && fl() == 0)
    L(2, V0.lSource, 15); feed(2)
    expect("layer 2 source fractal, fractal on layer 2", src(1) == .fractal && fl() == 2 && own("layer2.source") == .dmx)
    L(3, V0.lSource, 12); feed(2)
    expect("layer 3 takes the fractal; layer 2 still says fractal (shows nothing)", src(2) == .fractal && src(1) == .fractal && fl() == 3)
    L(3, V0.lSource, 25); L(3, V0.lGenType, 25); L(3, V0.lGenCount, 0); feed(2)
    expect("layer 3 generator Prisms, fractal back to base 0, count kept at 0 (keep)", src(2) == .gen && fl() == 0 && gControl.with { $0.layers[2].gen.type } == .prisms
           && abs(gControl.with { $0.layers[2].gen.count } - GenParams().count) < 1e-9)
    L(3, V0.lGenCount, 255); L(3, V0.lGenType, 115); feed(2)
    expect("count 255 = 1.0, type band 110-119 = Shapes Burst", gControl.with { $0.layers[2].gen.count } == 1 && gControl.with { $0.layers[2].gen.type } == .burst)
    L(3, V0.lGenType, 200); feed(2)
    expect("reserved type 200 keeps Shapes Burst", gControl.with { $0.layers[2].gen.type } == .burst)
    print("19. Layer FX 3 ch 23 generator speed (0 keep, 128 stop, 255 +1), ch 24 thickness 255")
    X(3, V0.xPosX, 128); X(3, V0.xGenSpeed, 0); feed(2)
    expect("ch 23 = 0 keeps the speed", abs(gControl.with { $0.layers[2].gen.speed } - GenParams().speed) < 1e-9)
    X(3, V0.xGenSpeed, 129); feed(2)
    expect("ch 23 = 129 (dead band) = stop", gControl.with { $0.layers[2].gen.speed } == 0)
    X(3, V0.xGenSpeed, 255); X(3, V0.xGenThickness, 255); feed(2)
    expect("ch 23 = 255 = +1, ch 24 = 255 = thickness 1", gControl.with { $0.layers[2].gen.speed } == 1 && gControl.with { $0.layers[2].gen.thickness } == 1)
    print("20. Fractal 24 ch 22 spin: 0 keep, 255 = +2 turns/s, 126 = stop; OSC helpers")
    func F(_ ch: Int, _ v: Int) { pk[V0.fractalStart - 1 + ch - 1] = UInt8(v) }
    gControl.with { $0.fractalSpin = 0.1 }
    F(V0.offX, 128); F(V0.offY, 128); F(V0.autoZoom, 128); F(V0.spin, 0); feed(2)
    expect("ch 22 = 0 keeps the spin (0.1)", gControl.with { $0.fractalSpin } == 0.1)
    F(V0.spin, 255); feed(2)
    expect("ch 22 = 255: spin +2 turns/s, owner dmx", gControl.with { $0.fractalSpin } == 2 && gControl.with { $0.owner(.spin) } == .dmx)
    F(V0.spin, 126); feed(2)
    expect("ch 22 = 126: stop", gControl.with { $0.fractalSpin } == 0)
    let r1 = gControl.with { $0.setFractalLayer(4) }, f4 = fl(), s4 = src(3)
    let r0 = gControl.with { $0.setFractalLayer(0) }
    expect("setFractalLayer(4): layer 4 fractal; (0): back to base (\(r1); \(r0))", f4 == 4 && s4 == .fractal && fl() == 0)
    expect("generator types \(GenType.names.count), sources parse", GenType.names.count == 13 && GenType.parse(.s("stars")) == .stars && v0GenType(125) == .stars && LayerSource.parse(.s("gen")) == .gen && LayerSource.parse(.s("ndi")) == .ndi && v0Source(35) == .ndi && v0Source(40) == nil && GenType.parse(.s("shapes burst")) == .burst)
    print("21. Fractal 24 v0.6: Julia c 32768 = keep, formula / fold / trap / Julia / loop bands")
    F(V0.juliaRe, 128); F(V0.juliaRe + 1, 0); F(V0.juliaIm, 128); F(V0.juliaIm + 1, 0); feed(2)
    expect("Julia c 32768/32768 keeps -0.8 + 0.156i, formula Mandelbrot, fold off", gControl.with { $0.frac.juliaRe == -0.8 && $0.frac.juliaIm == 0.156 && $0.frac.formula == .mandelbrot && $0.frac.fold == 0 })
    F(V0.type, 15); F(V0.power, 70); F(V0.colouring, 55); F(V0.audio, 255); F(V0.fractalControl, 52); feed(2)
    expect("formula 15 = Burning Ship, fold 70 = 8, trap 55 = star, Julia 1.0, ch 24 52 = dive next",
           gControl.with { $0.frac.formula == .burningShip && $0.frac.fold == 8 && !$0.frac.foldMirror && $0.frac.trap == .star && $0.frac.julia == 1 && $0.frac.loop == .dive && $0.frac.loopNext == .next })
    F(V0.power, 125); F(V0.fractalControl, 0); F(V0.type, 0); F(V0.colouring, 0); F(V0.audio, 0); F(V0.juliaRe, 192); feed(2)
    expect("fold 125 = 2 mirror, loop off, back to classic, Julia c re +1", gControl.with { $0.frac.fold == 2 && $0.frac.foldMirror && $0.frac.loop == .off && $0.frac.formula == .mandelbrot && $0.frac.trap == .off && $0.frac.julia == 0 && $0.frac.juliaRe == 1 })
    F(V0.power, 0); F(V0.juliaRe, 128); feed(2)
    print("22. Audio react FX speed: a kick_hit -> fx1_speed route shifts the slot's effective speed; masterfx_speed parses")
    do {
        var rs = [AudioRoute](repeating: AudioRoute(), count: audioRouteCount)
        rs[0] = AudioRoute(on: true, source: .kick_hit, target: .fx1_speed, layer: 1, amount: 0.35, curve: .hard, smooth: 0)
        var ft = AudioFeatures(); ft.hits[0] = 1
        let rt = AudioModRuntime()
        let la = rt.step(rs, ft, dt: 1.0 / 60, frozen: false).layers[layerIndex(1)]
        var fx = LayerFX(); fx.fx[0].type = .starTrails
        let sp = audioFXSpeed(fx.fx, la)
        expect("fx1_speed +0.35 on a kick hit: slot 1 speed 0.5 -> 0.85, slot 2 untouched, nothing stored", abs(la.fx1Speed - 0.35) < 1e-9 && abs(sp[0].speed - 0.85) < 1e-9 && sp[1].speed == 0.5 && fx.fx[0].speed == 0.5)
        let la0 = rt.step(rs, AudioFeatures(), dt: 1.0 / 60, frozen: false).layers[layerIndex(1)]
        let big = audioFXSpeed([FXSlot(type: .starTrails, amount: 0.5, speed: 0.9)], LayerAudio(fx1Speed: 0.35))
        expect("silent source: speed offset back to 0 (base 0.5); 0.9 + 0.35 clamps to 1", la0.fx1Speed == 0 && big[0].speed == 1)
        expect("masterfx_speed / aliases parse, groups right", AudioModTarget.parse("masterfx_speed") == .masterfx_speed && AudioModTarget.parse("fxspeed") == .masterfx_speed && AudioModTarget.parse("speed1") == .fx1_speed && AudioModTarget.parse("fx2speed") == .fx2_speed
               && AudioModTarget.fx1_speed.isLayer && AudioModTarget.fx2_speed.isLayer && !AudioModTarget.masterfx_speed.isLayer && AudioModTarget.masterfx_speed.group == "master" && AudioModTarget.fx1_speed.group == "layer")
    }
    print("23. Record (recorder.swift): /oats/record/start args, default path, disk guard")
    let ra = Recorder.parseArgs([.s("vertical")]), rb = Recorder.parseArgs([.s("~/Movies/x.mp4"), .s("9:16")]), rc = Recorder.parseArgs([.s("1080p")]), rd = Recorder.parseArgs([.s("huge")])
    expect("size parses: vertical, 9:16 -> vertical; 1080p -> 1080p; no size -> 1080p; 'huge' -> bad args",
           ra.size == .vertical && ra.path.isEmpty && rb.size == .vertical && rb.path == "~/Movies/x.mp4" && rc.size == .p1080
           && Recorder.parseArgs([]).size == .p1080 && !rd.bad.isEmpty)
    let recDir = (NSHomeDirectory() as NSString).appendingPathComponent("Movies/OATS VIZ/teaser-takes")
    let planV = Recorder.makePlan(path: "", size: .vertical, freeGB: 13, now: Date(timeIntervalSince1970: 1_800_000_000))
    var planPath = ""
    if case .success(let pl) = planV { planPath = pl.path }
    expect("default path \(planPath.replacingOccurrences(of: NSHomeDirectory(), with: "~"))",
           planPath.hasPrefix(recDir + "/") && planPath.hasSuffix("-vertical.mp4") && (planPath as NSString).lastPathComponent.count == "yyyymmdd-HHmmss-vertical.mp4".count)
    var planH = ""
    if case .success(let pl) = Recorder.makePlan(path: "", size: .p1080, freeGB: 3.0) { planH = pl.path }
    expect("1080p default name ends -1080p.mp4; 3.0 GB free is allowed", planH.hasSuffix("-1080p.mp4"))
    var guardMsg = ""
    if case .failure(let why) = Recorder.makePlan(path: "", size: .p1080, freeGB: 2.9) { guardMsg = why.description }
    expect("disk guard refuses at 2.9 GB free: \(guardMsg)", guardMsg.contains("refused") && guardMsg.contains("3 GB"))
    let rr = Recorder.rects(size: .vertical, cw: 1920, ch: 1080), rh = Recorder.rects(size: .p1080, cw: 1920, ch: 1080)
    expect("vertical = centre 608x1080 crop of the 1080p canvas -> 1080x1920; 1080p = the whole canvas 1:1",
           rr.src == SIMD4<Float>(656, 0, 608, 1080) && rr.dst == SIMD4<Float>(0, 0, 1080, 1920) && rh.src == SIMD4<Float>(0, 0, 1920, 1080) && rh.dst == SIMD4<Float>(0, 0, 1920, 1080))
    print("24. Audio kick presence gate / return ramp / snare body + crack (synthetic audio through AudioAnalyzer, 48 kHz)")
    do {
        let ana = AudioAnalyzer(); ana.reset(rate: 48000)
        let st = AudioSettings()
        var seed: UInt32 = 12345
        func noise() -> Float { seed = seed &* 1664525 &+ 1013904223; return Float(seed) / Float(UInt32.max) * 2 - 1 }
        // 0.5 s block (120 BPM): a kick (55 Hz sine, 80 ms decay) at its start over a -60 dBFS noise floor
        func kickBlock(_ gain: Float) -> [Float] {
            (0..<24000).map { i in let tt = Float(i) / 48000; return gain * 0.8 * sinf(2 * .pi * 55 * tt) * expf(-tt / 0.08) + 0.001 * noise() }
        }
        func run(_ blocks: Int, _ gain: Float) { for _ in 0..<blocks { ana.analyze(kickBlock(gain), st) } }
        run(16, 1)                                                        // 8 s of full kicks
        let k1 = ana.counts[0], c1 = ana.kickConf
        expect("(a) 55 Hz kick train 8 s: \(k1) kick hits (want 12-16), confidence \(c1) (want > 0.9)", k1 >= 12 && k1 <= 16 && c1 > 0.9)
        run(12, Float(pow(10, -24.0 / 20)))                               // 6 s the same train at -24 dB (filtered out)
        let k2 = ana.counts[0] - k1, c2 = ana.kickConf
        expect("(b) same train at -24 dB for 6 s: \(k2) kick hits (want 0), confidence \(c2) (want 0)", k2 == 0 && c2 == 0)
        let back = kickBlock(1)
        ana.analyze(Array(back[0..<4800]), st)                            // 100 ms into the first returned kick
        let c3a = ana.kickConf, k3 = ana.counts[0] - k1 - k2
        ana.analyze(Array(back[4800...]), st); run(2, 1)                  // 1.5 s after the return
        let c3b = ana.kickConf
        expect("(c) kick returns: hit \(k3) (want >= 1), confidence 100 ms in \(c3a) (want 0.05-0.6: eased, not instant), 1.5 s in \(c3b) (want > 0.9)",
               k3 >= 1 && c3a > 0.05 && c3a < 0.6 && c3b > 0.9)
        // snare: 200 Hz body (100 ms decay) + crack (40 sines over 1.5-5 kHz, 60 ms decay)
        func snareBlock(body: Bool, crack: Bool) -> [Float] {
            var fr = [Float](), ph = [Float]()
            for k in 0..<40 { fr.append(1500 + 3500 * Float(k) / 39 + 20 * noise()); ph.append(.pi * noise()) }
            return (0..<24000).map { i in
                let tt = Float(i) / 48000
                var v: Float = 0.001 * noise()
                if body { v += 0.5 * sinf(2 * .pi * 200 * tt) * expf(-tt / 0.1) }
                if crack { var c: Float = 0; for k in 0..<40 { c += sinf(2 * .pi * fr[k] * tt + ph[k]) }; v += 0.07 * c * expf(-tt / 0.06) }
                return v
            }
        }
        ana.analyze((0..<48000).map { _ in 0.001 * noise() }, st)         // 1 s quiet
        let s0 = ana.counts[1]
        ana.analyze(snareBlock(body: true, crack: true), st)
        let s1 = ana.counts[1] - s0
        ana.analyze(snareBlock(body: true, crack: false), st); ana.analyze(snareBlock(body: true, crack: false), st)
        let s2 = ana.counts[1] - s0 - s1
        ana.analyze(snareBlock(body: false, crack: true), st)
        let s3 = ana.counts[1] - s0 - s1 - s2
        expect("(d) snare burst (200 Hz body + 1.5-5 kHz crack): \(s1) snare hit (want 1); body alone \(s2), crack alone \(s3) (want 0)", s1 == 1 && s2 == 0 && s3 == 0)
    }
    print("25. Star/Warp/SpiralTrails stepped stamping (fx.swift): hold frames, beat-synced stamp interval, hold forever at 0.97, per-stamp fade")
    do {
        let hold = FXRuntime.longExposure(.spiralTrails, amount: 0.5, speed: 1, dt: 1 / 60.0, stamp: false)
        expect("(a) non-stamp frame: fade 1, rotation 0, zoom 0 (type kept)", hold.y == 1 && hold.z == 0 && hold.w == 0 && Int(hold.x) == FXType.spiralTrails.rawValue)
        let iv = 0.25 * 60 / 124                                          // 1/4 beat at 124 BPM = 0.121 s (~8.3 stamps/s)
        let st = FXRuntime.longExposure(.starTrails, amount: 0.5, speed: 1, dt: iv)
        let r124 = FXRuntime.stampRate(speed: 0.5, bpm: 124, known: true), r0 = FXRuntime.stampRate(speed: 0.5, bpm: 120, known: false)
        expect("(b) stamp at 124 BPM, 1/4 beat, speed 1: rotation = 90 deg/s x interval (\(String(format: "%.2f", Double(st.z) * 180 / .pi)) deg per stamp); still speed = 1/4 beat = \(String(format: "%.2f", r124.hz)) Hz synced; no tempo = 8 Hz unsynced",
               abs(Double(st.z) - (.pi / 2) * iv) < 1e-6 && abs(r124.hz - 124.0 / 60 / 0.25) < 1e-9 && r124.synced && r0.hz == 8 && !r0.synced)
        expect("subdivision follows |speed - 0.5|: 0.5 -> 1/4, 0.6 -> 1/2, 0.75 -> 1/4, 1 and 0 -> 1/8 beat",
               FXRuntime.stampBeats(speed: 0.5) == 0.25 && FXRuntime.stampBeats(speed: 0.6) == 0.5 && FXRuntime.stampBeats(speed: 0.75) == 0.25 && FXRuntime.stampBeats(speed: 1) == 0.125 && FXRuntime.stampBeats(speed: 0) == 0.125)
        let keep = FXRuntime.longExposure(.starTrails, amount: 0.97, speed: 0.5, dt: iv)
        expect("(c) amount 0.97: fade exactly 1 (Solitaire: every copy stays until covered), still", keep.y == 1 && keep.z == 0)
        let half = FXRuntime.longExposure(.starTrails, amount: 0.5, speed: 0.5, dt: iv)
        var perFrame = 1.0
        for _ in 0..<7 { perFrame *= exp(-3 * (iv / 7) / (0.15 * pow(67, 0.5))) }       // the old per-frame curve over 7 frames of the interval
        expect("(d) amount 0.5: fade per stamp \(String(format: "%.4f", Double(half.y))) < 1 = the old per-frame curve integrated over the interval",
               half.y < 1 && abs(Double(half.y) - perFrame) < 1e-6)
    }
    print("26. Look indicators (2026-10-24, status fx_look / gen_look / fractal.look): a look stands until a value it set is changed by hand; scenes bring the names back")
    do {
        let osc = OSCServer(selftest: Config(), filter: SourceFilter(cfg: Config()))
        func msg(_ a: String, _ args: [OSCArg]) -> OSCMessage { OSCMessage(address: a, types: "," + args.map { x -> String in if case .s = x { return "s" }; return "f" }.joined(), args: args, inBundle: false) }
        func fxLook(_ i: Int) -> String { gControl.with { $0.layers[i].fx.look } }
        func genLook(_ i: Int) -> String { gControl.with { $0.layers[i].genLook } }
        osc.inject(msg("/oats/layers/2/fx/preset", [.s("Kaleido Bloom")]))
        let a1 = gControl.with { $0.layers[1].fx.fx[0].amount }
        expect("fx/preset 'kaleido bloom' on layer 2: fx_look = 'Kaleido Bloom', FX1 Kaleido", fxLook(1) == "Kaleido Bloom" && gControl.with { $0.layers[1].fx.fx[0].type } == .kaleido)
        osc.inject(msg("/oats/layers/2/gen/look", [.s("Ring Pulse")]))
        expect("gen/look 'Ring Pulse' on layer 2 records the name only: gen_look = 'Ring Pulse'", genLook(1) == "Ring Pulse")
        // a scene holding both looks (a scratch scenes file: never the show's scenes.json; thumbnail grab pointed at a closed port)
        gScenesFileOverride = (NSTemporaryDirectory() as NSString).appendingPathComponent("oats-selftest-scenes-\(getpid()).json")
        previewPort = 1
        print("    " + gScenes.store(sceneMax, name: "selftest looks"))
        osc.inject(msg("/oats/layers/2/fx/1/amount", [.f(Float(a1 > 0.5 ? 0.2 : 0.9))]))
        expect("slot 1 amount by hand: fx_look cleared (the values no longer stand)", fxLook(1) == "" && gControl.with { $0.layers[1].fx.fx[0].type } == .kaleido)
        osc.inject(msg("/oats/layers/2/gen/count", [.f(0.77)]))
        expect("gen count by hand: gen_look cleared", genLook(1) == "")
        osc.inject(msg("/oats/layers/2/fx/preset", [.s("Kaleido Bloom")]))
        osc.inject(msg("/oats/layers/2/fx/reset", []))
        expect("fx/reset clears the FX look too", fxLook(1) == "" && lfx(1).neutral)
        print("    " + gScenes.go(sceneMax, fade: 0, from: "selftest"))
        expect("scene recalled (cut): fx_look 'Kaleido Bloom' and gen_look 'Ring Pulse' are back", fxLook(1) == "Kaleido Bloom" && genLook(1) == "Ring Pulse")
        X(2, V0.xFX1 + 1, 77); feed(2)
        expect("DMX moves layer 2 FX1 amount: fx_look cleared again (\(own("layer2.fx1")))", fxLook(1) == "" || own("layer2.fx1") != .dmx)
        X(2, V0.xFX1 + 1, 0); feed(2)
        osc.inject(msg("/oats/fractal/1/preset", [.s("none")]))
        expect("fractal preset none: fractal look '' (= formula.preset)", gControl.with { $0.frac.preset } == "")
        try? FileManager.default.removeItem(atPath: gScenesFileOverride)
    }
    print("27. Listen monitor (2026-10-24, audio.swift AudioMonitor): /oats/audio/listen parses, off by default, volume clamps, status fields")
    do {
        func au(_ a: String, _ args: [OSCArg]) -> (String, Bool) { gAudio.osc(OSCMessage(address: a, types: "", args: args, inBundle: false)) ?? ("not an audio address", false) }
        func st() -> [String: Any] { gAudio.statusDict(routes: [], preset: "", shown: []) }
        let s0 = st()
        expect("defaults: listen off, volume 0.8, status has listen / listen_volume / listen_device / listen_note",
               (s0["listen"] as? Bool) == false && (s0["listen_volume"] as? Double) == 0.8 && s0["listen_device"] is String && (s0["listen_note"] as? String) == "")
        let v1 = au("/oats/audio/listen/volume", [.f(1.7)]), v2 = au("/oats/audio/listen/volume", [.f(-3)])
        expect("volume clamps: 1.7 -> 1.0, -3 -> 0.0 ('\(v1.0)', '\(v2.0)')", v1.1 && v2.1 && v1.0.hasSuffix("1.00") && v2.0.hasSuffix("0.00") && (st()["listen_volume"] as? Double) == 0)
        _ = au("/oats/audio/listen/volume", [.f(0.8)])
        let bad = au("/oats/audio/listen", [.s("loud")]), on = au("/oats/audio/listen", [.i(1)])
        expect("listen i 1 parses ('\(on.0)'); a string is refused ('\(bad.0)')", on.1 && (st()["listen"] as? Bool) == true && !bad.1)
        let off = au("/oats/audio/listen", [.i(0)])
        expect("listen i 0: off again, note empty ('\(off.0)')", off.1 && (st()["listen"] as? Bool) == false && (st()["listen_note"] as? String) == "" && (st()["listen_volume"] as? Double) == 0.8)
        expect("unknown audio address lists listen", au("/oats/audio/nothing", []).0.contains("listen/volume"))
    }

    if !haveClip { print("  note: bank 1 slot 2 not in the library: clip checks were skipped") }
    print(fails == 0 ? "PASS: \(checks) checks" : "FAIL: \(fails) of \(checks) checks")
    return fails == 0 ? 0 : 1
}
