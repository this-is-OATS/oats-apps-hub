import Foundation

// Fractal phasers (2026-10-23): 3 LFOs on look parameters of the normal content, evaluated once per frame on the render
// thread (engine.swift) from the frame's display time. Beat rates follow the tempo clock (Link / DMX / tap / OSC, the
// beat extrapolated to the frame like the layer beat mod); second rates follow the clock x effect speed. Each phaser's
// output is wave(-1...1) x depth x a 0.25 s fade-in/out of its on switch, summed per target and clamped to -1...1.
// Ranges at depth 1 (applyPhasers in engine.swift; the base values are never changed, only what is drawn):
//   spread       the Spread <-> Tighten macro +-1            palette     palette offset +-0.5 cycle
//   zoom         +-0.5 decade around the current depth (an offset on what is drawn; the auto-zoom and loop keep their own depth)
//   rotation     +-45 deg                                    iterations  x0.5 ... x2
//   julia        Julia morph +-0.5 (only on a direct-path look: Julia, kaleido or warp already on, so the depth cap never moves)
//   orbit        the Julia constant on a small circle (radius 0.05; x = wave, y = the wave a quarter cycle later)
//   twist        kaleido / fold-c seams turned +-half a sector  warp  +-0.15 (direct-path looks only)
//   trapsize     x0.5 ... x2                                 trapmix     +-0.5

struct PhaserMod {
    var spread = 0.0, palette = 0.0, zoom = 0.0, rotation = 0.0, iterations = 0.0, julia = 0.0
    var orbitX = 0.0, orbitY = 0.0, twist = 0.0, warp = 0.0, trapsize = 0.0, trapmix = 0.0
    var any = false
}

/// Deterministic per-step random in -1...1 (beat-synced random steps are the same on every run at the same beat).
@inline(__always) func phaserHash(_ n: Int64, _ k: Int) -> Double {
    var x = UInt64(bitPattern: n) &* 0x9E37_79B9_7F4A_7C15 &+ UInt64(k + 1) &* 0xBF58_476D_1CE4_E5B9
    x ^= x >> 31; x = x &* 0x94D0_49BB_1331_11EB; x ^= x >> 29
    return Double(x >> 11) / Double(1 << 53) * 2 - 1
}

/// One wave value at cycle position x (cycles; any real), shape s, phaser index k.
func phaserWave(_ s: PhaserShape, _ x: Double, _ k: Int) -> Double {
    let n = Int64(floor(x)), f = x - floor(x)
    switch s {
    case .sine: return sin(2 * .pi * f)
    case .triangle: return 1 - 4 * abs(f - 0.5)            // -1 at the cycle start, +1 half way
    case .saw: return 2 * f - 1
    case .square: return f < 0.5 ? 1 : -1
    case .random: return phaserHash(n, k)
    case .smooth:
        let a = phaserHash(n, k), b = phaserHash(n + 1, k)
        let e = f * f * (3 - 2 * f)
        return a + (b - a) * e
    }
}

/// "0/s is stopped" (2026-10-23): with the zoom on HOLD (speed 0, loop off) the zoom-breathe phasers pause, with Colour
/// Cycle 0 the spread and palette-offset phasers pause: their offset eases to 0 over 0.3 s and holds there; moving again
/// resumes them the same way. FractalMods.phaserFree ("Phasers run even when stopped") turns this off.
enum PhaserPause: String { case hold, cycle, speed }
func phaserPauseReason(_ t: PhaserTarget, hold: Bool, cycle0: Bool, speed0: Bool = false) -> PhaserPause? {
    if speed0 { return .speed }                             // master effect speed 0 = everything stopped
    if hold && t == .zoom { return .hold }
    if cycle0 && (t == .spread || t == .palette) { return .cycle }
    return nil
}

final class PhaserRuntime {
    private var acc = [Double](repeating: 0, count: phaserCount)   // seconds-rate cycles
    private var gain = [Double](repeating: 0, count: phaserCount)
    private var run = [Double](repeating: 1, count: phaserCount)   // pause ramp: 1 running ... 0 paused (0.3 s each way)
    private(set) var shown = [Double](repeating: 0, count: phaserCount)
    private(set) var paused = [PhaserPause?](repeating: nil, count: phaserCount)

    /// dt: this frame's time step (0 while frozen), already x effect speed. beat: the tempo clock's beat at the frame.
    /// hold / cycle0: the zoom is on HOLD / Colour Cycle is 0 (pauses the phasers on those, unless free); rdt = real time step.
    /// The on/off fade and the pause ramp run on REAL time (rdt; 0 only while frozen): off = 0 within 0.3 s, then exactly 0,
    /// even at master effect speed 0 (2026-10-23 fix: the fade used dt x effect speed, so at speed 0 an off phaser never faded).
    func step(_ ps: [Phaser], dt: Double, beat: Double, hold: Bool = false, cycle0: Bool = false, free: Bool = true, rdt: Double = -1,
              speed0: Bool = false) -> PhaserMod {
        var m = PhaserMod()
        let rt = rdt >= 0 ? rdt : dt
        for k in 0..<min(phaserCount, ps.count) {
            let p = ps[k]
            gain[k] = p.on ? min(1, gain[k] + rt / 0.3) : max(0, gain[k] - rt / 0.3)
            let why = !p.on ? nil : (speed0 ? PhaserPause.speed : (free ? nil : phaserPauseReason(p.target, hold: hold, cycle0: cycle0)))
            paused[k] = why
            run[k] = why != nil ? max(0, run[k] - rt / 0.3) : min(1, run[k] + rt / 0.3)
            if p.seconds > 0 && run[k] > 0 { acc[k] = (acc[k] + dt / max(0.1, p.seconds)).truncatingRemainder(dividingBy: 1e6) }
            let x = (p.seconds > 0 ? acc[k] : beat / phaserBeats(p.beats)) + p.phase
            let g = gain[k] * gain[k] * (3 - 2 * gain[k]), r = run[k] * run[k] * (3 - 2 * run[k])   // eased
            let amp = min(1, max(0, p.depth)) * g * r
            guard amp > 0 else { shown[k] = 0; continue }
            let v = phaserWave(p.shape, x, k) * amp
            shown[k] = v
            m.any = true
            switch p.target {
            case .spread: m.spread += v
            case .palette: m.palette += v
            case .zoom: m.zoom += v
            case .rotation: m.rotation += v
            case .iterations: m.iterations += v
            case .julia: m.julia += v
            case .orbit: m.orbitX += v; m.orbitY += phaserWave(p.shape, x + 0.25, k) * amp
            case .twist: m.twist += v
            case .warp: m.warp += v
            case .trapsize: m.trapsize += v
            case .trapmix: m.trapmix += v
            }
        }
        func c(_ v: inout Double) { v = min(1, max(-1, v)) }
        c(&m.spread); c(&m.palette); c(&m.zoom); c(&m.rotation); c(&m.iterations); c(&m.julia)
        c(&m.orbitX); c(&m.orbitY); c(&m.twist); c(&m.warp); c(&m.trapsize); c(&m.trapmix)
        return m
    }
}

// MARK: - phaser presets (tools/fractal_presets.json "phaser_presets")

func loadPhaserPresets() -> [[String: Any]] {
    guard let d = FileManager.default.contents(atPath: fractalPresetsPath()),
          let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any], let l = j["phaser_presets"] as? [[String: Any]] else { return [] }
    return l
}
let gPhaserPresetNames: [String] = loadPhaserPresets().compactMap { $0["name"] as? String }

/// The preset whose 3 phasers equal `ps` (float32 OSC round trips tolerated; phasers off on both sides match whatever
/// their settings), or "". A phaser change over OSC keeps / finds the preset name this way, so a restore that sends the
/// values one by one (tools/oats_state.py) ends with the name back, and a change away from it clears it (2026-10-23).
func matchingPhaserPreset(_ ps: [Phaser], list: [[String: Any]]) -> String {
    func same(_ a: Phaser, _ b: Phaser) -> Bool {
        if !a.on && !b.on { return true }
        let dp = abs(a.phase - b.phase)
        guard a.on == b.on, a.target == b.target, a.shape == b.shape, abs(a.depth - b.depth) < 1e-4, dp < 1e-4 || abs(dp - 1) < 1e-4 else { return false }
        if a.seconds > 0 || b.seconds > 0 { return abs(a.seconds - b.seconds) < 1e-3 }
        return abs(a.beats - b.beats) < 1e-6
    }
    guard ps.contains(where: { $0.on }) else { return "" }
    for p in list {
        guard let name = p["name"] as? String else { continue }
        let rows = (p["phasers"] as? [[String: Any]]) ?? []
        var ok = true
        for k in 0..<min(phaserCount, ps.count) {
            var want = Phaser()
            if k < rows.count { want = Phaser.from(rows[k], base: Phaser()); if rows[k]["on"] == nil { want.on = true } }
            if !same(ps[k], want) { ok = false; break }
        }
        if ok { return name }
    }
    return ""
}

/// /oats/fractal/1/phaser/preset s NAME|off: the 3 phasers (and the spread, if the preset sets it) from the file
/// (read on every call). "off" = every phaser off (their settings stay), spread unchanged.
func applyPhaserPreset(_ name: String) -> String {
    if ["off", "none", "stop", "0"].contains(name.lowercased()) {
        gControl.with { c in for k in 0..<phaserCount { c.frac.phasers[k].on = false }; c.frac.phaserPreset = "" }
        return "phasers off"
    }
    let list = loadPhaserPresets()
    guard let p = list.first(where: { ($0["name"] as? String)?.caseInsensitiveCompare(name) == .orderedSame }) else {
        return "no phaser preset '\(name)' in \(fractalPresetsPath()) (have: " + list.compactMap { $0["name"] as? String }.joined(separator: ", ") + ")"
    }
    let pn = p["name"] as? String ?? name
    let rows = (p["phasers"] as? [[String: Any]]) ?? []
    var desc: [String] = []
    gControl.with { c in
        for k in 0..<phaserCount {
            if k < rows.count {
                var ph = Phaser.from(rows[k], base: Phaser())
                if rows[k]["on"] == nil { ph.on = true }
                c.frac.phasers[k] = ph
            } else { c.frac.phasers[k].on = false }
        }
        if let v = (p["spread"] as? NSNumber)?.doubleValue, v.isFinite { c.frac.spread = min(1, max(-1, v)) }
        c.frac.phaserPreset = pn
        desc = c.frac.phasers.filter { $0.on }.map { ph in
            "\(ph.target.rawValue) \(ph.shape.rawValue) " + (ph.seconds > 0 ? String(format: "%.3g s", ph.seconds) : String(format: "%.3g beats", ph.beats)) + String(format: " x%.2f", ph.depth)
        }
    }
    return "phaser preset '\(pn)': " + (desc.isEmpty ? "all off" : desc.joined(separator: "; "))
}

// MARK: - `oats-m0 --selftest-phasers`: off / preset off / HOLD / Cycle 0 / effect speed 0 really stop the offsets

func phaserSelfTest() -> Int32 {
    var fails = 0
    func expect(_ what: String, _ ok: Bool) { print((ok ? "  ok   " : "  FAIL ") + what); if !ok { fails += 1 } }
    let f = 1.0 / 60
    func run(_ rt: PhaserRuntime, _ ps: [Phaser], secs: Double, beat0: Double, speed: Double = 1, hold: Bool = false, cycle0: Bool = false) -> (PhaserMod, Double) {
        var m = PhaserMod(), b = beat0
        for _ in 0..<Int(secs / f) { b += f * 2; m = rt.step(ps, dt: f * speed, beat: b, hold: hold, cycle0: cycle0, free: false, rdt: f, speed0: speed == 0) }
        return (m, b)
    }
    var ps = [Phaser](repeating: Phaser(), count: phaserCount)
    ps[0] = Phaser(on: true, target: .spread, shape: .triangle, beats: 2, seconds: 0, depth: 0.6, phase: 0)
    ps[1] = Phaser(on: true, target: .zoom, shape: .saw, beats: 2, seconds: 0, depth: 1, phase: 0)
    ps[2] = Phaser(on: true, target: .rotation, shape: .sine, beats: 1, seconds: 0, depth: 1, phase: 0.1)
    for speed in [1.0, 0.0] {
        let rt = PhaserRuntime()
        var (m, b) = run(rt, ps, secs: 1, beat0: 0.37, speed: max(speed, 1))
        expect("speed \(speed): on -> moving (spread \(String(format: "%.2f", m.spread)), zoom \(String(format: "%.2f", m.zoom)))", m.any)
        var off = ps; for k in 0..<phaserCount { off[k].on = false }           // = /phaser/preset off
        (m, b) = run(rt, off, secs: 0.5, beat0: b, speed: speed)
        expect("speed \(speed): off -> after 0.5 s every offset exactly 0", m.spread == 0 && m.zoom == 0 && m.rotation == 0 && !m.any)
        (m, _) = run(rt, off, secs: 5, beat0: b, speed: speed)
        expect("speed \(speed): off -> still exactly 0 after 5 s more (no bursts)", m.spread == 0 && m.zoom == 0 && m.rotation == 0 && !m.any)
    }
    do {
        let rt = PhaserRuntime()
        var (m, b) = run(rt, ps, secs: 1, beat0: 0.37)
        (m, b) = run(rt, ps, secs: 0.5, beat0: b, hold: true, cycle0: true)
        expect("HOLD + Cycle 0: zoom breathe, spread 0 after 0.5 s; rotation still moving", m.zoom == 0 && m.spread == 0 && m.rotation != 0)
        expect("paused_by: spread cycle, zoom hold, rotation nil", rt.paused[0] == .cycle && rt.paused[1] == .hold && rt.paused[2] == nil)
        (m, _) = run(rt, ps, secs: 0.5, beat0: b)
        expect("moving again: zoom + spread resume", m.zoom != 0 || m.spread != 0)
        (m, _) = run(rt, ps, secs: 0.5, beat0: b, speed: 0)
        expect("effect speed 0: everything 0 after 0.5 s (paused_by speed)", !m.any && rt.paused.allSatisfy { $0 == .speed })
    }
    print(fails == 0 ? "PASS: phasers stop when off / stopped" : "FAIL: \(fails) phaser check(s)")
    return fails == 0 ? 0 : 1
}
