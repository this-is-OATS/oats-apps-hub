import Foundation
import Metal

// Layer sources (2026-10-22): every clip layer 1-4 picks its SOURCE = Clip | Fractal | Generator, and every source goes
// through the same layer pipeline (opacity, blend, transform, 2 FX, beat mod, colour link).
//  - Clip: the clip decoders (layers.swift), unchanged.
//  - Fractal: there is ONE fractal renderer (CPU reference orbit + GPU perturbation). It draws on the layer that
//    selected it last (Control.fractalLayer, latest move wins); a layer that still says Fractal but lost it shows
//    nothing (status "fractal_note"). fractalLayer 0 = the old bottom "Layer 0 / base", at its own opacity.
//  - Generator: a procedural GPU pattern (kernel `generator`, below) rendered into this layer's own rgba16Float
//    texture, PREMULTIPLIED with a transparent background, so it blends over whatever is under it.
// Generators are antialiased analytically (distance to the edge in pixels, no derivatives in compute) and resolution
// independent (coordinates in frame heights). Density is capped: at most 48 elements across the frame height and
// line half-widths never below 1.5 px, so no 1-pixel high-frequency patterns (fine detail like that is what
// triggered the old NDI freeze); radial patterns fade out where their spacing drops below ~6 px (centres).

enum LayerSource: String, CaseIterable {
    case clip, fractal, gen, ndi                              // ndi (2026-11-01, ndiin.swift): an NDI source on the LAN
    static func parse(_ a: OSCArg?) -> LayerSource? {
        guard let a = a else { return nil }
        if case .s(let s) = a {
            switch s.lowercased().filter({ $0.isLetter }) {
            case "clip", "clips", "media": return .clip
            case "fractal", "mandelbrot", "deep": return .fractal
            case "gen", "generator", "shape", "shapes": return .gen
            case "ndi", "camera", "cam", "ndisource": return .ndi
            default: return nil
            }
        }
        if let v = a.number, v.isFinite, abs(v) < 1e6 { let i = Int(v.rounded()); return (0...3).contains(i) ? allCases[i] : nil }
        return nil
    }
}

enum GenType: Int, CaseIterable {
    case lines = 0, angles, prisms, circles, dots, grid, polygons, rays, spiral, waves, tunnel, burst,
         stars                                         // 2026-10-23: random star field (appended: DMX bands keep their values)
    static let names = ["Lines", "Angles", "Prisms", "Circles", "Dots", "Grid", "Polygons", "Rays", "Spiral", "Waves", "Tunnel", "Shapes Burst", "Stars"]
    var name: String { GenType.names[rawValue] }
    /// "prisms", "Shapes Burst", "burst", "stars" (case, spaces ignored) or i 0..12.
    static func parse(_ a: OSCArg?) -> GenType? {
        guard let a = a else { return nil }
        if case .s(let s) = a {
            let k = s.lowercased().filter { $0.isLetter }
            if k == "burst" || k == "shapesburst" || k == "shapes" { return .burst }
            if k == "chevrons" || k == "zigzag" || k == "angle" { return .angles }
            if k == "triangles" || k == "prism" { return .prisms }
            if k == "rings" || k == "circle" { return .circles }
            if k == "checker" || k == "squares" { return .grid }
            if k == "polygon" || k == "ngon" { return .polygons }
            if k == "starburst" || k == "ray" { return .rays }
            if k == "wave" || k == "sine" { return .waves }
            if k == "bars" || k == "line" { return .lines }
            if k == "dot" || k == "discs" { return .dots }
            if k == "star" || k == "starfield" || k == "sky" { return .stars }
            return allCases.first { $0.name.lowercased().filter { $0.isLetter } == k }
        }
        if let v = a.number, v.isFinite, abs(v) < 1e6 { return GenType(rawValue: Int(v.rounded())) }
        return nil
    }
}

enum GenColorMode: String, CaseIterable { case white, link, accent, custom }

struct GenParams: Equatable {
    var type: GenType = .lines
    var count = 0.4                     // 0..1 density: 2 .. 48 elements across the frame height (log)
    var thickness = 0.35                // 0..1 of the element period (never below 3 px)
    var softness = 0.1                  // 0..1 edge blur (0 = 1-pixel antialiased edge)
    var speed = 0.25                    // -1..1 motion along the pattern's natural axis; 0 = stop; 0.5 = 1 period/s
    var angle = 0.0                     // degrees -180..180, + = counter-clockwise
    var variation = 0.5                 // 0..1 per type (sides for Polygons, amplitude for Waves, ...); 0.5 = the plain look
    var beatSync = false                // motion locked to the tempo clock (speed 0.5 = 1 period per beat)
    var colorA = SIMD3<Double>(1, 1, 1)
    var colorB = SIMD3<Double>(1, 1, 1)
    var colorMode: GenColorMode = .white

    /// Elements across the frame height (density cap: 48).
    var elements: Double { 2 * pow(24, min(1, max(0, count))) }
    var dict: [String: Any] {
        func r3(_ v: Double) -> Double { (v * 1000).rounded() / 1000 }
        return ["type": type.name, "type_index": type.rawValue, "count": r3(count), "elements": r3(elements), "thickness": r3(thickness),
                "softness": r3(softness), "speed": r3(speed), "angle": r3(angle), "variation": r3(variation), "beatsync": beatSync,
                "colorA": [r3(colorA.x), r3(colorA.y), r3(colorA.z)], "colorB": [r3(colorB.x), r3(colorB.y), r3(colorB.z)],
                "colormode": colorMode.rawValue]
    }
}

// MARK: - layer overlay (2026-10-23): a second generator drawn on top of the layer's own source (clip, fractal or gen),
// inside the layer: before its FX, motion (follow) and blend. Gen source: evaluated inline in the same generator pass.
// Clip / fractal source: one generator pass into the layer's generator texture (otherwise unused), which the composite
// mixes over the source sample (W3C separable blend over a premultiplied backdrop). Off or opacity 0 = no work at all.

enum OverlayBlend: String, CaseIterable {
    case add, screen, multiply, alpha, difference
    var mode: BlendMode { switch self { case .add: return .add; case .screen: return .screen; case .multiply: return .multiply; case .alpha: return .alpha; case .difference: return .difference } }
    static func parse(_ a: OSCArg?) -> OverlayBlend? {
        guard let a = a else { return nil }
        if case .s(let s) = a {
            let k = s.lowercased().filter { $0.isLetter }
            if k == "normal" || k == "over" { return .alpha }
            if k == "diff" { return .difference }
            return allCases.first { $0.rawValue == k }
        }
        if let v = a.number, v.isFinite, abs(v) < 1e6 { let i = Int(v.rounded()); return (0..<allCases.count).contains(i) ? allCases[i] : nil }
        return nil
    }
}

struct OverlayParams: Equatable {
    var on = false
    var gen: GenParams = { var g = GenParams(); g.type = .rays; return g }()
    var blend: OverlayBlend = .screen
    var opacity = 1.0
    var follow = true                   // true: the layer's in-pattern transform (spins with the layer); false: fixed on screen
    var look = ""                       // the gen look applied last (/overlay/look), "" after a manual change of the type
    var dict: [String: Any] {
        ["on": on, "blend": blend.rawValue, "opacity": (opacity * 1000).rounded() / 1000, "follow": follow, "look": look].merging(gen.dict) { a, _ in a }
    }
    /// Scene / state form (type as index), like the layer "gen" dict.
    var sceneDict: [String: Any] {
        let g = gen
        return ["on": on, "blend": blend.rawValue, "opacity": opacity, "follow": follow, "look": look,
                "type": g.type.rawValue, "count": g.count, "thickness": g.thickness, "softness": g.softness, "speed": g.speed,
                "angle": g.angle, "variation": g.variation, "beatsync": g.beatSync, "colorA": [g.colorA.x, g.colorA.y, g.colorA.z],
                "colorB": [g.colorB.x, g.colorB.y, g.colorB.z], "colormode": g.colorMode.rawValue]
    }
    mutating func apply(_ d: [String: Any]) {
        func num(_ k: String) -> Double? { (d[k] as? NSNumber).map { $0.doubleValue }.flatMap { $0.isFinite ? $0 : nil } }
        func rgb(_ k: String) -> SIMD3<Double>? {
            guard let a = d[k] as? [Any], a.count == 3, let x = (a[0] as? NSNumber)?.doubleValue, let y = (a[1] as? NSNumber)?.doubleValue,
                  let z = (a[2] as? NSNumber)?.doubleValue else { return nil }
            return SIMD3<Double>(min(1, max(0, x)), min(1, max(0, y)), min(1, max(0, z)))
        }
        if let v = d["on"] as? NSNumber { on = v.boolValue }
        if let s = d["blend"] as? String, let v = OverlayBlend(rawValue: s) { blend = v }
        if let v = num("opacity") { opacity = min(1, max(0, v)) }
        if let v = d["follow"] as? NSNumber { follow = v.boolValue }
        if let s = d["look"] as? String { look = s }
        if let v = num("type"), let t = GenType(rawValue: Int(v.rounded())) { gen.type = t }
        if let v = num("count") { gen.count = min(1, max(0, v)) }
        if let v = num("thickness") { gen.thickness = min(1, max(0, v)) }
        if let v = num("softness") { gen.softness = min(1, max(0, v)) }
        if let v = num("speed") { gen.speed = min(1, max(-1, v)) }
        if let v = num("angle") { gen.angle = min(180, max(-180, v)) }
        if let v = num("variation") { gen.variation = min(1, max(0, v)) }
        if let v = d["beatsync"] as? NSNumber { gen.beatSync = v.boolValue }
        if let v = rgb("colorA") { gen.colorA = v }
        if let v = rgb("colorB") { gen.colorB = v }
        if let s = d["colormode"] as? String, let v = GenColorMode(rawValue: s) { gen.colorMode = v }
    }
}

/// Generator looks of tools/gen_presets.json ("looks": name -> {"gen": {...}}), re-read on every /overlay/look.
enum GenLooks {
    static func path() -> String {
        if !gPresetsDirOverride.isEmpty { return (gPresetsDirOverride as NSString).appendingPathComponent("gen_presets.json") }
        return URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath().deletingLastPathComponent()
            .deletingLastPathComponent().appendingPathComponent("tools/gen_presets.json").standardizedFileURL.path
    }
    /// (looks in file order by name, error). Each look's generator params over the defaults.
    static func load() -> (looks: [(name: String, gen: GenParams)], error: String) {
        let p = path()
        guard let d = FileManager.default.contents(atPath: p), let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
              let ls = j["looks"] as? [String: Any] else { return ([], "no readable \(p)") }
        var out: [(String, GenParams)] = []
        for (n, v) in ls {
            guard let e = v as? [String: Any], let g = e["gen"] as? [String: Any] else { continue }
            var o = OverlayParams(); o.gen = GenParams()
            var gd = g
            if let ts = g["type"] as? String { gd["type"] = GenType.parse(.s(ts))?.rawValue ?? 0 }
            o.apply(gd)
            out.append((n, o.gen))
        }
        return (out.sorted { $0.0 < $1.0 }, "")
    }
    static func find(_ name: String) -> (String, GenParams)? {
        let k = name.lowercased().filter { $0.isLetter || $0.isNumber }
        return load().looks.first { $0.name.lowercased().filter { $0.isLetter || $0.isNumber } == k }
    }
}

/// Render thread: one generator texture per layer (allocated on first use) and the motion phases.
final class GenRuntime {
    let dev: MTLDevice
    let w: Int, h: Int
    private var tex = [MTLTexture?](repeating: nil, count: compCount)
    private var phase = [Double](repeating: 0, count: 2 * compCount)   // layer i (4 = BG): main i, overlay compCount + i
    private(set) var allocated = 0

    init(dev: MTLDevice, w: Int, h: Int) { self.dev = dev; self.w = w; self.h = h }

    func texture(_ i: Int) -> MTLTexture? {
        if tex[i] == nil {
            let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: w, height: h, mipmapped: false)
            d.usage = [.shaderRead, .shaderWrite]
            d.storageMode = .private
            tex[i] = dev.makeTexture(descriptor: d)
            if tex[i] != nil { allocated += 1; olog("gen: generator texture allocated for \(layerLabel(i)) (\(w)x\(h) rgba16Float, 16 MB)") }
        }
        return tex[i]
    }

    /// The generator kernel's 4 float4. dt = motion time of this frame (0 while frozen, x effect speed); beat = tempo
    /// clock (beats, extrapolated to this frame); link = colour link colour (nil = off); accent = the layer's accent.
    func params(_ i: Int, _ g: GenParams, dt: Double, beat: Double, link: SIMD3<Float>?, accent: SIMD3<Float>) -> [SIMD4<Float>] {
        let rate = 2 * min(1, max(-1, g.speed))                     // periods per second (or per beat when synced)
        if g.beatSync { phase[i] = beat * rate } else { phase[i] = (phase[i] + rate * dt).truncatingRemainder(dividingBy: 4096) }
        let ph = g.beatSync ? phase[i].truncatingRemainder(dividingBy: 4096) : phase[i]
        let a = g.angle * .pi / 180
        func f3(_ v: SIMD3<Double>) -> SIMD3<Float> { SIMD3<Float>(Float(min(1, max(0, v.x))), Float(min(1, max(0, v.y))), Float(min(1, max(0, v.z)))) }
        var cA = SIMD3<Float>(1, 1, 1), cB = cA
        switch g.colorMode {
        case .white: break
        case .link:
            if let l = link { let m = max(l.x, max(l.y, l.z)); cA = m > 0.001 ? l / m : cA; cB = cA }
        case .accent: cA = accent; cB = accent
        case .custom: cA = f3(g.colorA); cB = f3(g.colorB)
        }
        let beatFrac = beat - floor(beat)
        return [SIMD4<Float>(Float(g.type.rawValue), Float(g.elements), Float(min(1, max(0, g.thickness))), Float(min(1, max(0, g.softness)))),
                SIMD4<Float>(Float(ph), Float(cos(a)), Float(sin(a)), Float(min(1, max(0, g.variation)))),
                SIMD4<Float>(cA.x, cA.y, cA.z, Float(beatFrac)),
                SIMD4<Float>(cB.x, cB.y, cB.z, Float(min(1, max(0, g.count))))]
    }

    /// The generator kernel's buffer 0: 10 float4 = main (4), overlay (4), (overlay on, overlay blend mode, overlay
    /// opacity, main gain), (overlay follows the layer transform, -, -, -). An overlay-only pass (clip / fractal layers)
    /// sends the overlay as `main` with gain = its opacity and no overlay.
    static func pack(_ main: [SIMD4<Float>], gain: Float = 1, overlay: [SIMD4<Float>]? = nil, blend: BlendMode = .screen,
                     opacity: Float = 0, follow: Bool = true) -> [SIMD4<Float>] {
        main + (overlay ?? main) + [SIMD4<Float>(overlay != nil ? 1 : 0, Float(blend.rawValue), opacity, gain), SIMD4<Float>(follow ? 1 : 0, 0, 0, 0)]
    }
}

// MARK: - MSL (inserted into shaders.swift, after fxMSL: uses hash21)

let genMSL = """
// ---- generators (src/gen.swift) ----
// Coordinates: p in frame heights (height = 1, centre 0, y up), rotated by the angle. px = one SCREEN pixel in pattern
// units. Every element is drawn with gBand (a band of half width hw around distance 0, antialiased over aa). Output
// premultiplied rgba. The layer transform (2026-10-23) is applied here, not in the composite: X = (x0, x1, edge) as
// fx.swift L_base (pos, cos/sin, scale, flags, tiles, edge on): the screen point is inverse-transformed into the
// pattern, so the pattern fills the whole frame at any angle / position / scale (no corners). The magnification
// m = scale / tiles keeps px one screen pixel and caps the density at 48 elements per screen height (no 1-px detail).
inline float gBand(float d, float hw, float aa) { return 1.0 - smoothstep(hw - aa, hw + aa, d); }
inline float gPar(float k) { return fract(k * 0.5) * 2.0; }                      // 0 / 1 alternating (negatives too)
inline float gDist(float x) { return abs(fract(x + 0.5) - 0.5); }               // distance to the nearest integer
inline float gPoly(float2 p, float n, float rot) {                              // n-gon "apothem" metric (nested n-gons)
    float seg = 6.2831853 / n;
    float a = atan2(p.y, p.x) + rot;
    a = a - seg * floor(a / seg);
    return length(p) * cos(a - 0.5 * seg);
}
// One pattern at q0 (frame heights, centre 0, y up, before the pattern angle): returns (alpha, colour select 0..1).
// g = that pattern's 4 float4 (GenRuntime.params), px = one screen pixel in pattern units, mag = screen px per pattern px.
inline float2 genEval(constant float4* g, float2 q0, float px, float mag) {
    float ca = g[1].y, sa = g[1].z;
    float2 p = float2(ca * q0.x + sa * q0.y, -sa * q0.x + ca * q0.y);           // pattern turns counter-clockwise
    uint type = uint(g[0].x + 0.5);
    float N = clamp(g[0].y, 1.0, max(1.0, 48.0 * min(1.0, mag))), th = g[0].z, soft = g[0].w;
    float ph = g[1].x, vr = g[1].w, cnt = g[3].w;
    float minHw = 1.5 * px;                                                        // lines >= 3 px
    float aa = 0.75 * px + soft * 0.5 / N;
    float r = length(p);
    float a = 0.0, sel = 0.0;
    switch (type) {
        case 0u: {                                                                 // Lines: parallel bars, moving across
            float u = p.y * N + ph, k = floor(u);
            float hw = max(th * 0.5 / N * (gPar(k) > 0.5 ? (1.5 - vr) : 1.0), minHw);
            a = gBand(gDist(u - 0.5) / N, hw, aa); sel = gPar(k);
            break;
        }
        case 1u: {                                                                 // Angles: chevrons / zigzag
            float s = tan(mix(0.1745, 1.2217, vr));                                // 10 .. 70 deg (0.5 = 40 deg)
            float zx = gDist(p.x * N * 0.25) * 4.0 / N;
            float u = (p.y + zx * s) * N + ph, k = floor(u);
            float nrm = sqrt(1.0 + s * s);
            a = gBand(gDist(u - 0.5) / N / nrm, max(th * 0.5 / N / nrm, minHw), aa); sel = gPar(k);
            break;
        }
        case 2u: {                                                                 // Prisms: triangle grid, facet shading
            float2 q = p * N; q.y += ph;
            float a0 = q.y, a1 = dot(q, float2(0.8660254, -0.5)), a2 = dot(q, float2(-0.8660254, -0.5));
            float e = min(min(gDist(a0), gDist(a1)), gDist(a2)) / N;
            float3 id = floor(float3(a0, a1, a2));
            float up = gPar(id.x + id.y + id.z);
            float shade = (0.3 + 0.7 * hash21(id.xy * 0.37 + id.z * 1.13)) * (up > 0.5 ? 1.0 : 0.62);
            float line = gBand(e, max(th * 0.18 / N, minHw), aa);
            float fill = clamp(vr * 1.6 - 0.3, 0.0, 1.0) * shade * smoothstep(0.0, aa * 2.0, e);
            a = line + (1.0 - line) * fill;
            sel = a > 0.0 ? (1.0 - line) * fill / a : 0.0;
            break;
        }
        case 3u: {                                                                 // Circles: concentric rings, moving out
            float ex = exp2((vr - 0.5) * 2.0);                                     // 0.5 = even spacing
            float rn = max(r * 2.0, 1e-4);
            float u = pow(rn, ex) * N - ph, k = floor(u);
            float du = max(N * ex * pow(rn, ex - 1.0) * 2.0, 1e-3), sp = 1.0 / du;
            a = gBand(gDist(u - 0.5) * sp, max(th * 0.5 * sp, minHw), aa) * smoothstep(4.0 * px, 8.0 * px, sp);
            sel = gPar(k);
            break;
        }
        case 4u: {                                                                 // Dots: grid of discs (offset rows)
            float2 q = p * N; q.x += ph;
            float row = floor(q.y);
            q.x += 0.5 * gPar(row);
            float2 id = floor(q), c = fract(q) - 0.5;
            float rad = max(th * 0.5, minHw * N) * (1.0 + (vr - 0.5) * 1.6 * sin(length(id) * 0.8 - ph * 3.1416));
            rad = clamp(rad, minHw * N, 0.5);
            a = 1.0 - smoothstep(-aa, aa, (length(c) - rad) / N); sel = gPar(row);
            break;
        }
        case 5u: {                                                                 // Grid: squares, checker above 0.5
            float2 q = p * N; q.x += ph;
            float dl = min(gDist(q.x), gDist(q.y)) / N;
            float line = gBand(dl, max(th * 0.25 / N, minHw), aa);
            float tx = 1.0 - 4.0 * abs(fract(q.x * 0.5 + 0.25) - 0.5), ty = 1.0 - 4.0 * abs(fract(q.y * 0.5 + 0.25) - 0.5);
            float e2 = 2.0 * N * aa;
            float chk = 0.5 + 0.5 * clamp(tx / e2, -1.0, 1.0) * clamp(ty / e2, -1.0, 1.0);
            float fill = chk * clamp((vr - 0.5) * 2.0, 0.0, 1.0);
            a = line + (1.0 - line) * fill;
            sel = a > 0.0 ? (1.0 - line) * fill / a : 0.0;
            break;
        }
        case 6u: {                                                                 // Polygons: nested n-gons, 3..8 sides
            float n = 3.0 + floor(vr * 5.99);
            float u = gPoly(p, n, 1.5707963) * 2.0 * N - ph, k = floor(u);
            a = gBand(gDist(u - 0.5) / (2.0 * N), max(th * 0.5 / (2.0 * N), minHw), aa); sel = gPar(k);
            break;
        }
        case 7u: {                                                                 // Rays: starburst, turning
            float K = max(3.0, floor(N + 0.5)), tw = (vr - 0.5) * 8.0;
            float ang = atan2(p.y, p.x) / 6.2831853;
            float u = (ang + r * tw) * K + ph * 0.25, k = floor(u);
            float gr = K * sqrt(1.0 / (39.478 * max(r * r, 1e-8)) + tw * tw), sp = 1.0 / gr;
            a = gBand(gDist(u - 0.5) * sp, max(th * 0.5 * sp, minHw), aa) * smoothstep(5.0 * px, 9.0 * px, sp);
            sel = gPar(k);
            break;
        }
        case 8u: {                                                                 // Spiral: 1..6 arms, winding out
            float K = 1.0 + floor(vr * 5.99);
            float ang = atan2(p.y, p.x) / 6.2831853;
            float u = ang * K + r * 2.0 * N * 0.5 - ph, k = floor(u);
            float gr = sqrt(K * K / (39.478 * max(r * r, 1e-8)) + N * N), sp = 1.0 / gr;
            a = gBand(gDist(u - 0.5) * sp, max(th * 0.5 * sp, minHw), aa) * smoothstep(4.0 * px, 8.0 * px, sp);
            sel = gPar(k);
            break;
        }
        case 9u: {                                                                 // Waves: sine bands, travelling
            float amp = vr * 0.2, f = 1.25;
            float s = 6.2831853 * (p.x * f + ph * 0.25);
            float v = p.y + amp * sin(s);
            float sl = amp * 6.2831853 * f * cos(s);
            float u = v * N, k = floor(u);
            a = gBand(gDist(u - 0.5) / N / sqrt(1.0 + sl * sl), max(th * 0.5 / N, minHw), aa); sel = gPar(k);
            break;
        }
        case 10u: {                                                                // Tunnel: rings receding (perspective)
            float e = vr < 0.5 ? mix(1.0, 2.0, vr * 2.0) : mix(2.0, 8.0, (vr - 0.5) * 2.0);   // diamond .. circle .. square
            float2 ap = max(abs(p), float2(1e-5));
            float rr = max(pow(pow(ap.x, e) + pow(ap.y, e), 1.0 / e), 1e-4);
            float kk = N * 0.1;
            float u = kk / rr + ph, k = floor(u);
            float sp = rr * rr / kk;
            a = gBand(gDist(u - 0.5) * sp, max(th * 0.5 * sp, minHw), aa) * smoothstep(4.0 * px, 10.0 * px, sp);
            sel = gPar(k);
            break;
        }
        case 12u: {                                                                // Stars: random scatter in hashed cells
            float Ns = clamp(g[0].y * 3.0, 2.0, 120.0 * min(1.0, mag));            // cells >= 9 screen px
            float2 qq = p * Ns + float2(0.0, 0.0);
            float2 id = floor(qq), f = fract(qq);
            float h1 = hash21(id + 0.17), h2 = hash21(id * 1.31 + 7.7), h3 = hash21(id * 0.73 + 3.1), h4 = hash21(id + float2(9.2, 4.4));
            if (h4 < 0.22) break;                                                  // empty cells: no visible grid
            float2 c = float2(0.3 + 0.4 * h1, 0.3 + 0.4 * h2);
            float dia = mix(2.0, 2.0 + 2.0 * (0.5 + th), h3 * h3);                 // 2 .. 4 px (thickness: bigger)
            float rad = 0.5 * min(dia, 6.0) * px;
            float d = length((f - c) / Ns);
            float aa2 = 0.6 * px + soft * 3.0 * px;
            float b = 1.0 - vr * 0.85 * fract(h4 * 7.13);                           // brightness variance
            float tw = 0.5 + 0.5 * sin(6.2831853 * (ph * (0.4 + h1) + h2 * 7.0));
            a = (1.0 - smoothstep(rad - aa2, rad + aa2, d)) * b * mix(1.0, tw, 0.7);
            sel = h3 > 0.5 ? 1.0 : 0.0;
            break;
        }
        default: {                                                                 // Shapes Burst: expanding on the beat
            float M = 1.0 + floor(cnt * 5.99);
            float idx = floor(vr * 6.99);                                          // 0 circle, 1..6 = 3..8 sides
            float base = floor(ph), fr = ph - base;
            for (int j = 0; j < 6; ++j) {
                if (float(j) >= M) break;
                float age = fr + float(j), id = base - float(j);
                float rad = age / M * 0.75;
                float fade = 1.0 - age / M;
                float m = idx < 0.5 ? r : gPoly(p, 2.0 + idx, hash21(float2(id, 3.7)) * 6.2831853);
                float hw = max(th * 0.03 * (1.0 - 0.5 * age / M), minHw);
                float b = gBand(abs(m - rad), hw, aa) * fade;
                if (b > a) { a = b; sel = gPar(id); }
            }
            break;
        }
    }
    return float2(a, sel);
}
// g: GenRuntime.pack (10 float4): main pattern g[0..3], overlay g[4..7], g[8] = (overlay on, overlay blend, overlay
// opacity, main gain), g[9].x = overlay follows the layer transform (else fixed on screen: no transform, no edge).
// The overlay is composited over the main pattern inside this pass (ovMix: W3C blend over the premultiplied main).
kernel void generator(texture2d<float, access::write> outT [[texture(0)]],
                      constant float4* g [[buffer(0)]],
                      constant float4* X [[buffer(1)]],
                      uint2 gid [[thread_position_in_grid]]) {
    uint w = outT.get_width(), h = outT.get_height();
    if (gid.x >= w || gid.y >= h) return;
    float2 outSz = float2(float(w), float(h));
    float asp = outSz.x / outSz.y;
    float4 x0 = X[0], x1 = X[1];
    float2 fs = (float2(gid) + 0.5) / outSz;
    float2 cc = (fs - 0.5) * float2(asp, 1.0) - x0.xy * float2(asp, 1.0) * 0.5;
    cc = float2(x0.z * cc.x - x0.w * cc.y, x0.w * cc.x + x0.z * cc.y) / max(x1.x, 0.01);
    uint fl = uint(x1.y + 0.5);
    if ((fl & 1u) != 0u) cc.x = -cc.x;
    if ((fl & 2u) != 0u) cc.y = -cc.y;
    float2 lu = cc / float2(asp, 1.0) + 0.5;
    float tn = max(1.0, x1.z);
    if (tn > 1.5) {
        float2 tg = lu * tn, cell = floor(tg);
        lu = fract(tg);
        if ((fl & 4u) != 0u) lu = select(lu, 1.0 - lu, fmod(cell, 2.0) != 0.0);
    }
    float mag = max(x1.x, 0.01) / tn;                                              // screen px per pattern px
    float edgeA = x1.w > 0.5 ? edgeAlpha(lu, outSz, mag, X[2]) : 1.0;
    float px = 1.0 / (float(h) * mag);
    float2 q0 = (lu - 0.5) * float2(asp, 1.0);
    q0.y = -q0.y;
    float4 S = float4(0.0);
    uint np = g[8].x > 0.5 ? 2u : 1u;
    for (uint k = 0u; k < np; ++k) {                                               // one copy of genEval: main, then the overlay
        constant float4* gg = g + 4u * k;
        float2 q = q0; float pk = px, mk = mag, ek = edgeA, gain = g[8].w;
        if (k == 1u) {
            gain = g[8].z;
            if (g[9].x < 0.5) { q = (fs - 0.5) * float2(asp, 1.0); q.y = -q.y; pk = 1.0 / float(h); mk = 1.0; ek = 1.0; }
        }
        if (ek * gain <= 0.0) continue;
        float2 e = genEval(gg, q, pk, mk);
        float ak = clamp(e.x, 0.0, 1.0) * ek * gain;
        float4 C = float4(mix(gg[2].xyz, gg[3].xyz, clamp(e.y, 0.0, 1.0)) * ak, ak);
        S = k == 0u ? C : ovMix(S, C, uint(g[8].y + 0.5));
    }
    outT.write(S, gid);
}

"""

// MARK: - control helpers (OSC and DMX)

extension Control {
    /// Layer li (0-based) shows source s. Fractal: latest move wins, this layer takes the one fractal; a layer that
    /// gives up the fractal sends it back to the base layer 0. Returns a log fragment.
    mutating func setSource(_ li: Int, _ s: LayerSource) -> String {
        if s == .fractal { dropLayerTurn(li) }
        if li == bgIndex {                                  // BG (L0): Fractal = the fractal comes home to the base layer
            layers[li].source = s
            if s == .fractal {
                let prev = fractalLayer
                fractalLayer = 0
                return "BG source fractal" + (prev == 0 ? "" : " (fractal moves from layer \(prev): layer \(prev) shows nothing until re-selected)")
            }
            return "BG source \(s.rawValue)" + (fractalLayer == 0 ? " (the fractal is not shown anywhere now: put it on a layer or back on BG)" : "")
        }
        let n = li + 1
        layers[li].source = s
        if s == .fractal {
            let prev = fractalLayer
            fractalLayer = n
            if prev == n { return "layer \(n) source fractal (already on it)" }
            return "layer \(n) source fractal (fractal moves " + (prev == 0 ? "from the base layer 0" : "from layer \(prev): layer \(prev) shows nothing until re-selected") + ")"
        }
        if fractalLayer == n { fractalLayer = 0; return "layer \(n) source \(s.rawValue) (fractal back to the base layer 0" + (layers[bgIndex].source == .fractal ? ")" : ": BG shows its own \(layers[bgIndex].source.rawValue), so the fractal is not shown)") }
        return "layer \(n) source \(s.rawValue)"
    }
    /// The fractal has ONE rotation / spin (Deep zoom > Movement, inside the formula): a layer that takes the fractal drops
    /// its own transform rotation, spin and a rotation beat move (the other transform values stay), so the two never stack.
    mutating func dropLayerTurn(_ li: Int) {
        guard li >= 0 && li < layers.count else { return }
        var f = layers[li].fx
        if f.rotation == 0 && f.spin == 0 && f.modTarget != .rotation { return }
        f.rotation = 0; f.spin = 0
        if f.modTarget == .rotation { f.modTarget = .none }
        f.resetSeq += 1                                     // zeroes the accumulated spin angle (fx.swift)
        layers[li].fx = f
    }
    /// Sends the fractal to layer n (1..4: that layer's source becomes fractal) or to the base layer 0.
    mutating func setFractalLayer(_ n: Int) -> String {
        if n >= 1 && n <= layerCount { return setSource(n - 1, .fractal) }
        let prev = fractalLayer
        fractalLayer = 0
        let was = layers[bgIndex].source
        layers[bgIndex].source = .fractal                   // the base layer shows it again
        dropLayerTurn(bgIndex)
        return (prev == 0 ? "fractal on the base layer 0" + (was == .fractal ? " (already)" : " (BG source \(was.rawValue) -> fractal)") : "fractal to the base layer 0 (layer \(prev) still says fractal: it shows nothing until re-selected)")
    }
}

// MARK: - `oats-m0 --shader-check`: compile the MSL, run every generator once at 1920x1080 (GPU ms, mean coverage)

/// IEEE half -> Double (Float16 is not available on x86_64 macOS).
func halfToDouble(_ hb: UInt16) -> Double {
    let e = Int((hb >> 10) & 0x1f), m = Double(hb & 0x3ff), sg = hb & 0x8000 != 0 ? -1.0 : 1.0
    if e == 0 { return sg * m * pow(2, -24) }
    if e == 31 { return m == 0 ? sg * .infinity : .nan }
    return sg * (1 + m / 1024) * pow(2, Double(e - 15))
}

func shaderCheck() -> Int32 {
    guard let d = MTLCreateSystemDefaultDevice(), let q = d.makeCommandQueue() else { print("FAIL: no Metal device"); return 1 }
    let t0 = nowTicks()
    let lib: MTLLibrary
    do { lib = try d.makeLibrary(source: shaderSource, options: nil) } catch { print("FAIL: shader compile: \(error)"); return 1 }
    print(String(format: "MSL compiled in %.0f ms on %@", ticksToSec(nowTicks() &- t0) * 1000, d.name))
    var fails = 0
    for k in ["composite", "composite_fx", "generator", "mandel_pert", "master_fx", "to_uyvy", "testcard"] where lib.makeFunction(name: k) == nil { print("FAIL: no kernel \(k)"); fails += 1 }
    guard let f = lib.makeFunction(name: "generator"), let p = try? d.makeComputePipelineState(function: f) else { print("FAIL: generator pipeline"); return 1 }
    let w = 1920, h = 1080
    let td = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: w, height: h, mipmapped: false)
    td.usage = [.shaderRead, .shaderWrite]
    td.storageMode = .shared
    guard let t = d.makeTexture(descriptor: td) else { print("FAIL: texture"); return 1 }
    let rt = GenRuntime(dev: d, w: w, h: h)
    let tg = MTLSize(width: p.threadExecutionWidth, height: p.maxTotalThreadsPerThreadgroup / p.threadExecutionWidth, depth: 1)
    var buf = [UInt16](repeating: 0, count: w * h * 4)
    for ty in GenType.allCases {
        var g = GenParams(); g.type = ty
        var gp = GenRuntime.pack(rt.params(0, g, dt: 0.37, beat: 1.37, link: nil, accent: SIMD3<Float>(1, 0, 1)))
        var ms = 0.0
        for _ in 0..<3 {                                   // first run warms the pipeline
            guard let cb = q.makeCommandBuffer(), let enc = cb.makeComputeCommandEncoder() else { return 1 }
            enc.setComputePipelineState(p); enc.setTexture(t, index: 0)
            enc.setBytes(&gp, length: MemoryLayout<SIMD4<Float>>.stride * gp.count, index: 0)
            var gx: [SIMD4<Float>] = [SIMD4<Float>(0, 0, cos(0.7), sin(0.7)), SIMD4<Float>(1, 0, 1, 0), SIMD4<Float>(0, 0, 0, 0)]   // turned 40 deg
            enc.setBytes(&gx, length: MemoryLayout<SIMD4<Float>>.stride * 3, index: 1)
            enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tg)
            enc.endEncoding(); cb.commit(); cb.waitUntilCompleted()
            ms = (cb.gpuEndTime - cb.gpuStartTime) * 1000
        }
        t.getBytes(&buf, bytesPerRow: w * 8, from: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0)
        var sum = 0.0, n = 0
        for i in stride(from: 3, to: buf.count, by: 4 * 97) { sum += halfToDouble(buf[i]); n += 1 }
        let cov = sum / Double(max(1, n))
        let ok = ty == .stars ? cov > 0.0003 && cov < 0.5 : cov > 0.02 && cov < 0.98
        if !ok { fails += 1 }
        print(String(format: "  %@ %-13@ GPU %.2f ms, mean coverage %.2f", ok ? "ok  " : "FAIL", ty.name as NSString, ms, cov))
    }
    // overlay inline (Lines + overlay Rays screen 0.6, follow): the same pass, one more pattern evaluation
    do {
        var g = GenParams(); g.type = .lines
        var o = GenParams(); o.type = .rays
        var gp = GenRuntime.pack(rt.params(0, g, dt: 0.37, beat: 1.37, link: nil, accent: SIMD3<Float>(1, 0, 1)),
                                 overlay: rt.params(layerCount, o, dt: 0.37, beat: 1.37, link: nil, accent: SIMD3<Float>(1, 0, 1)),
                                 blend: .screen, opacity: 0.6, follow: true)
        var ms = 0.0
        for _ in 0..<3 {
            guard let cb = q.makeCommandBuffer(), let enc = cb.makeComputeCommandEncoder() else { return 1 }
            enc.setComputePipelineState(p); enc.setTexture(t, index: 0)
            enc.setBytes(&gp, length: MemoryLayout<SIMD4<Float>>.stride * gp.count, index: 0)
            var gx: [SIMD4<Float>] = [SIMD4<Float>(0, 0, cos(0.7), sin(0.7)), SIMD4<Float>(1, 0, 1, 0), SIMD4<Float>(0, 0, 0, 0)]
            enc.setBytes(&gx, length: MemoryLayout<SIMD4<Float>>.stride * 3, index: 1)
            enc.dispatchThreads(MTLSize(width: w, height: h, depth: 1), threadsPerThreadgroup: tg)
            enc.endEncoding(); cb.commit(); cb.waitUntilCompleted()
            ms = (cb.gpuEndTime - cb.gpuStartTime) * 1000
        }
        t.getBytes(&buf, bytesPerRow: w * 8, from: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0)
        var sum = 0.0, n = 0
        for i in stride(from: 3, to: buf.count, by: 4 * 97) { sum += halfToDouble(buf[i]); n += 1 }
        let cov = sum / Double(max(1, n)), ok = cov > 0.02 && cov < 0.99
        if !ok { fails += 1 }
        print(String(format: "  %@ Lines+overlay Rays GPU %.2f ms, mean coverage %.2f", ok ? "ok  " : "FAIL", ms, cov))
    }
    if outputShaderCheck(d) { print("  ok   output window render pipeline") } else { fails += 1 }
    // FX kernels: the composite_fx variant with every stage (Trails + Star/Warp/SpiralTrails included) and master_fx
    do {
        let cv = MTLFunctionConstantValues()
        for k in 0..<4 { var b = true; cv.setConstantValue(&b, type: .bool, index: k) }
        _ = try d.makeComputePipelineState(function: try lib.makeFunction(name: "composite_fx", constantValues: cv))
        guard let mf = lib.makeFunction(name: "master_fx") else { throw NSError(domain: "oats", code: 1) }
        _ = try d.makeComputePipelineState(function: mf)
        print("  ok   composite_fx (all stages) + master_fx pipelines")
    } catch { print("FAIL: FX pipelines: \(error)"); fails += 1 }
    print(fails == 0 ? "PASS: shaders compile, \(GenType.allCases.count) generators draw" : "FAIL: \(fails)")
    return fails == 0 ? 0 : 1
}
