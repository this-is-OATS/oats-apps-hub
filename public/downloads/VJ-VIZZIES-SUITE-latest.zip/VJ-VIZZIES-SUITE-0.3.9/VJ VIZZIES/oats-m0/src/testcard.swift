import Foundation
import Metal
import CoreGraphics
import CoreText
import CoreImage

// Test cards (2026-10-23): output content drawn by the player at canvas resolution (content "testcard" / "ndicard",
// OSC /oats/test/content s test|ndi, DMX Master 16 ch 15 bands 30 / 40, GUI Master > Test content).
//  - Procedural parts (bars, wedges, grid, circle, markers, sweep bar, 7-segment time-of-day clock) in the `testcard`
//    kernel, every frame: one cheap full-frame pass instead of the layer composite.
//  - Text and the QR code: drawn with CoreText / CoreGraphics into an rgba8 overlay on a utility queue, about once a
//    second (only when a line changed), double-buffered; the kernel blends it on top. No per-frame CPU drawing.
// No 1-pixel detail anywhere (the finest wedge is 2 px lines; the old native NDI freeze came from 1-px detail).
// Startup card: on a cold start (no --restart) the output shows --startup-card (default test) until the first control
// input (OSC from a person / the GUI, a DMX change after the first packet, a scene go) or --startup-card-secs.

final class StartupCard {
    private let lock = NSLock()
    private var card: Content? = nil
    private var configured = "off", endedBy = "", restart = false
    private var secs = 0.0, t0 = 0.0
    func begin(_ cfg: Config) {
        lock.lock()
        configured = cfg.startupCard.isCard ? cfg.startupCard.short : "off"
        restart = cfg.restart; secs = cfg.startupCardSecs; t0 = ticksToSec(nowTicks() &- gStartTicks)
        card = cfg.restart || !cfg.startupCard.isCard ? nil : cfg.startupCard
        endedBy = cfg.restart ? "restart (--restart: watchdog / crash / supervisor restart)" : (card == nil ? "off" : "")
        let c = card
        lock.unlock()
        if let c = c { olog("startup card: \(c.short) card until the first control input" + (secs > 0 ? String(format: " or %.0f s", secs) : "")) }
        else if cfg.restart { olog("startup card: none (--restart)") }
    }
    /// The card to show now (nil = normal content). Render thread, every frame.
    func current(t: Double) -> Content? {
        lock.lock()
        if card != nil && secs > 0 && t - t0 >= secs { card = nil; endedBy = String(format: "timeout %.0f s", secs); lock.unlock(); olog("startup card: ended (timeout)"); return nil }
        let c = card
        lock.unlock()
        return c
    }
    var waiting: Bool { lock.lock(); defer { lock.unlock() }; return card != nil }
    /// A control input: ends the startup card (no-op after that).
    func input(_ what: String) {
        lock.lock()
        guard card != nil else { lock.unlock(); return }
        card = nil; endedBy = what
        lock.unlock()
        olog("startup card: ended by \(what): normal content")
    }
    var statusDict: [String: Any] {
        lock.lock(); defer { lock.unlock() }
        return ["card": configured, "waiting": card != nil, "showing": card?.short ?? "", "ended_by": endedBy, "secs": secs, "restart": restart]
    }
}
let gStartup = StartupCard()

/// OSC addresses that are not a person's control input (helpers, polling, automatic requests).
func oscIsInternal(_ addr: String) -> Bool {
    addr == "/oats/tempo/link" || addr == "/oats/system/ping" || addr == "/oats/system/snapshot" || addr == "/oats/output/snapshot" || addr == "/oats/library/reload"
        || addr == "/cmd" || addr.hasPrefix("/cmd/") || addr.hasPrefix("/oats/analysis/")
}

/// The NDI source name receivers list: "<LOCALHOSTNAME>.LOCAL (<name>)" (README: Vision shows "OBSHOST.LOCAL (…)").
private var cachedHost: String? = nil
func ndiFullName(_ name: String) -> String {
    if cachedHost == nil {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/sbin/scutil")
        p.arguments = ["--get", "LocalHostName"]
        let pipe = Pipe()
        p.standardOutput = pipe; p.standardError = FileHandle.nullDevice
        var hn = ""
        if (try? p.run()) != nil {
            p.waitUntilExit()
            hn = String(decoding: pipe.fileHandleForReading.readDataToEndOfFile(), as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        if hn.isEmpty { hn = ProcessInfo.processInfo.hostName.components(separatedBy: ".").first ?? "MAC" }
        cachedHost = hn.uppercased() + ".LOCAL"
    }
    return "\(cachedHost!) (\(name))"
}

final class TestCards {
    let dev: MTLDevice
    let w: Int, h: Int
    let cfg: Config
    private var tex: [MTLTexture] = []
    private let lock = NSLock()
    private var cur = -1, curKind: Content? = nil, busy = false, lastReq = -10.0, lastKey = ""
    private let q = DispatchQueue(label: "testcard", qos: .utility)
    private var qrFor = "", qr: CGImage? = nil
    private(set) var frame: UInt32 = 0

    init(dev: MTLDevice, w: Int, h: Int, cfg: Config) { self.dev = dev; self.w = w; self.h = h; self.cfg = cfg }

    /// Render thread, every card frame: the ready overlay for this card (nil until the first one is drawn) and the
    /// kernel's float4. A new overlay is requested at most once a second.
    func frameParams(kind: Content, t: Double) -> (p: SIMD4<Float>, overlay: MTLTexture?) {
        frame &+= 1
        lock.lock()
        let need = !busy && (curKind != kind || t - lastReq >= 1.0)
        let ready: MTLTexture? = curKind == kind && cur >= 0 ? tex[cur] : nil
        if need { busy = true; lastReq = t }
        lock.unlock()
        if need { q.async { [self] in build(kind) } }
        let sweep = (t / 2.0).truncatingRemainder(dividingBy: 1)
        let sw = sweep < 0.5 ? sweep * 2 : 2 - sweep * 2           // back and forth, 2 s per pass
        // 2026-10-24: the 7-segment readout is the time of day (HHMMSS, local), not a frame counter: a card left on
        // screen should say what time it is, and the operator asked for it.
        var tt = time(nil); var tmv = tm(); localtime_r(&tt, &tmv)
        let hms = UInt32(tmv.tm_hour) * 10_000 + UInt32(tmv.tm_min) * 100 + UInt32(tmv.tm_sec)
        // standby (kind 2): y = the animation time in seconds (wraps hourly) instead of the clock
        let k: Float = kind == .ndicard ? 1 : (kind == .standby ? 2 : 0)
        let y = kind == .standby ? Float(t.truncatingRemainder(dividingBy: 3600)) : Float(hms)
        return (SIMD4<Float>(k, y, Float(sw), ready != nil ? 1 : 0), ready)
    }

    // MARK: overlay (utility queue)

    private func lines(_ kind: Content) -> [String: String] {
        if kind == .standby { return [:] }                    // the logo never changes: drawn once
        let df = DateFormatter(); df.dateFormat = "HH:mm:ss"
        let fps = abs(cfg.fps - 59.94) < 0.01 ? "59.94" : (abs(cfg.fps - 29.97) < 0.01 ? "29.97" : String(format: "%.0f", cfg.fps))
        var d: [String: String] = ["time": df.string(from: Date()), "res": "\(w) × \(h) · \(fps) fps", "name": ndiFullName(cfg.name)]
        if kind == .ndicard {
            let nd = gNDIOut?.statusDict() ?? ["mode": "off"]
            let mode = nd["mode"] as? String ?? "off", sending = nd["sending"] as? Bool ?? false
            let conns = nd["connections"] as? Int ?? gNDI.connections
            let names = ((nd["receivers"] as? [String]) ?? gNDI.products).filter { !$0.isEmpty }
            let ip = en0Networks().first.map { ipv4Text($0.addr) } ?? ""
            let net = ip.split(separator: ".").prefix(3).joined(separator: ".")
            d["mode"] = "NDI mode \(mode)" + (mode == "off" ? " (NDI is off)" : (sending ? " · sending" : " · not sending"))
            d["rx"] = "Receivers connected: \(conns)" + (names.isEmpty ? (conns == 0 ? " (none yet)" : "") : " · " + names.prefix(4).joined(separator: ", "))
            d["net"] = ip.isEmpty ? "Mac en0: no IPv4 address (check the cable) · NDI group "
                + (cfg.groups.isEmpty ? "Public" : cfg.groups)
                : "Mac en0 \(ip) · NDI group \(cfg.groups.isEmpty ? "Public" : cfg.groups) · the receiver must be on \(net).x"
            d["url"] = ip.isEmpty ? "" : "http://\(ip):\(cfg.guiPort)"
        }
        return d
    }

    private func build(_ kind: Content) {
        let L = lines(kind)
        let key = kind.rawValue + "|" + L.keys.sorted().map { "\($0)=\(L[$0]!)" }.joined(separator: "|")
        lock.lock(); let same = key == lastKey && curKind == kind; lock.unlock()
        if same { lock.lock(); busy = false; lock.unlock(); return }
        if tex.isEmpty {
            let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba8Unorm, width: w, height: h, mipmapped: false)
            d.usage = [.shaderRead]
            d.storageMode = .shared
            for _ in 0..<2 { if let t = dev.makeTexture(descriptor: d) { tex.append(t) } }
            if tex.count < 2 { tex = []; lock.lock(); busy = false; lock.unlock(); return }
            olog("testcard: text overlay textures allocated (2 x \(w)x\(h) rgba8, \((2 * w * h * 4) >> 20) MB)")
        }
        let t0 = nowTicks()
        guard let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                  space: CGColorSpace(name: CGColorSpace.sRGB)!, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            lock.lock(); busy = false; lock.unlock(); return
        }
        // a 1920x1080 virtual frame, as large as fits, centred on the canvas (mapping.swift: any canvas aspect)
        let s = min(CGFloat(w) / 1920, CGFloat(h) / 1080), W: CGFloat = 1920
        let ox = (CGFloat(w) - 1920 * s) / 2, oy = (CGFloat(h) - 1080 * s) / 2
        ctx.translateBy(x: ox, y: CGFloat(h) - oy); ctx.scaleBy(x: s, y: -s)   // 1920x1080 virtual pixels, y down
        ctx.textMatrix = CGAffineTransform(scaleX: 1, y: -1)
        if kind == .testcard { drawTest(ctx, W, L) } else if kind == .standby { drawStandby(ctx, W) } else { drawNDI(ctx, W, L) }
        guard let data = ctx.data else { lock.lock(); busy = false; lock.unlock(); return }
        lock.lock(); let next = cur < 0 ? 0 : 1 - cur; lock.unlock()
        tex[next].replace(region: MTLRegionMake2D(0, 0, w, h), mipmapLevel: 0, withBytes: data, bytesPerRow: w * 4)
        lock.lock(); cur = next; curKind = kind; lastKey = key; busy = false; lock.unlock()
        let ms = ticksToSec(nowTicks() &- t0) * 1000
        if ms > 40 { olog(String(format: "testcard: overlay drawn in %.0f ms (utility queue)", ms)) }
    }

    private func col(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, _ a: CGFloat = 1) -> CGColor { CGColor(srgbRed: r, green: g, blue: b, alpha: a) }

    /// Text with its top at y; align 0 left / 1 centre / 2 right of x; shrinks to maxW. Returns the drawn width.
    @discardableResult
    private func text(_ ctx: CGContext, _ s: String, x: CGFloat, y: CGFloat, size: CGFloat, bold: Bool = false, color: CGColor,
                      align: Int = 0, maxW: CGFloat = 0) -> CGFloat {
        func line(_ sz: CGFloat) -> (CTLine, CGFloat, CGFloat) {
            let font = CTFontCreateUIFontForLanguage(bold ? .emphasizedSystem : .system, sz, nil)!
            let a = NSAttributedString(string: s, attributes: [NSAttributedString.Key(kCTFontAttributeName as String): font,
                                                               NSAttributedString.Key(kCTForegroundColorAttributeName as String): color])
            let l = CTLineCreateWithAttributedString(a)
            var asc: CGFloat = 0, desc: CGFloat = 0, lead: CGFloat = 0
            let wd = CGFloat(CTLineGetTypographicBounds(l, &asc, &desc, &lead))
            return (l, wd, asc)
        }
        var (l, wd, asc) = line(size)
        if maxW > 0 && wd > maxW { (l, wd, asc) = line(size * maxW / wd) }
        let x0 = align == 1 ? x - wd / 2 : (align == 2 ? x - wd : x)
        ctx.textPosition = CGPoint(x: x0, y: y + asc)
        CTLineDraw(l, ctx)
        return wd
    }
    private func panel(_ ctx: CGContext, _ r: CGRect, _ c: CGColor, radius: CGFloat = 14) {
        ctx.setFillColor(c)
        ctx.addPath(CGPath(roundedRect: r, cornerWidth: radius, cornerHeight: radius, transform: nil))
        ctx.fillPath()
    }

    private func drawTest(_ ctx: CGContext, _ W: CGFloat, _ L: [String: String]) {
        let cx = W / 2, white = col(1, 1, 1), dark = col(0.02, 0.03, 0.06, 0.88)
        panel(ctx, CGRect(x: cx - 330, y: 30, width: 660, height: 112), dark)
        text(ctx, "VJ VIZZIES", x: cx, y: 38, size: 78, bold: true, color: white, align: 1)
        text(ctx, "TEST CARD", x: cx, y: 118, size: 18, bold: true, color: col(0.65, 0.55, 0.98), align: 1)
        for (k, lw) in [2, 3, 4, 6, 8].enumerated() {                       // wedge labels (black strip 560-585)
            text(ctx, "\(lw) px lines", x: cx - 720 + 288 * CGFloat(k) + 144, y: 562, size: 17, bold: true, color: white, align: 1)
        }
        text(ctx, "TIME", x: cx - 272, y: 744, size: 22, bold: true, color: col(0.2, 1, 0.45), align: 2)
        panel(ctx, CGRect(x: cx - 520, y: 806, width: 1040, height: 116), dark)
        text(ctx, (L["res"] ?? "") + " · " + (L["name"] ?? ""), x: cx, y: 814, size: 28, bold: true, color: white, align: 1, maxW: 1000)
        text(ctx, L["time"] ?? "", x: cx, y: 852, size: 56, bold: true, color: white, align: 1)
    }

    // MARK: standby card (2026-11-02): the app logo as the GUI draws it, VJ  ◆◆◆  VIZZIES, for the audience.
    // Drawn once here; the kernel animates it: VIZZIES' white letters take the flowing L1..L4 gradient, VJ gets rolling
    // scanlines, a shine crosses every 12 s and the soft glow (the shadow's low alpha) breathes on 4 s.
    private func sysFont(_ size: CGFloat, weight: CGFloat) -> CTFont {
        let base = CTFontCreateUIFontForLanguage(.system, size, nil)!
        let attrs: [CFString: Any] = [kCTFontFamilyNameAttribute: CTFontCopyFamilyName(base),
                                      kCTFontTraitsAttribute: [kCTFontWeightTrait: weight] as CFDictionary]
        return CTFontCreateWithFontDescriptor(CTFontDescriptorCreateWithAttributes(attrs as CFDictionary), size, nil)
    }
    private func logoLine(_ s: String, font: CTFont, kern: CGFloat, color: CGColor) -> (CTLine, CGFloat, CGFloat) {
        let a = NSAttributedString(string: s, attributes: [NSAttributedString.Key(kCTFontAttributeName as String): font,
                                                           NSAttributedString.Key(kCTForegroundColorAttributeName as String): color,
                                                           NSAttributedString.Key(kCTKernAttributeName as String): kern])
        let l = CTLineCreateWithAttributedString(a)
        var asc: CGFloat = 0, desc: CGFloat = 0, lead: CGFloat = 0
        let wd = CGFloat(CTLineGetTypographicBounds(l, &asc, &desc, &lead)) - kern    // no trailing kern after the last letter
        return (l, wd, asc)
    }
    private func drawStandby(_ ctx: CGContext, _ W: CGFloat) {
        let size: CGFloat = 200, cy: CGFloat = 540
        let vj = logoLine("VJ", font: sysFont(size, weight: 0.62), kern: size * 0.11, color: col(0.2, 1, 0.4))
        let vz = logoLine("VIZZIES", font: sysFont(size, weight: -0.4), kern: size * 0.25, color: col(1, 1, 1))
        let dia = size * 0.22, gapD = size * 0.08, colW = dia * 1.42, pad = size * 0.33
        let total = vj.1 + pad + colW + pad + vz.1, x0 = (W - total) / 2
        let capH = CTFontGetCapHeight(sysFont(size, weight: 0.62)), base = cy + capH / 2   // cap height centred on the frame
        func draw(_ l: (CTLine, CGFloat, CGFloat), _ x: CGFloat, glow: CGColor) {
            ctx.saveGState(); ctx.setShadow(offset: .zero, blur: 46, color: glow)
            ctx.textPosition = CGPoint(x: x, y: base); CTLineDraw(l.0, ctx); ctx.restoreGState()
        }
        draw(vj, x0, glow: col(0.2, 1, 0.4, 0.75))
        draw(vz, x0 + vj.1 + pad + colW + pad, glow: col(0.65, 0.55, 0.98, 0.85))
        // three diamonds in a column, cyan to magenta, with a magenta glow (centred on the cap height)
        let dcx = x0 + vj.1 + pad + colW / 2, step = dia * 1.42 + gapD, top = cy - step
        let grad = CGGradient(colorsSpace: CGColorSpace(name: CGColorSpace.sRGB)!, colors: [col(0.22, 0.85, 1), col(0.88, 0.36, 1)] as CFArray, locations: [0, 1])!
        for k in 0..<3 {
            let c = CGPoint(x: dcx, y: top + CGFloat(k) * step), r = dia * 0.71
            let path = CGMutablePath(); path.move(to: CGPoint(x: c.x, y: c.y - r)); path.addLine(to: CGPoint(x: c.x + r, y: c.y))
            path.addLine(to: CGPoint(x: c.x, y: c.y + r)); path.addLine(to: CGPoint(x: c.x - r, y: c.y)); path.closeSubpath()
            ctx.saveGState(); ctx.setShadow(offset: .zero, blur: 30, color: col(0.88, 0.36, 1, 0.7))
            ctx.setFillColor(col(0.55, 0.6, 1)); ctx.addPath(path); ctx.fillPath(); ctx.restoreGState()
            ctx.saveGState(); ctx.addPath(path); ctx.clip()
            ctx.drawLinearGradient(grad, start: CGPoint(x: c.x - r, y: c.y - r), end: CGPoint(x: c.x + r, y: c.y + r), options: [])
            ctx.restoreGState()
        }
    }

    private func drawNDI(_ ctx: CGContext, _ W: CGFloat, _ L: [String: String]) {
        let white = col(1, 1, 1), dim = col(0.62, 0.68, 0.82), violet = col(0.65, 0.55, 0.98), cyan = col(0.13, 0.83, 0.93)
        text(ctx, "VJ VIZZIES · NDI SETUP", x: 80, y: 46, size: 30, bold: true, color: violet)
        text(ctx, L["time"] ?? "", x: W - 80, y: 46, size: 30, bold: true, color: dim, align: 2)
        text(ctx, "NDI SOURCE NAME", x: 80, y: 116, size: 24, bold: true, color: dim)
        text(ctx, L["name"] ?? "", x: 80, y: 146, size: 84, bold: true, color: white, maxW: W - 160)
        text(ctx, (L["res"] ?? "") + " · " + (L["mode"] ?? ""), x: 80, y: 268, size: 32, color: white, maxW: W - 160)
        text(ctx, L["rx"] ?? "", x: 80, y: 316, size: 32, color: white, maxW: W - 160)
        text(ctx, L["net"] ?? "", x: 80, y: 364, size: 32, color: cyan, maxW: W - 160)
        ctx.setFillColor(col(1, 1, 1, 0.12)); ctx.fill(CGRect(x: 80, y: 438, width: W - 160, height: 2))
        let steps: [(String, String)] = [
            ("Vectorworks Vision", "Video screen › Source: NDI › pick the name above › Bandwidth: Low"),
            ("OBS", "Sources › + › NDI Source › pick the name above"),
            ("OSEE GoStream", "Input › NDI › pick the name above (GoStream Deck: needs the NDI licence)"),
            ("NDI Studio Monitor", "Menu › pick the name above"),
        ]
        for (i, st) in steps.enumerated() {
            let y = 466 + CGFloat(i) * 104
            panel(ctx, CGRect(x: 80, y: y, width: 44, height: 44), violet, radius: 22)
            text(ctx, "\(i + 1)", x: 102, y: y + 6, size: 28, bold: true, color: col(0.04, 0.05, 0.12), align: 1)
            text(ctx, st.0, x: 146, y: y - 2, size: 32, bold: true, color: white, maxW: 1150)
            text(ctx, st.1, x: 146, y: y + 40, size: 26, color: dim, maxW: 1150)
        }
        // controls URL + QR (CoreImage CIQRCodeGenerator, drawn with whole-pixel modules, no smoothing)
        let url = L["url"] ?? ""
        let qx: CGFloat = 1440, qy: CGFloat = 466, qs: CGFloat = 380
        if !url.isEmpty {
            if qrFor != url { qr = TestCards.qrImage(url); qrFor = url }
            panel(ctx, CGRect(x: qx, y: qy, width: qs, height: qs), white, radius: 10)
            if let img = qr {
                let m = CGFloat(img.width), side = floor((qs - 40) / m) * m, o = (qs - side) / 2
                ctx.saveGState()
                ctx.interpolationQuality = .none
                ctx.translateBy(x: qx + o, y: qy + o + side); ctx.scaleBy(x: 1, y: -1)
                ctx.draw(img, in: CGRect(x: 0, y: 0, width: side, height: side))
                ctx.restoreGState()
            }
            text(ctx, "Controls (phone / laptop on this network)", x: qx + qs / 2, y: qy + qs + 14, size: 22, color: dim, align: 1, maxW: 440)
            text(ctx, url, x: qx + qs / 2, y: qy + qs + 44, size: 32, bold: true, color: white, align: 1, maxW: 440)
        }
        text(ctx, "Moving bar and counter: if they stop, the feed is frozen.", x: 80, y: 976, size: 22, color: dim, maxW: 1200)
    }

    static func qrImage(_ s: String) -> CGImage? {
        guard let f = CIFilter(name: "CIQRCodeGenerator") else { return nil }
        f.setValue(s.data(using: .utf8), forKey: "inputMessage")
        f.setValue("M", forKey: "inputCorrectionLevel")
        guard let img = f.outputImage else { return nil }
        return CIContext(options: [.useSoftwareRenderer: true]).createCGImage(img, from: img.extent)
    }
}

// MARK: - MSL (inserted into shaders.swift)

let testcardMSL = """
// ---- test cards (src/testcard.swift) ----
constant uint kSeg7[10] = { 0x3Fu, 0x06u, 0x5Bu, 0x4Fu, 0x66u, 0x6Du, 0x7Du, 0x07u, 0x7Fu, 0x6Fu };
constant float3 kBars[8] = { float3(0.75), float3(0.75, 0.75, 0.0), float3(0.0, 0.75, 0.75), float3(0.0, 0.75, 0.0),
                             float3(0.75, 0.0, 0.75), float3(0.75, 0.0, 0.0), float3(0.0, 0.0, 0.75), float3(0.0) };
inline float tcSeg(float2 q, uint d) {                 // q: 0..1 inside the digit cell (y down)
    uint m = kSeg7[d % 10u];
    float t = 0.14;
    bool on = false;
    on = on || ((m & 1u) != 0u && q.y < t && q.x > t && q.x < 1.0 - t);
    on = on || ((m & 2u) != 0u && q.x > 1.0 - t && q.y > 0.5 * t && q.y < 0.5);
    on = on || ((m & 4u) != 0u && q.x > 1.0 - t && q.y > 0.5 && q.y < 1.0 - 0.5 * t);
    on = on || ((m & 8u) != 0u && q.y > 1.0 - t && q.x > t && q.x < 1.0 - t);
    on = on || ((m & 16u) != 0u && q.x < t && q.y > 0.5 && q.y < 1.0 - 0.5 * t);
    on = on || ((m & 32u) != 0u && q.x < t && q.y > 0.5 * t && q.y < 0.5);
    on = on || ((m & 64u) != 0u && abs(q.y - 0.5) < 0.5 * t && q.x > t && q.x < 1.0 - t);
    return on ? 1.0 : 0.0;
}
inline bool tcIn(float2 P, float x0, float y0, float x1, float y1) { return P.x >= x0 && P.x < x1 && P.y >= y0 && P.y < y1; }
inline float tcCounter(float2 P, float x0, float y0, float cw, float ch, float g, uint v, uint n) {
    float cx = P.x - x0, cy = P.y - y0;
    if (cy < 0.0 || cy >= ch || cx < 0.0) return 0.0;
    uint k = uint(cx / (cw + g));
    if (k >= n) return 0.0;
    float lx = cx - float(k) * (cw + g);
    if (lx >= cw) return 0.0;
    uint pw = 1u;
    for (uint j = 0u; j + 1u + k < n; ++j) pw *= 10u;
    return tcSeg(float2(lx / cw, cy / ch), (v / pw) % 10u);
}
// HH:MM:SS in 7-segment digits: three 2-digit groups with a colon cell (half a digit wide) between them.
// Total width 7*cw + 7*g, so it sits where the 7-digit counter did.
inline float tcClock(float2 P, float x0, float y0, float cw, float ch, float g, uint hms) {
    float gw = 2.0 * cw + g, colw = 0.5 * cw, pitch = gw + g + colw + g;
    float v = tcCounter(P, x0, y0, cw, ch, g, (hms / 10000u) % 100u, 2u);
    v = max(v, tcCounter(P, x0 + pitch, y0, cw, ch, g, (hms / 100u) % 100u, 2u));
    v = max(v, tcCounter(P, x0 + 2.0 * pitch, y0, cw, ch, g, hms % 100u, 2u));
    float r = 0.07 * ch;
    for (uint i = 0u; i < 2u; ++i) {
        float cxm = x0 + float(i) * pitch + gw + g + 0.5 * colw;
        if (length(P - float2(cxm, y0 + 0.3 * ch)) < r || length(P - float2(cxm, y0 + 0.7 * ch)) < r) v = 1.0;
    }
    return v;
}
// p[0] = (kind 0 test / 1 ndi, time of day as HHMMSS, sweep 0..1, overlay valid). Coordinates: a 1920x1080 virtual frame,
// as large as fits and centred (the grid, background and frame edge still cover the whole canvas).
kernel void testcard(texture2d<float, access::write> outT [[texture(0)]],
                     texture2d<float, access::read> ov [[texture(1)]],
                     constant float4* p [[buffer(0)]],
                     uint2 gid [[thread_position_in_grid]]) {
    uint w = outT.get_width(), h = outT.get_height();
    if (gid.x >= w || gid.y >= h) return;
    float s = min(float(w) / 1920.0, float(h) / 1080.0), W = 1920.0, cx = 0.5 * W;   // 1920x1080 virtual frame, centred
    float2 P = (float2(gid) + 0.5 - 0.5 * (float2(float(w), float(h)) - s * float2(1920.0, 1080.0))) / s;
    uint kind = uint(p[0].x + 0.5), hms = uint(p[0].y + 0.5);
    float sweep = p[0].z;
    float ex = min(float(gid.x), float(w) - 1.0 - float(gid.x)) / s, ey = min(float(gid.y), float(h) - 1.0 - float(gid.y)) / s;
    float3 col;
    if (kind == 0u) {
        col = float3(0.24);
        float gx = abs(fract((P.x - cx) / 60.0 + 0.5) - 0.5) * 60.0, gy = abs(fract((P.y - 540.0) / 60.0 + 0.5) - 0.5) * 60.0;
        if (min(gx, gy) < 1.25) col = float3(0.6);                                   // 60 px grid (2.5 px lines)
        float bx0 = cx - 720.0;
        if (tcIn(P, bx0, 150.0, bx0 + 1440.0, 470.0)) col = kBars[min(7u, uint((P.x - bx0) / 180.0))];          // 75 % bars
        else if (tcIn(P, bx0, 470.0, bx0 + 1440.0, 560.0)) col = float3(float(min(10u, uint((P.x - bx0) / (1440.0 / 11.0)))) / 10.0);
        else if (tcIn(P, bx0, 560.0, bx0 + 1440.0, 585.0)) col = float3(0.0);       // wedge labels (overlay)
        else if (tcIn(P, bx0, 585.0, bx0 + 1440.0, 700.0)) {                         // line wedges in real pixels: 2..8 px
            uint k = min(4u, uint((P.x - bx0) / 288.0));
            uint lw = k == 0u ? 2u : (k == 1u ? 3u : (k == 2u ? 4u : (k == 3u ? 6u : 8u)));
            uint c = P.y < 642.5 ? gid.x : gid.y;
            col = float3(((c / lw) & 1u) == 0u ? 0.92 : 0.04);
        } else if (tcIn(P, cx - 252.0, 712.0, cx + 252.0, 800.0)) {                  // clock (time of day)
            col = float3(0.0);
            if (tcClock(P, cx - 238.0, 720.0, 56.0, 72.0, 12.0, hms) > 0.5) col = float3(0.2, 1.0, 0.45);
        } else if (tcIn(P, bx0, 930.0, bx0 + 1440.0, 1000.0)) {                      // sweep bar
            col = float3(0.05);
            float sx = bx0 + 8.0 + sweep * (1440.0 - 64.0);
            if (P.x >= sx && P.x < sx + 48.0 && P.y >= 938.0 && P.y < 992.0) col = float3(1.0);
        }
        float r = length(P - float2(cx, 540.0));
        if (abs(r - 500.0) < 2.0) col = float3(1.0);                                 // geometry circle (aspect / scaling)
        if ((abs(P.x - cx) < 1.5 && abs(P.y - 540.0) < 40.0) || (abs(P.y - 540.0) < 1.5 && abs(P.x - cx) < 40.0)) col = float3(1.0);
        if (min(ex, ey) < 4.0) col = float3(1.0);                                    // frame edge
        if ((ex >= 14.0 && ex < 104.0 && ey >= 14.0 && ey < 22.0) || (ey >= 14.0 && ey < 104.0 && ex >= 14.0 && ex < 22.0)) col = float3(1.0, 0.82, 0.1);
    } else if (kind == 2u) {                                                        // STANDBY: dark navy, three slow glows
        float t = p[0].y;
        float2 q = (P - float2(cx, 540.0)) / 1080.0;
        col = mix(float3(0.075, 0.07, 0.17), float3(0.11, 0.08, 0.18), P.y / 1080.0);
        float2 c1 = float2(0.55 * sin(t * 0.050), 0.25 * cos(t * 0.070));
        float2 c2 = float2(0.60 * cos(t * 0.043 + 2.0), 0.30 * sin(t * 0.061 + 1.0));
        float2 c3 = float2(0.50 * sin(t * 0.037 + 4.0), 0.28 * cos(t * 0.053 + 3.0));
        col += float3(0.45, 0.25, 0.95) * 0.16 * exp(-dot(q - c1, q - c1) * 6.0);
        col += float3(0.13, 0.75, 0.95) * 0.10 * exp(-dot(q - c2, q - c2) * 7.0);
        col += float3(0.95, 0.30, 0.80) * 0.09 * exp(-dot(q - c3, q - c3) * 8.0);
        float2 g = (P + float2(t * 6.0, 0.0)) / 90.0;                                // faint drifting diamond lattice
        float2 f = abs(fract(float2(g.x + g.y, g.x - g.y) * 0.7071) - 0.5);
        if (min(f.x, f.y) < 0.012) col += 0.012;
        col *= 1.0 - 0.56 * dot(q, q);                                               // vignette
    } else {
        col = mix(float3(0.035, 0.05, 0.11), float3(0.07, 0.085, 0.19), P.y / 1080.0);
        float gx = abs(fract(P.x / 120.0 + 0.5) - 0.5) * 120.0, gy = abs(fract(P.y / 120.0 + 0.5) - 0.5) * 120.0;
        if (min(gx, gy) < 1.0) col += 0.03;
        if (tcIn(P, 80.0, 1022.0, W - 80.0, 1052.0)) {
            col = float3(0.02, 0.03, 0.07);
            float sx = 84.0 + sweep * (W - 168.0 - 40.0);
            if (P.x >= sx && P.x < sx + 40.0 && P.y >= 1026.0 && P.y < 1048.0) col = float3(0.65, 0.55, 0.98);
        }
        if (tcClock(P, W - 80.0 - 7.0 * 30.0 - 7.0 * 8.0, 966.0, 30.0, 44.0, 8.0, hms) > 0.5) col = float3(0.2, 1.0, 0.45);
        if (min(ex, ey) < 4.0) col = float3(0.65, 0.55, 0.98);
    }
    if (p[0].w > 0.5) {
        float4 o = ov.read(gid);                                                     // premultiplied text + QR
        if (kind == 2u && o.a > 0.002) {                                             // standby: animate the logo
            float t = p[0].y;
            float3 c = o.rgb / o.a;
            float mx = max(c.r, max(c.g, c.b)), mn = min(c.r, min(c.g, c.b));
            if (mx - mn < 0.12 && mx > 0.5 && o.a > 0.05) {                          // VIZZIES (white): flowing L1..L4 gradient
                float u = fract(P.x / 1400.0 - t / 12.0) * 4.0;
                float3 A = float3(0.133, 0.827, 0.933), B = float3(0.957, 0.447, 0.816), C = float3(0.984, 0.749, 0.141), D = float3(0.639, 0.902, 0.208);
                float3 gc = u < 1.0 ? mix(A, B, u) : (u < 2.0 ? mix(B, C, u - 1.0) : (u < 3.0 ? mix(C, D, u - 2.0) : mix(D, A, u - 3.0)));
                c = gc * mx;
            }
            if (c.g > c.r + 0.3 && c.g > c.b + 0.3) c *= (fract((P.y + t * 20.0) / 5.0) < 0.55 ? 1.0 : 0.5);   // VJ: rolling scanlines
            float text = smoothstep(0.85, 1.0, o.a);
            float ph = fract(t / 12.0) * 3.0;                                        // shine: crosses in 4 s, then 8 s rest
            float bx = mix(cx - 1000.0, cx + 1000.0, ph);
            float d = (P.x - bx) + (P.y - 540.0) * 0.36;
            c = mix(c, float3(1.0), ph < 1.0 ? 0.85 * exp(-d * d / 3200.0) * text : 0.0);
            float k = 0.55 + 0.45 * sin(t * 1.5708);                                 // the glow breathes on 4 s
            float a = clamp(o.a * mix(1.0, 1.4 * k, 1.0 - text), 0.0, 1.0);
            o = float4(c * a, a);
        }
        col = col * (1.0 - o.a) + o.rgb;
    }
    outT.write(float4(col, 1.0), gid);
}

"""
