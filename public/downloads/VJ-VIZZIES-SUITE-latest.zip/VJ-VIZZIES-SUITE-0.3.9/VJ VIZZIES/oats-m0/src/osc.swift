import Foundation
import Darwin

// OSC 1.0 over UDP: messages and #bundle (recursive). Types i f s d h T F N (plus b, S, c, r, m, t, I,
// arrays skipped safely). Every parse step is bounds-checked; a malformed packet is logged and dropped.

enum OSCArg: CustomStringConvertible {
    case i(Int32), f(Float), s(String), d(Double), h(Int64), t, fls, n, other(Character)

    var description: String {
        switch self {
        case .i(let v): return "\(v)"
        case .f(let v): return String(format: "%g", Double(v))
        case .s(let v): return "\"\(v.count > 80 ? String(v.prefix(80)) + "…" : v)\""
        case .d(let v): return String(format: "%g", v)
        case .h(let v): return "\(v)"
        case .t: return "T"
        case .fls: return "F"
        case .n: return "N"
        case .other(let c): return "<\(c)>"
        }
    }
    var number: Double? {
        switch self {
        case .i(let v): return Double(v)
        case .f(let v): return Double(v)
        case .d(let v): return v
        case .h(let v): return Double(v)
        default: return nil
        }
    }
}

struct OSCMessage {
    let address: String
    let types: String
    let args: [OSCArg]
    let inBundle: Bool
}

struct OSCParseError: Error { let why: String }

struct OSCReader {
    let b: [UInt8]
    var pos: Int
    let end: Int

    init(_ b: [UInt8], _ start: Int, _ end: Int) { self.b = b; pos = start; self.end = end }

    var remaining: Int { end - pos }

    mutating func string() throws -> String {
        guard pos < end else { throw OSCParseError(why: "string past end") }
        var z = pos
        while z < end && b[z] != 0 { z += 1 }
        guard z < end else { throw OSCParseError(why: "unterminated string") }
        let s = String(decoding: b[pos..<z], as: UTF8.self)
        let padded = (z - pos + 1 + 3) & ~3
        pos = min(pos + padded, end)                     // lenient: a missing final pad is accepted
        return s
    }
    mutating func u32() throws -> UInt32 {
        guard remaining >= 4 else { throw OSCParseError(why: "int32 past end") }
        let v = UInt32(b[pos]) << 24 | UInt32(b[pos + 1]) << 16 | UInt32(b[pos + 2]) << 8 | UInt32(b[pos + 3])
        pos += 4
        return v
    }
    mutating func u64() throws -> UInt64 {
        let hi = try u32(), lo = try u32()
        return UInt64(hi) << 32 | UInt64(lo)
    }
    mutating func skip(_ n: Int) throws {
        guard n >= 0, remaining >= n else { throw OSCParseError(why: "blob past end") }
        pos += n
    }
}

/// Parses one UDP payload into messages. Bundles nest up to 8 deep.
func oscParse(_ b: [UInt8], _ start: Int, _ end: Int, depth: Int = 0, inBundle: Bool = false) throws -> [OSCMessage] {
    guard depth <= 8 else { throw OSCParseError(why: "bundle nesting too deep") }
    guard start >= 0, end <= b.count, end - start >= 2 else { throw OSCParseError(why: "packet too short (\(end - start) bytes)") }
    if b[start] == UInt8(ascii: "#") {
        var r = OSCReader(b, start, end)
        let tag = try r.string()
        guard tag == "#bundle" else { throw OSCParseError(why: "bad bundle tag") }
        _ = try r.u64()                                   // time tag: ignored (executed immediately)
        var out: [OSCMessage] = []
        while r.remaining > 0 {
            let size = Int(Int32(bitPattern: try r.u32()))
            guard size > 0, size <= r.remaining else { throw OSCParseError(why: "bad bundle element size \(size)") }
            out += try oscParse(b, r.pos, r.pos + size, depth: depth + 1, inBundle: true)
            r.pos += size
        }
        return out
    }
    guard b[start] == UInt8(ascii: "/") else { throw OSCParseError(why: "address does not start with /") }
    var r = OSCReader(b, start, end)
    let address = try r.string()
    var types = ""
    var args: [OSCArg] = []
    if r.remaining > 0 && b[r.pos] == UInt8(ascii: ",") {
        let tt = try r.string()
        types = tt
        for ch in tt.dropFirst() {
            switch ch {
            case "i": args.append(.i(Int32(bitPattern: try r.u32())))
            case "f": args.append(.f(Float(bitPattern: try r.u32())))
            case "s", "S": args.append(.s(try r.string()))
            case "d": args.append(.d(Double(bitPattern: try r.u64())))
            case "h": args.append(.h(Int64(bitPattern: try r.u64())))
            case "t": _ = try r.u64(); args.append(.other("t"))
            case "T": args.append(.t)
            case "F": args.append(.fls)
            case "N": args.append(.n)
            case "I": args.append(.other("I"))
            case "c", "r", "m": _ = try r.u32(); args.append(.other(ch))
            case "b":
                let n = Int(Int32(bitPattern: try r.u32()))
                guard n >= 0 else { throw OSCParseError(why: "negative blob size") }
                try r.skip((n + 3) & ~3)
                args.append(.other("b"))
            case "[", "]": break
            default: throw OSCParseError(why: "unknown type tag '\(ch)'")
            }
        }
    }
    return [OSCMessage(address: address, types: types, args: args, inBundle: inBundle)]
}

/// Builds a simple OSC message (string args only).
func oscEncode(_ address: String, _ strings: [String]) -> [UInt8] {
    func pad(_ s: String) -> [UInt8] {
        var v = Array(s.utf8) + [0]
        while v.count % 4 != 0 { v.append(0) }
        return v
    }
    return pad(address) + pad("," + String(repeating: "s", count: strings.count)) + strings.flatMap(pad)
}

func sockaddrString(_ a: sockaddr_in) -> String {
    var addr = a.sin_addr
    var buf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
    inet_ntop(AF_INET, &addr, &buf, socklen_t(INET_ADDRSTRLEN))
    return String(cString: buf) + ":" + String(UInt16(bigEndian: a.sin_port))
}

func sockaddrIP(_ a: sockaddr_in) -> String {
    var addr = a.sin_addr
    var buf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
    inet_ntop(AF_INET, &addr, &buf, socklen_t(INET_ADDRSTRLEN))
    return String(cString: buf)
}

/// Opens a UDP socket bound to 0.0.0.0:port. Returns -1 and logs on failure.
/// `addrHost` (host byte order) binds one local address instead of 0.0.0.0.
func udpBind(port: Int, reusePort: Bool, rcvTimeoutMs: Int, what: String, addrHost: UInt32? = nil) -> Int32 {
    let fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
    guard fd >= 0 else { olog("\(what): socket() failed errno=\(errno)"); return -1 }
    var one: Int32 = 1
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, socklen_t(MemoryLayout<Int32>.size))
    if reusePort { setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &one, socklen_t(MemoryLayout<Int32>.size)) }
    var rcvbuf: Int32 = 1 << 20
    setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcvbuf, socklen_t(MemoryLayout<Int32>.size))
    var tv = timeval(tv_sec: rcvTimeoutMs / 1000, tv_usec: Int32((rcvTimeoutMs % 1000) * 1000))
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
    var sa = sockaddr_in()
    sa.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
    sa.sin_family = sa_family_t(AF_INET)
    sa.sin_port = in_port_t(UInt16(port).bigEndian)
    sa.sin_addr.s_addr = addrHost.map { $0.bigEndian } ?? INADDR_ANY
    let r = withUnsafePointer(to: &sa) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
    guard r == 0 else {
        olog("\(what): bind \(addrHost.map(ipv4Text) ?? "0.0.0.0"):\(port) failed: \(String(cString: strerror(errno)))")
        close(fd)
        return -1
    }
    return fd
}

// MARK: - bound addresses (OSC, sACN, preview): 127.0.0.1 and en0's IPv4 only, never 0.0.0.0
// With net.inet.ip.check_interface = 1 a packet that arrives on the building Wi-Fi (en1) or Tailscale is never
// delivered to a socket bound to en0's address, so a spoofed lighting-LAN source address no longer helps.

/// en0's first IPv4 address (host byte order), or nil (none, or only a self-assigned 169.254.x.x).
func en0Addr() -> UInt32? { en0Networks().first?.addr }

/// What each service is bound to right now (status.json "listen"), e.g. "osc": ["127.0.0.1:7000", "192.168.1.148:7000"].
final class ListenRegistry {
    private let lock = NSLock()
    private var m: [String: [String]] = [:]
    func set(_ k: String, _ v: [String]) { lock.lock(); m[k] = v; lock.unlock() }
    func snapshot() -> [String: [String]] { lock.lock(); defer { lock.unlock() }; return m }
}
let gListen = ListenRegistry()

/// One socket per local address (127.0.0.1 when `loopback`, plus en0's address) for one port. `refresh()` re-reads
/// en0 at most every 5 s: when its address appears, changes or goes away the en0 socket is closed and bound again
/// (logged). Only the owner's own thread calls refresh() and uses `fds`, so no socket is closed under a poll.
final class BoundSockets {
    let port: Int, what: String, key: String, loopback: Bool, tcp: Bool, reusePort: Bool, rcvTimeoutMs: Int
    private(set) var fds: [Int32] = []
    private var lo: Int32 = -1
    private var en: Int32 = -1
    private var enAddr: UInt32? = nil
    private var lastCheck: UInt64 = 0
    private var warnedNoEn0 = false
    private var failedAddr: UInt32? = nil

    init(port: Int, what: String, key: String, loopback: Bool, tcp: Bool, reusePort: Bool = false, rcvTimeoutMs: Int = 500) {
        self.port = port; self.what = what; self.key = key; self.loopback = loopback; self.tcp = tcp
        self.reusePort = reusePort; self.rcvTimeoutMs = rcvTimeoutMs
    }

    /// The first bind. Returns false when the loopback socket can't be bound (the port is taken: another instance).
    func open() -> Bool {
        if loopback {
            lo = bindOne(0x7f00_0001)
            if lo < 0 { return false }
        }
        refresh(force: true)
        return true
    }

    var boundText: [String] {
        var out: [String] = []
        if lo >= 0 { out.append("127.0.0.1:\(port)") }
        if en >= 0, let a = enAddr { out.append("\(ipv4Text(a)):\(port)") }
        return out
    }

    /// At most every 5 s (or `force`): follow en0's address.
    func refresh(force: Bool = false) {
        let now = nowTicks()
        if !force && ticksToSec(now &- lastCheck) < 5 { return }
        lastCheck = now
        let want = en0Addr()
        if want == enAddr && (en >= 0 || want == nil) { if force { fds = [lo, en].filter { $0 >= 0 }; gListen.set(key, boundText) }; return }
        if en >= 0 { close(en); en = -1 }
        let old = enAddr
        enAddr = want
        if let a = want {
            en = bindOne(a)
            if en >= 0 {
                olog("\(what): listening on \(ipv4Text(a)):\(port)" + (old != nil && old != a ? " (en0 changed from \(ipv4Text(old!)))" : "") +
                     (loopback ? " and 127.0.0.1:\(port)" : "") + " (\(tcp ? "TCP" : "UDP"), never 0.0.0.0)")
                warnedNoEn0 = false; failedAddr = nil
            } else {
                if failedAddr != a { olog("\(what): bind \(ipv4Text(a)):\(port) failed: retrying every 5 s") }
                failedAddr = a
                enAddr = nil                                  // try again next time
            }
        } else if !warnedNoEn0 {
            warnedNoEn0 = true
            olog("\(what): en0 has no IPv4 address: " + (loopback ? "only 127.0.0.1:\(port) for now" : "not listening") +
                 "; retrying en0 every 5 s (never 0.0.0.0)")
        }
        fds = [lo, en].filter { $0 >= 0 }
        gListen.set(key, boundText)
    }

    private func bindOne(_ addr: UInt32) -> Int32 {
        if !tcp { return udpBind(port: port, reusePort: reusePort, rcvTimeoutMs: rcvTimeoutMs, what: what, addrHost: addr) }
        let fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)
        guard fd >= 0 else { olog("\(what): socket() failed errno=\(errno)"); return -1 }
        var one: Int32 = 1
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, socklen_t(MemoryLayout<Int32>.size))
        var sa = sockaddr_in()
        sa.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        sa.sin_family = sa_family_t(AF_INET)
        sa.sin_port = in_port_t(UInt16(port).bigEndian)
        sa.sin_addr.s_addr = addr.bigEndian
        let r = withUnsafePointer(to: &sa) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
        guard r == 0, listen(fd, 16) == 0 else {
            olog("\(what): cannot listen on TCP \(ipv4Text(addr)):\(port) (\(String(cString: strerror(errno))))")
            close(fd); return -1
        }
        _ = fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK)
        return fd
    }

    /// UDP: waits up to rcvTimeoutMs on every bound socket and reads one datagram. n < 0 = nothing (timeout).
    func recv(_ buf: inout [UInt8], _ from: inout sockaddr_in) -> (n: Int, fd: Int32) {
        refresh()
        if fds.isEmpty { usleep(useconds_t(rcvTimeoutMs * 1000)); return (-1, -1) }
        var p = fds.map { pollfd(fd: $0, events: Int16(POLLIN), revents: 0) }
        let r = poll(&p, nfds_t(p.count), Int32(rcvTimeoutMs))
        if r <= 0 { return (-1, -1) }
        for x in p where x.revents & Int16(POLLIN | POLLERR) != 0 {
            var flen = socklen_t(MemoryLayout<sockaddr_in>.size)
            let n = buf.withUnsafeMutableBytes { raw in
                withUnsafeMutablePointer(to: &from) {
                    $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { recvfrom(x.fd, raw.baseAddress, raw.count, MSG_DONTWAIT, $0, &flen) }
                }
            }
            if n >= 0 { return (n, x.fd) }
        }
        return (-1, -1)
    }
}

/// DNS-rebinding guard for the HTTP servers (preview 8091): the Host header must name this Mac itself
/// (localhost, 127.0.0.1, en0's address or <LocalHostName>.local), with no port or the server's own port. A page
/// on evil.example that re-points its name at 192.168.1.148 still sends "Host: evil.example" and gets 403.
final class HostCheck {
    static let shared = HostCheck()
    let localName: String                                     // "obshost.local" (scutil --get LocalHostName), or ""
    private init() {
        var name = ""
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/sbin/scutil")
        p.arguments = ["--get", "LocalHostName"]
        let pipe = Pipe()
        p.standardOutput = pipe; p.standardError = FileHandle.nullDevice
        if (try? p.run()) != nil {
            p.waitUntilExit()
            let out = String(decoding: pipe.fileHandleForReading.readDataToEndOfFile(), as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
            if p.terminationStatus == 0 && !out.isEmpty && !out.contains(" ") { name = out.lowercased() + ".local" }
        }
        localName = name
    }
    var namesText: String { (["localhost", "127.0.0.1"] + (en0Addr().map { [ipv4Text($0)] } ?? []) + (localName.isEmpty ? [] : [localName])).joined(separator: ", ") }

    /// host[:port] -> (lowercased host without a trailing dot, port or nil); nil when malformed or an IPv6 literal.
    static func split(_ hp: String) -> (String, Int?)? {
        var h = hp.trimmingCharacters(in: .whitespaces).lowercased()
        if h.isEmpty || h.hasPrefix("[") { return nil }
        var port: Int? = nil
        if let i = h.lastIndex(of: ":") {
            guard let p = Int(h[h.index(after: i)...]), (1...65535).contains(p) else { return nil }
            port = p; h = String(h[..<i])
        }
        if h.hasSuffix(".") { h.removeLast() }
        return h.isEmpty ? nil : (h, port)
    }

    func isSelf(_ h: String) -> Bool {
        if h == "localhost" || h == "127.0.0.1" || (!localName.isEmpty && h == localName) { return true }
        if let a = en0Addr(), h == ipv4Text(a) { return true }
        return false
    }

    /// The Host header of a request to `port`.
    func allowsHost(_ header: String?, port: Int) -> Bool {
        guard let hd = header, let (h, p) = HostCheck.split(hd) else { return false }
        if let p = p, p != port { return false }
        return isSelf(h)
    }

    /// The Origin header for CORS: http://<this Mac>[:port] (the GUI page on :8090). Returns it when allowed.
    func allowedOrigin(_ origin: String?) -> String? {
        guard let o = origin, o.lowercased().hasPrefix("http://") else { return nil }
        let rest = String(o.dropFirst(7))
        guard !rest.contains("/"), let (h, _) = HostCheck.split(rest), isSelf(h) else { return nil }
        return o
    }
}

// MARK: - control source filter (OSC, sACN, preview)
// A second layer behind the address binding: packets and connections whose source is not on an allowed network
// are dropped in the application and counted.

func ipv4Text(_ h: UInt32) -> String { "\(h >> 24).\((h >> 16) & 0xff).\((h >> 8) & 0xff).\(h & 0xff)" }

/// An IPv4 network in host byte order (address already masked).
struct IPv4Net: Equatable {
    let net: UInt32
    let mask: UInt32
    init(addr: UInt32, mask: UInt32) { self.mask = mask; net = addr & mask }
    var text: String { "\(ipv4Text(net))/\(mask.nonzeroBitCount)" }
    @inline(__always) func contains(_ h: UInt32) -> Bool { h & mask == net }
    static func prefixMask(_ bits: Int) -> UInt32 { bits <= 0 ? 0 : (bits >= 32 ? ~UInt32(0) : ~UInt32(0) << UInt32(32 - bits)) }
    /// "a.b.c.d/p" or "a.b.c.d" (= /32).
    static func parse(_ s: String) -> IPv4Net? {
        let p = s.split(separator: "/", maxSplits: 1, omittingEmptySubsequences: false).map(String.init)
        var a = in_addr()
        guard let ip = p.first, inet_pton(AF_INET, ip, &a) == 1 else { return nil }
        var bits = 32
        if p.count == 2 { guard let b = Int(p[1]), (0...32).contains(b) else { return nil }; bits = b }
        return IPv4Net(addr: UInt32(bigEndian: a.s_addr), mask: prefixMask(bits))
    }
}

/// en0's IPv4 networks (address & netmask, via getifaddrs). A self-assigned 169.254.x.x doesn't count.
func en0Networks() -> [(net: IPv4Net, addr: UInt32)] {
    var out: [(net: IPv4Net, addr: UInt32)] = []
    var ifa: UnsafeMutablePointer<ifaddrs>? = nil
    guard getifaddrs(&ifa) == 0, let first = ifa else { return out }
    defer { freeifaddrs(first) }
    var p: UnsafeMutablePointer<ifaddrs>? = first
    while let cur = p {
        p = cur.pointee.ifa_next
        guard String(cString: cur.pointee.ifa_name) == "en0", let sa = cur.pointee.ifa_addr,
              sa.pointee.sa_family == UInt8(AF_INET), let nm = cur.pointee.ifa_netmask else { continue }
        let a = sa.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { UInt32(bigEndian: $0.pointee.sin_addr.s_addr) }
        if a >> 16 == 0xa9fe { continue }
        // The netmask sockaddr can be cut short (trailing zero bytes left out): read only the bytes it has.
        let len = Int(nm.pointee.sa_len)
        let raw = UnsafeRawPointer(nm)
        var m: UInt32 = 0
        for i in 0..<4 { m = m << 8 | UInt32(4 + i < len ? raw.load(fromByteOffset: 4 + i, as: UInt8.self) : 0) }
        let bits = m.nonzeroBitCount
        if bits < 8 || m != IPv4Net.prefixMask(bits) {          // garbled mask: never widen to "everything"
            olog(String(format: "control sources: WARNING: en0 %@ has an odd netmask 0x%08x: using /24", ipv4Text(a), m))
            m = IPv4Net.prefixMask(24)
        }
        out.append((IPv4Net(addr: a, mask: m), a))
    }
    return out
}

/// Which source addresses may control the player: 127.0.0.0/8 always, plus en0's network (or --allow-net).
/// When the list comes from en0, a refused source makes it re-read en0 (at most every 5 s), so control follows
/// en0 if it had no address at start or changed since.
final class SourceFilter {
    static let loopback = IPv4Net(addr: 0x7f00_0000, mask: 0xff00_0000)
    let any: Bool
    let fromEn0: Bool
    private let lock = NSLock()
    private var nets: [IPv4Net]
    private var lastCheck = nowTicks()

    init(cfg: Config) {
        any = cfg.allowAny
        fromEn0 = cfg.allowNets == nil
        nets = SourceFilter.dedupe([SourceFilter.loopback] + (cfg.allowNets ?? en0Networks().map { $0.net }))
    }

    private static func dedupe(_ n: [IPv4Net]) -> [IPv4Net] { n.reduce(into: []) { if !$0.contains($1) { $0.append($1) } } }

    var list: [String] { lock.lock(); defer { lock.unlock() }; return nets.map { $0.text } }
    var listText: String { any ? "any (--allow-any)" : list.joined(separator: ", ") }

    /// The start-up log lines.
    func describe(oscPort: Int) -> [String] {
        if any { return ["control sources: filter OFF (--allow-any): OSC, sACN and preview accept any source address"] }
        var out = ["control sources allowed (OSC \(oscPort), sACN 5568, preview 8091): \(listText)" +
                   (fromEn0 ? " (127.0.0.0/8 + en0's network)" : " (127.0.0.0/8 + --allow-net)") + "; everything else is dropped and counted"]
        if fromEn0 {
            let e = en0Networks()
            if e.isEmpty { out.append("control sources: WARNING: en0 has no IPv4 address: control only from this Mac (127.0.0.0/8) until en0 has one (re-read at most every 5 s when a source is refused)") }
            else { out.append("control sources: en0 " + e.map { "\(ipv4Text($0.addr))/\($0.net.mask.nonzeroBitCount)" }.joined(separator: ", ")) }
        }
        return out
    }

    @inline(__always) func allows(_ a: in_addr) -> Bool {
        if any { return true }
        let h = UInt32(bigEndian: a.s_addr)
        lock.lock()
        let ok = nets.contains { $0.contains(h) }
        lock.unlock()
        return ok || (fromEn0 && recheck(h))
    }

    private func recheck(_ h: UInt32) -> Bool {
        let now = nowTicks()
        lock.lock()
        if ticksToSec(now &- lastCheck) < 5 { lock.unlock(); return false }
        lastCheck = now
        lock.unlock()
        let fresh = SourceFilter.dedupe([SourceFilter.loopback] + en0Networks().map { $0.net })
        lock.lock()
        let changed = fresh != nets
        nets = fresh
        lock.unlock()
        if changed { olog("control sources: en0 changed, allowed now: " + fresh.map { $0.text }.joined(separator: ", ")) }
        return fresh.contains { $0.contains(h) }
    }
}

/// Logs the first refusal per source address once (per service); later ones are only counted.
final class RejectLog {
    private let lock = NSLock()
    private var seen = Set<UInt32>()
    private var full = false
    let what: String, key: String
    let filter: SourceFilter
    init(_ what: String, key: String, filter: SourceFilter) { self.what = what; self.key = key; self.filter = filter }

    func note(_ a: in_addr, _ detail: String) {
        let h = UInt32(bigEndian: a.s_addr)
        lock.lock()
        var first = false, nowFull = false
        if !seen.contains(h) {
            if seen.count < 256 { seen.insert(h); first = true } else if !full { full = true; nowFull = true }
        }
        lock.unlock()
        if first {
            olog("\(what): REFUSED \(ipv4Text(h)) (\(detail)): not on an allowed network (\(filter.listText)); further ones from this address are only counted (status.json \(key))")
        } else if nowFull {
            olog("\(what): more than 256 refused source addresses: new ones are no longer logged (still counted in \(key))")
        }
    }
}

final class OSCServer {
    private let socks: BoundSockets
    private var replyFD: Int32 = -1                          // the socket the current packet came in on (osc thread only)
    let cfg: Config
    let statusString: () -> String
    let filter: SourceFilter
    private let rejects: RejectLog
    // Every per-message log line ("OSC <peer> <address> ...", ~600 bytes, file + stdout) goes through this one
    // limiter: at most 20 lines per second, then one line "N OSC messages not logged" (an OSC flood can't fill the disk).
    private let limiter = LogLimiter(perSecond: 20, summary: "OSC messages not logged in the last second (log rate limit 20 lines/s)")
    private let mapLimiter = LogLimiter(perSecond: 3)        // mapping edits: the GUI sends them while dragging

    init?(cfg: Config, filter: SourceFilter, statusString: @escaping () -> String) {
        // 127.0.0.1 (GUI server, Link and the Mac apps) + en0's address (the lighting LAN); never 0.0.0.0
        socks = BoundSockets(port: cfg.oscPort, what: "OSC", key: "osc", loopback: true, tcp: false, rcvTimeoutMs: 500)
        guard socks.open() else { return nil }
        self.cfg = cfg
        self.filter = filter
        self.rejects = RejectLog("OSC", key: "osc.rejected", filter: filter)
        self.statusString = statusString
        olog("OSC listening on \(socks.boundText.joined(separator: ", ")) (UDP)\(cfg.debug ? ", debug addresses on" : "")")
    }

    /// `--selftest-dmx` only (dmx.swift): the handlers without a socket (nothing is bound; `inject` runs one message).
    init(selftest cfg: Config, filter: SourceFilter) {
        socks = BoundSockets(port: cfg.oscPort, what: "OSC", key: "osc", loopback: true, tcp: false, rcvTimeoutMs: 500)
        self.cfg = cfg
        self.filter = filter
        self.rejects = RejectLog("OSC", key: "osc.rejected", filter: filter)
        self.statusString = { "" }
    }
    func inject(_ m: OSCMessage) { handle(m, from: sockaddr_in(), peer: "selftest") }

    func start() {
        let t = Thread { [self] in self.run() }
        t.name = "osc"
        t.qualityOfService = .userInitiated
        t.start()
    }

    private func run() {
        var buf = [UInt8](repeating: 0, count: 65536)
        while true {
            var from = sockaddr_in()
            let (n, rfd) = socks.recv(&buf, &from)
            if n < 0 { continue }
            replyFD = rfd
            let peer = sockaddrString(from)
            if !filter.allows(from.sin_addr) {
                gControl.with { $0.oscRejected += 1 }
                rejects.note(from.sin_addr, "first packet from \(peer), \(n) bytes")
                continue
            }
            let msgs: [OSCMessage]
            do { msgs = try oscParse(buf, 0, n) }
            catch let e as OSCParseError {
                gControl.with { $0.oscMalformed += 1 }
                limiter.log("OSC \(peer) malformed packet (\(n) bytes): \(e.why)")
                continue
            } catch { continue }
            for m in msgs { handle(m, from: from, peer: peer) }
        }
    }

    private func reply(_ bytes: [UInt8], to: sockaddr_in) {
        guard replyFD >= 0 else { return }
        var dst = to
        _ = bytes.withUnsafeBytes { raw in
            withUnsafePointer(to: &dst) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { sendto(replyFD, raw.baseAddress, raw.count, 0, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) }
            }
        }
    }

    private func handle(_ m: OSCMessage, from: sockaddr_in, peer: String) {
        // Ableton Link helper (bin/oats-link, ~50 Hz from 127.0.0.1): no log line, not counted as "last OSC"
        if m.address == "/oats/tempo/link" {
            let v = m.args.map { $0.number }
            if v.count >= 5, let bpm = v[0], let beat = v[1], let ph = v[2], let peers = v[3], let pl = v[4],
               bpm.isFinite, beat.isFinite, ph.isFinite, bpm >= 20, bpm <= 999 {
                let now = ticksToSec(nowTicks() &- gStartTicks)
                gLink.with { l in
                    l.bpm = bpm; l.beat = beat; l.phase = ph; l.peers = Int(peers); l.playing = pl != 0; l.at = now; l.count += 1
                    if l.from.isEmpty { l.from = peer }
                }
            } else { limiter.log("OSC \(peer) /oats/tempo/link \(m.types) -> bad args (want f bpm, d beat, f phase, i peers, i playing)") }
            return
        }
        // the startup card (testcard.swift) ends on the first OSC from a person / the GUI (not helpers or polling)
        if !oscIsInternal(m.address) { gStartup.input("OSC \(m.address.prefix(80)) from \(peer)") }
        // Bounded log text: a well-formed message can carry a ~64 KB address or hundreds of args.
        let addr = m.address.count > 160 ? String(m.address.prefix(160)) + "…" : m.address
        let types = m.types.count > 40 ? String(m.types.prefix(40)) + "…" : m.types
        var argText = m.args.prefix(40).map { $0.description }.joined(separator: " ")
        if argText.count > 300 || m.args.count > 40 { argText = String(argText.prefix(300)) + "…" }
        let head = "OSC \(peer) \(addr) \(types.isEmpty ? "," : types)\(argText.isEmpty ? "" : " " + argText)\(m.inBundle ? " (bundle)" : "")"
        let now = nowTicks()
        gControl.with { $0.oscCount += 1; $0.lastOSCAddress = addr; $0.lastOSCTicks = now }
        let a0 = m.args.first
        let num = a0?.number

        // Latest move wins: an OSC/GUI command always applies and takes its parameter(s) until the console moves
        // the matching DMX channel again. Returns " (takes X from DMX)" for the log when DMX had it.
        func take(_ ps: [Param], depthMove: Bool = false) -> String {
            let fromDMX: [String] = gControl.with { c in
                let was = ps.filter { c.owner($0) == .dmx }.map { $0.rawValue }
                c.ltpOSC(ps, depthMove: depthMove)
                return was
            }
            return fromDMX.isEmpty ? "" : " (takes " + fromDMX.joined(separator: ", ") + " from DMX)"
        }
        func finite(_ v: Double?) -> Double? { (v != nil && v!.isFinite) ? v : nil }

        switch m.address {
        case "/oats/fractal/1/zoomspeed":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want f|i|d)"); return }
            let tk = take([.zoomspeed, .depth])
            let c = min(5, max(-5, v))
            gControl.with { $0.zoomSpeed = c }
            limiter.log(head + String(format: " -> zoomspeed=%.4f decades/s%@", c, c != v ? " (clamped)" : "") + tk)
        case "/oats/fractal/1/zoom":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want d|f)"); return }
            let tk = take([.depth, .zoomspeed], depthMove: true)
            let c = min(log10WidthMax, max(log10WidthMin, v))
            gControl.with { $0.zoomSet = c }
            limiter.log(head + String(format: " -> log10 width=%.4f (width %.4g, depth %.2f)%@", c, pow(10, c), log10WidthMax - c, c != v ? " (clamped)" : "") + tk)
        case "/oats/fractal/1/depth":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want d|f, log10 zoom 0..\(Int(zoomDepthMax)))"); return }
            let tk = take([.depth, .zoomspeed], depthMove: true)
            let c = min(zoomDepthMax, max(0, v))
            gControl.with { $0.zoomSet = log10WidthMax - c }
            limiter.log(head + String(format: " -> depth=%.4f (zoom 10^%.2f, width %.4g)%@", c, c, pow(10, log10WidthMax - c), c != v ? " (clamped)" : "") + tk)
        case "/oats/fractal/1/target":
            var idx: Int? = nil
            if case .s(let s)? = a0 { idx = findTarget(s) }
            else if let v = finite(num), abs(v) < 1e6 { let r = Int(v.rounded()); if r >= 1 && r <= zoomTargets.count { idx = r - 1 } }
            guard let ti = idx else {
                limiter.log(head + " -> bad args (want i 1..\(zoomTargets.count) or s " + zoomTargets.map { $0.name }.joined(separator: "|") + ")"); return
            }
            let tk = take([.target])
            let (keep, sn, dive): (Bool, String, Bool) = gControl.with { c in
                c.targetRequest = ti; c.centerRequest = nil
                if c.diveOnSelect { c.diveSeq += 1 }
                return (c.keepDepth, c.switchShape(to: ti), c.diveOnSelect)
            }
            limiter.log(head + " -> target \(ti + 1) \(zoomTargets[ti].name)" + (keep ? " (keep depth)" : " (depth back to 0 when its orbit is ready)") + (dive ? " + dive burst" : "") + sn + tk)
        case "/oats/fractal/1/target/dive":
            // "Dive on select" (Deep zoom > Zoom > Places): a target change from OSC / the GUI zooms in for 1.5 s by itself
            var on: Bool? = nil
            if let a = a0 { switch a { case .t: on = true; case .fls: on = false; default: if let v = finite(a.number) { on = v != 0 } } }
            guard let b = on else { limiter.log(head + " -> bad args (want i 0|1)"); return }
            gControl.with { $0.diveOnSelect = b }
            limiter.log(head + " -> dive on select " + (b ? "ON (a place change zooms in for 1.5 s)" : "off"))
        case "/oats/fractal/1/target/keepdepth":
            var on: Bool? = nil
            if let a = a0 {
                switch a { case .t: on = true; case .fls: on = false; default: if let v = finite(a.number) { on = v != 0 } }
            }
            guard let b = on else { limiter.log(head + " -> bad args (want i|f|T|F)"); return }
            gControl.with { $0.keepDepth = b }
            limiter.log(head + " -> target keepdepth \(b ? "ON (target changes keep the depth)" : "off (target changes go back to depth 0)")")
        case "/oats/fractal/1/center":
            func text(_ a: OSCArg?) -> String? {
                guard let a = a else { return nil }
                if case .s(let s) = a { return s.trimmingCharacters(in: .whitespaces) }
                if let v = finite(a.number) { return String(format: "%.17g", v) }
                return nil
            }
            guard m.args.count >= 2, let re = text(m.args[0]), let im = text(m.args[1]), re.count <= 200, im.count <= 200,
                  let spec = CentreSpec.custom(re: re, im: im) else {
                limiter.log(head + " -> bad args (want s s decimal strings, or d d; |re|, |im| <= 4)"); return
            }
            let tk = take([.target])
            gControl.with { $0.centerRequest = spec; $0.targetRequest = nil }
            limiter.log(head + " -> custom centre re=\(re) im=\(im) (depth kept)" + tk)
        case "/oats/fractal/1/iter":
            guard let v = finite(num), abs(v) < 1e9 else { limiter.log(head + " -> bad args (want i: 0 = auto, else \(minIterOverride)..\(maxIterLimit); 12-24 = Blob)"); return }
            let r = Int(v.rounded())
            let tk = take([.iterations])
            let c = r <= 0 ? 0 : min(maxIterLimit, max(minIterOverride, r))
            gControl.with { $0.iterOverride = c }
            limiter.log(head + (c == 0 ? " -> iterations auto (400 + 600 x depth, 500..\(maxIterLimit))" : " -> iterations fixed at \(c)") + (c != r && r > 0 ? " (clamped)" : "") + tk)
        case "/oats/fractal/1/res":
            guard let v = finite(num), abs(v) < 1e6 else { limiter.log(head + " -> bad args (want i: 0 = governor, 1..5 or 1080|900|720|540|360)"); return }
            let r = Int(v.rounded())
            var lvl: Int? = nil
            if r == 0 { lvl = 0 }
            else if r >= 1 && r <= Governor.levels.count { lvl = r }
            else if let k = Governor.levels.firstIndex(where: { $0.h == r }) { lvl = k + 1 }
            else if let k = [1080, 900, 720, 540, 360].firstIndex(of: r) { lvl = k + 1 }   // the 1080p names on another canvas
            guard let l = lvl else { limiter.log(head + " -> bad args (want i: 0 = governor, 1..5 or 1080|900|720|540|360)"); return }
            gControl.with { $0.resOverride = l }
            limiter.log(head + (l == 0 ? " -> internal resolution: governor (auto)" : " -> internal resolution fixed at \(Governor.levels[l - 1].w)x\(Governor.levels[l - 1].h) (governor off)"))
        case "/oats/fractal/1/palette":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want i|f)"); return }
            let tk = take([.palette])
            let r = Int(max(-1e6, min(1e6, v.rounded())))
            let c = min(5, max(1, r))
            gControl.with { $0.palette = c }
            limiter.log(head + " -> palette=\(c) \(paletteNames[c])" + (c != r ? " (out of range \(r), clamped)" : "") + tk)
        case "/oats/fractal/1/palette/speed":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want f)"); return }
            let tk = take([.palette_speed])
            let c = min(10, max(-10, v))
            gControl.with { $0.paletteSpeed = c }
            limiter.log(head + String(format: " -> palette speed=%.4f cycles/s%@", c, c != v ? " (clamped)" : "") + tk)
        case "/oats/fractal/1/palette/offset":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want f)"); return }
            let tk = take([.palette_offset])
            let c = min(1, max(0, v))
            gControl.with { $0.paletteOffset = c }
            limiter.log(head + String(format: " -> palette offset=%.4f%@", c, c != v ? " (clamped)" : "") + tk)
        case "/oats/fractal/1/rotation":
            guard let v = finite(num), abs(v) < 1e6 else { limiter.log(head + " -> bad args (want f degrees, + = counter-clockwise)"); return }
            let tk = take([.rotation])
            var c = v.truncatingRemainder(dividingBy: 360); if c < 0 { c += 360 }
            gControl.with { $0.rotation = c }
            limiter.log(head + String(format: " -> fractal rotation %.2f deg", c) + tk)
        case "/oats/fractal/1/spin":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want f turns/s -2..2, 0 = stop)"); return }
            let tk = take([.spin])
            let c = min(2, max(-2, v))
            gControl.with { $0.fractalSpin = c }
            limiter.log(head + String(format: " -> fractal spin %.3f turns/s%@%@", c, c == 0 ? " (stop: the angle stays)" : "", c != v ? " (clamped)" : "") + tk)
        case "/oats/fractal/1/spin/reset":
            gControl.with { $0.fractalSpinReset += 1; $0.fractalSpin = 0 }
            limiter.log(head + " -> fractal spin stop + angle back to the rotation value")
        case "/oats/master/blackout":
            var on: Bool? = nil
            if let a = a0 {
                switch a { case .t: on = true; case .fls: on = false; default: if let v = finite(a.number) { on = v != 0 } }
            }
            guard let b = on else { limiter.log(head + " -> bad args (want i|f|T|F)"); return }
            let tk = take([.master])
            gControl.with { $0.blackout = b }
            limiter.log(head + " -> blackout \(b ? "ON" : "off")" + tk)
        case "/oats/master/dimmer":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want f)"); return }
            let tk = take([.dimmer])
            let c = min(1, max(0, v))
            gControl.with { $0.dimmer = c }
            limiter.log(head + String(format: " -> dimmer=%.3f%@", c, c != v ? " (clamped)" : "") + tk)
        case "/oats/master/speed":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want f 0..2)"); return }
            let tk = take([.effect_speed])
            let c = min(2, max(0, v))
            gControl.with { $0.effectSpeed = c }
            limiter.log(head + String(format: " -> effect speed=%.3fx%@", c, c != v ? " (clamped)" : "") + tk)
        case "/oats/test/content":
            guard case .s(let s)? = a0, let ct = Content.parse(s) else { limiter.log(head + " -> bad args (want s normal|deep|noise|test|ndi; off = normal)"); return }
            let tk = take([.content])
            gControl.with { $0.content = ct }
            limiter.log(head + " -> content=\(ct.rawValue)" + tk)
        case "/oats/tempo/bpm":
            guard let v = finite(num) else { limiter.log(head + " -> bad args (want f)"); return }
            let tk = take([.bpm])
            gControl.with { $0.bpm = v }
            limiter.log(head + String(format: " -> bpm=%.2f (tempo clock: autopilot beats)", v) + tk)
        case "/oats/tempo/source":
            guard case .s(let v)? = a0, ["auto", "link", "dmx", "tap", "osc"].contains(v.lowercased().trimmingCharacters(in: .whitespaces)) else {
                limiter.log(head + " -> bad args (want s auto|link|dmx|tap|osc)"); return
            }
            let src = v.lowercased().trimmingCharacters(in: .whitespaces)
            gControl.with { $0.tempoSource = src }
            limiter.log(head + " -> tempo source \(src)" + (src == "auto" || src == "link" ? " (Ableton Link leads while a session is present, else DMX/tap/OSC)" : " (Link ignored: DMX/tap/OSC BPM, latest move wins)"))
        case "/oats/tempo/forward":
            var dest = ""
            if case .s(let v)? = a0 { dest = v.trimmingCharacters(in: .whitespaces) }
            if dest.lowercased() == "off" || dest == "0" { dest = "" }
            if !dest.isEmpty && parseHostPort(dest) == nil { limiter.log(head + " -> bad args (want s host:port or off)"); return }
            if !dest.isEmpty, let d = parseHostPort(dest), !filter.allows(d.sin_addr) {
                limiter.log(head + " -> refused: \(dest) is not on the lighting network or this Mac (\(filter.listText))"); return
            }
            gControl.with { $0.tempoForward = dest }
            limiter.log(head + " -> tempo forward " + (dest.isEmpty ? "off" : "to \(dest) (MA3 OSC /cmd \"Master 3.1 At BPM <bpm>\" while Link leads, on change, max 2 Hz)"))
        case "/oats/output/display":
            guard let v = finite(num), v >= 0, v <= 16 else { limiter.log(head + " -> bad args (want i: 0 = off, 1..n = screen index from status.json screens)"); return }
            limiter.log(head + " -> " + gOutput.setDisplay(Int(v.rounded())))
        case "/oats/output/fit":
            guard case .s(let s)? = a0, let f = OutFit(rawValue: s.lowercased().trimmingCharacters(in: .whitespaces)) else {
                limiter.log(head + " -> bad args (want s fill|fit|1:1)"); return
            }
            limiter.log(head + " -> " + gOutput.setFit(f))
        case "/oats/output/test":
            // 0 off, 1 the display test pattern, 2 the cabinet grid (mapping.swift: canvas pixels through the slices)
            var on: Int? = nil
            if let a = a0 {
                switch a { case .t: on = 1; case .fls: on = 0; default: if let v = finite(a.number), v >= 0, v <= 2 { on = Int(v.rounded()) } }
            }
            guard let b = on else { limiter.log(head + " -> bad args (want i 0 off | 1 display test | 2 cabinet grid)"); return }
            limiter.log(head + " -> " + gOutput.setTest(b))
        case "/oats/output/snapshot":
            limiter.log(head + " -> " + gOutput.requestSnapshot())
        case "/oats/record/start":
            // recorder.swift: [s path] [s size 1080p|vertical]; default ~/Movies/OATS VIZ/teaser-takes/<yyyymmdd-HHMMSS>-<size>.mp4
            let pa = Recorder.parseArgs(m.args)
            if !pa.bad.isEmpty { limiter.log(head + " -> bad args (\(pa.bad))"); return }
            limiter.log(head + " -> " + gRecorder.start(path: pa.path, size: pa.size))
        case "/oats/record/stop":
            limiter.log(head + " -> " + gRecorder.stop(why: "OSC"))
        case "/oats/ndi/sources":
            // ndiin.swift: logs the discovered NDI sources with their slot numbers (status.json ndi_sources has the same)
            gNDIIn.requestSourceLog()
            limiter.log(head + " -> NDI sources: " + gNDIIn.describeSources())
        case "/oats/ndi/mode":
            // NDI mode (ndiout.swift): off | native | native-soft | helper | auto. HDMI never depends on it.
            guard case .s(let v)? = a0, let md = NDIMode.parse(v) else {
                limiter.log(head + " -> bad args (want s off|native|native-soft|helper|auto)"); return
            }
            limiter.log(head + " -> " + (gNDIOut?.setMode(md, why: "OSC") ?? "NDI not ready"))
        case "/oats/ndi/quality":
            // previs (960x540 @ half rate) | full (1920x1080 @ output rate); ndiout.swift. HDMI never depends on it.
            guard case .s(let v)? = a0, let q = NDIQuality.parse(v) else { limiter.log(head + " -> bad args (want s full|previs)"); return }
            limiter.log(head + " -> " + (gNDIOut?.setQuality(q) ?? "NDI not ready"))
        case "/oats/ndi/soft":
            guard case .s(let v)? = a0, let sk = NDISoft(rawValue: v.lowercased()) else { limiter.log(head + " -> bad args (want s half|blur)"); return }
            gNDIOut?.setSoft(sk)
            limiter.log(head + " -> native-soft pass: " + (sk == .half ? "2x2 box to 960x540" : "3x3 tent at 1920x1080"))
        case "/oats/system/ping":
            let s = statusString()
            reply(oscEncode("/oats/system/pong", [s]), to: from)
            limiter.log(head + " -> pong to \(peer): \(s)")
        case "/oats/system/snapshot":
            gControl.with { $0.snapshotRequest = true }
            limiter.log(head + " -> snapshot requested")
        case "/oats/debug/stall":
            guard cfg.debug else { limiter.log(head + " -> unhandled (debug addresses are off; start with --debug)"); return }
            guard let v = finite(num), v >= 0 else { limiter.log(head + " -> bad args (want f seconds)"); return }
            let c = min(30, v)
            gControl.with { $0.stallRequest = c }
            limiter.log(head + String(format: " -> DEBUG: render thread will sleep %.3f s", c))
        default:
            if m.address.hasPrefix("/oats/fractal/1/"), handleFractalMods(m, String(m.address.dropFirst(16)), head: head) { return }
            if m.address.hasPrefix("/oats/scene/") {
                if let r = gScenes.osc(m) { limiter.log(head + " -> " + r) }
                else { limiter.log(head + " -> bad args (scene: s \"b.s\", i b i s, or i n 1..\(sceneMax); see README Scenes)") }
                return
            }
            if let (t, ok) = gAudio.osc(m) {                // /oats/audio/... (audio.swift)
                if ok { limiter.log(head + " -> " + t) } else { limiter.log(head + " -> " + t) }
                return
            }
            if let (t, ok) = gMapping.osc(m, display: gOutput.sizeAndFit().display) {   // canvas, slices, cabinet, layer scaling (mapping.swift)
                if ok { mapLimiter.log(head + " -> " + t) } else { limiter.log(head + " -> " + t) }
                return
            }
            if handleLayer(m, head: head) { return }
            if m.address == "/cmd" || m.address.hasPrefix("/cmd/") {
                limiter.log(head + " -> ignored (/cmd: MA3 command echo)")
            } else {
                limiter.log(head + " -> unhandled")
            }
        }
    }

    // MARK: motion + FX (fx.swift)
    // /oats/layers/{n}/transform/{x,y,scale,rotation,spin,flipx,flipy,tile,mirror} f, transform/spinfill s auto|locked|mirror|off,
    // /edge/feather f 0..1, /edge/shape s rect|oval|circle; /fx/{1,2}/{type s|i, amount f, speed f};
    // /mod/{target s, shape s, beats f, depth f}; /fx/reset; /fx/preset s name. Owner keys layer<n>.{pos,scale,rotation,spin,
    // tile,fx1,fx2,mod} (the same groups DMX "Layer FX 24" takes).
    private func handleLayerFX(_ m: OSCMessage, _ n: Int, _ cmd: [String], head: String) {
        let li = layerIndex(n), k = "layer\(n)."              // n 0 = BG
        let a0 = m.args.first
        func finite(_ v: Double?) -> Double? { (v != nil && v!.isFinite) ? v : nil }
        func flag(_ a: OSCArg?) -> Bool? {
            guard let a = a else { return nil }
            switch a { case .t: return true; case .fls: return false; default: return finite(a.number).map { $0 != 0 } }
        }
        func take(_ keys: [String]) { gControl.with { c in for x in keys { c.layerOwners[k + x] = .osc } } }
        func num(_ lo: Double, _ hi: Double, _ what: String) -> Double? {
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f \(what))"); return nil }
            return min(hi, max(lo, v))
        }
        switch cmd {
        case ["transform", "x"], ["transform", "y"]:
            guard let v = num(-1, 1, "-1..1") else { return }
            take(["pos"]); gControl.with { if cmd[1] == "x" { $0.layers[li].fx.x = v } else { $0.layers[li].fx.y = v } }
            limiter.log(head + String(format: " -> layer %d position %@=%.3f", n, cmd[1], v))
        case ["transform", "scale"]:
            guard let v = num(0.1, 4, "0.1..4") else { return }
            take(["scale"]); gControl.with { $0.layers[li].fx.scale = v }
            limiter.log(head + String(format: " -> layer %d scale %.3fx", n, v))
        case ["transform", "rotation"]:
            guard let v0 = finite(a0?.number), abs(v0) < 1e6 else { limiter.log(head + " -> bad args (want f degrees -180..180)"); return }
            let v = remainder(v0, 360) == -180 ? 180 : remainder(v0, 360)
            take(["rotation"]); gControl.with { $0.layers[li].fx.rotation = v }
            limiter.log(head + String(format: " -> layer %d rotation %.2f deg", n, v))
        case ["transform", "spin"]:
            guard let v = num(-2, 2, "turns/s -2..2") else { return }
            take(["spin"]); gControl.with { $0.layers[li].fx.spin = v }
            limiter.log(head + String(format: " -> layer %d spin %.3f turns/s%@", n, v, v == 0 ? " (stop)" : ""))
        case ["transform", "flipx"], ["transform", "flipy"], ["transform", "mirror"]:
            guard let b = flag(a0) else { limiter.log(head + " -> bad args (want i|f|T|F)"); return }
            take(["tile"])
            gControl.with { c in
                switch cmd[1] { case "flipx": c.layers[li].fx.flipX = b; case "flipy": c.layers[li].fx.flipY = b; default: c.layers[li].fx.mirror = b }
            }
            limiter.log(head + " -> layer \(n) \(cmd[1]) \(b ? "on" : "off")")
        case ["transform", "spinfill"]:
            guard let v = SpinFill.parse(a0) else { limiter.log(head + " -> bad args (want s auto|locked|mirror|off)"); return }
            take(["spinfill"]); gControl.with { $0.layers[li].fx.spinFill = v }
            let src = gControl.with { $0.layers[li].source }
            limiter.log(head + " -> layer \(n) spin fill \(v.rawValue)" + (src == .clip ? "" : " (layer source is \(src.rawValue): spin fill acts on clip layers; generators turn inside the pattern, fractals in the formula)"))
        case ["edge", "feather"]:
            guard let v = num(0, 1, "0..1 (0 = hard)") else { return }
            take(["edge"]); gControl.with { $0.layers[li].fx.edgeFeather = v }
            limiter.log(head + String(format: " -> layer %d edge feather %.3f", n, v))
        case ["edge", "shape"]:
            guard let v = EdgeShape.parse(a0) else { limiter.log(head + " -> bad args (want s rect|oval|circle)"); return }
            take(["edge"]); gControl.with { $0.layers[li].fx.edgeShape = v }
            limiter.log(head + " -> layer \(n) edge shape \(v.rawValue)")
        case ["transform", "tile"]:
            guard let v = num(1, 8, "1..8") else { return }
            take(["tile"]); gControl.with { $0.layers[li].fx.tile = Int(v.rounded()) }
            limiter.log(head + " -> layer \(n) tile \(Int(v.rounded()))")
        case ["fx", "1", "type"], ["fx", "2", "type"], ["fx", "1", "amount"], ["fx", "2", "amount"], ["fx", "1", "speed"], ["fx", "2", "speed"]:
            let s = Int(cmd[1])! - 1
            if cmd[2] == "type" {
                guard let t = FXType.parse(a0) else { limiter.log(head + " -> bad args (want s " + FXType.names.joined(separator: "|") + " or i 0..\(FXType.maxIndex))"); return }
                take(["fx\(s + 1)"]); gControl.with { $0.layers[li].fx.fx[s].type = t; $0.layers[li].fx.look = "" }   // a change by hand: the look is no longer "on"
                limiter.log(head + " -> layer \(n) FX\(s + 1) \(t.name)")
            } else {
                guard let v = num(0, 1, "0..1") else { return }
                take(["fx\(s + 1)"]); gControl.with { if cmd[2] == "amount" { $0.layers[li].fx.fx[s].amount = v } else { $0.layers[li].fx.fx[s].speed = v }; $0.layers[li].fx.look = "" }
                limiter.log(head + String(format: " -> layer %d FX%d %@=%.3f", n, s + 1, cmd[2], v))
            }
        case ["mod", "target"]:
            guard let t = ModTarget.parse(a0) else { limiter.log(head + " -> bad args (want s " + ModTarget.names.joined(separator: "|") + ")"); return }
            take(["mod"]); gControl.with { $0.layers[li].fx.modTarget = t }
            limiter.log(head + " -> layer \(n) beat mod target \(t.name)")
        case ["mod", "shape"]:
            guard let t = ModShape.parse(a0) else { limiter.log(head + " -> bad args (want s sine|saw|square|random)"); return }
            take(["mod"]); gControl.with { $0.layers[li].fx.modShape = t }
            limiter.log(head + " -> layer \(n) beat mod shape \(t.name)")
        case ["mod", "beats"]:
            guard let v0 = finite(a0?.number), v0 > 0 else { limiter.log(head + " -> bad args (want f beats 0.25|0.5|1|2|4|8|16)"); return }
            let v = snapModBeats(v0)
            take(["mod"]); gControl.with { $0.layers[li].fx.modBeats = v }
            limiter.log(head + " -> layer \(n) beat mod every \(modBeatName(v)) beat(s)" + (v != v0 ? " (snapped)" : ""))
        case ["mod", "depth"]:
            guard let v = num(0, 1, "0..1") else { return }
            take(["mod"]); gControl.with { $0.layers[li].fx.modDepth = v }
            limiter.log(head + String(format: " -> layer %d beat mod depth %.3f", n, v))
        case ["fx", "reset"]:
            if let v = a0?.number, v.rounded() == 0 { return }                 // button release
            take(["pos", "scale", "rotation", "spin", "tile", "fx1", "fx2", "mod", "spinfill", "edge"])
            gControl.with { $0.layers[li].fx.reset() }
            limiter.log(head + " -> layer \(n) transform + FX + beat mod reset to neutral")
        case ["fx", "preset"]:
            guard case .s(let name)? = a0 else { limiter.log(head + " -> bad args (want s preset name)"); return }
            let st = FXPresets.shared.load()
            guard let (pn, fx) = FXPresets.shared.find(name) else {
                limiter.log(head + " -> no preset '\(name)' (\(st); have: " + FXPresets.shared.names.joined(separator: ", ") + ")"); return
            }
            take(["pos", "scale", "rotation", "spin", "tile", "fx1", "fx2", "mod", "spinfill", "edge"])
            gControl.with { c in let s = c.layers[li].fx.resetSeq; c.layers[li].fx = fx; c.layers[li].fx.resetSeq = s + 1; c.layers[li].fx.look = pn }   // status fx_look (lit indicator)
            limiter.log(head + " -> layer \(n) preset '\(pn)'")
        default:
            limiter.log(head + " -> unhandled (layer FX address)")
        }
    }

    /// /oats/layers/{n}/gen/{type s|i, count f, thickness f, softness f, speed f, angle f, variation f, beatsync i,
    /// colorA fff, colorB fff, colormode s white|link|accent|custom}. Owner keys layer<n>.gen.<param> (type, count, speed,
    /// thickness are the ones DMX can take too). Does not switch the source (send /source gen).
    private func handleGen(_ m: OSCMessage, _ n: Int, _ what: String, head: String, kp: WritableKeyPath<LayerCtl, GenParams> = \LayerCtl.gen,
                           owner: String? = nil, label: String = "gen") {
        let li = layerIndex(n), k = owner ?? "layer\(n).gen."
        let a0 = m.args.first
        func finite(_ v: Double?) -> Double? { (v != nil && v!.isFinite) ? v : nil }
        func num(_ lo: Double, _ hi: Double, _ want: String) -> Double? {
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f \(want))"); return nil }
            return min(hi, max(lo, v))
        }
        func take(_ p: String) { gControl.with { $0.layerOwners[owner != nil ? k : k + p] = .osc } }
        func rgb() -> SIMD3<Double>? {
            guard m.args.count >= 3, let r = finite(m.args[0].number), let g = finite(m.args[1].number), let b = finite(m.args[2].number) else { return nil }
            return SIMD3<Double>(min(1, max(0, r)), min(1, max(0, g)), min(1, max(0, b)))
        }
        // /gen/look s NAME (2026-10-24): records the gen look's name only (the GUI server sends it after the look's params,
        // tools/oats_script.py look); status.json gen_look lights the look's button. Any gen param by hand clears it below.
        if label == "gen" && what.lowercased() == "look" {
            guard case .s(let name)? = a0 else { limiter.log(head + " -> bad args (want s gen look name)"); return }
            let ln = GenLooks.find(name)?.0 ?? name.trimmingCharacters(in: .whitespaces)
            gControl.with { $0.layers[li].genLook = ln }
            limiter.log(head + " -> layer \(n) gen look '\(ln)'" + (GenLooks.find(name) == nil ? " (not in tools/gen_presets.json: name recorded as sent)" : ""))
            return
        }
        var line = ""
        switch what.lowercased() {
        case "type":
            guard let t = GenType.parse(a0) else { limiter.log(head + " -> bad args (want s " + GenType.names.joined(separator: "|") + " or i 0..\(GenType.allCases.count - 1))"); return }
            take("type"); gControl.with { $0.layers[li][keyPath: kp].type = t }; line = "type \(t.name)"
        case "count", "density":
            guard let v = num(0, 1, "0..1 density") else { return }
            take("count"); gControl.with { $0.layers[li][keyPath: kp].count = v }; line = String(format: "count %.3f (%.1f elements)", v, 2 * pow(24, v))
        case "thickness":
            guard let v = num(0, 1, "0..1") else { return }
            take("thickness"); gControl.with { $0.layers[li][keyPath: kp].thickness = v }; line = String(format: "thickness %.3f", v)
        case "softness":
            guard let v = num(0, 1, "0..1") else { return }
            take("softness"); gControl.with { $0.layers[li][keyPath: kp].softness = v }; line = String(format: "softness %.3f", v)
        case "speed":
            guard let v = num(-1, 1, "-1..1, 0 = stop") else { return }
            take("speed"); gControl.with { $0.layers[li][keyPath: kp].speed = v }; line = String(format: "speed %.3f", v)
        case "angle":
            guard let v = num(-180, 180, "degrees -180..180") else { return }
            take("angle"); gControl.with { $0.layers[li][keyPath: kp].angle = v }; line = String(format: "angle %.1f deg", v)
        case "variation":
            guard let v = num(0, 1, "0..1") else { return }
            take("variation"); gControl.with { $0.layers[li][keyPath: kp].variation = v }; line = String(format: "variation %.3f", v)
        case "beatsync":
            var on: Bool? = nil
            if let a = a0 { switch a { case .t: on = true; case .fls: on = false; default: on = finite(a.number).map { $0 != 0 } } }
            guard let b = on else { limiter.log(head + " -> bad args (want i 0|1)"); return }
            take("beatsync"); gControl.with { $0.layers[li][keyPath: kp].beatSync = b }; line = "beatsync \(b ? "on" : "off")"
        case "colora", "colorb":
            guard let c = rgb() else { limiter.log(head + " -> bad args (want f f f 0..1)"); return }
            let isA = what.lowercased() == "colora"
            take(isA ? "colorA" : "colorB")
            gControl.with { if isA { $0.layers[li][keyPath: kp].colorA = c } else { $0.layers[li][keyPath: kp].colorB = c } }
            line = String(format: "colour %@ %.2f %.2f %.2f (colormode custom uses it)", isA ? "A" : "B", c.x, c.y, c.z)
        case "colormode":
            var md: GenColorMode? = nil
            if case .s(let s)? = a0 { md = GenColorMode(rawValue: s.lowercased().trimmingCharacters(in: .whitespaces)) }
            else if let v = finite(a0?.number), v >= 0, v < 4 { md = GenColorMode.allCases[Int(v)] }
            guard let cm = md else { limiter.log(head + " -> bad args (want s white|link|accent|custom)"); return }
            take("colormode"); gControl.with { $0.layers[li][keyPath: kp].colorMode = cm }; line = "colormode \(cm.rawValue)"
        default:
            limiter.log(head + " -> unhandled (\(label): type count thickness softness speed angle variation beatsync colorA colorB colormode)"); return
        }
        if label != "gen" {
            let on = gControl.with { c -> Bool in if what.lowercased() == "type" { c.layers[li].overlay.look = "" }; return c.layers[li].overlay.on }
            limiter.log(head + " -> layer \(n) \(label) " + line + (on ? "" : " (overlay is off: send /oats/layers/\(n)/overlay/on 1)")); return
        }
        let src = gControl.with { c -> LayerSource in c.layers[li].genLook = ""; return c.layers[li].source }   // a gen param by hand: the gen look is no longer "on"
        limiter.log(head + " -> layer \(n) gen " + line + (src == .gen ? "" : " (layer source is \(src.rawValue): send /oats/layers/\(n)/source gen to show it)"))
    }

    /// /oats/layers/{n}/overlay/{on i, type s|i, opacity f, blend s add|screen|multiply|alpha|difference, follow i,
    /// count f, thickness f, softness f, speed f, angle f, variation f, beatsync i, colormode s, colorA fff, colorB fff,
    /// look s NAME}. A generator drawn over the layer's own source inside the layer (gen.swift). Owner key layer<n>.overlay
    /// (no DMX: no free channels). look = a gen look's generator params (tools/gen_presets.json, its blend / FX ignored).
    private func handleOverlay(_ m: OSCMessage, _ n: Int, _ what: String, head: String) {
        let li = layerIndex(n), key = "layer\(n).overlay"
        let a0 = m.args.first
        func flag() -> Bool? {
            guard let a = a0 else { return nil }
            switch a { case .t: return true; case .fls: return false; default: return a.number.flatMap { $0.isFinite ? $0 != 0 : nil } }
        }
        switch what.lowercased() {
        case "on", "enable", "enabled":
            guard let b = flag() else { limiter.log(head + " -> bad args (want i 0|1)"); return }
            gControl.with { $0.layers[li].overlay.on = b; $0.layerOwners[key] = .osc }
            limiter.log(head + " -> layer \(n) overlay \(b ? "on" : "off")")
        case "opacity":
            guard let v = a0?.number, v.isFinite else { limiter.log(head + " -> bad args (want f 0..1)"); return }
            let c = min(1, max(0, v))
            gControl.with { $0.layers[li].overlay.opacity = c; $0.layerOwners[key] = .osc }
            limiter.log(head + String(format: " -> layer %d overlay opacity %.3f", n, c))
        case "blend":
            guard let b = OverlayBlend.parse(a0) else { limiter.log(head + " -> bad args (want s " + OverlayBlend.allCases.map { $0.rawValue }.joined(separator: "|") + ")"); return }
            gControl.with { $0.layers[li].overlay.blend = b; $0.layerOwners[key] = .osc }
            limiter.log(head + " -> layer \(n) overlay blend \(b.rawValue)")
        case "follow":
            guard let b = flag() else { limiter.log(head + " -> bad args (want i 0|1: 1 follows the layer motion, 0 fixed)"); return }
            gControl.with { $0.layers[li].overlay.follow = b; $0.layerOwners[key] = .osc }
            limiter.log(head + " -> layer \(n) overlay " + (b ? "follows the layer transform" : "fixed on screen"))
        case "look":
            guard case .s(let name)? = a0 else { limiter.log(head + " -> bad args (want s gen look name)"); return }
            guard let (ln, g) = GenLooks.find(name) else {
                let l = GenLooks.load()
                limiter.log(head + " -> no gen look '\(name)'" + (l.error.isEmpty ? " (have: " + l.looks.map { $0.name }.joined(separator: ", ") + ")" : " (\(l.error))")); return
            }
            gControl.with { $0.layers[li].overlay.gen = g; $0.layers[li].overlay.look = ln; $0.layerOwners[key] = .osc }
            limiter.log(head + " -> layer \(n) overlay look '\(ln)' (\(g.type.name))")
        default:
            handleGen(m, n, what, head: head, kp: \LayerCtl.overlay.gen, owner: key, label: "overlay")
        }
    }

    /// /oats/master/fx/{type s|i, amount f, speed f, reset, preset s NAME}. Owner key master.fx. Presets: the "master"
    /// section of tools/fx_presets.json (re-read every time); "off" / "none" = reset.
    private func handleMasterFX(_ m: OSCMessage, _ cmd: [String], head: String) -> Bool {
        let a0 = m.args.first
        func finite(_ v: Double?) -> Double? { (v != nil && v!.isFinite) ? v : nil }
        switch cmd {
        case ["type"]:
            guard let t = FXType.parse(a0) else { limiter.log(head + " -> bad args (want s " + FXType.names.joined(separator: "|") + " or i 0..\(FXType.maxIndex))"); return true }
            gControl.with { $0.masterFX.type = t; $0.layerOwners["master.fx"] = .osc }
            limiter.log(head + " -> master FX \(t.name)")
        case ["amount"], ["speed"]:
            guard let v0 = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 0..1)"); return true }
            let v = min(1, max(0, v0))
            gControl.with { c in if cmd[0] == "amount" { c.masterFX.amount = v } else { c.masterFX.speed = v }; c.layerOwners["master.fx"] = .osc }
            limiter.log(head + String(format: " -> master FX %@=%.3f", cmd[0], v))
        case ["reset"]:
            if let v = a0?.number, v.rounded() == 0 { return true }
            gControl.with { $0.masterFX = FXSlot(); $0.layerOwners["master.fx"] = .osc }
            limiter.log(head + " -> master FX reset (None)")
        case ["preset"]:
            guard case .s(let name)? = a0 else { limiter.log(head + " -> bad args (want s master preset name)"); return true }
            let st = FXPresets.shared.load()
            let k = name.lowercased().filter { $0.isLetter }
            let hit: (String, FXSlot)? = FXPresets.shared.findMaster(name) ?? ((k == "off" || k == "none") ? ("Off", FXSlot()) : nil)
            guard let (pn, slot) = hit else {
                limiter.log(head + " -> no master preset '\(name)' (\(st); have: " + FXPresets.shared.masterNames.joined(separator: ", ") + ")"); return true
            }
            gControl.with { $0.masterFX = slot; $0.layerOwners["master.fx"] = .osc }
            limiter.log(head + " -> master FX preset '\(pn)' (\(slot.type.name) \(String(format: "%.2f", slot.amount)), speed \(String(format: "%.2f", slot.speed)))")
        default:
            limiter.log(head + " -> unhandled (master FX address)")
        }
        return true
    }

    // MARK: lights -> VJ colour link
    // /oats/color/link f f f (0..1), /amount f, /mode s tint|hue|replace, /target s all|clips|fractal. Owner keys color.*
    private func handleColor(_ m: OSCMessage, _ cmd: [String], head: String) -> Bool {
        let a0 = m.args.first
        func finite(_ v: Double?) -> Double? { (v != nil && v!.isFinite) ? v : nil }
        func s0() -> String? { if case .s(let v)? = a0 { return v.lowercased().trimmingCharacters(in: .whitespaces) }; return nil }
        switch cmd {
        case ["link"]:
            guard m.args.count >= 3, let r = finite(m.args[0].number), let g = finite(m.args[1].number), let b = finite(m.args[2].number) else {
                limiter.log(head + " -> bad args (want f f f, 0..1)"); return true
            }
            gControl.with { c in c.color.r = min(1, max(0, r)); c.color.g = min(1, max(0, g)); c.color.b = min(1, max(0, b)); c.layerOwners["color.rgb"] = .osc }
            limiter.log(head + String(format: " -> colour link rgb %.3f %.3f %.3f", min(1, max(0, r)), min(1, max(0, g)), min(1, max(0, b))))
        case ["amount"]:
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 0..1)"); return true }
            let c = min(1, max(0, v))
            gControl.with { $0.color.amount = c; $0.layerOwners["color.amount"] = .osc }
            limiter.log(head + String(format: " -> colour link amount %.3f", c))
        case ["mode"]:
            var md: ColorMode? = s0().flatMap { ColorMode(rawValue: $0 == "hue-shift" || $0 == "hueshift" ? "hue" : $0) }
            if md == nil, let v = finite(a0?.number) { md = ColorMode.allCases[min(2, max(0, Int(v.rounded())))] }
            guard let x = md else { limiter.log(head + " -> bad args (want s tint|hue|replace)"); return true }
            gControl.with { $0.color.mode = x; $0.layerOwners["color.mode"] = .osc }
            limiter.log(head + " -> colour link mode \(x.rawValue)")
        case ["target"]:
            var tg: ColorTarget? = s0().flatMap { ColorTarget(rawValue: $0) }
            if tg == nil, let v = finite(a0?.number) { tg = ColorTarget.allCases[min(2, max(0, Int(v.rounded())))] }
            guard let x = tg else { limiter.log(head + " -> bad args (want s all|clips|fractal)"); return true }
            gControl.with { $0.color.target = x; $0.layerOwners["color.target"] = .osc }
            limiter.log(head + " -> colour link target \(x.rawValue)")
        default:
            limiter.log(head + " -> unhandled (colour address)")
        }
        return true
    }


    // MARK: formula modifiers + endless-zoom loop (state.swift FractalMods)
    // /oats/fractal/1/formula s|i, /fold i N, /fold/mirror i, /foldc i N, /foldc/mirror i, /julia f, /julia/c f f,
    // /julia/drift f, /julia/beat i, /warp f, /bailout f, /trap s|i, /trap/mix f, /trap/size f,
    // /loop s off|minibrot|dive, /loop/next s same|next|random, /loop/depth f, /loop/fade f, /preset s NAME|none.
    // Owner keys (DMX Fractal 24 can take them): fractal.formula, .fold, .julia, .juliac, .trap, .loop.
    private func handleFractalMods(_ m: OSCMessage, _ cmd: String, head: String) -> Bool {
        let a0 = m.args.first
        func finite(_ v: Double?) -> Double? { (v != nil && v!.isFinite) ? v : nil }
        func take(_ keys: [String]) { gControl.with { c in for k in keys { c.layerOwners[k] = .osc } } }
        func flag(_ a: OSCArg?) -> Bool? {
            guard let a = a else { return nil }
            switch a { case .t: return true; case .fls: return false; default: return finite(a.number).map { $0 != 0 } }
        }
        func text(_ a: OSCArg?) -> String? { if case .s(let v)? = a { return v.trimmingCharacters(in: .whitespaces) }; return nil }
        func set(_ keys: [String], _ what: String, _ body: (inout FractalMods) -> Void) {
            take(keys)
            gControl.with { c in body(&c.frac); c.frac.preset = "" }
            limiter.log(head + " -> " + what)
        }
        func foldN(_ v: Double) -> Int { let r = Int(max(-1e6, min(1e6, v.rounded()))); return r < 1 ? 0 : min(12, r) }   // 1 + mirror = one axis
        switch cmd {
        case "formula":
            var f: Formula? = nil
            if let t = text(a0) { f = Formula.parse(t) } else if let v = finite(a0?.number), abs(v) < 100 { f = Formula(rawValue: Int(v.rounded())) }
            guard let fo = f else { limiter.log(head + " -> bad args (want s " + Formula.allCases.map { $0.key }.joined(separator: "|") + " or i 0..6)"); return true }
            set(["fractal.formula"], "formula \(fo.name) (perturbation: deep zoom kept)") { $0.formula = fo }
        case "fold", "foldc":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want i N: 0 = off, 2..12)"); return true }
            let n = foldN(v)
            if cmd == "fold" {
                let wild = gControl.with { $0.frac.foldMode == .wild }
                set(["fractal.fold"], n == 0 ? "twist off" : "twist \(n) " + (wild ? "wild: z folded inside the iteration (direct float32 path: depth capped at 1e\(directDepthMax))" : "clean: c folded once into \(n) sector(s) (deep-zoom safe)") + (n == 1 ? " (1 = one mirror axis, needs the mirror)" : "")) { $0.fold = n }
            }
            else { set([], n == 0 ? "fold c off" : "fold c \(n) around the view centre (deep-zoom safe)") { $0.foldC = n } }
        case "fold/mode":
            guard let t = text(a0)?.lowercased(), let md = FoldMode(rawValue: t) else { limiter.log(head + " -> bad args (want s clean|wild)"); return true }
            set(["fractal.fold"], md == .clean ? "twist mode clean (a true kaleidoscope: c folded once, deep-zoom safe, mirror = no seams)"
                : "twist mode wild (z folded inside every iteration: direct float32 path, smooth fold, 2x2 supersampling, depth capped at 1e\(directDepthMax))") { $0.foldMode = md }
        case "fold/mirror", "foldc/mirror":
            guard let b = flag(a0) else { limiter.log(head + " -> bad args (want i 0|1)"); return true }
            if cmd == "fold/mirror" { set(["fractal.fold"], "kaleido fold mirror \(b ? "on" : "off")") { $0.foldMirror = b } }
            else { set([], "fold c mirror \(b ? "on" : "off")") { $0.foldCMirror = b } }
        case "julia":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 0..1)"); return true }
            let c = min(1, max(0, v))
            set(["fractal.julia"], String(format: "Julia morph %.3f%@", c, c > 0 ? " (direct float32 path: depth capped at 1e\(directDepthMax))" : "")) { $0.julia = c }
        case "julia/c":
            guard m.args.count >= 2, let re = finite(m.args[0].number), let im = finite(m.args[1].number) else { limiter.log(head + " -> bad args (want f re, f im; -2..2)"); return true }
            let r = min(2, max(-2, re)), i = min(2, max(-2, im))
            set(["fractal.juliac"], String(format: "Julia constant %.5f %+.5fi", r, i)) { $0.juliaRe = r; $0.juliaIm = i }
        case "julia/drift":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f cycles/s (or per beat), 0 = still)"); return true }
            let c = min(4, max(-4, v))
            set([], String(format: "Julia drift %.3f", c)) { $0.juliaDrift = c }
        case "julia/beat":
            guard let b = flag(a0) else { limiter.log(head + " -> bad args (want i 0|1)"); return true }
            set([], "Julia drift " + (b ? "beat-synced (cycles per beat)" : "free (cycles/s)")) { $0.juliaBeat = b }
        case "warp":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 0..0.5)"); return true }
            let c = min(0.5, max(-0.5, v))
            set([], String(format: "warp k %.3f (z^2 + c + k sin z%@)", c, c != 0 ? "; direct float32 path" : "")) { $0.warp = c }
        case "bailout":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 2..1024, default 256)"); return true }
            let c = min(1024, max(2, v))
            set([], String(format: "bailout radius %.1f", c)) { $0.bailout = c }
        case "trap":
            var t: TrapShape? = nil
            if let x = text(a0) { t = TrapShape(rawValue: x.lowercased()) } else if let v = finite(a0?.number), v >= 0, v < 6 { t = TrapShape.allCases[Int(v)] }
            guard let tr = t else { limiter.log(head + " -> bad args (want s " + TrapShape.allCases.map { $0.rawValue }.joined(separator: "|") + ")"); return true }
            set(["fractal.trap"], "orbit trap \(tr.rawValue)") { $0.trap = tr }
        case "trap/mix", "trap/size":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f)"); return true }
            if cmd == "trap/mix" { let c = min(1, max(0, v)); set([], String(format: "trap mix %.3f", c)) { $0.trapMix = c } }
            else { let c = min(4, max(0.01, v)); set([], String(format: "trap size %.3f", c)) { $0.trapSize = c } }
        case "loop":
            var l: LoopMode? = nil
            if let x = text(a0) { l = LoopMode(rawValue: x.lowercased()) } else if let v = finite(a0?.number), v >= 0, v < 3 { l = LoopMode.allCases[Int(v)] }
            guard let lm = l else { limiter.log(head + " -> bad args (want s off|minibrot|dive)"); return true }
            set(["fractal.loop"], "loop \(lm.rawValue)" + (lm == .off ? "" : " (comes round while the auto-zoom runs inward)")) { $0.loop = lm }
        case "loop/next":
            guard let x = text(a0), let n = LoopNext(rawValue: x.lowercased()) else { limiter.log(head + " -> bad args (want s same|next|random)"); return true }
            set([], "loop next target: \(n.rawValue)") { $0.loopNext = n }
        case "loop/depth":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f log10 zoom 1..28)"); return true }
            let c = min(zoomDepthMax, max(1, v))
            set([], String(format: "dive & return at depth %.2f", c)) { $0.loopDepth = c }
        case "loop/fade":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f seconds 0.2..10)"); return true }
            let c = min(10, max(0.2, v))
            set([], String(format: "loop crossfade %.2f s (Minibrot loop: %.2f s)", c, c * 0.5)) { $0.loopFade = c }
        case "power":
            // Branches: z^p + c, 1.5 ... 6. Integer 2...5 on the Mandelbrot family = Multibrot (perturbation, deep zoom)
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f \(powerMin)..\(powerMax), 2 = classic)"); return true }
            take(["fractal.formula"])
            let (p, fo, polar) = gControl.with { c -> (Double, Formula, Bool) in c.frac.setPower(v); c.frac.preset = ""; return (c.frac.power, c.frac.formula, c.frac.polarPower) }
            limiter.log(head + String(format: " -> power %.3f, ", p) + (polar ? "real exponent z^p (direct float32 path: depth capped at 1e\(directDepthMax))" : "\(fo.name) (perturbation: deep zoom kept)"))
        case "shape":
            guard let t = text(a0), let sp = findShapePreset(t) else {
                limiter.log(head + " -> bad args (want s " + shapePresets.map { $0.name }.joined(separator: "|") + ")"); return true
            }
            take(["fractal.formula", "fractal.fold", "fractal.julia", "fractal.juliac"])
            let direct = gControl.with { c -> Bool in c.frac.apply(sp); return c.frac.direct }
            limiter.log(head + " -> shape \(sp.name): \(sp.formula.name)" + (sp.fold >= 2 ? ", kaleido \(sp.fold)" + (sp.mirror ? " mirror" : "") : "")
                        + (sp.julia > 0 ? String(format: ", Julia %.3f %+.3fi", sp.jre, sp.jim) : "") + (direct ? " (direct float32 path: depth capped at 1e\(directDepthMax))" : " (deep zoom kept)"))
        case "shape/reset":
            // this target's shape back to the defaults (formula, twist, rotation, iterations, Julia, trap, advanced fold)
            let tn: String = gControl.with { c in
                c.shape = ShapeMemo()
                let n = zoomTargets[min(zoomTargets.count - 1, max(0, c.shapeTarget))].name
                c.shapeMemory[n] = nil
                for k in ["fractal.formula", "fractal.fold", "fractal.julia", "fractal.juliac", "fractal.trap"] { c.layerOwners[k] = .osc }
                c.ltpOSC([.rotation, .iterations], depthMove: false)
                return n
            }
            limiter.log(head + " -> shape reset: \(tn) back to the default shape (Mandelbrot, no twist, rotation 0, iterations auto)")
        case "shape/memory":
            guard let b = flag(a0) else { limiter.log(head + " -> bad args (want i 0|1)"); return true }
            gControl.with { $0.shapeMemoryOn = b }
            limiter.log(head + " -> shape memory " + (b ? "ON (each target keeps its own shape)" : "off (the shape stays when the target changes)"))
        case "shape/memory/data":
            // restore (tools/oats_state.py): s JSON {"SEAHORSE": {shape dict}, ...}; replaces the saved shapes
            guard let t = text(a0), t.count < 60000, let d = t.data(using: .utf8),
                  let j = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] else { limiter.log(head + " -> bad args (want s JSON {TARGET: {shape}})"); return true }
            let n: Int = gControl.with { c in c.setShapeMemory(j); return c.shapeMemory.count }
            limiter.log(head + " -> shape memory data: \(n) target shape(s) loaded")
        case "preset":
            guard let name = text(a0) else { limiter.log(head + " -> bad args (want s NAME|none)"); return true }
            limiter.log(head + " -> " + applyFractalPreset(name))
        case "spread":
            // Spread <-> Tighten macro: -1 spread (wider, softer gradients) ... 0 as before ... +1 tighten (denser bands, crisper edges)
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f -1 spread ... 0 ... +1 tighten)"); return true }
            let c = min(1, max(-1, v))
            take(["fractal.spread"])
            gControl.with { $0.frac.spread = c }
            limiter.log(head + String(format: " -> spread %+.2f (palette density x%.2f%@)", c, pow(4.0, c), c > 0 ? String(format: ", smoothing -%.0f%%", c * 85) : ""))
        case "phaser/free":
            // "Phasers run even when stopped": 1 = the old behaviour (HOLD / Cycle 0 do not pause the phasers on zoom / colour)
            guard let b = flag(a0) else { limiter.log(head + " -> bad args (want i 0|1)"); return true }
            take(["fractal.phasers"])
            gControl.with { $0.frac.phaserFree = b }
            limiter.log(head + " -> phasers " + (b ? "run even when stopped (HOLD / Cycle 0 do not pause them)" : "pause when stopped: HOLD pauses the zoom breathe, Cycle 0 spread / offset"))
        case "phaser/preset":
            guard let name = text(a0) else { limiter.log(head + " -> bad args (want s NAME|off)"); return true }
            take(["fractal.phasers"])
            limiter.log(head + " -> " + applyPhaserPreset(name))
        default:
            if cmd.hasPrefix("phaser/") { return handlePhaser(m, String(cmd.dropFirst(7)), head: head) }
            return false
        }
        return true
    }

    // /oats/fractal/1/phaser/{1..3}/{target s, shape s, beats f, seconds f, depth f, phase f, on i} (phasers.swift).
    // Owner key fractal.phasers. A change keeps the phaser preset name only while the 3 phasers still equal a preset
    // (matchingPhaserPreset; a restore value by value gets it back), else clears it (the look's own name stays).
    private func handlePhaser(_ m: OSCMessage, _ rest: String, head: String) -> Bool {
        let parts = rest.split(separator: "/").map(String.init)
        guard parts.count == 2, let n = Int(parts[0]), (1...phaserCount).contains(n) else {
            limiter.log(head + " -> bad address (want /oats/fractal/1/phaser/{1..\(phaserCount)}/{target,shape,beats,seconds,depth,phase,on} or /phaser/preset)")
            return true
        }
        let k = n - 1, a0 = m.args.first
        func finite(_ v: Double?) -> Double? { (v != nil && v!.isFinite) ? v : nil }
        func text() -> String? { if case .s(let v)? = a0 { return v.trimmingCharacters(in: .whitespaces) }; return nil }
        func set(_ what: String, _ body: (inout Phaser) -> Void) {
            let presets = loadPhaserPresets()           // the file, read outside the control lock
            gControl.with { c in body(&c.frac.phasers[k]); c.frac.phaserPreset = matchingPhaserPreset(c.frac.phasers, list: presets); c.layerOwners["fractal.phasers"] = .osc }
            limiter.log(head + " -> phaser \(n) " + what)
        }
        switch parts[1] {
        case "target":
            guard let t = text().flatMap(PhaserTarget.parse) else { limiter.log(head + " -> bad args (want s " + PhaserTarget.allCases.map { $0.rawValue }.joined(separator: "|") + ")"); return true }
            set("target \(t.label)") { $0.target = t }
        case "shape":
            guard let t = text().flatMap(PhaserShape.parse) else { limiter.log(head + " -> bad args (want s " + PhaserShape.allCases.map { $0.rawValue }.joined(separator: "|") + ")"); return true }
            set("shape \(t.rawValue)") { $0.shape = t }
        case "beats":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f beats 0.25..32)"); return true }
            let b = phaserBeats(v)
            set(String(format: "rate %.3g beats (tempo clock)", b)) { $0.beats = b; $0.seconds = 0 }
        case "seconds":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f seconds 0.1..600; 0 = back to beats)"); return true }
            let sec = v <= 0 ? 0 : min(600, max(0.1, v))
            set(sec == 0 ? "rate in beats again" : String(format: "rate %.3g s per cycle", sec)) { $0.seconds = sec }
        case "depth":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 0..1)"); return true }
            let d = min(1, max(0, v))
            set(String(format: "depth %.2f", d)) { $0.depth = d }
        case "phase":
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 0..1)"); return true }
            let ph = v - floor(v)
            set(String(format: "phase %.3f", ph)) { $0.phase = ph }
        case "on":
            var b: Bool? = nil
            if let a = a0 { switch a { case .t: b = true; case .fls: b = false; default: b = finite(a.number).map { $0 != 0 } } }
            guard let on = b else { limiter.log(head + " -> bad args (want i 0|1)"); return true }
            set(on ? "on" : "off") { $0.on = on }
        default:
            limiter.log(head + " -> unknown phaser parameter '\(parts[1])' (target, shape, beats, seconds, depth, phase, on)")
        }
        return true
    }

    // MARK: M2a clip layers
    // /oats/layers/{n}/play i bank i slot | clear | opacity f | blend s|i | speed f | transition f | playmode s|i
    // /oats/fractal/opacity f; Resolume aliases /composition/layers/{n}/clips/{c}/connect [i 1] (layer's bank, slot c),
    // /composition/layers/{n}/video/opacity f, /composition/layers/{n}/clear. Owner keys "layer<n>.<param>".
    private func handleLayer(_ m: OSCMessage, head: String) -> Bool {
        let parts = m.address.split(separator: "/", omittingEmptySubsequences: true).map(String.init)
        let a0 = m.args.first
        func finite(_ v: Double?) -> Double? { (v != nil && v!.isFinite) ? v : nil }
        func take(_ keys: [String]) { gControl.with { c in for k in keys { c.layerOwners[k] = .osc } } }
        // column go: slot c on every layer whose bank has a slot c (Resolume: /composition/columns/{c}/connect i 1)
        if parts.count == 4, (parts[0] == "oats" && parts[1] == "column" && parts[3] == "go") ||
                             (parts[0] == "composition" && parts[1] == "columns" && parts[3] == "connect"), let col = Int(parts[2]) {
            if let v = a0?.number, v.rounded() != 1, parts[0] == "composition" { return true }   // 0 = release
            guard col >= 1 && col <= 255 else { limiter.log(head + " -> no column \(col) (1..255)"); return true }
            let lib = gLibrary
            let done = gControl.with { $0.columnGo(col, owner: .osc, lib: lib) }
            limiter.log(head + " -> column \(col): " + (done.isEmpty ? "no layer's bank has a slot \(col)" : done.joined(separator: ", ")))
            return true
        }
        if parts.count >= 3, parts[0] == "oats", parts[1] == "color" { return handleColor(m, Array(parts[2...]), head: head) }
        if parts == ["oats", "library", "reload"] {
            let dir = gLibrary.dir
            let nl = Library(dir: dir)
            gLibrary = nl
            limiter.log(head + " -> library reloaded: " + nl.banks.map { "bank \($0.bank) \($0.name) \($0.clips.count)" }.joined(separator: ", ") + (nl.error.isEmpty ? "" : " (\(nl.error))"))
            return true
        }
        if parts == ["oats", "tempo", "tap"] {
            gControl.with { $0.tapSeq += 1 }
            limiter.log(head + " -> tap"); return true
        }
        if parts == ["oats", "tempo", "resync"] {
            gControl.with { $0.resyncSeq += 1 }
            limiter.log(head + " -> tempo resync (beat 1)"); return true
        }
        if parts == ["oats", "analysis", "out"] {
            var dest = ""
            if case .s(let v)? = a0 { dest = v.trimmingCharacters(in: .whitespaces) }
            if dest.lowercased() == "off" || dest == "0" { dest = "" }
            if !dest.isEmpty && parseHostPort(dest) == nil { limiter.log(head + " -> bad args (want s host:port or off)"); return true }
            if !dest.isEmpty, let d = parseHostPort(dest), !filter.allows(d.sin_addr) {
                limiter.log(head + " -> refused: \(dest) is not on the lighting network or this Mac (\(filter.listText))"); return true
            }
            gControl.with { $0.analysisOut = dest }
            limiter.log(head + " -> analysis OSC out " + (dest.isEmpty ? "off" : "to \(dest)"))
            return true
        }
        if parts == ["oats", "fractal", "opacity"] {
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 0..1)"); return true }
            let c = min(1, max(0, v))
            take(["fractal.opacity"])
            gControl.with { $0.fractalOpacity = c }
            limiter.log(head + String(format: " -> fractal layer opacity=%.3f", c))
            return true
        }
        if parts == ["oats", "fractal", "layer"] || parts == ["oats", "fractal", "1", "layer"] {
            guard let v = finite(a0?.number), v >= 0, v <= Double(layerCount) else { limiter.log(head + " -> bad args (want i 0 = base, 1..\(layerCount))"); return true }
            let k = Int(v.rounded())
            var keys = ["fractal.layer"]; if k > 0 { keys.append("layer\(k).source") }
            take(keys)
            let r = gControl.with { $0.setFractalLayer(k) }
            limiter.log(head + " -> " + r)
            return true
        }
        if parts.count >= 3, parts[0] == "oats", parts[1] == "master", parts[2] == "fx" { return handleMasterFX(m, Array(parts[3...]), head: head) }
        var n = 0, cmd: [String] = []
        if parts.count >= 4, parts[0] == "oats", parts[1] == "layers", let k = Int(parts[2]) { n = k; cmd = Array(parts[3...]) }
        else if parts.count >= 4, parts[0] == "composition", parts[1] == "layers", let k = Int(parts[2]) { n = k; cmd = ["rs"] + Array(parts[3...]) }
        else { return false }
        guard n >= 0 && n <= layerCount else { limiter.log(head + " -> no layer \(n) (0 = BG, 1..\(layerCount))"); return true }
        let li = layerIndex(n)                              // /oats/layers/0/... = BG (the base layer L0, a full layer)
        let key = "layer\(n)."
        func play(bank: Int, slot: Int) {
            guard gLibrary.clip(bank: bank, slot: slot) != nil else {
                limiter.log(head + " -> bank \(bank) slot \(slot) is not in the library (bank \(bank) has \(gLibrary.slots(bank: bank)) slots)"); return
            }
            take([key + "clip"])
            let (tr, sw): (Double, String) = gControl.with { c in
                c.layers[li].bank = bank; c.layers[li].slot = slot; c.layers[li].playSeq += 1
                var s = ""
                if c.layers[li].source != .clip { c.layerOwners[key + "source"] = .osc; s = " (" + c.setSource(li, .clip) + ")" }   // a clip play shows the clip
                return (c.layers[li].transition, s)
            }
            limiter.log(head + " -> layer \(n) play bank \(bank) slot \(slot) '\(gLibrary.clip(bank: bank, slot: slot)!.name)'" + (tr > 0 ? String(format: " (transition %.2f s)", tr) : "") + sw)
        }
        switch cmd {
        case ["play"]:
            guard m.args.count >= 2, let b = finite(m.args[0].number), let sl = finite(m.args[1].number), abs(b) < 1e6, abs(sl) < 1e6 else {
                limiter.log(head + " -> bad args (want i bank, i slot)"); return true
            }
            play(bank: Int(b.rounded()), slot: Int(sl.rounded()))
        case ["clear"], ["rs", "clear"]:
            take([key + "clip"])
            gControl.with { c in c.layers[li].slot = 0; c.layers[li].playSeq += 1 }
            limiter.log(head + " -> layer \(n) clear")
        case ["opacity"], ["rs", "video", "opacity"]:
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 0..1)"); return true }
            let c = min(1, max(0, v))
            take([key + "opacity"] + (n == 0 ? ["fractal.opacity"] : []))
            gControl.with { $0.layers[li].opacity = c }
            limiter.log(head + String(format: " -> layer %d opacity=%.3f", n, c))
        case ["blend"]:
            guard let b = BlendMode.parse(a0) else {
                limiter.log(head + " -> bad args (want s " + BlendMode.allCases.map { $0.name }.joined(separator: "|") + " or i 1..8)"); return true
            }
            take([key + "blend"])
            gControl.with { $0.layers[li].blend = b }
            limiter.log(head + " -> layer \(n) blend \(b.name)")
        case ["speed"]:
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f 0..4)"); return true }
            let c = min(4, max(0, v))
            take([key + "speed"])
            gControl.with { $0.layers[li].speed = c }
            limiter.log(head + String(format: " -> layer %d speed=%.3fx (forward only)", n, c))
        case ["transition"]:
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f seconds 0..10)"); return true }
            let c = min(10, max(0, v))
            take([key + "transition"])
            gControl.with { $0.layers[li].transition = c }
            limiter.log(head + String(format: " -> layer %d transition=%.2f s", n, c))
        case ["seek"], ["seek", "sec"]:                     // scrub the playing clip: f 0..1 of its duration, or seconds
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f " + (cmd.count == 1 ? "0..1)" : "seconds)")); return true }
            if cmd.count == 1 { gSeek.set(li, fraction: v) } else { gSeek.set(li, seconds: v) }
            if cmd.count == 1 { limiter.log(head + String(format: " -> layer %d seek %.3f", n, v)) }   // seconds form: logged by the layer
        case ["next"], ["prev"], ["random"]:
            if let v = a0?.number, v.rounded() == 0 { return true }       // button release
            let op = ClipNav(rawValue: cmd[0])!
            let lib = gLibrary
            let r = gControl.with { $0.navLayer(li, op, owner: .osc, lib: lib) }
            limiter.log(head + " -> " + (r ?? "layer \(n): bank has no clips"))
        case ["autopilot"]:
            var ap: Autopilot? = nil
            if case .s(let v)? = a0 { ap = Autopilot(rawValue: v.lowercased()) }
            else if let v = finite(a0?.number) { ap = [Autopilot.off, .order, .shuffle][min(2, max(0, Int(v.rounded())))] }
            guard let a = ap else { limiter.log(head + " -> bad args (want s off|order|shuffle)"); return true }
            take([key + "autopilot"])
            let (ev, bt) = gControl.with { c -> (Double, Double) in c.layers[li].autopilot = a; return (c.layers[li].apEvery, c.layers[li].apBeats) }
            limiter.log(head + " -> layer \(n) autopilot \(a.rawValue)" + (a == .off ? "" : ev > 0 ? String(format: " every %.1f s", ev) : String(format: " every %.0f beats", bt)))
        case ["autopilot", "every"]:
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f seconds 0.1..3600)"); return true }
            let c = min(3600, max(0.1, v))
            take([key + "autopilot"])
            gControl.with { $0.layers[li].apEvery = c }
            limiter.log(head + String(format: " -> layer %d autopilot every %.2f s", n, c))
        case ["autopilot", "beats"]:
            guard let v = finite(a0?.number) else { limiter.log(head + " -> bad args (want f beats 0.25..256)"); return true }
            let c = min(256, max(0.25, v))
            take([key + "autopilot"])
            gControl.with { $0.layers[li].apBeats = c; $0.layers[li].apEvery = 0 }
            limiter.log(head + String(format: " -> layer %d autopilot every %g beats (player BPM)", n, c))
        case ["playmode"]:
            guard let pm = PlayMode.parse(a0) else { limiter.log(head + " -> bad args (want s loop|once, or i 0|1)"); return true }
            take([key + "playmode"])
            gControl.with { $0.layers[li].playmode = pm }
            limiter.log(head + " -> layer \(n) playmode \(pm == .loop ? "loop" : "once + hold")")
        case _ where cmd.first == "transform" || cmd.first == "fx" || cmd.first == "mod" || cmd.first == "edge":
            handleLayerFX(m, n, cmd, head: head)
        case ["source"]:
            guard let s = LayerSource.parse(a0) else { limiter.log(head + " -> bad args (want s clip|fractal|gen|ndi, or i 0|1|2|3)"); return true }
            take([key + "source"] + (s == .fractal ? ["fractal.layer"] : []))
            let r = gControl.with { $0.setSource(li, s) }
            limiter.log(head + " -> " + r)
        case ["ndi"]:
            // NDI source for this layer (ndiin.swift): the full NDI name or a unique part ("OBSBOT"); also selects source ndi
            guard case .s(let v)? = a0 else { limiter.log(head + " -> bad args (want s NDI source name or a part of it, e.g. \"OBSBOT\")"); return true }
            let nm = String(v.prefix(200)).trimmingCharacters(in: .whitespaces)
            take([key + "ndi", key + "source"])
            let r = gControl.with { c -> String in
                c.layers[li].ndiName = nm
                return c.layers[li].source == .ndi ? "\(layerLabel(li)) NDI source '\(nm)'" : c.setSource(li, .ndi) + ", NDI source '\(nm)'"
            }
            limiter.log(head + " -> " + r)
        case ["ndi", "bandwidth"]:
            guard let b = NDIBandwidth.parse(a0) else { limiter.log(head + " -> bad args (want s full|proxy)"); return true }
            take([key + "ndi"])
            gControl.with { $0.layers[li].ndiBandwidth = b }
            limiter.log(head + " -> \(layerLabel(li)) NDI bandwidth \(b.rawValue)")
        case _ where cmd.first == "gen" && cmd.count == 2:
            handleGen(m, n, cmd[1], head: head)
        case _ where cmd.first == "overlay" && cmd.count == 2:
            handleOverlay(m, n, cmd[1], head: head)
        default:
            if cmd.count == 4, cmd[0] == "rs", cmd[1] == "clips", let col = Int(cmd[2]), cmd[3] == "connect" {
                if let v = a0?.number, v.rounded() != 1 { return true }       // Resolume sends 1 on press, 0 on release
                let bank = gControl.with { $0.layers[li].bank }
                play(bank: bank, slot: col)
                return true
            }
            limiter.log(head + " -> unhandled (layer address)")
        }
        return true
    }
}

/// "host:port" (IPv4 or name) -> sockaddr_in, or nil.
func parseHostPort(_ s: String) -> sockaddr_in? {
    let p = s.split(separator: ":")
    guard p.count == 2, let port = UInt16(p[1]), port > 0 else { return nil }
    var a = sockaddr_in()
    a.sin_len = UInt8(MemoryLayout<sockaddr_in>.size); a.sin_family = sa_family_t(AF_INET); a.sin_port = port.bigEndian
    if inet_pton(AF_INET, String(p[0]), &a.sin_addr) == 1 { return a }
    var hints = addrinfo(); hints.ai_family = AF_INET; hints.ai_socktype = SOCK_DGRAM
    var res: UnsafeMutablePointer<addrinfo>? = nil
    guard getaddrinfo(String(p[0]), nil, &hints, &res) == 0, let r = res, let sa = r.pointee.ai_addr else { return nil }
    defer { freeaddrinfo(res) }
    a.sin_addr = sa.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { $0.pointee.sin_addr }
    return a
}

/// OSC message with float args.
func oscEncodeFloats(_ address: String, _ fs: [Float]) -> [UInt8] {
    func pad(_ s: String) -> [UInt8] { var v = Array(s.utf8) + [0]; while v.count % 4 != 0 { v.append(0) }; return v }
    var out = pad(address) + pad("," + String(repeating: "f", count: fs.count))
    for f in fs { let u = f.bitPattern.bigEndian; withUnsafeBytes(of: u) { out += $0 } }
    return out
}


// MARK: - fractal presets (tools/fractal_presets.json)

/// tools/fractal_presets.json next to the binary's folder (<bin>/../tools).
func fractalPresetsPath() -> String {
    if !gPresetsDirOverride.isEmpty { return (gPresetsDirOverride as NSString).appendingPathComponent("fractal_presets.json") }
    return URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath().deletingLastPathComponent()
        .deletingLastPathComponent().appendingPathComponent("tools/fractal_presets.json").standardizedFileURL.path
}
func loadFractalPresets() -> [[String: Any]] {
    guard let d = FileManager.default.contents(atPath: fractalPresetsPath()),
          let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any], let l = j["presets"] as? [[String: Any]] else { return [] }
    return l
}
/// Names for status.json (read once at start; /preset reads the file again, so edits apply without a restart).
let gFractalPresetNames: [String] = loadFractalPresets().compactMap { $0["name"] as? String }

/// Applies a preset: formula modifiers back to the defaults (the loop depth and fade stay), then its fields.
/// Fields: formula, fold, fold_mirror, foldc, foldc_mirror, julia, julia_c [re, im], julia_drift, julia_beat, warp,
/// bailout, trap, trap_mix, trap_size, loop, loop_next, loop_depth, palette, palette_speed, target, center [re, im],
/// depth, zoomspeed, rotation. "none" = the classic defaults only.
func applyFractalPreset(_ name: String) -> String {
    let none = ["none", "off", "reset", "classic"].contains(name.lowercased())
    let list = loadFractalPresets()
    guard none || list.contains(where: { ($0["name"] as? String)?.caseInsensitiveCompare(name) == .orderedSame }) else {
        return "no preset '\(name)' in \(fractalPresetsPath()) (have: " + list.compactMap { $0["name"] as? String }.joined(separator: ", ") + ")"
    }
    let p = none ? [:] : list.first { ($0["name"] as? String)?.caseInsensitiveCompare(name) == .orderedSame }!
    let f = (p["set"] as? [String: Any]) ?? p
    func num(_ k: String) -> Double? { (f[k] as? NSNumber)?.doubleValue }
    func str(_ k: String) -> String? { f[k] as? String }
    func pair(_ k: String) -> (Double, Double)? {
        guard let a = f[k] as? [Any], a.count == 2 else { return nil }
        if let x = (a[0] as? NSNumber)?.doubleValue, let y = (a[1] as? NSNumber)?.doubleValue { return (x, y) }
        return nil
    }
    var notes: [String] = []
    gControl.with { c in
        let oldShape = c.shape, oldTarget = c.shapeTarget      // shape memory: a preset with a target saves the old target's shape
        var m = FractalMods()
        m.loopDepth = c.frac.loopDepth; m.loopFade = c.frac.loopFade
        m.phasers = c.frac.phasers; m.phaserPreset = c.frac.phaserPreset; m.spread = c.frac.spread   // kept unless the look sets them
        m.phaserFree = c.frac.phaserFree
        if let v = num("spread") { m.spread = min(1, max(-1, v)) }
        if let rows = f["phasers"] as? [[String: Any]] {
            for k in 0..<phaserCount { m.phasers[k] = k < rows.count ? Phaser.from(rows[k]) : Phaser() }
            m.phaserPreset = ""
        }
        if let s = str("formula"), let fo = Formula.parse(s) { m.formula = fo }
        if let v = num("power") { m.setPower(v) }
        if let v = num("fold") { m.fold = v < 1 ? 0 : min(12, Int(v.rounded())) }
        if let s = str("fold_mode"), let md = FoldMode(rawValue: s.lowercased()) { m.foldMode = md }
        else if m.fold >= 2 { m.foldMode = .wild }                      // looks written before Twist modes meant the fold of z
        if let v = num("fold_mirror") { m.foldMirror = v != 0 }
        if let v = num("foldc") { m.foldC = v < 2 ? 0 : min(12, Int(v.rounded())) }
        if let v = num("foldc_mirror") { m.foldCMirror = v != 0 }
        if let v = num("julia") { m.julia = min(1, max(0, v)) }
        if let (x, y) = pair("julia_c") { m.juliaRe = min(2, max(-2, x)); m.juliaIm = min(2, max(-2, y)) }
        if let v = num("julia_drift") { m.juliaDrift = min(4, max(-4, v)) }
        if let v = num("julia_beat") { m.juliaBeat = v != 0 }
        if let v = num("warp") { m.warp = min(0.5, max(-0.5, v)) }
        if let v = num("bailout") { m.bailout = min(1024, max(2, v)) }
        if let s = str("trap"), let t = TrapShape(rawValue: s.lowercased()) { m.trap = t }
        if let v = num("trap_mix") { m.trapMix = min(1, max(0, v)) }
        if let v = num("trap_size") { m.trapSize = min(4, max(0.01, v)) }
        if let s = str("loop"), let l = LoopMode(rawValue: s.lowercased()) { m.loop = l }
        if let s = str("loop_next"), let l = LoopNext(rawValue: s.lowercased()) { m.loopNext = l }
        if let v = num("loop_depth") { m.loopDepth = min(zoomDepthMax, max(1, v)) }
        m.preset = none ? "" : (p["name"] as? String ?? name)
        c.frac = m
        for k in ["fractal.formula", "fractal.fold", "fractal.julia", "fractal.juliac", "fractal.trap", "fractal.loop"] { c.layerOwners[k] = .osc }
        var ps: [Param] = []
        if let v = num("palette") { c.palette = min(5, max(1, Int(v.rounded()))); ps.append(.palette) }
        if let v = num("palette_speed") { c.paletteSpeed = min(10, max(-10, v)); ps.append(.palette_speed) }
        if let v = num("rotation") { var r = v.truncatingRemainder(dividingBy: 360); if r < 0 { r += 360 }; c.rotation = r; ps.append(.rotation) }
        let depth = num("depth").map { min(zoomDepthMax, max(0, $0)) }
        if let s = str("target"), let ti = findTarget(s) {
            c.targetRequest = ti; c.centerRequest = nil; c.targetDepth = depth ?? 0; ps.append(.target)
            if c.shapeMemoryOn && ti != oldTarget && oldTarget >= 0 && oldTarget < zoomTargets.count { c.shapeMemory[zoomTargets[oldTarget].name] = oldShape }
            c.shapeTarget = ti
            if depth != nil { ps.append(.depth) }
        } else if let (x, y) = pair("center"), let spec = CentreSpec.custom(re: String(format: "%.17g", x), im: String(format: "%.17g", y)) {
            c.centerRequest = spec; c.targetRequest = nil; ps.append(.target)
            if let d = depth { c.zoomSet = log10WidthMax - d; ps.append(.depth) }
        } else if let d = depth { c.zoomSet = log10WidthMax - d; ps.append(.depth) }
        if let v = num("zoomspeed") { ps.append(.zoomspeed); c.ltpOSC(ps, depthMove: false); c.zoomSpeed = min(5, max(-5, v)) }
        else if !ps.isEmpty { c.ltpOSC(ps, depthMove: ps.contains(.depth)) }
        notes.append(none ? "fractal preset none: classic Mandelbrot, no modifiers, loop off" :
                     "fractal preset '\(m.preset)': \(m.formula.name)" + (m.fold >= 2 ? ", fold \(m.fold)" : "") + (m.julia > 0 ? String(format: ", Julia %.2f", m.julia) : "")
                     + (m.trap != .off ? ", trap \(m.trap.rawValue)" : "") + (m.loop != .off ? ", loop \(m.loop.rawValue)" : ""))
    }
    return notes.joined()
}
