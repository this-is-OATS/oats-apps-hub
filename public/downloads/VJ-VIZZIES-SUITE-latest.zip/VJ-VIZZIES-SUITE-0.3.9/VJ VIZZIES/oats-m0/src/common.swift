// Copied unchanged from ndi-bench/src/common.swift (timing, CPU/memory, stats helpers) for oats-m0.
import Foundation
import Darwin

// ---------- timing ----------
let gTimebase: mach_timebase_info_data_t = {
    var t = mach_timebase_info_data_t()
    mach_timebase_info(&t)
    return t
}()

@inline(__always) func nowTicks() -> UInt64 { mach_absolute_time() }
func ticksToSec(_ t: UInt64) -> Double { Double(t) * Double(gTimebase.numer) / Double(gTimebase.denom) / 1e9 }
func secToTicks(_ s: Double) -> UInt64 { UInt64(s * 1e9 * Double(gTimebase.denom) / Double(gTimebase.numer)) }

// ---------- per-process CPU / memory ----------
func procCPUSeconds() -> Double {
    var ru = rusage()
    getrusage(RUSAGE_SELF, &ru)
    let u = Double(ru.ru_utime.tv_sec) + Double(ru.ru_utime.tv_usec) / 1e6
    let s = Double(ru.ru_stime.tv_sec) + Double(ru.ru_stime.tv_usec) / 1e6
    return u + s
}

func maxRSSMB() -> Double {
    var ru = rusage()
    getrusage(RUSAGE_SELF, &ru)
    return Double(ru.ru_maxrss) / 1048576.0   // bytes on macOS
}

func memMB() -> (rss: Double, footprint: Double) {
    var info = mach_task_basic_info()
    var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size / MemoryLayout<natural_t>.size)
    _ = withUnsafeMutablePointer(to: &info) {
        $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
            task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
        }
    }
    var vm = task_vm_info_data_t()
    var c2 = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<natural_t>.size)
    _ = withUnsafeMutablePointer(to: &vm) {
        $0.withMemoryRebound(to: integer_t.self, capacity: Int(c2)) {
            task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &c2)
        }
    }
    return (Double(info.resident_size) / 1048576.0, Double(vm.phys_footprint) / 1048576.0)
}

// ---------- system-wide per-core load ----------
struct CoreTicks { var busy: UInt32; var total: UInt32 }

func perCoreTicks() -> [CoreTicks] {
    var cpuCount: natural_t = 0
    var arr: processor_info_array_t? = nil
    var cnt: mach_msg_type_number_t = 0
    guard host_processor_info(mach_host_self(), PROCESSOR_CPU_LOAD_INFO, &cpuCount, &arr, &cnt) == KERN_SUCCESS,
          let a = arr else { return [] }
    var out: [CoreTicks] = []
    for i in 0..<Int(cpuCount) {
        let b = Int(CPU_STATE_MAX) * i
        let user = UInt32(bitPattern: a[b + Int(CPU_STATE_USER)])
        let sys = UInt32(bitPattern: a[b + Int(CPU_STATE_SYSTEM)])
        let idle = UInt32(bitPattern: a[b + Int(CPU_STATE_IDLE)])
        let nice = UInt32(bitPattern: a[b + Int(CPU_STATE_NICE)])
        out.append(CoreTicks(busy: user &+ sys &+ nice, total: user &+ sys &+ idle &+ nice))
    }
    vm_deallocate(mach_task_self_, vm_address_t(UInt(bitPattern: a)), vm_size_t(Int(cnt) * MemoryLayout<integer_t>.stride))
    return out
}

func coreBusyPct(_ a: [CoreTicks], _ b: [CoreTicks]) -> [Double] {
    guard a.count == b.count else { return [] }
    return zip(a, b).map { (x, y) in
        let db = Double(y.busy &- x.busy), dt = Double(y.total &- x.total)
        return dt > 0 ? 100.0 * db / dt : 0
    }
}

// ---------- stats ----------
struct Stats {
    var v: [Double] = []
    mutating func add(_ x: Double) { v.append(x) }
    var mean: Double { v.isEmpty ? 0 : v.reduce(0, +) / Double(v.count) }
    func pct(_ q: Double) -> Double {
        if v.isEmpty { return 0 }
        let s = v.sorted()
        return s[min(s.count - 1, Int((Double(s.count - 1) * q).rounded()))]
    }
    var maxv: Double { v.max() ?? 0 }
    func summary() -> String {
        String(format: "mean=%.3f p50=%.3f p95=%.3f p99=%.3f max=%.3f n=%d", mean, pct(0.5), pct(0.95), pct(0.99), maxv, v.count)
    }
}

func argMap() -> [String: String] {
    var m: [String: String] = [:]
    var it = CommandLine.arguments.dropFirst().makeIterator()
    while let k = it.next() {
        if k.hasPrefix("--") { m[String(k.dropFirst(2))] = it.next() ?? "" }
    }
    return m
}
