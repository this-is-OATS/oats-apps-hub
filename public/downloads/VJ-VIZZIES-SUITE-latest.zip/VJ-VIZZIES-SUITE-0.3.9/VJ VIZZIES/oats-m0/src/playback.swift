import Foundation

// Clip playback tools (Resolume-like): next / previous / random within a layer's current bank, column go (slot c on
// every layer whose bank has a slot c), autopilot per layer (order or shuffle, every N seconds or N beats), and the
// player's tempo clock (BPM from Ableton Link via bin/oats-link, else DMX Master ch 2-3 / tap ch 4 / OSC /oats/tempo/bpm,
// tap over OSC /oats/tempo/tap). While Link leads, a PLL bends the clock's rate so beat mod 4 converges on Link's
// beat (quantum 4: phase 0 = bar start) without jumps; the beat never runs backwards.
// The commands change LayerCtl (bank, slot, playSeq) like /oats/layers/{n}/play, so the layer's transition applies.
// The playback thread (50 Hz) runs the tempo clock and the autopilots; it never touches the render thread.

enum ClipNav: String { case next, prev, random }

extension Control {
    /// One step on layer li (0-based) within its current bank. Returns a log fragment, or nil if nothing to do.
    /// owner: who moved it ("layer<n>.clip" is taken). Call under the gControl lock.
    mutating func navLayer(_ li: Int, _ op: ClipNav, owner: Owner, lib: Library) -> String? {
        let l = layers[li], ss = lib.slotNumbers(bank: l.bank)
        guard !ss.isEmpty else { return nil }
        var to: Int
        switch op {
        case .next: to = ss.first { $0 > l.slot } ?? ss[0]
        case .prev: to = ss.last { $0 < l.slot && l.slot > 0 } ?? ss[ss.count - 1]
        case .random:
            let others = ss.filter { $0 != l.slot }
            to = others.randomElement() ?? ss[0]
        }
        if l.slot == 0 && op == .prev { to = ss[ss.count - 1] }
        return playSlot(li, bank: l.bank, slot: to, owner: owner, lib: lib)
    }

    mutating func playSlot(_ li: Int, bank: Int, slot: Int, owner: Owner, lib: Library) -> String? {
        guard let clip = lib.clip(bank: bank, slot: slot) else { return nil }
        layers[li].bank = bank; layers[li].slot = slot; layers[li].playSeq += 1
        layerOwners["layer\(layerNum(li)).clip"] = owner
        return "\(layerLabel(li)) -> \(bank).\(slot) '\(clip.name)'"
    }

    /// Column c: slot c on every layer whose current bank has a slot c. Returns the log fragments.
    mutating func columnGo(_ col: Int, owner: Owner, lib: Library) -> [String] {
        (0..<layerCount).compactMap { li in playSlot(li, bank: layers[li].bank, slot: col, owner: owner, lib: lib) }
    }
}

/// Latest /oats/tempo/link from the Link helper (OSC thread writes, playback thread reads).
struct LinkInfo {
    var bpm = 0.0, beat = 0.0, phase = 0.0
    var peers = 0, playing = false
    var at = -1.0                       // render-clock seconds when it arrived (-1 = never)
    var count = 0
    var from = ""
}
final class LinkStore {
    private let lock = NSLock()
    private var l = LinkInfo()
    func with<T>(_ body: (inout LinkInfo) -> T) -> T { lock.lock(); defer { lock.unlock() }; return body(&l) }
}
let gLink = LinkStore()

/// Tempo clock + autopilot state, read by status.json.
struct PlaybackInfo {
    var bpm = 120.0
    var rate = 120.0                    // the clock's actual rate in BPM (bpm, bent by the Link PLL): render extrapolates with it
    var bpmSource = "default"           // default (120) | set (DMX/OSC/GUI BPM) | tap | link | link-held (Link gone, its last BPM kept)
    var setting = "auto"
    var link: [String: Any] = [:]
    var forward: [String: Any] = [:]
    var beat = 0.0                      // beats since start (or since the last resync)
    var at = 0.0                        // render-clock seconds of `beat` (render extrapolates: beat + (t - at) x bpm / 60)
    var frozen = false
    var taps = 0
    var autopilot: [[String: Any]] = []
}

final class PlaybackStore {
    private let lock = NSLock()
    private var p = PlaybackInfo()
    func with<T>(_ body: (inout PlaybackInfo) -> T) -> T { lock.lock(); defer { lock.unlock() }; return body(&p) }
}
let gPlayback = PlaybackStore()

final class Playback {
    private var lastT = 0.0
    private var beat = 0.0
    private var seenTap = 0, seenResync = 0
    private var tapTimes: [Double] = []
    private var tapBPM = 0.0
    private var wasLink = false, heldBPM = 0.0, phaseErr = 0.0
    private var fwdFd: Int32 = -1, fwdDest = "", fwdAddr: sockaddr_in? = nil, fwdLast = -1.0, fwdT = -10.0, fwdSent = 0, fwdErrors = 0
    private struct AP { var seenSeq = -1; var t0 = 0.0; var b0 = 0.0; var bag: [Int] = []; var bagBank = -1; var changes = 0 }
    private var ap = [AP](repeating: AP(), count: compCount)

    func start() {
        let t = Thread { [self] in
            while !gFlags.stopping { self.tick(); usleep(20_000) }
        }
        t.name = "playback"
        t.qualityOfService = .userInitiated
        t.start()
        olog("playback: tempo clock + autopilot thread (50 Hz)")
    }

    private func tick() {
        let now = ticksToSec(nowTicks() &- gStartTicks)
        let dt = lastT == 0 ? 0 : min(0.5, now - lastT)
        lastT = now
        let lib = gLibrary
        var logs: [String] = []
        let lk = gLink.with { $0 }
        let linkAge = lk.at < 0 ? Double.infinity : max(0, now - lk.at)
        let linkFresh = linkAge < 1.0 && lk.peers >= 1
        var useLink = false
        let (manBPM, manSrc, setting, fwd): (Double, String, String, String) = gControl.with { c in
            useLink = linkFresh && (c.tempoSource == "auto" || c.tempoSource == "link")
            if c.tapSeq != seenTap {                      // OSC taps: average of the last 5, reset after 2 s
                seenTap = c.tapSeq
                if let l = tapTimes.last, now - l > 2 { tapTimes.removeAll() }
                tapTimes.append(now); if tapTimes.count > 5 { tapTimes.removeFirst() }
                if tapTimes.count >= 2 {
                    let b = 60 * Double(tapTimes.count - 1) / (tapTimes.last! - tapTimes.first!)
                    if b >= 20 && b <= 400 { tapBPM = b; c.bpm = b; c.owners[.bpm] = .osc; logs.append(String(format: "tap tempo %.1f BPM", b)) }
                }
            }
            if c.resyncSeq != seenResync {
                seenResync = c.resyncSeq
                if useLink { logs.append("tempo resync ignored: Ableton Link sets the bar") } else { beat = beat.rounded(.up); logs.append("tempo resync (beat 1)") }
            }
            let m: (Double, String) = c.bpm > 0 ? (min(400, max(20, c.bpm)), tapBPM > 0 && abs(c.bpm - tapBPM) < 1e-9 ? "tap" : "set") : (120, "default")
            return (m.0, m.1, c.tempoSource, c.tempoForward)
        }
        var bpm = manBPM, src = manSrc, rate = manBPM
        if useLink {
            // PLL: Link's beat now (extrapolated from the message's arrival), compared with ours modulo the bar (4)
            bpm = min(999, max(20, lk.bpm)); src = "link"
            let target = lk.beat + linkAge * lk.bpm / 60
            var err = (target - beat).truncatingRemainder(dividingBy: 4)
            if err >= 2 { err -= 4 } else if err < -2 { err += 4 }
            phaseErr = err
            rate = bpm * (1 + max(-0.25, min(0.25, 0.5 * err)))     // ~1 s time constant, at most 25 % faster/slower
            heldBPM = bpm
            if !wasLink { logs.append(String(format: "tempo: Ableton Link leads (%.2f BPM, %d peer%@, bar phase error %.2f beats: converging)", bpm, lk.peers, lk.peers == 1 ? "" : "s", err)) }
        } else {
            if wasLink {
                logs.append("tempo: Ableton Link " + (linkAge >= 1 ? String(format: "silent for %.1f s", linkAge) : lk.peers < 1 ? "has no peers" : "ignored (source \(setting))")
                            + " -> " + (manSrc == "default" && heldBPM > 0 ? String(format: "keeping its last %.2f BPM", heldBPM) : String(format: "%@ %.2f BPM", manSrc, manBPM)))
            }
            if manSrc == "default" && heldBPM > 0 { bpm = heldBPM; rate = heldBPM; src = "link-held" }
            phaseErr = 0
        }
        wasLink = useLink
        let frozen = gStats.with { $0.frozen }
        if !frozen { beat += rate / 60 * dt }
        forward(fwd, bpm: bpm, on: useLink, now: now, logs: &logs)
        var apInfo: [[String: Any]] = []
        gControl.with { c in
            for li in 0..<compCount {
                let l = c.layers[li]
                if l.playSeq != ap[li].seenSeq { ap[li].seenSeq = l.playSeq; ap[li].t0 = now; ap[li].b0 = beat }   // any change restarts the wait
                var due = false
                if l.autopilot != .off && l.slot > 0 && !frozen {
                    due = l.apEvery > 0 ? now - ap[li].t0 >= l.apEvery : beat - ap[li].b0 >= max(0.25, l.apBeats) - 1e-6
                }
                if due {
                    var line: String? = nil
                    if l.autopilot == .order { line = c.navLayer(li, .next, owner: c.layerOwners["layer\(layerNum(li)).clip"] ?? .none, lib: lib) }
                    else {
                        let ss = lib.slotNumbers(bank: l.bank)
                        if ap[li].bagBank != l.bank { ap[li].bag = []; ap[li].bagBank = l.bank }
                        ap[li].bag = ap[li].bag.filter { ss.contains($0) && $0 != l.slot }
                        if ap[li].bag.isEmpty { ap[li].bag = ss.filter { $0 != l.slot }.shuffled() }   // a new round, without repeats
                        if let s = ap[li].bag.popLast() {
                            line = c.playSlot(li, bank: l.bank, slot: s, owner: c.layerOwners["layer\(layerNum(li)).clip"] ?? .none, lib: lib)
                        }
                    }
                    ap[li].t0 = now; ap[li].b0 = beat
                    if let x = line { ap[li].changes += 1; ap[li].seenSeq = c.layers[li].playSeq; logs.append("autopilot \(l.autopilot.rawValue) " + x) }
                }
                let wait = l.apEvery > 0 ? l.apEvery - (now - ap[li].t0) : (max(0.25, l.apBeats) - (beat - ap[li].b0)) * 60 / bpm
                apInfo.append(["layer": layerNum(li), "mode": l.autopilot.rawValue, "every_s": l.apEvery, "beats": l.apBeats,
                               "next_in_s": l.autopilot == .off ? -1 : (max(0, wait) * 100).rounded() / 100,
                               "changes": ap[li].changes, "shuffle_left": ap[li].bag.count])
            }
        }
        let linkD: [String: Any] = ["seen": lk.at >= 0, "bpm": (lk.bpm * 100).rounded() / 100, "peers": lk.peers, "playing": lk.playing,
                                    "age_ms": lk.at < 0 ? -1 : Int((linkAge * 1000).rounded()), "fresh": linkFresh, "leads": useLink,
                                    "phase_err": (phaseErr * 1000).rounded() / 1000, "locked": useLink && abs(phaseErr) < 0.05, "messages": lk.count]
        let fwdD: [String: Any] = ["to": fwd.isEmpty ? "off" : fwd, "last_bpm": fwdLast, "sent": fwdSent, "errors": fwdErrors]
        gPlayback.with { p in
            p.bpm = bpm; p.rate = rate; p.bpmSource = src; p.setting = setting; p.beat = beat; p.at = now; p.frozen = frozen; p.taps = seenTap
            p.autopilot = apInfo; p.link = linkD; p.forward = fwdD
        }
        for l in logs { olog("playback: " + l) }
    }

    /// MA3 tempo forward (off by default): OSC /cmd "Master 3.1 At BPM <bpm>" while Link leads, rounded to 0.1,
    /// only when it changes, at most 2 Hz.
    private func forward(_ dest: String, bpm: Double, on: Bool, now: Double, logs: inout [String]) {
        if dest != fwdDest {
            fwdDest = dest; fwdLast = -1
            fwdAddr = dest.isEmpty ? nil : parseHostPort(dest)
            if fwdAddr != nil && fwdFd < 0 { fwdFd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP) }
        }
        guard on, var d = fwdAddr, fwdFd >= 0, now - fwdT >= 0.5 else { return }
        let r = (bpm * 10).rounded() / 10
        guard r != fwdLast else { return }
        let pk = oscEncode("/cmd", [String(format: "Master 3.1 At BPM %.1f", r)])
        let n = pk.withUnsafeBytes { raw in
            withUnsafePointer(to: &d) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { sendto(fwdFd, raw.baseAddress, raw.count, 0, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
        }
        fwdT = now
        if n < 0 { fwdErrors += 1; return }
        if fwdLast < 0 { logs.append(String(format: "tempo forward: MA3 /cmd Master 3.1 At BPM %.1f to %@", r, dest)) }
        fwdLast = r; fwdSent += 1
    }
}
