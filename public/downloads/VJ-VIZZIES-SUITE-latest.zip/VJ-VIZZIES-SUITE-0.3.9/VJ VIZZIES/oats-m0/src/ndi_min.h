// Copied from ndi-bench/src/ndi_min.h for oats-m0, plus: metadata frames, NDIlib_send_capture,
// NDIlib_send_free_metadata, the shader parameter block and two atomic helpers.
// Minimal hand-written declarations of the NDI 6 C ABI (no SDK headers on disk).
// Layouts mirror Processing.NDI.structs.h / Processing.NDI.Send.h / Find.h / Recv.h.
// Enums are declared as int32_t (NDI enums are int-sized: each has a *_max = 0x7fffffff member).
#include <stdint.h>
#include <stdbool.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <semaphore.h>

typedef void *NDIlib_send_instance_t;
typedef void *NDIlib_find_instance_t;
typedef void *NDIlib_recv_instance_t;

typedef struct NDIlib_source_t {
    const char *p_ndi_name;
    const char *p_url_address;      // union { p_url_address; p_ip_address; }
} NDIlib_source_t;

typedef struct NDIlib_send_create_t {
    const char *p_ndi_name;
    const char *p_groups;
    bool clock_video;
    bool clock_audio;
} NDIlib_send_create_t;

typedef struct NDIlib_find_create_t {
    bool show_local_sources;
    const char *p_groups;
    const char *p_extra_ips;
} NDIlib_find_create_t;

typedef struct NDIlib_recv_create_v3_t {
    NDIlib_source_t source_to_connect_to;
    int32_t color_format;           // NDIlib_recv_color_format_e: 100 = fastest, 101 = best
    int32_t bandwidth;              // NDIlib_recv_bandwidth_e: 100 = highest
    bool allow_video_fields;
    const char *p_ndi_recv_name;
} NDIlib_recv_create_v3_t;

typedef struct NDIlib_video_frame_v2_t {
    int32_t xres;
    int32_t yres;
    uint32_t FourCC;                // NDIlib_FourCC_video_type_e
    int32_t frame_rate_N;
    int32_t frame_rate_D;
    float picture_aspect_ratio;
    int32_t frame_format_type;      // 1 = progressive
    int64_t timecode;               // INT64_MAX = synthesize
    uint8_t *p_data;
    int32_t line_stride_in_bytes;   // union { line_stride_in_bytes; data_size_in_bytes; }
    const char *p_metadata;
    int64_t timestamp;
} NDIlib_video_frame_v2_t;

// NDIlib_metadata_frame_t: int32 length @0, int64 timecode @8, char* p_data @16, size 24.
typedef struct NDIlib_metadata_frame_t {
    int32_t length;
    int64_t timecode;
    char *p_data;
} NDIlib_metadata_frame_t;

typedef struct NDIlib_recv_performance_t {
    int64_t video_frames;
    int64_t audio_frames;
    int64_t metadata_frames;
} NDIlib_recv_performance_t;

typedef struct NDIlib_recv_queue_t {
    int32_t video_frames;
    int32_t audio_frames;
    int32_t metadata_frames;
} NDIlib_recv_queue_t;

typedef bool (*fn_initialize)(void);
typedef void (*fn_destroy)(void);
typedef const char *(*fn_version)(void);
typedef NDIlib_send_instance_t (*fn_send_create)(const NDIlib_send_create_t *);
typedef void (*fn_send_destroy)(NDIlib_send_instance_t);
typedef void (*fn_send_video)(NDIlib_send_instance_t, const NDIlib_video_frame_v2_t *);
typedef int (*fn_send_get_no_connections)(NDIlib_send_instance_t, uint32_t);
// NDIlib_frame_type_e NDIlib_send_capture(send, NDIlib_metadata_frame_t*, timeout_ms): 0 none, 3 metadata, 4 error, 100 status change
typedef int32_t (*fn_send_capture)(NDIlib_send_instance_t, NDIlib_metadata_frame_t *, uint32_t);
typedef void (*fn_send_free_metadata)(NDIlib_send_instance_t, const NDIlib_metadata_frame_t *);
typedef NDIlib_find_instance_t (*fn_find_create_v2)(const NDIlib_find_create_t *);
typedef void (*fn_find_destroy)(NDIlib_find_instance_t);
typedef bool (*fn_find_wait)(NDIlib_find_instance_t, uint32_t);
typedef const NDIlib_source_t *(*fn_find_get_current)(NDIlib_find_instance_t, uint32_t *);
typedef NDIlib_recv_instance_t (*fn_recv_create_v3)(const NDIlib_recv_create_v3_t *);
typedef void (*fn_recv_destroy)(NDIlib_recv_instance_t);
typedef int32_t (*fn_recv_capture_v2)(NDIlib_recv_instance_t, NDIlib_video_frame_v2_t *, void *, void *, uint32_t);
typedef void (*fn_recv_free_video_v2)(NDIlib_recv_instance_t, const NDIlib_video_frame_v2_t *);
typedef void (*fn_recv_get_performance)(NDIlib_recv_instance_t, NDIlib_recv_performance_t *, NDIlib_recv_performance_t *);
typedef void (*fn_recv_get_queue)(NDIlib_recv_instance_t, NDIlib_recv_queue_t *);

// Audio (src/audio.swift receive, tests/ndi_audio_send.swift send). NDIlib_audio_frame_v2_t: planar float (FLTP),
// sample_rate @0, no_channels @4, no_samples @8, timecode @16, p_data @24, channel_stride_in_bytes @32, p_metadata @40,
// timestamp @48, size 56. NDIlib_recv_capture_v2 returns 0 none, 1 video, 2 audio, 3 metadata, 4 error, 100 status change.
typedef struct NDIlib_audio_frame_v2_t {
    int32_t sample_rate;
    int32_t no_channels;
    int32_t no_samples;
    int64_t timecode;
    float *p_data;
    int32_t channel_stride_in_bytes;
    const char *p_metadata;
    int64_t timestamp;
} NDIlib_audio_frame_v2_t;
typedef int32_t (*fn_recv_capture_audio_v2)(NDIlib_recv_instance_t, void *, NDIlib_audio_frame_v2_t *, void *, uint32_t);
typedef void (*fn_recv_free_audio_v2)(NDIlib_recv_instance_t, const NDIlib_audio_frame_v2_t *);
typedef int (*fn_recv_get_no_connections)(NDIlib_recv_instance_t);
typedef void (*fn_send_audio_v2)(NDIlib_send_instance_t, const NDIlib_audio_frame_v2_t *);

// ---------- oats-m0 additions (not NDI) ----------

// Parameter block shared by every Metal kernel (mirrors `struct P` in the MSL source; C layout, 48 bytes).
typedef struct OatsParams {
    float cx;          // centre real
    float cy;          // centre imaginary
    float scale;       // complex units per pixel (mandel) / amplitude (noise)
    float phase;       // palette phase (mandel) / per-frame seed (noise)
    uint32_t maxIter;
    uint32_t w;
    uint32_t h;
    uint32_t use2020;
    uint32_t pal;      // 0 = bench cosine (DEEP), 1 OATS Navy, 2 Viridis, 3 Magma, 4 Inferno, 5 Plasma
    float density;     // palette cycles per escape iteration
    float dimmer;      // 0..1, multiplies RGB before the UYVY pack (0 = black Y16 U128 V128)
    float flash;       // strobe flash 0..1 (audio react, audio.swift): RGB toward white x dimmer in to_uyvy (was the unused seed)
} OatsParams;

// Deep-zoom kernel parameters (shaders.swift mandel_pert, struct PP; 48 bytes).
typedef struct OatsPertParams {
    float scale;       // complex units per internal pixel
    float phase;       // palette phase
    float density;     // palette cycles per escape iteration
    float cx;          // centre (float32; only for the cardioid test of shallow views)
    float cy;
    uint32_t maxIter;
    uint32_t rw;       // internal render size (governor)
    uint32_t rh;
    uint32_t orbLen;   // reference orbit entries Z_0 .. Z_{orbLen-1}
    uint32_t pal;
    uint32_t cardioid; // 1 = test the main cardioid / period-2 bulb first
    float rotC;        // screen -> plane rotation (cos, sin of minus the picture rotation)
    float rotS;
    float offX;        // view-centre offset from the reference centre, complex units (DMX Fractal ch 3-6)
    float offY;
    float crisp;       // spread macro (tighten side): 0 = smooth colouring ... 1 = per-iteration bands (crisp edges)
} OatsPertParams;

// Lock-free heartbeats between the render loop and the watchdog.
static inline void oats_store_u64(volatile uint64_t *p, uint64_t v) { __atomic_store_n(p, v, __ATOMIC_RELEASE); }
static inline uint64_t oats_load_u64(volatile uint64_t *p) { return __atomic_load_n(p, __ATOMIC_ACQUIRE); }
// Frame ring (ndiring.swift): compare-and-swap / fetch-add on 64-bit words in shared memory (lock-free across processes).
static inline bool oats_cas_u64(volatile uint64_t *p, uint64_t expected, uint64_t desired) {
    return __atomic_compare_exchange_n(p, &expected, desired, false, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE);
}
static inline uint64_t oats_add_u64(volatile uint64_t *p, uint64_t v) { return __atomic_add_fetch(p, v, __ATOMIC_ACQ_REL); }
// shm_open / sem_open are variadic (not callable from Swift): fixed-argument shims. oats_sem_open returns NULL on failure.
static inline int oats_shm_open(const char *name, int oflag, int mode) { return shm_open(name, oflag, (mode_t)mode); }
static inline sem_t *oats_sem_open(const char *name, int oflag, int mode, unsigned int value) {
    sem_t *s = sem_open(name, oflag, (mode_t)mode, value);
    return s == SEM_FAILED ? (sem_t *)0 : s;
}
