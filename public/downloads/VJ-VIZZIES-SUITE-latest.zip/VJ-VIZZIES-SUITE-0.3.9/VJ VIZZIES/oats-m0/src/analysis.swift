import Foundation
import Metal
import Darwin

// VJ -> lights groundwork: 3 dominant colours of the program output at ~10 Hz. Every 6th frame (60/6 = 10 Hz) the
// frame's own command buffer also box-filters the composite canvas (x dimmer) down to 64x36 float RGB; the
// completion handler hands the buffer to a utility queue that runs a small k-means (k = 3, 6 iterations, seeded
// from the last result) and publishes the colours sorted by weight. Optional OSC out (off by default):
// /oats/analysis/out s "host:port" | "off" (or --analysis-out host:port) sends, per analysis,
//   /oats/analysis/colors f x 9   (r g b of colours 1..3, 0..1, heaviest first)
//   /oats/analysis/weights f x 3  (share of the frame, 0..1)

/// The colour link as the render loop shows it (smoothed): x y z = rgb, w = amount. status.json color_link.
final class ColorShown {
    private let lock = NSLock()
    private var v = SIMD4<Double>(1, 1, 1, 0)
    func with<T>(_ body: (inout SIMD4<Double>) -> T) -> T { lock.lock(); defer { lock.unlock() }; return body(&v) }
}
let gColorShown = ColorShown()

let analysisW = 64, analysisH = 36, analysisEvery = 6

final class Analysis {
    let bufs: [MTLBuffer]                         // 2 slots, float4 x 64 x 36
    private let lock = NSLock()
    private var busy = [false, false]
    private var colors: [SIMD3<Float>] = [SIMD3(0, 0, 0), SIMD3(0.5, 0.5, 0.5), SIMD3(1, 1, 1)]
    private var weights: [Float] = [0, 0, 0]
    private var count = 0, sent = 0, sendErrors = 0
    private var lastUnix = 0.0, ms = 0.0
    private var winStart = nowTicks(), winCount = 0, hz = 0.0
    private let q = DispatchQueue(label: "analysis", qos: .utility)
    private var fd: Int32 = -1
    private var destText = "", dest: sockaddr_in? = nil

    init?(dev: MTLDevice) {
        var b: [MTLBuffer] = []
        for _ in 0..<2 {
            guard let x = dev.makeBuffer(length: analysisW * analysisH * 16, options: .storageModeShared) else { return nil }
            b.append(x)
        }
        bufs = b
    }

    /// Render thread: a free slot for this frame, or nil (still busy: skip this one).
    func begin() -> Int? {
        lock.lock(); defer { lock.unlock() }
        guard let i = busy.firstIndex(of: false) else { return nil }
        busy[i] = true
        return i
    }

    /// Completion handler: analyse slot i off the render thread.
    func gpuDone(_ i: Int, ok: Bool) {
        q.async { [self] in
            if ok { self.run(i) }
            self.lock.lock(); self.busy[i] = false; self.lock.unlock()
        }
    }

    private func run(_ i: Int) {
        let t0 = nowTicks()
        let n = analysisW * analysisH
        let p = bufs[i].contents().assumingMemoryBound(to: SIMD4<Float>.self)
        var px = [SIMD3<Float>](repeating: .zero, count: n)
        for k in 0..<n { let v = p[k]; px[k] = SIMD3(v.x, v.y, v.z) }
        lock.lock(); var c = colors; lock.unlock()
        // k-means, k = 3, seeded from the last result (stable colours frame to frame); an empty cluster is re-seeded
        // from the pixel farthest from its centre.
        var assign = [Int](repeating: 0, count: n)
        var w: [Float] = [0, 0, 0]
        for _ in 0..<6 {
            var sum = [SIMD3<Float>](repeating: .zero, count: 3), cnt: [Float] = [0, 0, 0]
            var far = 0, farD: Float = -1
            for k in 0..<n {
                let x = px[k]
                var best = 0, bd = Float.greatestFiniteMagnitude
                for j in 0..<3 { let d = x - c[j]; let dd = (d * d).sum(); if dd < bd { bd = dd; best = j } }
                assign[k] = best; sum[best] += x; cnt[best] += 1
                if bd > farD { farD = bd; far = k }
            }
            for j in 0..<3 { if cnt[j] > 0 { c[j] = sum[j] / cnt[j] } else { c[j] = px[far] } }
            w = cnt.map { $0 / Float(n) }
        }
        let order = (0..<3).sorted { w[$0] > w[$1] }
        let cs = order.map { c[$0] }, ws = order.map { w[$0] }
        let dt = ticksToSec(nowTicks() &- t0) * 1000
        let now = nowTicks()
        lock.lock()
        colors = cs; weights = ws; count += 1; lastUnix = Date().timeIntervalSince1970; ms = dt
        winCount += 1
        let ws_ = ticksToSec(now &- winStart)
        if ws_ >= 2 { hz = Double(winCount) / ws_; winCount = 0; winStart = now }
        lock.unlock()
        send(cs, ws)
    }

    private func send(_ cs: [SIMD3<Float>], _ ws: [Float]) {
        let want = gControl.with { $0.analysisOut }
        if want != destText {
            destText = want
            dest = want.isEmpty ? nil : parseHostPort(want)
            if dest != nil && fd < 0 { fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP) }
            olog("analysis: OSC out " + (want.isEmpty ? "off" : dest == nil ? "\(want): bad destination" : "to \(want) (/oats/analysis/colors, /weights, ~10 Hz)"))
        }
        guard var d = dest, fd >= 0 else { return }
        for pk in [oscEncodeFloats("/oats/analysis/colors", cs.flatMap { [$0.x, $0.y, $0.z] }), oscEncodeFloats("/oats/analysis/weights", ws)] {
            let r = pk.withUnsafeBytes { raw in
                withUnsafePointer(to: &d) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { sendto(fd, raw.baseAddress, raw.count, 0, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
            }
            lock.lock(); if r < 0 { sendErrors += 1 } else { sent += 1 }; lock.unlock()
        }
    }

    func statusDict(dest: String) -> [String: Any] {
        lock.lock(); defer { lock.unlock() }
        func r3(_ v: Float) -> Double { (Double(v) * 1000).rounded() / 1000 }
        return ["size": "\(analysisW)x\(analysisH)", "every_nth_frame": analysisEvery, "hz": (hz * 10).rounded() / 10, "count": count,
                "ms": (ms * 100).rounded() / 100, "last_unix": lastUnix,
                "colors": colors.map { [r3($0.x), r3($0.y), r3($0.z)] },
                "hex": colors.map { String(format: "#%02x%02x%02x", Int(min(1, max(0, $0.x)) * 255), Int(min(1, max(0, $0.y)) * 255), Int(min(1, max(0, $0.z)) * 255)) },
                "weights": weights.map(r3),
                "osc_out": dest.isEmpty ? "off" : dest, "osc_sent": sent, "osc_errors": sendErrors]
    }
}

/// Set by the engine at init (nil = no analysis buffers).
var gAnalysisImpl: Analysis? = nil
enum gAnalysis {
    static func statusDict(dest: String) -> [String: Any] { gAnalysisImpl?.statusDict(dest: dest) ?? ["error": "not running"] }
}
