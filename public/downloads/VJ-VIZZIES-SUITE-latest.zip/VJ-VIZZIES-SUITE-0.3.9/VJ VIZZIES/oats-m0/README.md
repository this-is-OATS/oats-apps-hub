# oats-m0: operator notes

The VJ VIZZIES (formerly OATS VIZ) player. NDI "OATS VIZ Program", the GDTF fixture type "OATS VIZ" and OSC `/oats/...` keep the old name (compatibility).

The M0 test build from `docs/PLAN.md` 13.1: one headless process with no window. It renders a fractal
with Metal (deep zoom to 1e28, see "Deep zoom"). **Since 2026-10-23 it is native arm64**: the show feed is the output window (HDMI);
NDI ("OATS VIZ Program", for Vision previs) is optional and sent by the x86_64 helper `bin/oats-ndi` under Rosetta (helper mode), natively, or not at all
(see "NDI modes + frame budget"). It takes OSC on UDP 7000 and sACN on UDP 5568, universe 5 (DMX personality v0, see "MA3 fixture"). A watchdog restarts it when it
stalls. NDI gets a private `NDI_CONFIG_DIR` with `adapters.allowed` = en0's address; `~/.ndi` is not touched.
`pin-check` found that this setting does not stop NDI on other interfaces (Known limits); NDI is announced on every network the Mac is on, by your choice.

Network today (2026-10-21): Mac en0 **192.168.1.148** (manual, no router; Wi-Fi on the building network for internet), previs PC **192.168.1.141** (static), router
192.168.1.1 (Netgear R7000 in Router mode, your own 192.168.1.0/24, not 10.x). `./m0.sh status` and
`./m0.sh net` show the live address. MA3's OSC line and sACN row hold the Mac's IP: if it changes, update them.

**Who can control it.** Only the lighting network (en0's network, 192.168.1.0/24 today) and this Mac itself
(127.0.0.0/8). OSC 7000, sACN 5568, the preview on 8091 and the GUI on 8090 refuse everything else (the Wi-Fi /
building network 192.168.0.x, Tailscale, ...): packets are dropped and counted (status.json `osc.rejected`,
`dmx.rejected`, `preview.rejected`), the GUI answers 403, and the first refusal per address is logged once.
NDI is not filtered: "OATS VIZ Program" is visible on both networks. Phone: join the Netgear Wi-Fi "gooats.net",
then open http://192.168.1.148:8090. Options: `--allow-net CIDR[,CIDR…]` replaces en0's network,
`--allow-any` turns the filter off (GUI: `OATS_GUI_ALLOW=CIDR,…` or `any`).

## Commands (run from this folder; the path has spaces, so quote it)

| Command | What it does |
|---|---|
| `./m0.sh build` | Compiles `bin/oats-m0` **native arm64** and the NDI helper `bin/oats-ndi` (x86_64), Command Line Tools only, then deletes the module cache. `--x86` = the old x86_64 player for Rosetta; `OATS_BUILD_OUT` / `OATS_NDI_OUT` build elsewhere, `OATS_BUILD_ONLY=player\|helper` one of them |
| `./m0.sh ndi [status\|start\|stop\|restart]` | The NDI helper's own restart loop (`start` / `stop` run it too when Rosetta is installed; it idles unless the player is in helper mode). `status`: mode, helper state, sends, stalls |
| `./m0.sh start` | **Show mode for M0**: "OATS VIZ Program", group Public. Starts a restart loop in the background |
| `./m0.sh start --no-ndi-meta` | **What Claude starts for your Vision test (M0 Parts A–C).** Same as show mode, but without the thread that reads receivers' product names: on 2026-10-21 deep content at full bandwidth hit single 107–227 ms send calls in 3 of 4 runs with that thread, 0 of 4 without it (busy Mac, so suggestive only) |
| `./m0.sh start --gate --no-ndi-meta` | **M0 Parts D and E** (measured): waits for a quiet Mac first |
| `python3 -I tests/perf.py --observe --match "OATS VIZ Program" --groups public --phases watch:300:0` | Loopback receiver next to Vision during Parts D/E: sends no OSC, judges the freeze rule on whatever is on air (`:0` = proxy, like Vision Low; `:100` = full) |
| `./m0.sh link status` | Ableton Link helper: running state, tempo source, last log lines (`link start/stop/restart` too) |
| `./m0.sh start --test` | Test mode: "OATS VIZ Test", group `oatsbench`, `--debug`. Use this for every test that isn't the M0 sheet |
| `./m0.sh start --gate …` | Waits until the 1-min load is 8 or less (checks every 30 s, at most 15 min, then starts and logs it). **Use it for every M0 measurement run**: Parts D and E, soaks, selftest timings (`pin-check` gates itself) |
| `./m0.sh start … --content deep` | Extra arguments go to the program (see options below) |
| `./m0.sh stop` | Stop file + SIGTERM. Waits up to 5 s, then SIGKILL. Leaves nothing running |
| `./m0.sh restart` | SIGTERM to the program only; the loop starts it again. Prints the time (for timing Vision's recovery, Part E), waits up to 6 s for the old process to go, then SIGKILLs it |
| `./m0.sh status` | status.json (pretty), whether it runs, whether the NDI pin still matches en0 (`NDI PIN MISMATCH` → restart), en0 Mbit/s out/in over 2 s, and who holds UDP 5568/7000 (warns if another program listens on 5568) |
| `./m0.sh net` | en0 address, mask, router, Wi-Fi power, route to the PC (`OATS_PC_IP`, default 192.168.1.141), en0 bytes |
| `./m0.sh pin-check 192.0.2.1` | Runs "OATS VIZ Test" for 12 s with `adapters.allowed=[bogus IP]`, then 12 s with the real en0 IP, each from its own log dir and only once the sender is ready. Decides on en0-specific evidence (dns-sd `Add` records on en0's interface index, the sender's bound sockets), not on the bench receiver (it also finds sources over 127.0.0.1). A `machinename` probe (`OATSPIN`) in the config shows whether libndi read the folder. If the array form doesn't pin, it repeats with the string form. Stop the loop first |

The restart loop: it detects en0's IPv4 (a self-assigned 169.254.x.x counts as none: it waits and retries),
writes `ndi-config/ndi-config.v1.json`, a copy of `~/.ndi/ndi-config.v1.json` with `ndi.adapters.allowed = [<en0 IP>]`
(`OATS_NDI_ALLOWED_FORM=string` writes `"<en0 IP>"` instead, the form NDI Access Manager uses), exports
`NDI_CONFIG_DIR`, and runs `arch -x86_64 bin/oats-m0`. If the config can't be written (disk full), it does not
start unpinned: it retries every 5 s. After exit 75 (watchdog, or a shutdown that hung) or a crash it logs
`RESTART #n at <time>` and restarts after 0.5 s (10 s if more than 10 restarts in 60 s). It ends on exit 0
or when the stop file exists. Exit 2 (refused: native arm64 with libndi 6.x), 64 (bad arguments) and
78 (port in use / config) are not restarted. `start` warns when en0 is not on 192.168.1.0/24 or another
interface has an address on the same subnet (Wi-Fi on). Pidfiles are trusted only after checking the
process's command line (stale ones are removed), and `build` refuses to run while the loop is up.

Program options: `--name` (default "OATS VIZ Program"), `--groups` (default empty = Public, NULL to NDI),
`--universe 5`, `--dmx-map v0|m0` (default v0, see "MA3 fixture"; m0 = the old 5-channel map), `--dmx-table` (prints the v0
channel table as JSON and exits; `--selftest-dmx` runs the Layer decoder self test; put `--media` first for either), `--osc-port 7000`, `--sacn-multicast-if <IPv4>` (also joins 239.255.0.5 on that interface
for universe 5), `--fps 60`, `--log-dir`, `--debug`, `--content normal|deep|noise`, `--no-ndi-meta` (A/B test:
no `ndi-meta` thread, so no receiver metadata; the render loop polls the connection count every 30 frames, as
the bench sender did), `--allow-net CIDR[,CIDR…]` / `--allow-any` (control sources, see "Who can control it"),
`--no-sacn` (no sACN receiver: for a test instance next to the live one, with another `--osc-port`),
`--preview-port N` (MJPEG preview, default 8091), `--scenes FILE` (default `scenes.json` here), `--presets-dir DIR`
(`fx_presets.json` + `fractal_presets.json`, default `tools/`), `--library FILE` (default `<media>/library.json`; clip paths stay
relative to `--media`): added 2026-10-22 for the standalone `dist/VJ VIZZIES.app`, which keeps its data outside the bundle; the defaults are unchanged,
`--orbit-check NAME [N]` (prints a target's double-double centre and orbit as JSON, then exits; no NDI, no Metal).

## OSC (UDP 7000, OSC 1.0; bundles accepted, MA3 sends none)

From MA3: `SendOSC 1 "/address,<types>,<values>"`. Every message is logged with the sender IP:port.

| Address | Args | Action |
|---|---|---|
| `/oats/fractal/1/zoomspeed` | f, i, d (or h); clamped to ±5 | decades/s: + zooms in, − out, 0 holds (Part B: `,f,0.3` and `,f,0`) |
| `/oats/fractal/1/zoom` | d or f | absolute log10 view width, clamped to log10(3e-28)…log10(3.0) |
| `/oats/fractal/1/depth` | d or f | log10 zoom, 0 (full set) … 28; zoom = 3.0 / view width |
| `/oats/fractal/1/target` | i 1…6 or s name | zoom target (see "Deep zoom"); depth goes back to 0 when its orbit is ready, unless keepdepth is on |
| `/oats/fractal/1/target/keepdepth` | i, f, T or F | 1 = target changes keep the current depth (stays on until 0) |
| `/oats/fractal/1/shape/memory` | i 0 or 1 | per-target shape memory (default 1): a target change saves the shape under the old target and loads the new one's (see "Per-target shape memory") |
| `/oats/fractal/1/shape/reset` | – | the current target's shape back to the defaults (Mandelbrot, no twist, rotation 0, iterations auto, no Julia / trap, advanced fold defaults); clears its saved shape |
| `/oats/fractal/1/shape/memory/data` | s JSON | replaces the saved shapes, `{"SEAHORSE": {shape}, …}` (tools/oats_state.py restore) |
| `/oats/fractal/1/center` | s s (or d d) | custom centre as decimal strings (up to 45 significant digits are used); depth is kept |
| `/oats/fractal/1/loop` | s off\|minibrot\|dive | endless zoom (see "Formula modifiers + endless zoom"); runs while the zoom goes inward |
| `/oats/fractal/1/loop/next`, `/loop/depth`, `/loop/fade` | s same\|next\|random; f 1…28; f 0.2…10 s | Dive & return: which target, at which depth (default 26), crossfade (default 2 s; Minibrot loop uses half) |
| `/oats/fractal/1/formula` | s mandelbrot\|burningship\|tricorn\|power3\|power4\|power5\|celtic or i 0…6 | iteration formula (all deep-zoom safe) |
| `/oats/fractal/1/fold`, `/fold/mirror`, `/fold/mode` | i N (0 = off, 1 + mirror = one axis, 2…12); i 0\|1; s clean\|wild | Twist (2026-10-23): **clean** (default) folds c once into N sectors (a true kaleidoscope, deep-zoom safe, mirror = seamless, unmirrored seams blended over 2.5 px); **wild** folds z inside every iteration (direct path, depth ≤ 1e4.5, smooth fold, 2×2 supersampling, 1×2 if the governor goes below 900p) |
| `/oats/fractal/1/power` | f 1.5…6 | Branches: z^p + c. Integer 2…5 on the Mandelbrot family = Multibrot (perturbation, deep zoom); anything else = polar z^p on the direct path (≤ 1e4.5). `/formula` resets it. DMX: none (all Fractal 24 channels are taken) |
| `/oats/fractal/1/shape` | s NAME | Deep zoom step 1 tile: Mandelbrot, Burning Ship, Tricorn, Celtic, Flower 3/4/5, Julia Dendrite/Rabbit/Spiral/Dust, Kaleido 6/8 (formula + power + Julia + fold; trap, iterations, colour stay) |
| `/oats/fractal/1/target/dive` | i 0\|1 | Dive on select (default 1): a target change from OSC / the GUI zooms in for 1.5 s once its orbit is drawn |
| `/oats/fractal/1/foldc`, `/foldc/mirror` | i N; i 0\|1 | fold of c around the view centre (deep-zoom safe) |
| `/oats/fractal/1/julia`, `/julia/c`, `/julia/drift`, `/julia/beat` | f 0…1; f f; f cycles/s (or per beat); i 0\|1 | Julia morph (float32 path), constant, drift (radius 0.04), beat-synced drift |
| `/oats/fractal/1/warp`, `/bailout` | f 0…0.5; f 2…1024 | z² + c + k·sin z (float32 path); escape radius (default 256) |
| `/oats/fractal/1/trap`, `/trap/mix`, `/trap/size` | s off\|point\|circle\|line\|cross\|star; f 0…1; f | orbit-trap colouring blended with the palette (deep-zoom safe) |
| `/oats/fractal/1/preset` | s NAME or none | a look from `tools/fractal_presets.json` (none = classic, no modifiers, loop off) |
| `/oats/fractal/1/iter` | i | max iterations: 0 = auto (400 + 600 × depth), else 8…60000 (GUI "Detail"; Blob = 16) |
| `/oats/fractal/1/res` | i | fractal internal resolution: 0 = governor, or 1080/900/720/540/360 (1…5) fixed |
| `/oats/fractal/1/palette` | i or f (rounded) | 1 OATS Navy, 2 Viridis, **3 Magma**, 4 Inferno, 5 Plasma (out of range: clamped + logged) |
| `/oats/fractal/1/palette/speed` | f, clamped to ±10 | palette cycles per second |
| `/oats/fractal/1/palette/offset` | f | 0…1 |
| `/oats/master/blackout` | i, f, T or F | nonzero / T = on (Part B: `,i,1` and `,i,0`) |
| `/oats/master/dimmer` | f | 0…1 |
| `/oats/master/speed` | f; clamped 0…2 | effect speed: multiplies auto-zoom and palette cycle (1 = normal, 0 = stopped); status `effect_speed`, owner key `effect_speed` |
| `/oats/test/content` | s, case-insensitive | `normal`, `deep`, `noise` (Parts D and E) |
| `/oats/tempo/bpm` | f | the player's tempo clock (autopilot beats); 0 = default 120 |
| `/oats/tempo/tap` / `/oats/tempo/resync` | – | tap tempo (average of the last 5 taps, reset after 2 s) / beat 1 now |
| `/oats/tempo/source` | s | `auto` (default) or `link`: Ableton Link leads while a session is present, else DMX/tap/OSC; `dmx`, `tap`, `osc`: Link ignored (the DMX/tap/OSC BPM, latest move wins) |
| `/oats/tempo/link` | f d f i i | from the Link helper only (bpm, beat, phase in quantum 4, peers, playing; ~50 Hz from 127.0.0.1; not logged) |
| `/oats/tempo/forward` | s | `host:port` or `off` (default): while Link leads, send MA3 OSC `/cmd "Master 3.1 At BPM <bpm>"` (0.1 BPM, on change, max 2 Hz) |
| `/oats/layers/{n}/seek` / `/oats/layers/{n}/seek/sec` | f 0..1 of the duration / f seconds | jump in the clip that is showing (tolerance 0.1 s, fast); not stored in scenes or state; GUI: the PREVIEW monitor's time bar, phone: the Play tab's bar |
| `/oats/layers/{n}/next` `/prev` `/random` | – (or i 1; i 0 = release, ignored) | next / previous (wrapping) / random other clip in the layer's current bank, with its transition |
| `/oats/layers/{n}/autopilot` | s off\|order\|shuffle (or i 0..2) | change clips by itself in the current bank; shuffle = random without repeats until the bank is used up |
| `/oats/layers/{n}/autopilot/every` / `/beats` | f seconds 0.1..3600 / f beats 1..256 | interval; `/beats` uses the player BPM (and sets every = 0) |
| `/oats/column/{c}/go` | – | slot c on every layer whose bank has a slot c (Resolume column); alias `/composition/columns/{c}/connect i 1` |
| `/oats/color/link` | f f f (0..1) | lights → VJ colour link: the colour (status `color_link`) |
| `/oats/color/amount` / `/mode` / `/target` | f 0..1 / s tint\|hue\|replace / s all\|clips\|fractal | match amount (0 = off), how, and on what |
| `/oats/library/reload` | – | re-read `media/library.json` (the GUI bins send it after every change); playing clips keep playing |
| `/oats/analysis/out` | s host:port \| off | OSC out of the 3 dominant output colours (~10 Hz; default off; see "VJ → lights") |
| `/oats/layers/{n}/source` | s clip\|fractal\|gen\|ndi (or i 0..3) | the layer's source (see "Layer sources" and "NDI sources") |
| `/oats/layers/{n}/ndi` | s name or a part ("OBSBOT") | NDI source for this layer (also selects source ndi); `/oats/layers/{n}/ndi/bandwidth s full\|proxy` |
| `/oats/ndi/sources` | – | logs the discovered NDI sources with their DMX slot numbers (status.json `ndi_sources`) |
| `/oats/ndi/mode` | s off\|native\|native-soft\|helper\|auto | NDI mode (see "NDI modes + frame budget"); status `ndi.mode`. HDMI never depends on it |
| `/oats/ndi/quality` | s previs\|full | NDI quality (`--ndi-quality`, default previs = 960×540 at 30 fps; full = 1920×1080 at 60); status `ndi.quality`. GUI: Output row, Previs / Full |
| `/oats/ndi/soft` | s half\|blur | the native-soft pass: half = 2×2 box to 960×540 (default), blur = 3×3 tent at 1080p |
| `/oats/fractal/1/spread` | f −1…+1 | Spread ↔ Tighten macro: −1 wider, softer gradients; 0 as before; +1 denser bands, crisper edges (owner `fractal.spread`) |
| `/oats/fractal/1/phaser/{1..3}/…` | target s, shape s, beats f, seconds f, depth f, phase f, on i | fractal phasers (see "Fractal phasers"); `/oats/fractal/1/phaser/preset s NAME\|off` |
| `/oats/system/ping` | – | replies `/oats/system/pong` with a status string to the sender's IP:port |
| `/oats/system/snapshot` | – | writes the program frame to `logs/snapshot.png` |
| `/oats/record/start` / `/oats/record/stop` | [s path] [s 1080p\|vertical] / – | record the program to an MP4 (see "Record"); status `record` |
| `/cmd …` | – | ignored, with a log line (MA3 command echo) |
| `/oats/layers/{n}/transform/…`, `/fx/…`, `/mod/…`, `/oats/master/fx/…` | see "Motion + FX" | layer transform, FX slots, beat mod, presets, master FX |
| `/oats/debug/stall` | f, 0..30 s | **only with --debug**: the render thread sleeps that long (watchdog test) |

Every handled message is logged in full. Anything else is logged as `unhandled`; `unhandled`, `bad args`, `/cmd`
and malformed-packet lines share a limit of 20 lines/s (then one "suppressed" count line). Long addresses are
logged cut to 160 characters, arguments to 300, and control characters from the network show as `?`.

### Output window (2026-10-22, `src/output.swift`)

`/oats/output/display i` (0 = off, 1..n = status.json `screens`; the main display only when it is the only one), `/oats/output/fit s fill|fit|1:1`,
`/oats/output/test i` (test pattern). Start option `--output-display N`. The process now runs an NSApplication run loop on the main thread
(accessory: no Dock icon, no menu bar, no window until a display is set); render, send, OSC, sACN and status threads are unchanged. The render loop
hands the finished UYVY buffer's index to the "output" thread (one lock + semaphore signal); that thread decodes it into a CAMetalLayer drawable
(displaySyncEnabled) and skips (counts) a present when a newer frame is waiting, two presents are queued or no drawable is free.
status.json `output {display, size, presented, skipped, ...}`, `screens [...]`. See ../README.md "Output window".
`./m0.sh build` with `OATS_BUILD_OUT=bin/oats-m0.new` compiles to another file, also while the player runs (then swap, keep `.prev`, `m0.sh restart`).

### Record (2026-10-23, `src/recorder.swift`)

Records the **program** (the UYVY frame HDMI shows: after master FX, dimmer, blackout; the canvas, not the LED slices) to an MP4 on
its own path. Nothing in the HDMI or NDI paths changes: each frame's command buffer gets one extra compute pass (UYVY → BGRA into an
IOSurface pixel buffer, zero copy to the encoder), and when the GPU is done a completion handler hands the buffer to the recorder
queue, which appends it to an `AVAssetWriter` (H.264 hardware, High profile, ~24 Mbit/s, keyframe every 2 s, BT.709 tags, at the
output frame rate, 1/60 s timestamps). The render thread only pops a ready pixel buffer and encodes the pass: no waits, no allocation.
When the writer is behind (no free buffer, or the input not ready) the frame is dropped and counted; the output stays at 60 fps.
- **OSC:** `/oats/record/start [s path] [s size]` — size `1080p` (default, 16:9 1920×1080: the whole canvas, fitted) or `vertical`
  (9:16 1080×1920: the **centre 9:16 crop** of the 16:9 program scaled to 1080 wide; no 9:16 re-render yet, see ../docs/PLAN.md).
  A string that parses as a size is the size, any other (`/…`, `~/…` or `*.mp4`) is the path; a folder (trailing `/`) gets the default
  name inside it. Default: `~/Movies/OATS VIZ/teaser-takes/<yyyymmdd-HHMMSS>-<size>.mp4` (folder created). `/oats/record/stop`.
- **Disk guard:** refuses to start with < 3 GB free, stops by itself at 2 GB free or after 10 minutes. The file is always finished
  cleanly: on stop, on SIGTERM / `m0.sh restart` (the shutdown waits up to 2.5 s for it) and on quit. An existing file is never overwritten.
- **status.json** `record {on, path, size, frames, dropped, seconds, bytes, free_gb, note, sizes, dir}`; log lines `recorder: …`.
- **GUI:** Master card › Output note row: **16:9 / 9:16** (the size for the next take) and **REC** (red dot + elapsed time while
  recording; click again to stop; the title shows frames / dropped / MB / GB free). Phone: Master tab › Record card.
- **Takes script** `tools/teaser_takes.py` (stdlib, `python3 -I`): the four teaser takes (deep-dive, looks, audio, scenes), each in
  1080p and vertical (8 files, 150 s each by default), driven over OSC with beat timing from status.json tempo; saves the look with
  `tools/oats_state.py` first and restores it at the end (also on Ctrl-C); writes `SHOT-LIST.md` next to the files with timestamps.
  `--dry-run` prints the plan and the OSC without sending or recording; `--secs`, `--takes`, `--sizes`, `--out`.
- Self-test (`--selftest-dmx` section 23): size parsing, default path, disk guard (injected free space), the 9:16 crop rects.
- **Off the render tick (2026-10-24).** The frame's command buffer now carries one blit only (the UYVY program into a 4-slot
  staging ring, microseconds); the UYVY → BGRA pass runs on the recorder's **own** command queue, and the pool get, append, drop
  accounting and finish all run on the recorder queue from the frame's completed handler (ring full / pool empty / writer not ready
  = dropped + counted; the tick never waits). Before, the compute pass wrote the encoder's IOSurface inside the frame's own command
  buffer and REC showed up as 20–60 ms "encode" in LATE lines (restart #17, 2026-10-23 23:57). `record.convert_ms` / `convert_ms_max`
  in status.json = that pass on the recorder queue; the finish line logs the max.
- Not built: ProRes (disk), audio in the file, 1:1, native 9:16 render, offline render, snapshot gallery (PLAN.md).

### LED wall mapping: canvas + output slices (2026-10-23, `src/mapping.swift`, `gui/mapping.html`)

The show feed is HDMI into an LED processor. Settings in `mapping.json` (default next to `bin/`, `--mapping FILE`; the app uses
`~/Library/Application Support/OATS VIZ/mapping.json`), venue presets in `mapping/<name>.json` next to it. GUI: Master card >
Output row > **Mapping…** (`/mapping`, served by gui/server.py and the app).

- **Canvas** (`--canvas WxH`, else mapping.json `canvas`, else 1920x1080; any aspect, 256..8192 each, even): the engine renders
  the whole composition at that size. Fractal: square pixels, the view width spans min(W, H x 16/9) px (a 3840x1080 wall shows
  more of the plane left and right, portrait more above/below; 1920x1080 unchanged); the governor's internal resolutions are
  the canvas x 1, 5/6, 2/3, 1/2, 1/3. Generators, FX and the composite already work in canvas pixels. Test cards draw a 1920x1080
  virtual frame as large as fits, centred; their grid, background and edge markers cover the whole canvas. Preview and the GUI
  thumbnails: letterboxed into 16:9. NDI stays 16:9: any other canvas is letterboxed into 1920x1080 (full) / 960x540 (previs)
  by the `uyvy_fit` kernel (1920x1080 keeps the old paths byte for byte). status.json `resolution`, `mapping.canvas`.
  **Changing the canvas needs a player restart**: `/oats/canvas s WxH` stores it in mapping.json (`mapping.restart_needed`), the
  Mapping page's *Restart player* button does it only on a click (server.py: oats_state.py save, m0.sh restart, restore incl. the
  output display; the app: restart + output display/fit again). `--canvas` on the command line wins over mapping.json.
- **Slices** per output display: source rect on the canvas (px), destination rect on the display (px), rotation 0/90/180/270
  (clockwise), flip h/v (applied in the output, before the rotation lookup), on/off. None stored = the default slice (whole canvas
  -> whole display with the output fit). The output window draws each enabled slice as one instanced textured quad straight
  from the UYVY frame (no extra full-frame copy); black outside the slices. OSC: `/oats/output/slices s JSON [i display]`
  (`[{"src":[x,y,w,h],"dst":[x,y,w,h],"rot":90,"flip":"h","on":true,"name":"left"}]`, `""` = default; display defaults to the
  output's), `/oats/output/slice/{n}/src|dst f f f f`, `/rot i`, `/flip s none|h|v|hv`, `/on i`, `/name s`, `/remove`
  (n = count + 1 adds one). Status `output.slices` (effective list), `output.slices_default`, `mapping.displays`.
- **Cabinet test pattern**: `/oats/output/cabinet i w i h` (px, default 128x128; 500 mm panels = their pixel count), then
  `/oats/output/test i 2`: cabinets numbered column-row from the canvas top-left, alternating blue/purple, a diagonal plus a
  top-left corner marker per cabinet (orientation), the slice source outlines + numbers. It is drawn in canvas pixels and goes
  through the slices, so rotation / flip mistakes show on the wall. `/oats/output/test i 1` is the old display test pattern.
- **Clip scaling** per layer: `/oats/layers/{n}/scaling s cover|fit` (cover = fill + crop, default; fit = whole clip, transparent bars).
- Edits are live; `/oats/mapping/save` writes mapping.json, `/oats/mapping/revert` reads it back (`mapping.dirty`).
  Presets: `/oats/mapping/save s NAME`, `/oats/mapping/load s NAME` (then save), `/oats/mapping/delete s NAME`, `/oats/mapping/reload`.
  Show packs (the app) carry mapping.json + mapping/*.json: merge adds the presets (the pack's current mapping becomes
  the preset "Imported pack"), replace also replaces mapping.json.
- `/oats/output/snapshot`: the output window's next frame as `logs/output-snapshot.png` (status `output.snapshot`).

**Show safety: display sleep.** While an output display is set (`/oats/output/display` > 0) the player holds an IOPM assertion
`PreventUserIdleDisplaySleep` (status `output.awake`; log "display sleep: prevented ..."), released when the output goes off. It
keeps the displays and the Mac awake regardless of the Energy settings. **A locked screen does not stop the output window, but
display sleep does**: on 2026-10-23 the screen locked and the displays turned off at 06:10 while the player ran (before this guard).
The lock itself was not re-tested here (it would have disturbed the running session); if a show Mac locks, check once that the
output display keeps its picture behind the lock (it is a borderless screen-saver-level window on a non-main display).

## MA3 fixture: DMX personality v0 (sACN universe 5, default)

The player is seven fixtures on one universe, like a media server: **OATS VIZ, mode "Master 16" at 5.001**,
**OATS VIZ, mode "Fractal 24" at 5.017**, four **OATS VIZ, mode "Layer 16"** (one per clip layer) at
**5.041, 5.057, 5.073, 5.089**, **OATS VIZ, mode "Color 8"** at **5.105** and four **OATS VIZ, mode "Layer FX 24"** at **5.113, 5.137, 5.161, 5.185** (208 channels; revision v0.10: Layer 16 ch 14 source 30 NDI + ch 3 = NDI slot; v0.9: Layer 16 ch 15 generator type 120 Stars, Master 16 ch 15 test content 30 Test card / 40 NDI card appended; v0.8: Layer FX 24 FX types 180 StarTrails, 190 WarpTrails, 200 SpiralTrails appended; v0.7: Master ch 9–10 scenes, see "Scenes"). The player maps Layer fixture N by its address: 41 + 16·(N−1). Fixture file: `~/Developer/oats-viz/gdtf/OATS@OATS VIZ.gdtf`
(fixture type "OATS VIZ", manufacturer OATS, short name OATSVIZ, GDTF DataVersion 1.2, FixtureTypeID
1D726D7B-C558-4602-84E0-3B3F2DCC3CE3). It is made by `python3 -I tools/make_gdtf.py --check bin/oats-m0`, which
validates the file and compares it channel by channel with the player's own decoder (`bin/oats-m0 --dmx-table`).
The output is byte-stable; change `REVISION` in the script when the table changes. "(snap)" = MA3 jumps instead of
fading (LogicalChannel Snap=Yes), so a cue fade can't run through the values in between.

**Master 16** (patch at 5.001)

| Ch | Attribute | Function | Default | Values |
|---|---|---|---|---|
| 1 | Dimmer (GrandMaster) | master dimmer | 0 | 0–255 = 0–100% |
| 2–3 | OatsBPM | BPM, 16-bit | 0 | 0 = no override; 1–65535 = 20–300 BPM (the tempo clock: autopilot beats) |
| 4 | OatsTap (snap) | tap | 0 | a tap each time it goes above 127 (tap BPM from the last 5 taps, used while ch 2–3 = 0) |
| 5 | OatsResync (snap) | resync | 0 | rising edge above 127 = beat 1 of the tempo clock |
| 6–7 | OatsCrossfade | crossfader | 0 | reserved |
| 8 | OatsColumn (snap) | column go | 0 | 0 none; 1–255 = column c (slot c on every layer whose bank has it), fires when the (2-packet debounced) value changes to it; sets "Column 1"…"Column 8", "Column 9+" (v0.3) |
| 9 | OatsScene (snap) | scene (v0.7) | 0 | 0 none; 1–128 = scene (bank − 1) × 16 + slot (sets "Scene 1.1" … "Scene 8.16"), 129–255 reserved. Fires when the (2-packet debounced) value changes to it; the first packet is the baseline (nothing fires on start-up / reconnect). Go to 0 (or another scene) to fire the same one again. See "Scenes" |
| 10 | OatsSceneFade | scene fade (v0.7) | 0 | 0 = the scene's own fade; 1–255 = 0.1–25.5 s, read when ch 9 fires |
| 11–13 | OatsMasterFX2–4 | composition effects | 0 | reserved |
| 14 | OatsEffectSpeed | effect speed | 128 | 0 Stopped, 1–127 slower (0–1×), 128 Normal (1.0×), 129–255 faster (up to 2.0×); multiplies auto-zoom (DMX, OSC, GUI) and palette cycle speed |
| 15 | OatsTestContent (snap) | test content | 0 | 0–9 Normal, 10–19 DEEP test, 20–29 NOISE test, 30–39 Test card, 40–49 NDI card (v0.9), 50–255 reserved (= Normal) |
| 16 | OatsMasterControl (snap) | master control | 0 | 0–9 Idle, 10–19 Blackout, 20–29 Freeze, 30–39 Safe look, 40–255 reserved (= Idle) |

**Fractal 24** (patch at 5.017)

| Ch | Attribute | Function | Default | Values |
|---|---|---|---|---|
| 1 | OatsFractalType (snap) | formula (v0.6) | 0 | 0–9 Mandelbrot, 10–19 Burning Ship, 20–29 Tricorn, 30–39 Multibrot 3, 40–49 Multibrot 4, 50–59 Multibrot 5, 60–69 Celtic, 70–255 reserved (keep) |
| 2 | OatsTarget (snap) | target | 0 | 0 Free (keep the current target), 1 SEAHORSE, 2 SPIRAL, 3 JULIA, 4 VOID, 5 ELEPHANT, 6 STAR, 7 SEAMINI, 8 STARMINI (v0.6), 9–255 reserved (= free) |
| 3–4 | OatsOffsetX | offset X, 16-bit | 32768 | 32768 = on target; 0 … 65535 = −1 … +1 view width (camera moves right) |
| 5–6 | OatsOffsetY | offset Y, 16-bit | 32768 | as X, + = camera moves up |
| 7–8 | OatsDepth | zoom depth, 16-bit | 0 | depth (log10 zoom) = 28 × v / 65535, absolute: 0 = full set, 65535 = 1e28 |
| 9 | OatsAutoZoom | auto-zoom speed | 128 | 125–131 Stop (128 ± 3); 132–255 zoom in up to 0.5 decades/s; 0–124 zoom out up to 0.5 |
| 10–11 | OatsIterations | max iterations, 16-bit | 0 | 0 = auto (400 + 600 × depth, governed); else the value itself, clamped to 100–60000 |
| 12–15 | OatsJuliaRe / OatsJuliaIm | Julia constant, 2 × 16-bit (v0.6) | 32768 | 0 and 32768 = keep (OSC/GUI value, default −0.8 + 0.156i); else −2 … +2 |
| 16 | OatsKaleidoFold (snap) | kaleido fold of z (v0.6) | 0 | 0–9 Off, 10–119 Fold 2…12 (bands of 10), 120–229 Fold 2…12 mirror, 230–255 reserved (keep) |
| 17 | OatsPalette (snap) | palette | 0 | 0–9 OATS Navy, 10–19 Viridis, 20–29 Magma, 30–39 Inferno, 40–49 Plasma, 50–255 reserved (keeps the palette) |
| 18 | OatsPaletteOffset | palette offset | 0 | 0–255 = 0–1 |
| 19 | OatsPaletteCycle | palette cycle speed | 0 | 0 = stop … 255 = 0.5 cycles/s (a fader: 0 = stop, not 128 as PLAN 16 had it; there is no reverse) |
| 20 | OatsColouring (snap) | orbit trap (v0.6) | 0 | 0–9 Off (palette), 10 Point, 20 Circle, 30 Line, 40 Cross, 50 Star, 60–255 reserved (keep); mix / size are OSC/GUI |
| 21 | OatsRotation | rotation | 0 | 0–255 = 0–360°, the picture turns counter-clockwise around the screen centre |
| 22 | OatsFractalSpin | spin (v0.5) | 0 | 0 Keep (OSC/GUI value stays), 1–124 spin clockwise (−2 … 0 turns/s), 125–131 Stop, 132–255 counter-clockwise (0 … +2 turns/s) |
| 23 | OatsJuliaAmount | Julia morph (v0.6) | 0 | 0 = Mandelbrot … 255 = the Julia set of ch 12–15's constant |
| 24 | OatsFractalControl (snap) | fractal control | 0 | 0–9 Idle, 10–19 Reset to target (depth 0), 20–29 Freeze zoom, 30–39 Loop minibrot, 40–49 Dive & return (same target), 50–59 Dive next target, 60–69 Dive random target (v0.6; 0–29 = loop off), 70–255 reserved (= Idle) |

MA3 encoders show the names above (GDTF ChannelSets); `At ChannelSet "SEAHORSE"` works, and
`AutoCreate FixtureType "OATS VIZ" At Preset * If FeatureGroup "Gobo" /ChannelSet` makes target presets.
Feature groups: Dimmer; Gobo (type, target, iterations, Julia, power); Focus (depth, auto-zoom); Color (palette,
offset, cycle, colouring); Position (offsets, rotation); Control (the rest). Every attribute except Dimmer is a custom
MA3 attribute (`Oats…`, with a short pretty name).

**Layer 16** (one per clip layer: layer 1 at 5.041, 2 at 5.057, 3 at 5.073, 4 at 5.089; revision v0.2, ch 10–13 named in v0.3)

| Ch | Attribute | Function | Default | Values |
|---|---|---|---|---|
| 1 | Dimmer (no GrandMaster) | layer opacity | 0 | 0–255 = 0–1 (glides like the master dimmer) |
| 2 | MediaFolder1 (snap) | bank | 0 | 0 Empty (= clear), 1–255 bank number; sets named from `media/library.json` (1 MIXKIT, 2 TUNNEL) |
| 3 | MediaContent1 (snap) | slot | 0 | 0 Clear / eject, 1–255 slot; sets named `<slot> <clip name>` (32 chars) **from bank 1's clips**: in other banks the numbers still play that bank's slot, the names don't fit |
| 4 | OatsBlend (snap) | blend | 0 | bands of 10: 0 Alpha, 10 Add, 20 Screen, 30 Multiply, 40 Difference, 50 Lighten, 60 Darken, 70 Overlay, 80–255 reserved (keeps the blend) |
| 5 | OatsPlayMode (snap) | playmode | 0 | 0–9 Loop, 10–19 Once + hold, 20–255 reserved (keeps it) |
| 6–7 | OatsPlaySpeed | speed, 16-bit | 16384 | speed = v / 16384: 0 stopped, 16384 = 1.0×, 65535 ≈ 4.0× (forward only) |
| 8 | OatsTransition | transition time | 0 | 0–255 = 0–10 s (crossfade on a clip change, fade-out on clear) |
| 9 | OatsRestart (snap) | restart | 0 | rising edge above 127 = replay the layer's clip from the start (uses the layer's transition) |
| 10 | OatsClipCommand (snap) | clip command | 0 | 0–9 Idle, 10–19 Next, 20–29 Previous, 30–39 Random (in the layer's bank), 40–255 = idle. Fires once on **entering** a band (2-packet debounce); go back to Idle to fire again (v0.3) |
| 11 | OatsAutopilot (snap) | autopilot | 0 | 0–9 Off, 10–19 Order, 20–29 Shuffle, 30–255 reserved (keeps it) |
| 12 | OatsAutopilotTime | autopilot interval | 0 | 0 = per beats (ch 13, player BPM); 1–255 = every 1–255 s |
| 13 | OatsAutopilotBeats (snap) | beats per change | 0 | bands of 10: 0 = 1, 10 = 2, 20 = 4, 30 = 8, 40 = 16, 50 = 32 beats; 60–255 reserved (keeps it) |
| 14 | OatsLayerSource (snap) | source (v0.5) | 0 | 0–9 Clip, 10–19 Fractal (this layer takes the one fractal, latest move wins), 20–29 Generator, 30–39 NDI (v0.10: ch 3 Slot then picks the n-th NDI source, see "NDI sources"), 40–255 reserved (keeps it) |
| 15 | OatsGenType (snap) | generator type (v0.5) | 0 | bands of 10: 0 Lines, 10 Angles, 20 Prisms, 30 Circles, 40 Dots, 50 Grid, 60 Polygons, 70 Rays, 80 Spiral, 90 Waves, 100 Tunnel, 110 Shapes Burst, 120 Stars (v0.9); 130–255 reserved (keeps it) |
| 16 | OatsGenCount | generator count / density (v0.5) | 0 | 0 Keep (OSC/GUI), 1–255 sparse → dense (2 … 48 elements across the frame height) |

**Color 8** (one fixture at 5.105, revision v0.3: lights → VJ colour link)

| Ch | Attribute | Function | Default | Values |
|---|---|---|---|---|
| 1–3 | ColorAdd_R / _G / _B (GDTF standard, feature Color.RGB, activation group ColorRGB) | link colour | 255 | 8-bit each; MA3 colour pickers, colour presets and colour effects treat it like an RGB fixture |
| 4 | OatsColorAmount | match amount | 0 | 0 Off … 255 full |
| 5 | OatsColorTarget (snap) | target | 0 | 0–9 All layers + fractal, 10–19 Clips only, 20–29 Fractal only, 30–255 reserved (keeps it) |
| 6 | OatsColorMode (snap) | mode | 0 | 0–9 Tint (multiply toward the colour), 10–19 Hue shift (rotate the hue toward it), 20–29 Replace (colorize the luminance), 30–255 reserved |
| 7–8 | OatsColorCh7/8 | reserved | 0 | – |

- The colour is normalised to its brightest component (a dim console colour still tints at full strength; the
  amount is the strength) and smoothed over ~100 ms in the render loop; mode and target switch at once. For the
  fractal, tint / hue shift act on its palette colours (the per-pixel palette output). Owner keys `color.rgb`,
  `color.amount`, `color.mode`, `color.target` (latest move wins with OSC/GUI). **A block of 8 zeros = not patched**
  (a patched one rests at R G B 255): DMX leaves the colour link alone. status.json `color_link`
  (r g b, amount, mode, target, hex, amount_shown, rgb_shown) and `dmx.color` (address, driven, raw).

- A bank or slot change (2-packet debounced) plays that clip with the layer's transition; bank 0 or slot 0 clears
  (fade-out with the transition). A clip that is not in the library is logged and ignored (the layer keeps playing).
- Owner keys (latest move wins, same rules as above): `layer<n>.opacity`, `.clip` (bank, slot and restart),
  `.blend`, `.playmode`, `.speed` (16-bit dead band 131), `.transition` — the same keys OSC/GUI take.
- **A Layer block of 16 zeros counts as not patched** (a patched one rests at 16384 on ch 6–7): DMX doesn't touch
  that layer, so OSC/GUI keep it. status.json `dmx.layers[]`: layer, address, driven, bank, slot, blend, playmode,
  restarts, raw. The channel names follow bank 1 because a GDTF channel set can't depend on another channel;
  re-run `make_gdtf.py` (new REVISION) after the library changes so MA3 shows the new names.
- `bin/oats-m0 --media DIR --selftest-dmx` feeds crafted Layer packets through the decoder (no network; prints
  PASS/FAIL). Safe while MA3 is live on universe 5.

**Defaults, decided:** the master dimmer defaults to **0** (revision v0.1; it was 255), so MA3 masters and faders can
dim it; without any DMX the player still runs at dimmer 100%. It is GrandMaster-controlled, so the GrandMaster and the B.O. key still take it down. The
Fractal defaults hold the full set: target free, offsets on target, depth 0, auto-zoom stop, palette OATS Navy.

**Patch it in MA3 (2.3.2 onPC on the PC):**
1. Copy `OATS@OATS VIZ.gdtf` to `C:\ProgramData\MALightingTechnology\gma3_library\fixturetypes\` on the PC (or a USB
   stick, `grandMA3/gma3_library/fixturetypes/`).
2. Menu > Patch > Fixture Types > Import > select "OATS VIZ" (OATS) > Import.
3. **First delete the five OATS dimmers 9001–9005** (or move them off 5.001–5.005): they overlap the new Master.
   On v0, 5.002–5.005 are BPM, tap and resync, so the old zoom/palette faders would set a BPM and tap. Presets and cues
   that used them have to be rebuilt on the new fixtures.
4. Add > fixture type OATS VIZ, mode **Master 16**, quantity 1, FID 9001, patch **5.001**. Add > OATS VIZ, mode
   **Fractal 24**, quantity 1, FID 9002, patch **5.017**. Leave the patch and accept.
5. Nothing else changes: the sACN Output row stays (unicast to 192.168.1.148, universe 5, priority 100).
6. Check: Fixture 9002, Target encoder > SEAHORSE, Depth up: `./m0.sh status` shows `dmx.fractal.target` and
   `dmx.fractal.depth`, and the log `DMX -> …` lines.
To update the type later, delete it in Patch > Fixture Types (or replace it there) and import the new file.
**But not while fixtures use it:** in MA3 2.3.2, overwriting the in-use fixture type detached the patched fixtures
9001/9002. See "Add the Layer fixtures" below.

**Add the Layer fixtures (revision v0.2) without breaking 9001/9002:**
1. Copy the new `OATS@OATS VIZ.gdtf` to `C:\ProgramData\MALightingTechnology\gma3_library\fixturetypes\` on the PC
   (it replaces the v0.1 file in the library folder only; the show file keeps its own copy of the type).
2. Menu > Patch > Fixture Types > Import > "OATS VIZ" (OATS) > Import, and **import it as a NEW fixture type**:
   if MA3 offers to replace / overwrite the existing "OATS VIZ", **don't** — choose import as new (MA3 then lists a
   second OATS VIZ type, e.g. numbered or named "OATS VIZ 2"). Do not touch the existing type: 9001 (Master 16)
   and 9002 (Fractal 24) stay on it; their modes are unchanged in v0.2, so they need nothing.
3. Add > the **new** OATS VIZ type, mode **Layer 16**, quantity **4**, FID **9011** (9011–9014), patch **5.041**
   (MA3 patches them back to back: 5.041, 5.057, 5.073, 5.089). Leave the patch and accept.
4. Check: Fixture 9011, Dimmer 100%, Bank encoder > MIXKIT, Slot > `1 driving through …`: the clip plays on layer 1;
   `./m0.sh status` / status.json `dmx.layers[0]` shows driven true, bank 1, slot 1.
5. Later (optional, when no show depends on it): re-patch 9001/9002 to the new type and delete the old one.

**Depth and auto-zoom:**
- While ch 9 is at Stop, **the console controls the depth**: ch 7–8 set it absolutely and the picture glides to it.
- Move ch 9 off Stop and the **auto-zoom drives the depth** from wherever it is; ch 7–8 are ignored meanwhile.
- Bring ch 9 back to Stop and the **depth holds** where the auto-zoom left it; the **next change on ch 7–8 takes
  console control again** (the picture goes to that value).
- Fractal control **Reset to target** (10–19): depth 0 once on entry, then held like an auto-zoom stop (with ch 9
  still running, the auto-zoom restarts from depth 0). **Freeze zoom** (20–29): the depth holds and ch 7–9 are
  ignored while it is set.
- A target change (ch 2) keeps the depth while the console controls it; during an auto-zoom or a hold the new target
  starts at depth 0 (as over OSC, unless keepdepth is on).
- Offsets are in **view widths**, so they stay the same size on screen at every depth (the zoom closes in on the
  target as the view shrinks; 32768 = the target in the centre).

**Master control:** Blackout / freeze / safe look are one parameter with the OSC blackout (latest move wins: the console moving ch 16 replaces an OSC blackout, an OSC blackout on or off releases a DMX blackout, freeze or safe look). **Freeze** holds the frame: zoom,
palette cycle, DEEP and NOISE stand still and other changes wait; dimmer, blackout and safe look stay live, so a
frozen frame can be faded. **Safe look** = blackout off (DMX and OSC), normal content, dimmer 100%, whatever else is
set, as long as it is held.

**Timing (PLAN 10):** continuous values (dimmer, offsets, depth, palette offset, rotation) glide linearly over the
measured packet interval (1/120–0.1 s; MA3 sends at most 30 Hz, the render runs at 60). Choice and index channels
(test content, master control, type, target, palette, fractal control) act only when 2 packets in a row agree.
Tap and resync are edges. Nothing in v0 is destructive, so nothing needs the 3 s hold.

**Ownership: latest move wins (LTP), per parameter.** Parameters: dimmer, content, bpm, effect_speed, zoomspeed (auto-zoom),
depth, target, offsets, palette, palette_speed, palette_offset, iterations, rotation, master (blackout / freeze /
safe look).
- An OSC/GUI command always applies at once and takes its parameter (log: `(takes palette from DMX)`).
- A DMX channel takes (or retakes) a parameter only when its value **changes**: 16-bit channels by more than a dead
  band of 0.2% (131 steps; leaving or entering 0 = auto / no override always counts), 8-bit channels by any step,
  choice / index channels when the 2-packet debounced value changes (log: `DMX retakes palette (console moved)`).
  MA3 repeating an unchanged value never overwrites what OSC set later.
- **Depth and zoom speed are one group**: a change on ch 7–8 (depth), ch 9 (auto-zoom) or ch 24 (Fractal control)
  takes both; auto-zoom from DMX keeps driving the depth while ch 9 is off-stop. An OSC/GUI depth, zoom or zoom
  speed move takes both until the console moves ch 7–8, 9 or 24 again (a depth/zoom move also stops a running DMX
  auto-zoom: zoom speed 0).
- **First appearance / reappearance rule:** the player keeps the last value seen from DMX per channel for the whole
  run (across losses and source changes). The very first packet after start is the baseline: it is applied only to
  parameters nobody has set over OSC/GUI since start. When a source reappears after a loss (or another source wins),
  only parameters whose channel now differs from the last value seen are taken; the rest stay as they are.
- **A Fractal block of 24 zeros counts as not patched** (a patched one rests at 32768/128 on ch 3–6 and 9): then DMX
  doesn't touch the fractal parameters at all. Resolution, keepdepth, ping and snapshot are OSC only.
- status.json `owners` maps each parameter to `dmx`, `osc` or `default` (never set); `owner` is the summary: `dmx`
  (DMX live, nothing taken over OSC), `mixed` (DMX live, some parameters set last over OSC/GUI), `osc` (no live DMX).

**DMX lost** (2.5 s silence or stream-terminated): hold the last look; every OSC command applies as always. A DMX
blackout becomes the OSC blackout (the GUI can clear it), a safe look stays as dimmer 100% / normal / blackout off, a
freeze zoom becomes zoom speed 0; a frame freeze is released. status.json `dmx`: `map`, `channels` (the 104 raw
values, 112 with Color 8), `master` (incl. `column`, `column_goes`), `layers[]` (incl. `commands`), `color` and `fractal` (decoded values, `depth_control`: console / auto-zoom / held / frozen / osc).

**Not done in v0:** the reserved channels (Master 6–7, 11–13, Color 7–8) are decoded raw into status.json only. Tempo (BPM, tap, resync) drives
the player's tempo clock, which only the autopilots use so far (no BPM-synced effects yet).

**Add the v0.3 fixtures (Color 8, new Layer/Master channel names) without breaking anything:**
1. `make_gdtf.py` wrote the v0.3 file and it was copied to `~/MALightingTechnology/gma3_library/fixturetypes/OATS@OATS VIZ.gdtf`
   on this Mac; copy the same file to `C:\ProgramData\MALightingTechnology\gma3_library\fixturetypes\` on the PC.
2. Patch > Fixture Types > Import > "OATS VIZ" (OATS) and **import it as a NEW fixture type** (never overwrite or
   replace the in-use type: in 2.3.2 that detached 9001/9002 before). 9001–9014 stay on their current type: the DMX
   layout of Master 16, Fractal 24 and Layer 16 is unchanged, so the new Layer ch 10–13 and Master ch 8 already work
   from the old fixtures (as the raw "OatsLayerCh10…13" / "OatsColumn" encoders, without the v0.3 names). Re-patch
   them to the new type later if you want the names.
3. Add > the **new** OATS VIZ type, mode **Color 8**, quantity 1, FID **9020**, name "OATS Color", patch **5.105**.
4. Add 9020 to your wash / colour groups (select the group plus 9020 and store it again with /Merge, or edit the
   group), so colour presets, the colour picker and colour effects hit it with the lights. Keep its Match amount
   (ch 4) at 0 (off) until you want the video to follow; store a preset with it at full.
5. Check: Fixture 9020 at a red colour preset, Match amount 100%: status.json `color_link` shows r 1, g 0, b 0,
   amount 1, `dmx.color.driven` true; the program goes red.

### Old M0 map (`--dmx-map m0`)

| Ch | Function | Values |
|---|---|---|
| 1 | master dimmer | 0–255 = 0–100% |
| 2 | zoom speed | 125–131 = hold; above = in, up to 0.5 decades/s at 255; below = out, up to 0.5 at 0 |
| 3 | palette (bands) | 0–51 OATS Navy, 52–102 Viridis, 103–153 Magma, 154–204 Inferno, 205–255 Plasma (MA3 10/30/50/70/90%) |
| 4 | palette cycle speed | 0–255 = 0–0.5 cycles/s |
| 5 | test content | 0–84 normal, 85–170 DEEP, 171–255 NOISE (MA3 0% / 50% / 100%) |

Channels 3 and 5 debounce 2 packets. Same latest-move-wins rule as v0 for dimmer, zoom speed, palette, palette speed and content.

### sACN rules (both maps)

- Sources are tracked by CID. Highest priority wins. With equal priority the most recently started source
  wins (logged; no HTP merge in M0). Preview packets are ignored. Duplicates and packets up to 19 behind are
  dropped (E1.31: (int8)(new−last) <= 0 and > −20). Other universes, non-zero start codes and packets whose PDU
  flags/lengths don't match are ignored. At most 64 sources are tracked at once.
- A source is lost after **2.5 s of silence**, or at once on stream-terminated (on any start code). With no source
  left: **hold the last look** (log: `DMX lost, holding last look`); OSC applies as always (latest move wins). The last
  DMX values stay, speeds included: a zoom speed other than hold keeps zooming to the 1e28 / full-set limit, and a
  palette cycle keeps cycling.

## Content

- **normal**: deep-zoom Mandelbrot (perturbation, see "Deep zoom"), bailout 256, smooth colour, black interior.
  Starts at target SEAHORSE, 3.0 wide (depth 0). Zoom integrates real time in log10 space, held between depth 0
  (width 3.0) and depth 28 (width 3e-28).
- **deep**: the bench DEEP content (unchanged, plain float32 kernel): width 3.0 ↔ 1e-5, log-space triangle, 24 s period, by clock. It uses
  the bench's own cosine palette, so the palette controls don't change it.
- **noise**: the bench NOISE content: full-amplitude noise, new every frame.
- **testcard** / **ndicard** (2026-10-23, `src/testcard.swift`, GDTF v0.9): see "Test cards" below.

### Test cards + startup card (2026-10-23, `src/testcard.swift`)

Output content drawn by the player at canvas resolution (1920×1080), instead of the layers (one cheap pass; the
layers keep their state underneath and come back when it ends). The procedural parts are a GPU kernel every frame; the
text and the QR code are drawn with CoreText / CoreGraphics into an overlay on a utility queue about once a second
(only when a line changed), so nothing heavy runs per frame. No 1-pixel detail (the finest wedge has 2 px lines).

- **Test card** (`/oats/test/content s test`, DMX Master ch 15 = 30, GUI Master › Test content › Test card):
  75 % colour bars, an 11-step greyscale wedge, 2 / 3 / 4 / 6 / 8 px line wedges (vertical + horizontal), a 60 px grid
  and a geometry circle + centre cross (aspect / scaling), a frame-edge border and corner markers (cropping), the
  VJ VIZZIES logo, resolution · fps · NDI source name, the time, a 7-digit frame counter and a sweep bar moving back
  and forth (a frozen feed is obvious).
- **NDI card** (`s ndi`, DMX 40, GUI "NDI card"): the exact NDI source name big (`<LOCALHOSTNAME>.LOCAL (<name>)`),
  resolution / fps, NDI mode + sending, receivers connected (count + names when the sender reports them), the Mac's
  en0 address + NDI group (Public) + "the receiver must be on a.b.c.x", short steps for Vectorworks Vision, OBS,
  OSEE GoStream (Deck: needs the NDI licence) and NDI Studio Monitor, and the controls URL `http://<en0>:8090`
  (`--gui-port`) with a QR code (CoreImage CIQRCodeGenerator). Live lines refresh about once a second.
- `/oats/test/content` also takes `normal|off|deep|noise|testcard|ndicard`. status.json `content` = what is shown,
  `content_set` = the set value, `test_content{}`.
- **Startup card:** a COLD start (`m0.sh start`, the app, autostart) shows `--startup-card test|ndi|off` (default test)
  until the first control input: OSC from a person or the GUI (not the Link helper, ping, snapshot, library reload or
  MA3 `/cmd` echoes), a DMX value change after the first packet (the baseline), or a scene go; `--startup-card-secs S`
  also ends it after S seconds (default 0 = input only). A restart by the supervisor (m0.sh's loop after exit 75, a
  crash or `m0.sh restart`; the app's player loop) passes `--restart`: no card, straight to the normal look.
  status.json `startup{card, waiting, showing, ended_by, secs, restart}`. Safe look (DMX) overrides the card.
- All motion runs on the clock, not on frames sent: a dropped frame doesn't slow the zoom.

## Logs and status (`logs/`)

- `oats-m0-<YYYYmmdd-HHMMSS>.log`: everything, with ms timestamps. The program also prints it on stdout; under
  `m0.sh` stdout is discarded (it is the same text) and only stderr is kept in `logs/console.err`.
  Every 5 s a `STATUS` line: fps, dropped ticks, longest send call, longest frame gap, alarms, gate fails,
  NDI connections, content, view width, palette, dimmer, blackout, live DMX source (name, priority, pkt/s),
  last OSC address and its age, CPU % of one core, RSS. `ALARM` lines: send call > 50 ms, sender frame gap
  > 100 ms (counted, not failed). `ALARM GATE` lines: send call > 100 ms or frame gap > 200 ms, which **fail**
  M0 Parts D and E (PLAN 13.1).
- `status.json`: the same fields plus pid, start time, libndi version, arch, NDI name/groups, DMX sources,
  `gate_send_over_100ms` / `gate_gap_over_200ms` (any non-zero = gate FAIL), `gpu_errors`, `window_end_unix`.
  It is written once per second, as a temp file that is then renamed.
- `status.json` `render` (2026-10-23): `stages` = GPU ms p95 per stage over the last 120 frames, from timestamp counters at
  the start and end of each stage's compute encoder: `fractal` (fractal / deep zoom + upscale + loop fade), `layers` (generators +
  composite), `master` (master FX; 0 when off), `output` (analysis, to_uyvy, preview, NDI copy); `stages_sum_ms_p95`, `timing`
  ("counters (stage boundaries)" or why not). The STATUS line adds `gpu_stages_p95=frac/layers/master/out`. `fx_info.layers_drawn`:
  the layers that drew this frame: a layer at opacity 0 (after beat mod and audio) or without content (no clip, the fractal elsewhere)
  adds no FX kernel variant and leaves its Trails history untouched (kept, valid again when it comes back; freed after 5 s).
- `loop.log`: starts, `RESTART #n at <time>`, stops. `snapshot.png`: the last `/oats/system/snapshot`.
- At start the log shows the libndi version, the CPU type (x86_64, Rosetta), `NDI_CONFIG_DIR` and `adapters.allowed`.
- NDI connections are logged when they change, plus any `<ndi_product …>` metadata a receiver sends.

## Live preview (TCP 8091, inside oats-m0)

- `GET /preview.mjpg` (multipart/x-mixed-replace, boundary `oatsframe`), optional `?w=160|256|320` (other values:
  nearest of these; height = w*9/16; default 256) and `?fps=10..30` (default 30). `GET /preview.jpg[?w=…]` = one JPEG.
  Bound to 127.0.0.1 + en0's address (never 0.0.0.0; re-bound when en0 changes; 2026-10-23), Host header must name this Mac (localhost, 127.0.0.1, en0, <name>.local) else 403, no PIN (read-only picture), CORS only for this Mac's own pages (the Origin is echoed, no `*`), widths 160/256/320/640/960/1920 (the GUI asks for the smallest that covers the monitor, 15 fps docked), at most 8 stream clients (9th: 503; 2026-10-23, was 4: the Mac app uses 2, plus the phone, other windows and the PC). Each size is encoded once per frame and shared, so a client costs only its socket write.
- `?layer=0..4&w=320|480` (2026-10-23): the GUI's PREVIEW monitor, ONE layer by itself (0 = BG fractal): its source
  texture(s) as the composite samples them (clip A/B crossfade, cover/fit, layer overlay; generators carry their own
  motion) over black, before opacity, blend, filters, clip motion and master. There is no per-layer post-FX texture
  (filters and clip motion run inside `composite_fx`), so it reads the source. One `preview_solo` dispatch on the
  frame's own command buffer, only while such a client exists (bits 16..23 of the demand word = wanted layers; two
  windows on different layers take turns). A generator layer at 0 % renders while it is previewed. Measured: output
  stage p95 0.84 -> 1.26 ms with a 480x270 solo of a generator (3x3 taps; the installed build uses 2x2 taps, cheaper,
  not re-measured). Every GUI window at 1280 px or wider uses 2 of the 8 stream slots (program + solo; each monitor has its own on / off, 2026-10-23, `oatsgui.preview` / `oatsgui.previewSolo`; off closes that stream); status
  `preview.solo_layers`, `preview.solo_size`.
- How: while a client is connected, every 2nd frame (60/30) the frame's own command buffer also box-filters the
  UYVY output (exactly what NDI gets, dimmer/blackout included) to BGRA; the completion handler hands it to the
  `preview-jpeg` thread (ImageIO JPEG q 0.6, about 0.3-0.6 ms) or drops it if that thread is busy. Sockets are
  non-blocking: a client that can't take a frame misses it, one that takes nothing for 5 s is dropped. No client:
  no GPU or CPU work (one atomic load per frame). The watchdog doesn't watch the preview threads.
- Log: one line per stream client connect/disconnect. status.json `preview`: listening, clients, fps, size,
  encode_ms_avg, frames, dropped (= dropped_busy + dropped_slow_client), every_nth_frame.
- If TCP 8091 is taken at start, the player logs it and runs without a preview (no retry: restart to get it back).

## GUI (control window, `gui/`)

A web control window for the running player: live preview, status pills and the OSC controls. Python stdlib
only; it does not start, stop or touch oats-m0, it only reads `logs/status.json` and sends OSC to 127.0.0.1:7000.

| Command | What it does |
|---|---|
| `gui/run.sh` | Starts the server in the background (pidfile `gui/run/gui.pid`, log `gui/run/gui.log`) on port 8090, all interfaces |
| `gui/run.sh stop` / `gui/run.sh status` | Stop it / show whether it runs and the URLs |
| `OATS_GUI_PIN=1234 gui/run.sh` | Same, but asks for a PIN (cookie after a login form). Default: no PIN |

Open http://localhost:8090 on this Mac, or http://192.168.1.148:8090 from a phone or laptop on your LAN.

**Load (2026-10-23).** The desktop page makes one shared `/api/status` request every 700 ms for all its cards (before: each card
polled on its own, ~13 requests/s), every 2 s when the page is not seen: a hidden tab, or the Mac app's window minimised, closed
(hidden), app hidden or fully covered (the apps call `window.__occluded = true/false` + an `oats-occlusion` event on window
occlusion changes). While not seen the live preview stream is closed, the audio meter stops polling and the beat dots stop.
The server keeps the encoded status for 200 ms and sends it gzip-compressed (24 KB -> about 7 KB).

**Phone controller (2026-10-23, `gui/phone.html`, served at `/phone`).** A separate one-hand page for iPhone / Android
in portrait (375–430 px wide, landscape fallback): fixed page (no page scroll, no zoom), safe-area insets, 44 px targets.
Top bar: wordmark + status dot (fps / DMX / NDI; tap for details), BPM + TAP, LINK, BLACKOUT (hold 0.5 s = on, tap = off).
Preview strip (MJPEG 256 wide at 15 fps from :8091; tap hides it, remembered, then a slim status line). Layer chips
L4 L3 L2 L1 BG (tap = select, long-press = clear). Tabs at the bottom: Play · Looks · FX · Fractal · Scenes · Master; only
the tab area scrolls. Sliders: drag sideways to set, drag up/down scrolls, double-tap = default. Status every 700 ms,
paused (with the preview) while the page is hidden. Deep link `/phone?tab=fx&layer=2`. Phones are sent there from `/`
(server: iPhone / Android Mobile user agent; page: touch + under 700 px + portrait); **Desktop view** on the phone page
(Master tab) keeps that phone on `/` (cookie `oatsview=desktop` + localStorage), the header **Phone** link goes back.
Home Screen: open `http://<Mac en0 IP>:8090/phone` in Safari on the lighting Wi-Fi › Share › Add to Home Screen (http is
fine; it opens full-screen, black-translucent status bar). Screenshots: `media/phone-*.png`.

**iPad remote (2026-10-24, `gui/remote.html`, served at `/remote`; spec `docs/remote-spec.md`).** Live since 2026-10-24: a
touch remote that only recalls what the desktop GUI built ("the remote plays, the desktop builds"). Landscape 1366x1024 and
1180x820, portrait 1024x1366; under 760 px wide it only offers the phone page. Every send goes through this server
(`POST /api/osc`, `POST /api/genlook`), one request at a time and in order; it never talks UDP and never opens the preview.
A pad shows its own state for 6 s after a tap, then live status takes over. Three pages, swipe or tap the tabs at the bottom:
- **SCENES**: bank rail 1–8 (tap = view + `/oats/scene/bank`), 4x4 scene pads (tap = `/oats/scene/go`, "IN" while fading,
  "LIVE" when there), NEXT / PREV (the next or previous stored slot in the shown bank, wrapping, sent as a scene go, never
  `/oats/scene/next`), FADE (SAVED = the scene's own fade, CUT = 0, 4 s, 8 s; a local choice, stored on the iPad), DIM
  (master dimmer, relative drag, 60 ms throttle). Empty banks and pads only toast.
- **LAYERS**: tiles L4 L3 L2 L1 BG with ON / OFF (opacity 0, or back to the level it had, remembered per layer on the
  iPad) and a 30-cell grid for the selected layer's current source: clips (layer play by bank / slot), generator looks
  (`/api/genlook`), or for the fractal: looks, dive places and shapes. Launching on a layer that is OFF also turns it on.
  The remote never changes a layer's source.
- **FX**: 12 hold-to-flash hits on the master FX slot (press = type + amount + speed or a master preset; release = back to
  what was there, or FX off), an XY pad (amount across, speed up, 50 ms throttle) that shapes the held hit or, with nothing
  held, fires the last hit while touched. Swipes on this page start only from the left / right screen-edge strips.
- **Bar** (every page): health dot + logo (tap = a plain-words status toast), NOW (scene + what is moving; tap = the full
  list), TAP (tap tempo, greyed while Link leads), LINK (hold 1 s = follow / ignore Link, `/oats/tempo/source`), BLACKOUT
  (hold half a second = on, tap = off; stays live when the player is offline).
PIN: with `OATS_GUI_PIN` set, `/remote` sends a logged-out iPad to `/login?next=/remote` and the PIN form returns there
(only `/remote` and `/phone` are accepted as `next`; anything else goes to `/`), so a Home Screen web app with its own
cookie jar logs in once and lands back on the remote. Home Screen: open `http://<Mac en0 IP>:8090/remote` in Safari on the
lighting Wi-Fi › Share › Add to Home Screen ("VIZ Remote"; full-screen, no browser chrome). The desktop GUI's Remote pill
lights while an iPad polls `/api/status?client=remote`. Test it without the show: a throw-away player on OSC 7300 plus
`OATS_GUI_PORT=8099 OATS_OSC_TO=127.0.0.1:7300 OATS_GUI_LOGS=<its log dir> python3 -I gui/server.py`; `/api/genlook` and
`/api/script` pass that `OATS_OSC_TO` on to `tools/oats_script.py --to` (before 2026-10-24 they always went to 7000).

**Layout (2026-10-22, compact redesign; old page backed up as `gui-before-compact.html` in the session scratchpad).**
One screen, three columns, no page scroll at 1920×1080 in Compact (only the panels scroll). Themes **Slate**
(default), **Light**, **Stage**; accents L1 cyan, L2 magenta, L3 amber, L4 lime, base / fractal violet, master white,
colour = the live link colour. The VJ VIZZIES wordmark flows in the layer colours with a slow 4 s glow breathe + shimmer,
tinted toward the colour link when it is on (static with reduced motion, paused in hidden tabs).
- **Header (one row)**: logo · beat dot, BPM + source, 4 bar dots, **LINK** chip (Ableton Link, peers), **TAP**, **⟲1** resync (`/oats/tempo/resync`) · master
  dimmer and master effect speed mini faders · BLACKOUT · theme · **density** (Compact 13 px text / 28 px controls,
  Touch 44 px; remembered; Touch is the default under 900 px) · **?** helpers on/off · preview thumbnail (click to
  enlarge / shrink, remembered; Esc shrinks; the on/off button is on the big view).
- **Editor dock (2026-10-23; old page backed up as `index-before-dock.html` in the session scratchpad).** Three
  columns, nothing ever shifts, no page scroll and no scroll bars at 1456×819 and 1920×1080:
  - **Left**: the Deep zoom card, a guided flow (2026-10-23; see "Deep zoom card" under Deep zoom). It fits the column; nothing scrolls at 1456×819 or 1920×1080.
  - **Middle, layer list** (fixed): one **44 px line per layer**, L4 → L1 then BG: colour chip (select), content name (one
    line; under it the summary, e.g. `Gen · Polygons · FX Twist 70%`, and a pulsing badge while a script runs; full name
    + position in the helper), opacity fader + value, blend, speed fader + value, ◀ ▶ 🔀, autopilot mode + interval,
    **✎ Edit**, ✕. Rows never grow. Drag a clip (or a Finder file) onto a line to play it there. BG line: since 2026-10-23
    a normal row (see "BG = layer L0").
  - **Middle, dock** (fills the rest, fixed size whatever the tab): tabs **Content · Overlay · Filters · Motion · Looks** for the
    selected layer ("Editing L4" in its colour), and on the right **Clips · Scenes**. ✎ Edit or the chip (or keys 1–4,
    0 = BG) selects the layer and opens the dock on its last-used tab (Content the first time); remembered per layer.
    - **Content**: source switch Clip | Fractal | Gen, then — Gen: generator picker (2 rows) + count, thickness,
      softness, speed, angle, variation, colour mode + A / B, beat sync; Clip: bank tabs + that bank's clips (click =
      play on this layer) + play mode (Loop / Once, `/oats/layers/{n}/playmode`) + transition 0–10 s
      (`/transition`); Fractal: the Fractal on Base / L1–L4 buttons + a pointer to the Deep zoom card.
    - **Overlay**: the layer overlay (below, "Layer overlay"): On / Off, blend (Add · Screen · Multiply · Alpha · Diff),
      motion (Follow · Fixed), "use look…" (a generator look's pattern), the type picker (2 rows) + opacity, count, speed,
      thickness. The rest (softness, angle, variation, colours, beat sync) is OSC only.
    - **Filters**: Filter 1 | Filter 2 (type from the player's list incl. StarTrails / WarpTrails / SpiralTrails, amount,
      speed) + the FX looks (presets, Reset). **Motion**: position pad, scale, rotation, spin, flip / mirror / tile,
      spin fill, edge feather + shape, beat move (target, shape, rate, depth). **Looks**: generator looks, scripts ▶ / ■
      (+ "running"), FX looks.
    - **Clips**: the clip bins (bank tabs, +, column row, slots, drag-drop upload, drag to swap, right-click remove;
      click = play on the selected layer). Scrolls (hidden bars, sticky column row) only if a bank has more slots than
      fit. **Scenes**: the scenes card (banks, 16 tiles, ◀ ▶, fade, Store, right-click menu).
    - Deep link: `?dock=content|filters|motion|looks|clips|scenes&layer=0..4`; `?preview=0` opens the page without the
      preview stream (screenshots).
  - **Focus: On** dims the other layer lines slightly while the dock shows a layer (dock, header, output and preview
    never dim). Screenshots: `media/gui-dock-*.png`.
  - **Monitors** (2026-10-23, windows 1280 px and wider): the preview left the right column; the dock's tab content
    has one fixed height (its tallest tab, measured per window size) and below it PREVIEW (the selected layer by
    itself, `?layer=n`, tag in the layer's colour, "L2 · empty" for an empty layer, a clip time bar along its bottom
    edge: click / drag scrubs, Shift fine, max 10 seeks/s) | PROGRAM (red tally, fps, Low/Full/Auto, Preview on/off,
    click to enlarge). 222x125 each at 1456x819, 605x340 at 1920x1080. Streams play through a small iframe each, so
    closing / switching really ends the connection in WebKit (the Mac app). Below 1280 px the old layout stays.
    Screenshot: `media/gui-monitors.png`.
  - Helpers: shortcuts line (generic per control type + mapped keys), MA3 in a side column; OSC addresses only with
    "?" menu > Show OSC addresses (off by default). Layer rows: one named-column grid for header and rows.
  - **Right**: preview, Master, blackout, tempo, output row, colour link, master FX + presets, audio react, test content.
- **Footer**: status pills (FPS, Vision / NDI, DMX, owner, alarms, CPU, preview, uptime) and the last OSC sent. A red
  "player offline" banner floats at the top when status.json is more than 3 s old.
- **Narrow (< 1280 px)**: the columns stack (the fixed dock layout is made for 1456 px and wider).
- **Pop-up helpers**: every button, fader and dropdown shows a helper after 400 ms hover (long-press on touch; the
  long-press does not also click): name, what it does, the shortcut, and in grey the OSC address and the MA3 channel
  with its DMX address (e.g. "MA3 Layer 2 · ch 14 Source · 5.070"). Never off-screen; Esc or moving away hides it.
  The texts are one table, `HELP` at the top of the first `<script>` in `index.html`, keyed by each control's `data-h`.
- **Keys**: 1–4 select a layer (and show it in the dock), 0 BG, ← → previous / next clip on the selected layer, Space or T tap, B blackout,
  ↑ ↓ zoom in / out, H hold, Shift+1–5 palette, ? helpers, Esc closes helpers / menus / the big preview.
- **Preview**: live MJPEG straight from oats-m0 (`http://<host>:8091/preview.mjpg`, 256x144 at 30 fps; see
  "Live preview" below). Turning it off or hiding the tab closes the stream. If the stream fails, the page falls back
  to snapshot polling (`/api/preview`, 2 frames/s) with a "slow preview" note and retries live every 15 s.
- **Looks + scripts** (dock > Looks, from `tools/gen_presets.json`): the **Generator looks** chips apply a look
  to the selected layer (`POST /api/genlook` → `tools/oats_script.py look`); the 5 **Scripts** are ▶ / ■ for the
  selected layer (`POST /api/script` run | stop; run is detached, log `logs/script-layer<n>.log`, one per layer). A
  running script shows as a pulsing badge on its layer row (status.json via the GUI: `scripts_running`, from the
  runner's pidfiles, live processes only). Helpers show a look's / script's `about`, else its type + FX / steps.
- One `/api/status` poll every 500 ms drives every control; a control you just moved ignores status for 1.8 s.
- **Owner tags**: every control works at all times (latest move wins). A small tag next to each control shows who
  set it last, from status.json `owners`: **MA3** (the console over DMX) or **OSC** (OSC or this GUI); no tag = default.
  The console takes a control back when it moves that channel; the header "owner" pill shows DMX / MIXED / OSC.
- `POST /api/osc` only sends addresses that start with `/oats/` (others: 400), and never `/oats/debug/…`.
  Anyone on your LAN who can open the page can drive the show: set `OATS_GUI_PIN` if the network isn't yours alone.

## Deep zoom (normal content)

The normal content zooms from the full set (depth 0, width 3.0) to **zoom 1e28** (depth 28, width 3e-28) and stays
sharp the whole way. "Depth" is log10 zoom; zoom = 3.0 / view width.

- **How** (PLAN 9, tier C): the centre is a decimal string, parsed into double-double (hi + lo double, about 32
  significant digits). The `ref-orbit` thread computes the centre's orbit Z_n in double-double and stores it as
  float32 in a shared Metal buffer. It is computed again only when the centre changes, and extended (not restarted)
  when the iterations grow; the render loop keeps drawing the previous orbit until the new one is ready (a few ms).
  On the GPU every pixel iterates only its tiny difference from that orbit, in float32, with rebasing (Zhuoran 2021)
  instead of glitch detection. One kernel draws every depth, so there is no seam. Palettes, palette offset,
  colour cycle, dimmer and blackout work as before. DEEP and NOISE are unchanged.
- **Iterations**: auto, 400 + 600 per decade (500 at the full set, 17,200 at 1e28), or fixed with `/oats/fractal/1/iter`.
- **Governor**: GPU time per frame from the command buffer. p95 over the last second above 12 ms (or one frame over
  25 ms) lowers the fractal's internal resolution, 1920x1080 → 1600x900 → 1280x720 → 960x540 → 640x360 (upscaled
  bilinear to 1080p), several steps at once if needed; at 640x360 it lowers the iterations (to ×0.05 at most).
  Below 6 ms for half a second it steps back up (iterations first). Jumps (another target, a depth jump of a decade
  or more) are checked before their first frame is drawn, so a jump cannot freeze the picture or trip the watchdog.
  Measured here (60 fps, 0 dropped): full set 1080p 4.4 ms; SEAHORSE 1e5 1280x720 11.3 ms, 1e15 640x360 6.5 ms,
  1e27 640x360 9.9 ms with full iterations; JULIA 1e27 1280x720 8.9 ms; VOID 1e26.8 (inside the small copy)
  640x360 at ×0.09 iterations, 9.9 ms. `/oats/fractal/1/res` fixes the resolution (governor off).
- **status.json** `fractal`: engine, depth_log10, view_width, target, iterations (and base, mode, scale),
  ref_orbit_len, ref_ready, ref_escaped, internal_res (and mode), gpu_ms_p95, palette_phase, the target list.
  The STATUS log line adds target, depth, iter, res, gpu_p95 and ref.
- **Loop turnaround and the bounded GPU wait (2026-10-24).** The dive-and-return / minibrot jump itself is cheap (a blit of the
  last fractal frame into `loopTex`, the depth-0 frame, the crossfade pass): on a throw-away player 9 turnarounds in a row stayed
  under 18 ms. The 2026-10-23 21:43 stall (GPU 138 ms, GPU wait 978 ms, encode 62 ms, watchdog restart) was the Mac swapping
  (5 of 6 GB swap in use): the loop textures and orbit buffers sit idle for a minute between loops, the OS paged them out, and the
  turnaround's command buffer paid their page-in. Two fixes: (1) a **Metal residency set** on the render queue keeps every render
  resource resident (macOS 15+; older systems touch the loop textures every frame while a loop is set), and (2) the render tick
  waits at most **2 periods (33 ms) for a frame's GPU job**; past that the last frame is held on the output, both heartbeats stay
  alive and the tick comes back next period (`held_ticks_window/total` in status.json; "GPU busy: … holding the last frame" and a
  "LATE … (held n tick(s))" line). A slow GPU frame can no longer trip the 1 s watchdog. Measurable: one second after every
  turnaround the log says `loop turnaround: max GPU x ms, max tick work y ms, n held tick(s) over its first 60 frames`; LATE lines
  now also show how long after commit the GPU started and the driver's own scheduling time.

| # | Target | What you see |
|---|---|---|
| 1 | SEAHORSE | seahorse valley, Misiurewicz point M24,2 next to the M0 centre: seahorse spirals at every depth (start target) |
| 2 | SPIRAL | seahorse valley, Misiurewicz M24,1: a tight double spiral that turns forever |
| 3 | JULIA | 1/3 limb branch point, Misiurewicz M4,1: a three-armed dendrite that looks like its own Julia set |
| 4 | VOID | deep minibrot (period 55, size 1.7e-27) by the Misiurewicz point M21,4: spirals, a cross, a 16-armed star, then a small copy of the set at depth ~27; black inside it after that |
| 5 | ELEPHANT | elephant valley, Misiurewicz M31,1: rows of elephant trunks curling into one spiral |
| 6 | STAR | 2/5 limb branch point, Misiurewicz M6,1: a five-armed star of stars |
| 7 | SEAMINI | seahorse-valley minibrot (period 201, size 4.8e-16) by SEAHORSE's M24,2: Minibrot loop target, comes round at depth 15.3 |
| 8 | STARMINI | minibrot (period 107, size 1.4e-14) by STAR's M6,1: Minibrot loop target, comes round at depth 13.8 |

A Misiurewicz point repeats its own picture at every depth (scaled by the cycle multiplier and turned), so those
zooms never run out of detail. The centres have 50 significant digits, refined with Newton's method in Python
decimal: `python3 -I tests/refine_targets.py --swift` prints the table in `src/deep.swift`; `--check-orbit bin/oats-m0`
checks the player's double-double parse (error ≤ 3e-33) and first orbit steps against decimal.

**Golden check** (`tests/golden_deep.py`): sets a target and depth (hold, Viridis, 640x360), takes a snapshot and
renders the same view on the CPU in Python decimal with plain z² + c (depth + 18 digits), then compares luma
(correlation) and the black-interior mask. Results 2026-10-21 (PASS = correlation ≥ 0.90 and mask ≥ 0.95):

| Target | 1e3 | 1e10 | 1e20 | 1e26.5 … 1e28 |
|---|---|---|---|---|
| SEAHORSE (160x90) | 0.976 | 0.949 | 0.942 | 1e27 0.962; 1e28 0.931 (64x36) |
| STAR (160x90) | 0.993 | 0.992 | 0.986 | 1e27 0.984 |
| VOID (160x90; deep ones 64x36) | 0.994 | 0.997 | 0.995 | 1e26.5 0.977; 1e27 0.955 (64% interior, mask 0.998) |
| SPIRAL, JULIA, ELEPHANT (64x36) | | | | 1e28 0.967, 0.975, 0.979 |

Mask agreement 1.000 everywhere else. The default run (SEAHORSE and STAR, four depths, 160x90) takes about a minute.
Run it against a test instance next to the live one (it puts the player's state back at the end): start
`arch -x86_64 bin/oats-m0 --name "OATS VIZ Test" --groups oatsbench --osc-port 7001 --no-sacn --fps 5 --log-dir /tmp/t`
(with `NDI_CONFIG_DIR` pointing at `ndi-config`), then `python3 -I tests/golden_deep.py --to 127.0.0.1:7001 --logs /tmp/t`.
That is two NDI senders at once: on 2026-10-21 one NDI send call blocked 1.07 s in both of them at the same moment
on a busy Mac, and the watchdog restarted the live one. Stop the test instance straight after.

**The limit is 1e28 in this version, and why.** The reference centre has about 32 significant digits
(double-double). At 1e28 one 1080p pixel is 1.6e-31 wide, still well above the rounding of the centre (≤ 3e-33)
and of the orbit (~1e-32); somewhere past 1e29–1e30 the reference itself is too coarse and the picture turns
blocky. The float32 differences would last to about 1e-38 (zoom ~1e34) before they underflow. What removes the
limit next: a higher-precision reference (quad-double or arbitrary precision; it is computed once per centre, so
its cost hardly matters) together with extended-exponent differences on the GPU (float + separate exponent) past
1e34; and BLA (bilinear approximation) to skip most iterations, which is what makes 1e100+ zooms run in real time
and would let deep views stay at 1080p.

**Other limits now:** no BLA, so deep views run at 640x360–1280x720 (upscaled) to hold 60 fps; no interior
detection, so a minibrot's inside costs full iterations (VOID's last decade runs at about ×0.1 iterations); a custom `/center` whose orbit escapes early
(far outside the set) is only good at shallow depth.

### Deep zoom card (GUI, 2026-10-23)

A guided flow in the left column. Header: "Deep zoom" plus a live line (`10^4.2 · zooming in · Seahorse · on BG`).
**Quick looks**: look chips with thumbnails (as many as fit), "+N more" opens all of them in a pop-up over the card.
Then five numbered steps as an accordion (one open, remembered in `oatsgui.dzstep`); a closed step shows a one-line
summary, an open one a guide sentence, its controls and "Next: … →".
1. **Shape**: the 8 targets, then the editor for that target: Formula, Twist (kaleido fold), Mirror (twist / fold c),
   Rotation, Iterations (auto at the left, else 100 … 60000), and a tab box Julia (morph, drift, clock) · Orbit trap
   (type, mix, size) · Advanced (bailout, warp, fold c, Julia constant); Reset shape.
2. **Zoom**: depth readout + slider, In / Hold / Out, Speed, Loop, Keep depth; Advanced: Return to, Loop at.
3. **Colour**: palettes, Cycle, Offset, Spread ↔ Tighten.  4. **Movement**: Rotation, Spin, the 3 phasers + presets.
5. **Show on**: Base | L1–L4, Base opacity, and an amber hint when the fractal is not visible anywhere.
The phone's Fractal tab has the same steps (compact).

### Shapes, Branches, Twist modes, places (2026-10-23)

- **Step 1 Shape** = 13 formation tiles with thumbnails (`gui/thumbs/shape/`, depth 0, default palette), then Branches (power
  1.5–6, detents 2–5), Twist (0–12 + Mirror, Clean | Wild), Detail (Auto | Blob 16 | 100…60000) and the tabs Julia (XY pad for c,
  −1.5…1.5, live while dragging; morph, drift, clock) · Orbit trap · Advanced (formula, bailout, warp, fold c + mirror).
  Rotation left the Shape step: the fractal has ONE rotation / spin, in step 4 Movement (in the formula). A layer whose source is
  Fractal (BG included) shows "Fractal turns in Deep zoom → Movement" instead of its own Rotation / Spin, the player ignores a
  fractal layer's transform rotation / spin / rotation beat move, and taking the fractal zeroes them (other transform values stay).
- Framing: Julia morph, Multibrot / a real power and a twist are centred on 0 at depth 0 (sliding to the place by depth 1.5;
  Julia stays centred on 0), so a tile shows the whole formation.
- **Step 2 Zoom** starts with the 8 places as thumbnail tiles (`gui/thumbs/place/`, each zoomed in at depth 6–9 with the
  default shape) and "On select": Keep depth · Dive (on by default).
- Depth limits: Mandelbrot, Ship, Tricorn, Celtic, Flower 3/4/5 and Clean twist 1e28; Julia shapes, a non-integer Branches,
  Wild twist and warp 1e4.5 (status `fractal.formula.note`, GUI orange "deep zoom ≤ 10^4.5").
- Status `fractal.formula`: power, power_polar, shape, shapes, fold_mode, wild_ss; `fractal.dive_on_select`. Scenes, shape memory
  and tools/oats_state.py carry power and fold_mode (older files with a fold ≥ 2 read as Wild, as they looked before).
- Thumbnails: `python3 -I tools/make_look_thumbs.py --only shape,place` (`OATS_THUMBS_BIN` = a new build).

### BG = layer L0 (2026-10-23)

The base layer is a full layer (`Control.layers[4]`, OSC `/oats/layers/0/...`, status `bg` with the layer keys, `n` 0): source
Fractal (default) | Clip | Gen, overlay, 2 filters, motion, beat move, blend (over black), opacity, autopilot, scenes, FX / gen
looks, scripts, audio-react routes (`/oats/audio/route/n/layer 0` or `s BG`) and the PREVIEW `?layer=0`. `/oats/fractal/opacity`
stays an alias of its opacity (owner `fractal.opacity`). One fractal: while it is on L1–L4, BG with source Fractal shows its own
clip (none = black) and says so (status `bg.fractal_note`, `bg.source_shown`); `/oats/fractal/layer 0` (GUI "Base") brings it
home and sets BG's source to Fractal. Composite: 5 layer slots, BG drawn first. DMX: none for BG (the Layer fixtures stay
L1–L4), OSC / GUI only. Scenes stored before this restore BG as a plain fractal base. GUI: the BG row is a normal row (chip BG,
same columns, ✎ opens the dock for L0, all dock tabs work); "Add FX…" is gone. Phone: BG is an editable layer chip.
GPU (throw-away instance at 30 fps next to the live one): layers stage p95 0.74 ms plain → 1.53 ms with a Kaleido filter on BG.

### Animations: one home per control; "0/s is stopped" (2026-10-23, `src/phasers.swift`)

The 3 phaser slots (OSC / status / scenes unchanged) are edited where their control lives: a ∿ next to Depth (Zoom), Spread
and Offset (Colour), Julia morph, Julia orbit (pad), Twist, Warp, Trap size / mix and Detail (Shape), Rotation (Movement).
∿ on takes a free slot ("3 animations max" when none is free) and opens a small editor under the control (shape, rate,
depth, Off); a ghost mark on the slider shows the moving value. The Movement step keeps Rotation, Spin, the Motion presets
and "If stopped: Pause | Run" (`/oats/fractal/1/phaser/free i`, default 0 = Pause, stored in scenes / state).
Pause rule: zoom on HOLD (speed 0, loop off) pauses the zoom breathe, Colour Cycle 0 the spread / offset animations, effect
speed 0 all of them; the offset eases to 0 over 0.3 s and holds there (status `phasers[].paused_by` hold | cycle | speed).
Fix: an OFF phaser now fades out on real time and is exactly 0 after 0.3 s (before, the fade ran on dt × effect speed, so at
effect speed 0 an off phaser kept moving the picture). `oats-m0 --selftest-phasers` checks off / preset off / HOLD / Cycle 0 /
speed 0.

### NDI receivers per peer (2026-10-23, `src/ndiout.swift`)

status `ndi.peers` [{ip, host, conns, seen_s_ago}] and `ndi.peer_count`: the sender process's (the helper's, or the player's in
native mode) established TCP sockets on its NDI listen ports (5960–6199), grouped by remote IP, scanned at 1 Hz with libproc;
a peer counts as gone after 5 s without a connection. 192.168.1.141 (OATS_PC_IP) = "PC (Vision)". GUI pill: "NDI → PC (Vision)"
or "NDI → n receivers" (raw connections only in its helper), "no NDI receiver" after 5 s at 0.

### Activity sweeps (GUI, 2026-10-23)

A 2 px line with a sweeping segment (one sweep = one cycle: beats × BPM or seconds; audio routes 0.8 s) on a closed Deep zoom
step whose control a phaser / fractal audio route moves (×N when several), on the layer row (beat move, audio route, phasers on
the fractal's layer) and on the dock tab (Motion / Filters / Overlay / Content) of the shown layer; a pulsing dot next to the
moved control in an open step. One rAF loop, transform only, paused while away; Motion: Off = a static mark.

### Per-target shape memory (2026-10-23, `src/state.swift` ShapeMemo)

The shape = formula, fold + mirror, fold c + mirror, Julia morph / constant / drift / beat, warp, bailout, orbit trap
(type, mix, size), rotation and the iteration override. With the memory on (default), every target change from
OSC / the GUI / MA3 DMX (Fractal ch 2) saves the live shape under the old target and loads the new target's saved
shape, or the defaults the first time. A preset with a target saves the old shape and applies its own; a scene recall
brings back its own saved shapes. A custom centre keeps the shape. The Dive loop's next / random target does not
switch shapes. status.json `fractal.shape_memory` {TARGET: shape}, `fractal.shape_memory_on`, `fractal.shape_target`,
`fractal.iterations_override`; scenes store `shape_memory`, `shape_memory_on` and `iterations`; tools/oats_state.py
restores the target first, then the saved shapes, then the live shape.

## Formula modifiers + endless zoom (2026-10-22, v0.6)

Everything here is inside the iteration, not a screen filter. status.json: `fractal.formula{}` (name, path, depth_cap,
fold, julia, trap, preset, presets …) and `fractal.loop{mode, running, phase, loops, end_depth, note}`.

**Paths.** The classic Mandelbrot with nothing on uses the golden-checked `mandel_pert` kernel unchanged.
`fractal_pert2` is the perturbation path for every formula plus orbit traps, fold c and the bailout: Burning Ship
and Celtic with the |a + d| − |a| sign cases, Tricorn with the conjugate, Multibrot 3/4/5 with the binomial
expansion; the double-double reference orbit iterates the same formula. So all formulas keep deep zoom to 1e28.
`fractal_direct` iterates the full z in float32 for what has no perturbation form: the **kaleido fold** of z
(z = fold(z), then F(z) + c, N = 2…12, optional mirror), the **Julia morph** (z0 = a·pixel, c = mix(pixel, J, a);
J drifts on a radius-0.04 circle at `/julia/drift`, per beat with `/julia/beat 1`) and the **warp** term (k·sin z).
It is honest to about 1e4.5: the depth is capped at 10^4.5 while any of them is on (GUI note), iterations ≤ 800.
**Fold c** folds c once around the view centre (a coordinate map), so it is deep-zoom safe. **Orbit traps**
(point, circle, line, cross, star) colour by the closest approach of the full z to the shape, blended with the
palette by `/trap/mix`; they also colour the inside of the set.

Tested 2026-10-22: Burning Ship on its real-axis antenna at 1e8 (clean), its hull area is dust (real, checked
against a CPU render). Known limit: Burning Ship / Celtic perturbation can show horizontal glitch streaks in some
places right next to the real axis (no glitch detection yet); move off the axis a little.

**Endless zoom.** `Minibrot loop` (VOID, SEAMINI, STARMINI = nucleus targets, `period` in the target table):
the player computes the minibrot's complex size λ = 1/(b·l²) and its colour offset K (escape counts near it
follow mu ≈ period·mu_full + K, median of 8 samples) once per target, off the render thread. On the way in the
view turns toward −arg λ (linear in depth), the centre shifts by λ·c0 (invisible until the last decade), and in
the last 2 decades the colour bands spread by 1/period around K. At depth −log10|λ| (VOID 26.77, SEAMINI 15.32,
STARMINI 13.85) the frame is the depth-0 view of the same target in shape, turn and colour; the player jumps to
depth 0 (palette phase + K·0.03) and hides the rest with a short crossfade (`/loop/fade` × 0.5, default 1 s) from a
frozen copy of the last frame (a blit of the fractal texture; no second fractal). `Dive & return` (any target):
at `/loop/depth` (default 26; 4.4 on the float32 path) the frame is frozen, the dive restarts at depth 0 (same,
next or random target; with a new target the frozen frame holds until its orbit is ready) and crossfades over
`/loop/fade` (2 s). Both run only while the zoom moves inward (auto-zoom > 0, not the console's depth channel).
Minibrot loop on another target or formula falls back to Dive (status note).

**Looks** (`tools/fractal_presets.json`, GUI Formula > Looks, `/oats/fractal/1/preset s NAME`): Kaleido Bloom 6
(fold 6 + Julia −0.8 + 0.156i, drifting), Burning Cathedral, Tricorn Mirror, Julia Breath, Star Trap, Celtic Knot,
Power 3 Flower, Endless Seahorse loop (SEAMINI minibrot loop at 0.5 dec/s). A preset resets the modifiers to the
classic defaults first; the file is read on every /preset (the GUI list on the next player start).

**DMX (Fractal 24, GDTF v0.6):** ch 1 formula, ch 12–15 Julia constant (0 / 32768 = keep), ch 16 kaleido fold
(+ mirror bands), ch 20 orbit trap, ch 23 Julia morph, ch 24 bands 30–69 the loop. All zero = classic, loop off.
Fold c, warp, bailout, trap mix/size, Julia drift, loop depth/fade are OSC/GUI only. Owner keys `fractal.formula`,
`.fold`, `.julia`, `.juliac`, `.trap`, `.loop` (latest move wins). MA3: import v0.6 as a new type and change
fixture 9002 (Fractal 24) to it; the other fixtures are unchanged. Until then the v0.5 type sends 128/0/128/0
on ch 12–15 (= keep) and 0 on ch 1, 16, 20, 23 (= classic), so nothing changes by itself.

**GUI.** Deep zoom card: Zoom gets a **Loop** row (Off · Minibrot · Dive; Dive adds "Return to" and "Loop at");
a new **Formula** group (Type, Kaleido, Julia, Trap + mix, a toggle strip Mirror · Mirror c · Julia beat · More,
More = Fold c, Julia drift, Warp, Bailout, Trap size; Looks chips). Header **Focus** toggle (default On): while the
editor dock shows a layer, the other layer lines dim slightly (the per-layer Details panels were replaced by the dock
on 2026-10-23, see "GUI"; Motion has **Spin fill** Auto · Lock · Mirror · Off and **Edge** feather + Rect · Oval · Circle). Cards never move on hover. **Sliders** (2026-10-23): click or drag sets the value under the mouse (the thumb
follows the cursor); hold Shift (or Alt) while dragging for 10× finer relative moves, release it to carry on from
there without a jump; double-click resets; arrow keys / Alt + wheel step. Master › Test content: Test card · NDI card ·
Off · Deep · Noise ("· startup" while the startup card waits for input). The Filter / Master FX lists follow the
player's FX list (status `fx_info.types`).

## Scenes (2026-10-22, `src/scenes.swift`, GDTF v0.7)

A **scene** is a full snapshot of the player's look: per layer the source, clip bank / slot, playmode, speed,
transition, generator (all parameters), transform / FX / beat mod, blend, opacity and autopilot; the fractal (target or
custom centre, depth, zoom speed, formula modifiers, loop, palette / cycle / offset, rotation, spin, which layer,
opacity); master FX, the colour link and the effect speed. Blackout, dimmer, test content, freeze and iterations
are not part of a scene.
- **Storage:** `scenes.json` in this folder (8 banks × 16 slots: name, colour, fade, keep depth, layers, the look),
  thumbnails (160×90 JPEG of the output, from the preview server at store time) in `media/.scenes/<bank>-<slot>.jpg`.
  Scene number **n = (bank − 1) × 16 + slot** (1–128); "1.2" = bank 1 slot 2 = scene 2.
- **Recall with a fade** (the scenes thread, 50 Hz, smoothstep): numbers crossfade over the fade time (opacity, speeds,
  generator parameters, transform, FX amounts, colours, palette speed / offset, rotation the short way round, zoom speed,
  Julia / warp / trap mix …). Discrete things switch at the fade start (clip, source, generator type, formula, FX type,
  blend, palette, loop, which layer has the fractal). A layer whose clip changes crossfades through its own clip
  transition, set to the fade time for that change and put back to the scene's transition afterwards. **0 = cut.**
- **Keep depth** (per scene, default on): the recall never moves the zoom depth; a different target lands at the current
  depth. Off: the depth glides to the stored one (same target), or the new target lands at the stored depth.
- **Layers** (per scene, default all): excluded layers are not touched by the recall.
- A recall is a "move" like OSC: it takes every parameter it sets (owners `osc`), and MA3 takes one back when it moves
  that channel. A new recall during a fade starts from wherever the fade is.
- **After a restart** scenes are still there (the file), but the live look starts from defaults as always.

| Address | Args | Action |
|---|---|---|
| `/oats/scene/store` | i n [s name] · i bank i slot [s name] · s "b.s" [s name] | store the current look (keeps the old name / colour / fade / flags when it replaces one) |
| `/oats/scene/go` | i n [f fade] · i bank i slot [f fade] · s "b.s" [f fade] | recall; without a fade: the scene's own |
| `/oats/scene/{n}/go` | – (or f fade; i 0 = release, ignored) | the same, n = 1…128 or b.s (`/oats/scene/1.2/go`) |
| `/oats/scene/next` `/prev` | – | the next / previous stored scene in the current bank (wraps) |
| `/oats/scene/bank` | i 1…8 | current bank (GUI tabs, next / prev) |
| `/oats/scene/delete` | n (as store) | remove it and its thumbnail |
| `/oats/scene/rename` | n s name | |
| `/oats/scene/fade` `/color` `/keepdepth` `/include` | n f seconds 0…60 · n s "#rrggbb" · n i 0\|1 · n i layer mask (1 = L1, 2 = L2, 4 = L3, 8 = L4) | per-scene settings |

From MA3: `SendOSC 1 "/oats/scene/go,i,12"`, or with the fixture: **Master 16 ch 9 = scene number, ch 10 = fade**.
status.json `scene`: current (n, 0 = none), current_label, current_name, bank, fading, progress, fade_s, count, rev (changes
on every store / edit), goes, last_go; `dmx.master.scene`, `scene_goes`, `scene_fade_raw`.

**GUI: the Scenes card** (below Clips): bank tabs 1–8, ◀ ▶ (prev / next), **Fade** (seconds, for scenes you store and
for "Set fade"), **Store** (then click a tile; it asks for a name), 16 tiles with thumbnail, number and name, coloured
by the scene colour. Click = go with the scene's fade; the current scene has a bright outline; a thin bar under the
card title shows the fade. Right-click / long-press a tile: Go (cut), Rename, Set fade, colour, Keep depth, L1–L4,
Store again, Delete. Esc closes the menu / cancels Store. The GUI reads `GET /api/scenes` (scenes.json without the looks)
and `GET /api/scenethumb?n=N`.

**MA3 (GDTF v0.7, same FixtureTypeID):** Master 16 ch 9 "Scene" and ch 10 "Scene fade" (were the reserved Deck and
Master FX 1; nothing else changed). Import v0.7 as a new revision of "OATS VIZ" (as for v0.5/v0.6) and change fixture
9001 to it; until then the old type sends 0 on both = no action. A cue that stores Scene = "Scene 1.12" (+ a fade) recalls
that player scene when it runs, also from a timecode show (below).

## Timecode & ShowKontrol (planned)

Not built yet (the beat / phrase listener is on hold until after the app build). The plan and the research are in
`docs/research/timecode-showkontrol.md` (`~/Developer/oats-viz/docs/research/`). The scene route already works
without new player code: ShowKontrol **Art-Net TC** → MA3 Timecode Slot → one MA3 timecode show per track → its cues set
Master 16 ch 9 (Scene) → the player recalls the scene. The OSC beat / BPM / phrase input (a learn-based mapper for
ShowKontrol / Beat Link Trigger, external tempo source) is the next step; several ShowKontrol details are UNCONFIRMED in
the research doc (whether CLUB can add OSC Out nodes, Art-Net TC options, mood keys) and need the trial.

## Tests (`tests/`, stdlib Python only, run with `python3 -I`)

- `osc_send.py [--to host:port] [--reply 1] ADDRESS [i:1 f:0.3 d:-1 s:deep T F N]`
- `sacn_send.py [--to IP] [--universe 5] [--priority 100] [--name N] [--cid HEX] --values 255,128,0,0,0 [--rate 30] [--duration 5] [--terminate] [--preview]`
- `selftest.py`: the full integration suite against a running `./m0.sh start --test`. Its sACN part was written
  for the M0 map: run it against `./m0.sh start --test --dmx-map m0 --universe 10` (not yet updated for v0). It covers every OSC
  address and type, the sACN rules (band edges, sequence, universe, priority, terminate, debounce, ownership),
  snapshot luma and render-loop gaps, a 22 s fuzz of both ports at 300 packets/s each, and the watchdog
  restart time (from status.json and from a bench receiver's gap). Takes about 5 minutes; `--only osc,sacn`,
  `--skip watchdog`, `--quick`, `--fuzz-secs`, `--fuzz-rate`.
- `golden_deep.py`: the deep-zoom golden check (see "Deep zoom"). `refine_targets.py`: computes and checks the zoom targets.
- `perf.py`: the Part D style runs with the freeze-test PASS rule (≥59.5 fps, ≤0.5% dropped, no send call
  > 100 ms, no sender gap > 200 ms, no receiver gap > 200 ms, 0 timecode gaps), with the bench receiver at full
  or lowest bandwidth: `python3 -I tests/perf.py --phases normal:75,deep:75,noise:60,deep:75:0`.

## Motion + FX (2026-10-22, `src/fx.swift`)

Every clip layer has a **transform** (position, scale, rotation, spin, flip, tile / mirror-tile), **2 FX slots**
(type + amount 0–1 + speed 0–1, 0.5 = default rate, 0 = stopped; speed is also scaled by the master effect speed) and
one **beat mod** (an LFO phase-locked to the player's tempo clock that modulates one target). One **master FX** slot
works on the final output before NDI. FX types (DMX bands of 10 in this order): None, Kaleido, Mirror, Warp, Twist,
Ripple, ZoomBlur, HueSpin, Posterize, Invert, Duotone (the colour-link colour while the link is on, else the layer's
accent), RGBSplit, Pixelate, SliceShift, Strobe, Blur, EdgeGlow, Trails (half-resolution feedback history, allocated the
first time Trails is used), and (2026-10-23, GDTF v0.8, appended so older DMX values keep their meaning) **StarTrails**,
**WarpTrails**, **SpiralTrails** (long exposure, see "Star trails" below). GUI: the editor dock's **Filters** and **Motion** tabs for the selected layer (FX 1 and 2, FX looks, Reset; XY pad,
scale, rotation, spin, flip / mirror / tile, beat move), and **Master FX** in the right column.

Order per pixel: screen-space UV FX (Kaleido, Mirror, Warp, Twist, Ripple, Pixelate, SliceShift) → inverse
transform → tile → sample → multi-tap FX (ZoomBlur, RGBSplit, Blur, EdgeGlow) → colour FX / Trails, in slot order.
Only **one multi-tap FX per layer** runs: if both slots are multi-tap, only slot 1's runs (nesting them multiplied the
cost to 20–40 ms). Position ±1 puts the layer's centre on the frame edge. Rotation + is counter-clockwise; a rotated
layer at scale < ~2 shows the layers below in the corners (tile > 1 is an endless wallpaper and has no corners).
Beat mod: sine peaks on the beat, saw falls from the beat, square is on for the first half, random holds one value per
cycle. Targets: rotation (±180° × depth), scale (× 1 + depth), pos X/Y (± depth), FX 1/2 amount and opacity (dipped
by depth).

GPU: while every layer is neutral, the unchanged `composite` kernel draws (same cost as before). Otherwise
`composite_fx` draws, in one of 16 variants specialised for the FX stages in use (compiled in the background at start,
~1.1 s). Measured 2026-10-22: 2 layers × 2 FX at 60.2 fps, 0 dropped, GPU max 11.6 ms per frame (the fractal stayed at
1920×1080). Kernel cost alone was 1.8–4.9 ms for 2 layers × 2 FX, measured next to the live player.

**Turning without corners (2026-10-23).** Generator layers apply the whole transform (position, scale, rotation /
spin, flip, tile) inside the pattern: each screen pixel is inverse-transformed into the pattern before it is
evaluated, so the pattern fills the frame at any angle (the composite draws gen layers untransformed; the density
cap follows the scale, so a small scale never makes 1-px detail). Fractal layers keep turning in the formula.
Clip layers get **Spin fill** (`/oats/layers/{n}/transform/spinfill s auto|locked|mirror|off`, owner `layer<n>.spinfill`):
**auto** (default) scales up each frame by exactly s(θ) = max((W|cos θ| + H|sin θ|)/W, (W|sin θ| + H|cos θ|)/H) (on top
of Scale, only while the angle shown ≠ 0), **locked** uses the worst case (2.04× at 16:9) all the time it turns (no
pumping), **mirror** mirror-repeats the clip outside its edges (no zoom), **off** = as before (corners show).
**Edge** (`/oats/layers/{n}/edge/feather f 0..1`, `/edge/shape s rect|oval|circle`, owner `layer<n>.edge`): alpha in
layer space, so it follows position, scale and rotation, for clip, gen and fractal layers. feather 0 = hard,
1 = a fade over half the shorter side; rect = the layer frame, oval = the inscribed ellipse, circle = a centred round
porthole (diameter = the shorter side). Presets: Soft frame, Vignette, Porthole. **DMX: none** (Layer FX 24 ch 23 / 24
are the generator speed / thickness and no channel is free): OSC / GUI / scenes only. status.json
`layers[].transform.spinfill`, `.edge{feather, shape}`, `edge_info`. Feedback histories (Trails / StarTrails …) are
freed after ~5 s without a Trails-type FX on that layer.

**OSC** (owner keys `layer<n>.pos|scale|rotation|spin|tile|fx1|fx2|mod|spinfill|edge`, `master.fx`; DMX takes the first eight)

| Address | Args | Action |
|---|---|---|
| `/oats/layers/{n}/transform/x` `/y` | f −1..1 | position |
| `/oats/layers/{n}/transform/scale` | f 0.1..4 | 1 = cover (as before) |
| `/oats/layers/{n}/transform/rotation` | f degrees | wrapped to −180..180 |
| `/oats/layers/{n}/transform/spin` | f −2..2 turns/s | 0 = stop (the angle stays) |
| `/oats/layers/{n}/transform/flipx` `/flipy` `/mirror` | i/f/T/F | flips; mirror = alternate tiles mirrored |
| `/oats/layers/{n}/transform/tile` | f 1..8 | repeats per axis |
| `/oats/layers/{n}/fx/{1,2}/type` | s name (case/spaces ignored) or i 0..20 | FX type |
| `/oats/layers/{n}/fx/{1,2}/amount` `/speed` | f 0..1 | amount; speed (0.5 default rate, 0 stopped, 1 = 8×) |
| `/oats/layers/{n}/mod/target` | s none\|rotation\|scale\|posx\|posy\|fx1\|fx2\|opacity | beat mod target |
| `/oats/layers/{n}/mod/shape` | s sine\|saw\|square\|random | LFO shape |
| `/oats/layers/{n}/mod/beats` | f | beats per cycle, snapped to 1/4, 1/2, 1, 2, 4, 8, 16 |
| `/oats/layers/{n}/mod/depth` | f 0..1 | depth |
| `/oats/layers/{n}/fx/reset` | – | transform, FX and beat mod back to neutral |
| `/oats/layers/{n}/fx/preset` | s name | apply a preset from `tools/fx_presets.json` (re-read every time) |
| `/oats/master/fx/type` `/amount` `/speed` `/reset` | as the layer slots | master FX slot |
| `/oats/master/fx/preset` | s name | a master look from the `"master"` list in `tools/fx_presets.json` (re-read every time); `off` / `none` = reset |

status.json: per layer `transform{}` (with `angle_shown`, `neutral`), `fx[]`, `mod{}` (with the LFO `value`);
`master_fx{}` (with `active`); `fx_info` (type and mod lists, preset names, `master_presets`, which kernel drew); `dmx.layer_fx[]`.

**Star trails (stepped long exposure, 2026-10-23).** StarTrails, WarpTrails and SpiralTrails stack discrete, crisp
copies of the layer, Windows 95 mouse trails / Solitaire cascading cards style, not a smooth smear: the layer's history
is **stamped** on the beat. On a stamp frame it is resampled (bilinear) rotated and / or zoomed around the layer's centre
(its position, so you can move the pole), faded one step, and combined with the new frame by lighten (max, so new
content never dims an old copy); between stamps it is held exactly. The current frame stays full resolution on top,
and the history is full resolution too (2 × 16 MB per layer, allocated the first time one of them is used; Trails keeps
its half-resolution history), so 1–2 px stars stay crisp. Outside the frame the history is mirrored (no tilted 16:9 edge).
No extra pass: one more sample and write per pixel inside `composite_fx` (master: inside `master_fx`).
- **Stamp clock**: beat-synced to the tempo clock (Link / TAP / DMX / OSC BPM, the same beat the phasers and the beat
  mod use): **1/4 beat** by default (124 BPM ≈ 8.3 stamps/s). The subdivision follows the speed so one slider does both:
  gentle spin (|speed − 0.5| < 0.17) = 1/2 beat, medium = 1/4, near the ends (> 0.37) = 1/8; still (0.5 ± 0.02) stamps
  at 1/4 beat (a still trail is still a trail). No tempo known (source "default") = a fixed 8 Hz. status.json slot:
  `stamp_hz`, `stamping` (true while beat-synced).
- **Amount** = trail length: the copies step down in distinct brightness bands and reach ~5 % after 0.15 s × 67^amount
  (0.5 ≈ 1.2 s, 0.8 ≈ 4 s; the fade is applied per stamp, fade^interval, not per frame); **≥ 0.97 = hold forever** (no
  fade at all: every copy stays at full strength until something covers it, Solitaire); 0 = off.
- **Speed**: 0.50 = still (DMX 128; ±0.01 dead band); below = counter-clockwise, above = clockwise, up to ±90°/s at 0 / 1
  in total (per stamp: rate × stamp interval, so the rotation per second is unchanged by the subdivision).
  WarpTrails: above 0.5 = radial steps outward ("hyperspace", up to 2.7× per second), below = inward. SpiralTrails:
  the StarTrails rotation plus an outward zoom (up to 1.8× per second).
- Only one feedback history per layer: if both slots are Trails-family, the first one runs.
- Frozen motion (freeze, effect speed 0) and a hidden layer hold the trail as it is (a stamp after a freeze moves nothing).
- **MA3 (GDTF v0.8, same FixtureTypeID):** only the Layer FX 24 type bands changed (ch 10, 13, 20: 180 StarTrails, 190
  WarpTrails, 200 SpiralTrails, Reserved from 210). Import v0.8 as a new fixture type and change only the Layer FX
  fixtures (9031–9034) to it; the other fixtures can stay on v0.7.

**DMX: mode "Layer FX 24"** (same fixture type, v0.4; v0.8 appended FX types 180 StarTrails, 190 WarpTrails, 200 SpiralTrails). An all-zero block = not patched = ignored. When it is patched,
the defaults are neutral (centre, 1×, upright, spin stop). Continuous channels glide over one packet interval, and
choice channels wait for 2 equal packets. Latest move wins per group (pos, scale, rotation, spin, tile, fx1, fx2, mod,
master.fx).

**Layer FX 24** (24 ch, patch at address 113, 137, 161, 185)

| Ch | Attribute | Function | Default | Values |
|---|---|---|---|---|
| 1–2 | OatsLayerX | Position X | 32768 | 0 Left, 32768 Centre, 32769 Right |
| 3–4 | OatsLayerY | Position Y | 32768 | 0 Up, 32768 Centre, 32769 Down |
| 5 | OatsLayerScale | Scale | 128 | 0 Smaller, 128 1x (cover), 129 Larger |
| 6–7 | OatsLayerRot | Rotation | 32768 | 0 Clockwise, 32768 Upright, 32769 Counter-clockwise |
| 8 | OatsLayerSpin | Spin | 128 | 0 Spin clockwise, 125 Stop, 132 Spin counter-clockwise |
| 9 | OatsLayerTile (snap) | Flip / tile | 0 | bands of 4: index = flip × 15 + tile; tile 0 Normal, 1–7 Tile 2–8, 8–14 Mirror 2–8; flip 0 none, 1 H, 2 V, 3 HV (value = 4 × index; e.g. 4 Tile 2, 36 Mirror 3, 60 Flip H); 240–255 reserved (keep) |
| 10 | OatsFX1Type (snap) | FX 1 type | 0 | 0 None, 10 Kaleido, 20 Mirror, 30 Warp, 40 Twist, 50 Ripple, 60 ZoomBlur, 70 HueSpin, 80 Posterize, 90 Invert, 100 Duotone, 110 RGBSplit, 120 Pixelate, 130 SliceShift, 140 Strobe, 150 Blur, 160 EdgeGlow, 170 Trails, 180 StarTrails, 190 WarpTrails, 200 SpiralTrails, 210 Reserved |
| 11 | OatsFX1Amount | FX 1 amount | 0 | 0 Off, 1 Amount |
| 12 | OatsFX1Speed | FX 1 speed | 128 | 0 Stopped, 1 Slower, 128 Normal, 129 Faster |
| 13 | OatsFX2Type (snap) | FX 2 type | 0 | 0 None, 10 Kaleido, 20 Mirror, 30 Warp, 40 Twist, 50 Ripple, 60 ZoomBlur, 70 HueSpin, 80 Posterize, 90 Invert, 100 Duotone, 110 RGBSplit, 120 Pixelate, 130 SliceShift, 140 Strobe, 150 Blur, 160 EdgeGlow, 170 Trails, 180 StarTrails, 190 WarpTrails, 200 SpiralTrails, 210 Reserved |
| 14 | OatsFX2Amount | FX 2 amount | 0 | 0 Off, 1 Amount |
| 15 | OatsFX2Speed | FX 2 speed | 128 | 0 Stopped, 1 Slower, 128 Normal, 129 Faster |
| 16 | OatsModTarget (snap) | Beat mod target | 0 | 0 None, 10 Rotation, 20 Scale, 30 Position X, 40 Position Y, 50 FX 1 amount, 60 FX 2 amount, 70 Opacity, 80 Reserved |
| 17 | OatsModShape (snap) | Beat mod shape | 0 | 0 Sine, 10 Saw, 20 Square, 30 Random step, 40 Reserved |
| 18 | OatsModRate (snap) | Beat mod rate | 0 | 0 1/4 beat, 10 1/2 beat, 20 1 beat, 30 2 beats, 40 4 beats, 50 8 beats, 60 16 beats, 70 Reserved |
| 19 | OatsModDepth | Beat mod depth | 0 |  |
| 20 | OatsMstFXType (snap) | Master FX type (Layer FX 1 only) | 0 | 0 None, 10 Kaleido, 20 Mirror, 30 Warp, 40 Twist, 50 Ripple, 60 ZoomBlur, 70 HueSpin, 80 Posterize, 90 Invert, 100 Duotone, 110 RGBSplit, 120 Pixelate, 130 SliceShift, 140 Strobe, 150 Blur, 160 EdgeGlow, 170 Trails, 180 StarTrails, 190 WarpTrails, 200 SpiralTrails, 210 Reserved |
| 21 | OatsMstFXAmount | Master FX amount | 0 | 0 Off, 1 Amount |
| 22 | OatsMstFXSpeed | Master FX speed | 128 | 0 Stopped, 1 Slower, 128 Normal, 129 Faster |
| 23 | OatsGenSpeed | generator speed (v0.5) | 0 | 0 Keep (OSC/GUI), 1–124 reverse (−1 … 0), 125–131 Stop, 132–255 forward (0 … +1; 0.5 = 1 period/s) |
| 24 | OatsGenThickness | generator thickness (v0.5) | 0 | 0 Keep (OSC/GUI), 1–255 thin → thick (never below 3 px) |

Scale ch 5: 0–128 = 0.1–1× (log), 128–255 = 1–4× (log). Rotation ch 6–7: −180…+180°. Spin ch 8: 125–131 stop, 132–255
up to +2 turns/s (counter-clockwise), 0–124 down to −2. Speed: 0 stopped, 128 = default, 255 = 8×.

**Presets** (`tools/fx_presets.json`; GUI buttons; `/oats/layers/{n}/fx/preset s <name>`). The DMX values below are for
building the same looks as MA3 presets on a Layer FX 24 fixture (from `python3 -I tools/make_gdtf.py --presets`):

| Preset | Layer FX 24 channels (others at the neutral defaults: ch 1-2/3-4/6-7 32768, ch 5 128, ch 8 128, ch 12/15 128, rest 0) |
|---|---|
| Slow Spin | ch 5 scale = 159, ch 8 spin = 134 |
| Kaleido Bloom | ch 8 spin = 133, ch 10 FX1 type = 10, ch 11 FX1 amount = 140, ch 12 FX1 speed = 102, ch 16 mod target = 20, ch 18 mod rate = 40, ch 19 mod depth = 89 |
| Beat Zoom | ch 16 mod target = 20, ch 17 mod shape = 10, ch 18 mod rate = 20, ch 19 mod depth = 64 |
| Glitch Hit | ch 10 FX1 type = 130, ch 11 FX1 amount = 153, ch 12 FX1 speed = 179, ch 13 FX2 type = 110, ch 14 FX2 amount = 128, ch 15 FX2 speed = 153, ch 16 mod target = 50, ch 17 mod shape = 30, ch 18 mod rate = 10, ch 19 mod depth = 255 |
| Tunnel Twist | ch 5 scale = 152, ch 8 spin = 137, ch 10 FX1 type = 40, ch 11 FX1 amount = 178, ch 13 FX2 type = 60, ch 14 FX2 amount = 128 |
| Mirror Wall | ch 9 flip/tile = 36, ch 16 mod target = 30, ch 18 mod rate = 60, ch 19 mod depth = 76 |
| Strobe 1/4 | ch 16 mod target = 70, ch 17 mod shape = 20, ch 19 mod depth = 255 |
| Trails Smear | ch 10 FX1 type = 170, ch 11 FX1 amount = 204, ch 13 FX2 type = 30, ch 14 FX2 amount = 76, ch 15 FX2 speed = 102 |
| Duotone Match | ch 10 FX1 type = 100, ch 11 FX1 amount = 255 |
| Pixel Drop | ch 10 FX1 type = 120, ch 11 FX1 amount = 153, ch 16 mod target = 50, ch 17 mod shape = 10, ch 18 mod rate = 20, ch 19 mod depth = 255 |
| Ripple Pool | ch 10 FX1 type = 50, ch 11 FX1 amount = 153, ch 13 FX2 type = 70, ch 14 FX2 amount = 51, ch 15 FX2 speed = 77 |
| Wobble | ch 5 scale = 141, ch 10 FX1 type = 30, ch 11 FX1 amount = 102, ch 12 FX1 speed = 153, ch 16 mod target = 10, ch 18 mod rate = 30, ch 19 mod depth = 15 |
| Star Trails | ch 10 FX1 type = 180, ch 11 FX1 amount = 204, ch 12 FX1 speed = 143 |
| Star Trails Fast | ch 10 FX1 type = 180, ch 11 FX1 amount = 178, ch 12 FX1 speed = 204 |
| Reverse Trails | ch 10 FX1 type = 180, ch 11 FX1 amount = 191, ch 12 FX1 speed = 77 |
| Comet Tail | ch 8 spin = 138, ch 10 FX1 type = 180, ch 11 FX1 amount = 153 |
| Warp Speed | ch 10 FX1 type = 190, ch 11 FX1 amount = 153, ch 12 FX1 speed = 217 |
| Hyperspace Jump | ch 10 FX1 type = 190, ch 11 FX1 amount = 178, ch 12 FX1 speed = 242, ch 16 mod target = 20, ch 17 mod shape = 10, ch 18 mod rate = 20, ch 19 mod depth = 102 |
| Vortex Trails | ch 10 FX1 type = 200, ch 11 FX1 amount = 178, ch 12 FX1 speed = 192 |
| Long Exposure | ch 10 FX1 type = 180, ch 11 FX1 amount = 255, ch 12 FX1 speed = 136 |
| Orbit Trails | ch 9 flip/tile = 4, ch 10 FX1 type = 180, ch 11 FX1 amount = 178, ch 12 FX1 speed = 179 |

**Master presets** (`"master"` in `tools/fx_presets.json`; GUI Master FX card buttons, Off = the card's Off button;
`/oats/master/fx/preset s <name>`). On MA3: Layer FX 1 ch 20–22.

| Master preset | Layer FX 1 ch 20 type / ch 21 amount / ch 22 speed |
|---|---|
| Star Trails | 180 StarTrails / 191 / 143 |
| Warp | 190 WarpTrails / 153 / 217 |
| Vortex | 200 SpiralTrails / 166 / 192 |
| Off | 0 / 0 / 128 |

## Layer sources + generators (2026-10-22, `src/gen.swift`)

Every layer 1–4 picks its **source**: **Clip** (the clip library, as before), **Fractal** (the deep-zoom Mandelbrot),
**Gen** (a procedural shape generator) or **NDI** (a sender on the LAN, see "NDI sources", 2026-11-01). Every source goes through the same layer pipeline: opacity, blend mode,
transform, the 2 FX slots, the beat mod and the colour link (the colour target "Clips only" means every layer that is
not the fractal; "Fractal only" follows the fractal to whatever layer it is on). So anything blends with anything.

- **One fractal.** There is one fractal renderer (CPU reference orbit + GPU, on an 8 GB M2). It draws on the layer
  that selected it last (latest move wins). A layer that still says Fractal after another layer took it shows
  nothing until Fractal is selected on it again (status.json `layers[].fractal_note`, GUI note in amber).
  **Layer 0 / base** is the old bottom fractal layer: it shows the fractal only while no layer 1–4 owns it, at its own
  opacity (`/oats/fractal/opacity`, unchanged). DEEP / NOISE test content always stays on the base layer.
  A layer that gives up the fractal (switches to Clip or Gen) sends it back to the base layer.
- **Clips under Fractal / Gen keep playing** (the decoders are not stopped), so switching back to Clip is instant.
  A clip play on a layer (GUI clip grid, `/oats/layers/{n}/play`) switches that layer's source to Clip.
- **Fractal spin.** `/oats/fractal/1/rotation f` (degrees) and `/oats/fractal/1/spin f` (turns/s, ±2, 0 = stop,
  the angle stays; `/oats/fractal/1/spin/reset` = stop + angle back; spin is scaled by the master effect speed) turn the fractal in its own coordinates: the
  perturbation delta coordinates are rotated in the kernel (`mandel_pert`, the same path as DMX ch 21), so there
  are no black corners and deep-zoom precision is unchanged at any depth. DMX: Fractal 24 ch 22 (was "BPM sync
  (reserved)"). When the fractal is on a layer, that layer's own transform spin (Layer FX ch 8) turns it too.
- **Generators** (GPU kernel `generator`, about 0.2–1.4 ms each at 1080p on the M2, rendered only while the layer's
  opacity is above 0, into the layer's own 16 MB texture, premultiplied, transparent background):
  Lines (parallel bars), Angles (chevrons / zigzag), Prisms (triangle grid with facet shading), Circles (concentric
  rings), Dots (grid of discs), Grid (squares; checker above variation 0.5), Polygons (nested n-gons, 3–8 sides),
  Rays (starburst), Spiral (1–6 arms), Waves (sine bands), Tunnel (rings receding), Shapes Burst (shapes expanding,
  one per motion period; with beat sync and speed 0.5, one per beat), and (2026-10-23, GDTF v0.9) **Stars**: a random
  star field in hashed cells (3× count cells, at most 120 per screen height, ~22 % empty), star diameters 2–4 px
  (thickness: bigger), brightness variance = variation, twinkle rate = speed (0 = still), softness = glow, colour A / B
  per star. The looks Star Field Trails, Night Sky Spin and Warp Stars use it.
  Parameters: type, count (density), thickness, softness, speed (−1…1 along the pattern's natural axis, 0 = stop;
  0.5 = 1 period per second, or per beat with beat sync), angle (degrees), variation (per type, 0.5 = the plain look:
  Lines alternate bar width, Angles slope 10–70°, Prisms facet fill, Circles ring spacing, Dots size wave, Grid
  checker fill, Polygons sides 3–8, Rays twist, Spiral arms 1–6, Waves amplitude, Tunnel shape diamond → circle →
  square, Shapes Burst shape circle / 3–8 sides), colour mode white (default) | link (the colour-link colour) |
  accent (the layer's GUI accent) | custom (colour A; colour B = the alternate elements).
- **No fine detail by design.** Density is capped at 48 elements across the frame height, line half-widths never go
  below 1.5 px (lines ≥ 3 px), and radial patterns (Rays, Spiral, Circles, Tunnel) fade out where their spacing drops
  under ~6 px. 1-pixel high-frequency patterns are what triggered the old NDI freeze (native arm64 libndi): don't
  remove these caps.
- **OSC:** `/oats/layers/{n}/source s clip|fractal|gen` (or i 0|1|2); `/oats/fractal/layer i 0..4` (0 = base);
  `/oats/layers/{n}/gen/{type s|i, count f, thickness f, softness f, speed f, angle f, variation f, beatsync i,
  colorA f f f, colorB f f f, colormode s white|link|accent|custom}`. A gen command does not switch the source.
  Owner keys: `layer<n>.source`, `fractal.layer`, `layer<n>.gen.<param>`, `spin`.
- **DMX (GDTF v0.5, same FixtureTypeID):** Layer 16 ch 14 Source, ch 15 Generator type, ch 16 count; Layer FX 24
  ch 23 generator speed, ch 24 thickness; Fractal 24 ch 22 Spin. All-zero = Clip / keep, so a v0.4 patch (these
  channels at 0) behaves exactly as before. Generator variation, softness, angle, beat sync and colours are
  OSC / GUI only for now.
- **status.json:** `layers[].source`, `layers[].gen{}`, `layers[].fractal_here`, `layers[].fractal_note`,
  `fractal.layer` (where it was drawn), `fractal.spin`, `fractal.spin_angle_deg`, `fractal.rotation_set_deg`,
  `fractal_layer.fractal_on`, `gen_info`.
- `oats-m0 --shader-check` compiles the Metal shaders and runs each generator once at 1920x1080 (GPU ms, coverage).

- **MA3:** import the v0.5 file as a NEW fixture type revision (same FixtureTypeID; MA3 shows it as a newer
  revision of "OATS VIZ"), then change the patched fixtures' type to it (or re-patch). Until then the v0.4 patch keeps
  working; the new channels just stay at 0 (= Clip / keep).

### Layer overlay (2026-10-23, `src/gen.swift`)

Shapes over a clip inside ONE layer: every layer 1–4 has an optional **overlay generator** drawn on top of its own
source (clip, fractal or gen) **before** the layer's filters, motion and blend, so FX, edge, opacity and the layer blend
treat clip + overlay as one picture.

- **Params:** on/off, type (any of the 13 generators), count, thickness, softness, speed, angle, variation, colour mode +
  A / B, beat sync (as the generator), **blend** add | screen | multiply | alpha | difference (W3C separable blend over
  the layer's premultiplied picture: where the source is transparent the overlay shows on its own), **opacity** 0..1.
- **Follow** (default): the overlay uses the layer's in-pattern transform (position, scale, rotation / spin, flip,
  tile, edge), so it turns with the layer without corners. **Fixed**: screen space, no transform, no edge.
- **Cost:** Gen source: evaluated inline in the same generator pass (one more pattern per pixel, no extra texture).
  Clip / fractal source: one generator pass into the layer's generator texture (allocated once, 16 MB) + one texture
  read in the composite. Off, opacity 0, a test card or a layer that draws nothing = no work at all. Measured on the M2
  at 1080p: `--shader-check` Lines 0.30 ms, Lines + overlay Rays inline 0.75 ms; a clip layer + overlay Rays
  screen 0.6: `render.stages.layers` 0.67 → 1.41 ms (p95).
- **OSC:** `/oats/layers/{n}/overlay/{on i, type s|i, opacity f, blend s, follow i, count f, thickness f, softness f,
  speed f, angle f, variation f, beatsync i, colormode s, colorA f f f, colorB f f f}` and `/oats/layers/{n}/overlay/look
  s NAME` (a look from `tools/gen_presets.json`: its generator params become the overlay; the look's blend / FX / opacity
  are not used; the file is re-read every time). Owner key `layer<n>.overlay`.
- **status.json:** `layers[].overlay{on, type, type_index, blend, opacity, follow, look, drawn, …gen params}`,
  `gen_info.overlay_blends`. **Scenes** store and recall it (on / type / blend / follow switch at the fade start, the
  numbers crossfade, an overlay switching on or off fades its opacity; scenes stored before it switch it off).
  `tools/oats_state.py` saves / restores it. **Audio react:** target `overlay_opacity` ("Overlay" in the GUI, + to
  the overlay opacity).
- **No DMX** for now: the Layer 16 / Layer FX 24 modes have no free channels. OSC / GUI / scenes only.
- **GUI:** desktop dock tab **Overlay** (see the dock above); phone Play tab: an Overlay card (On, pattern, opacity).

## NDI sources (2026-11-01, `src/ndiin.swift`)

Any NDI sender on the LAN (the camera senders "OBS.HOST (OBSBOT Cam)" / "OBS.HOST (Link Cam)" from oats-cam, another
Mac, djay, ...) can be the source of any layer 0–4 and goes through the full layer pipeline: opacity, blend, transform,
the 2 FX slots, beat mod, colour link ("Clips only" includes NDI layers), fit / cover (mapping layer_fit), overlay, scenes.
So a camera can be kaleido'd, tiled, strobed, blended under the fractal.

- **Where it runs:** receive is **native, in the player process** (arm64 libndi, dlopen, like the NDI audio receive): the
  known 6.3.2 arm64 freeze is on *send* of fine detail, and receive has run natively since the audio react. One supervisor
  thread (finder + bookkeeping, 4×/s) and one capture thread per receiver; **at most 4 receivers**, a source used on two
  layers shares one. Each frame is received as BGRA (BGRX = opaque: a swizzle view sets alpha 1), copied into an
  IOSurface-backed CVPixelBuffer from a small pool and turned into a Metal texture; the render thread only takes the newest
  one under a lock (never waits) and the command buffer holds it until the GPU is done. Nothing for 2 s = **black + a
  note** (status `layers[].ndi.note`, GUI note in amber). Audio is ignored. A capture call stuck > 2 s or a capture error
  drops that receiver and reconnects. The watchdog does not watch these threads; a frozen receive can only cost that
  layer's picture, never a render or HDMI frame.
- **Pick a source:** GUI dock > Content > Source **NDI** > the picker chips (green dot = live, the number = its DMX slot;
  dim = gone or pinned but not visible) + Bandwidth Full / Proxy. OSC `/oats/layers/{n}/ndi s NAME` (the full NDI name
  or a unique part, case-insensitive: "OBSBOT"; exact name wins, then the name in brackets, then any match; also
  selects source ndi), `/oats/layers/{n}/ndi/bandwidth s full|proxy` (proxy = NDI's preview stream, ~640×360, a fraction
  of the CPU), `/oats/layers/{n}/source s ndi`, `/oats/ndi/sources` (logs the list). Owner keys `layer<n>.ndi`,
  `layer<n>.source`. The layer row chip reads "NDI · OBSBOT Cam".
- **The player's own sender is never offered** (names ending in "(OATS VIZ Program)", i.e. `--name`): it cannot feed
  itself. Other local senders (oats-cam, oats-screen) are listed.
- **DMX (GDTF v0.10, same FixtureTypeID):** Layer 16 ch 14 Source = **30–39 NDI**; with it, **ch 3 Slot picks slot n**
  of the stable source list (slot 0 = none = black). The list is in status.json `ndi_sources[]` `{slot, name, short,
  url, age_s, live, pinned, layers}`: **alphabetical by NDI name** (case-insensitive, the full "MACHINE (name)" string),
  numbered from 1. `oats-m0/ndi_order.json` **pins names to slots** so MA3 presets stay valid ("slot 1 = Link Cam,
  slot 2 = OBSBOT Cam") whatever appears: a list `["Link Cam", "OBSBOT Cam"]` = slots 1, 2, ...; or an object
  `{"1": "Link Cam", "3": "OBSBOT"}` (slot number -> a part of the name, case-insensitive). Pinned names keep their slot
  even while not visible (shown dim, `live false`), the other sources fill the free slots A–Z. Re-read when the file
  changes (status `ndi_in.order_pins`, `order_error`). The clip bank/slot still play their clip underneath (hidden), as
  under Fractal / Gen; a slot without a clip logs "not in the library" and is harmless. The chosen NDI name (not the slot)
  is what the layer remembers, so a list change does not switch a running camera.
- **MA3:** import the v0.10 file (`~/MALightingTechnology/gma3_library/fixturetypes/OATS@OATS VIZ.gdtf` on this Mac; copy
  to `C:\ProgramData\MALightingTechnology\gma3_library\fixturetypes\` on the PC) as a new revision of "OATS VIZ" and
  change the Layer fixtures' type to it; until then the old type still sends 30–39 on ch 14 as a raw value and it works.
- **status.json:** `layers[].ndi {name, source, short, bandwidth, connected, fps, width, height, age_ms, dropped, frames,
  shown_age_ms, note}`, `ndi_sources[]`, `ndi_in {lib, receivers[], order_*}`. `dropped` = frames that arrived while
  the previous one was never shown (a 30 fps source on a 60 fps render drops none; a 60 fps source on a busy frame can)
  plus frames skipped because the GPU still held every pool buffer.
- **Scenes** store the NDI name + bandwidth; `tools/oats_state.py` saves / restores them.
- **Measured (2026-11-01, M2, OBSBOT Cam = 3840×2160 BGRX 30 fps, full bandwidth, on layer 2 at 80 % with Kaleido 0.5
  over the fractal, 6 s):** render 59.98–59.99 fps, 0 late frames, GPU stages p95 8.4–8.6 ms (layers stage 2.0–2.1 ms,
  was 0.7 without the camera), NDI 29.5–30.5 fps, dropped 1 (the first frame), CPU 40–60 % of one core (libndi's 4K
  decode + a 33 MB copy per frame). **Added latency** receive-thread -> render tick (`shown_age_ms`): 4.6–8.3 ms average,
  16.5 ms max, plus up to one 16.7 ms render frame and the display: well under the 100 ms target on our side; NDI's own
  encode / network / decode is on top (typically 1–2 frames of the sender). A 1080p sender costs a quarter of that copy.
- **Limits:** 4 receivers; BGRA only (libndi converts; interlaced sources are deinterlaced by the SDK); no audio; no
  alpha from BGRX senders (BGRA senders keep theirs); proxy bandwidth is OSC / GUI only (no DMX channel); the finder
  only sees what libndi sees on this Mac's interfaces (with the NDI_CONFIG_DIR pin that was en0 + local senders here).

## Known limits

- **Ableton Link**: the bar lock is slewed, not snapped (up to ~4 s after djay appears). Link carries no downbeat
  meaning beyond quantum 4: if djay's bar is off, fix it in djay. A crashed peer (not a clean quit) can keep peers ≥ 1
  for a few seconds until Link times it out.
- **A restart starts from defaults.** `python3 -I tools/oats_state.py save FILE` before and `… restore FILE` after puts the
  OSC / GUI-owned look back (what MA3 owned comes back from the console; blackout and test content are never touched).
  After `m0.sh restart` or a watchdog restart, everything set over OSC is gone (blackout off, dimmer 1, palette 1, content normal, target SEAHORSE at depth 0, zoom hold, iterations and resolution auto). DMX values come back with MA3's next packet. Re-fire your OSC macros after Part E's restart.
- **Latest move wins, per parameter.** With MA3's sACN row enabled, the GUI and the Part D OSC macros work at once; a parameter goes back to the console only when the console moves its channel (see "Ownership"). If the console's value hasn't changed, it won't take the parameter back: move the fader / change the preset to retake it. The held DMX values stay after a loss: put the Master dimmer at full and auto-zoom at Stop before you disable the row, or the picture stays dark or keeps zooming (until the GUI changes them).

- One x86_64 process, as tested in the bench; the native renderer + NDI helper split is M1. A watchdog stall
  restarts the whole process, so the picture is gone for a few seconds (restart + sender creation + discovery).
- The first start after every `./m0.sh build` takes 8–15 s (Rosetta translation + NDI start-up), against about
  2.5 s warm. Do one throw-away start/stop after building, before timing anything. An OS update or reboot can
  bring the slow start back.
- The watchdog runs from the moment the log opens: a stall over 1 s, or no frame sent 30 s after start (a hung
  NDI or Metal init), exits 75 and the loop restarts it. A SIGTERM shutdown that hangs in NDI teardown exits 75
  after 4.5 s.
- **sACN unicast and other programs on UDP 5568:** oats-m0 shares the port (SO_REUSEPORT), but macOS hands each
  unicast packet to only one of the programs bound to it (on this Mac, macOS 27.2, the one that bound first got
  all of them). If anything else on this Mac listens on 5568 (sACNView, MA3 onPC, a second oats-m0), oats-m0 can
  lose MA3's DMX and hold the last look. Check with `lsof -nP -iUDP:5568` (`m0.sh status` does and warns). A
  second oats-m0 stops at its OSC bind (exit 78) before it touches 5568 or announces an NDI source.
- Deep zoom stops at 1e28 (double-double reference, see "Deep zoom"). DEEP (the bench content, plain float32)
  shows float32 blockiness at its deepest, as in the bench.
- sACN: one universe, no HTP merge, no universe sync (a sync address is logged and ignored), no Art-Net.
  OSC: no `?` queries, no relative `+ - *`, and no address-pattern wildcards (`* ? [] {}`): addresses must
  match exactly; only `/oats/fractal/1`.
- **The adapter pin does not work (measured 2026-10-21, `logs/pincheck-run.txt`).** libndi 6.3.2 does read
  `NDI_CONFIG_DIR` (the `machinename` probe "OATSPIN" showed up in dns-sd), but `adapters.allowed` = a bogus
  10.255.255.1, in the array form and in the string form, changed nothing that can be seen from this Mac: the source
  was still announced on en0 (dns-sd interface 6, SRV `OBSHOST.local.:5962`, TXT `groups=oatsbench discovery=5960`),
  its TCP ports listen on all interfaces (`*:5960`, `*:5962`) and en0's address accepts connections on 5960. So
  NDI is announced on every interface (cable and building Wi-Fi), which you chose. **Never join the Netgear Wi-Fi from the Mac:** two links on 192.168.1.x send NDI over Wi-Fi. Whether the
  setting changes what a remote receiver gets needs a check from the PC (Part A). The bench receiver also queries
  127.0.0.1 directly, so its frames never test the pin.
- **The `ndi-meta` thread may cause the rare long send calls (not proven).** Part D style DEEP runs on 2026-10-21
  at full bandwidth: with the thread, 3 of 4 runs FAILED on one send call each (227, 107 and 222 ms, the last one
  started at load 10.3); with `--no-ndi-meta`, 4 of 4 PASSED (longest call 7.7-36 ms) (`logs/perf-partD1*.txt`).
  Four runs each, on a busy Mac, is suggestive only. For Parts D and E, consider `./m0.sh start --no-ndi-meta`
  (no receiver metadata in the log then; the connection count is still logged).
- The adapter config is written when the program starts. If en0's address changes while it runs, restart it
  (`m0.sh status` shows `NDI PIN MISMATCH`), even though the pin itself had no measurable effect (above).
- Logs aren't rotated (about 5 MB a day). The disk is tight: delete old `logs/*.log` after test runs.
- Single process, single NDI source: run only one oats-m0 or ndi-bench sender at a time.

## M2a: clip layers (2026-10-21)

4 clip layers over the fractal layer, Resolume-style (src/layers.swift, `composite` kernel in src/shaders.swift).

- Library: `~/Developer/oats-viz/media/library.json` (bank 1 = MIXKIT, bank 2 = TUNNEL; copies of the NAS files),
  built by `tools/make_library.swift` from `media/.catalog-rows.json`. `--media DIR` overrides the folder.
- Decode: AVQueuePlayer + AVPlayerLooper (loop) or a single item (once + hold), AVPlayerItemVideoOutput BGRA via
  CVMetalTextureCache, frame picked for the tick's display host time; no new frame = last frame kept. Audio muted.
- Scaling: cover (fill 1920x1080, crop overflow); portrait clips are covered too (PLAN 8 said fit: changed on purpose).
- Composite: fractal x `/oats/fractal/opacity` over black, then layers 1..4 bottom-up, W3C blend formulas in display
  space into an rgba16Float canvas; then master dimmer / blackout / freeze (to_uyvy) as before. Freeze holds clip frames.
- A clip change crossfades A -> B over the layer's transition time once B has its first frame (preroll); clear
  fades out the same way. Governor unchanged: it sees the whole command buffer's GPU time, so it lowers the
  fractal's internal resolution first. Fractal opacity 0 skips the fractal kernels.
- OSC: `/oats/layers/{n}/play i bank i slot`, `/clear`, `/opacity f`, `/blend s|i` (Alpha Add Screen Multiply
  Difference Lighten Darken Overlay, or 1..8), `/speed f` (0..4), `/transition f` (s, 0..10), `/playmode s`
  (loop|once); `/oats/fractal/opacity f`; Resolume aliases `/composition/layers/{n}/clips/{c}/connect [i 1]`
  (layer's current bank), `/composition/layers/{n}/video/opacity f`, `/composition/layers/{n}/clear`.
  Owner keys in status.json `owners`: `layer<n>.clip|opacity|blend|speed|transition|playmode`, `fractal.opacity`.
- status.json: `layers[]` (n, bank, slot, name, opacity, blend, playing, position, fps_decoded, transition, fade,
  decoders, preroll_ms, ...), `fractal_layer`, `library`. GUI: layer strip + clip grid (`GET /api/library`).
- DMX: one "Layer 16" fixture per layer at 41/57/73/89 (see "MA3 fixture", GDTF revision v0.3).

## Clip playback tools (2026-10-22, `src/playback.swift`)

- **Next / previous / random** per layer (OSC `/oats/layers/{n}/next|prev|random`, DMX Layer ch 10, GUI ◀ ▶ 🔀): within
  the layer's current bank, in slot order (wrapping; slots may have gaps), with the layer's transition.
- **Autopilot** per layer (OSC `/autopilot s off|order|shuffle`, `/autopilot/every f`, `/autopilot/beats f`; DMX Layer
  ch 11–13; GUI selector): order = next, shuffle = random without repeats until every slot of the bank has played.
  Any clip change (GUI, OSC, DMX, autopilot) restarts the wait. A freeze stops it. status.json `autopilot[]`
  (mode, every_s, beats, next_in_s, changes, shuffle_left) and `layers[].autopilot*`.
- **Tempo clock**: **Ableton Link** first (djay, see below) while a session is present, else BPM from Master ch 2–3,
  else the tap BPM (Master ch 4, OSC `/oats/tempo/tap`, GUI TAP), else `/oats/tempo/bpm`; 120 when none is given. Resync
  (Master ch 5, `/oats/tempo/resync`) = beat 1 now (ignored while Link leads: Link sets the bar). status.json `tempo`
  (bpm, source default|set|tap|link|link-held, beat, phase = beat mod 4, bar_beat 1–4, setting, peers, playing,
  link_age_ms, link{…}, forward{…}, taps). The playback thread runs at 50 Hz.

## Ableton Link / djay (2026-10-22, `../link-helper`, `src/playback.swift`)

djay Pro's only tempo output is Ableton Link. **In djay: Preferences > Ableton Link > enable Link first, and keep
Sync on.** The GUI's **LINK** chip (header, next to BPM) turns green with the peer count when Link leads; the BPM label
reads LINK and the 4 bar dots follow djay's bar (static dots, switched once per beat). Click the chip: auto ↔ DMX/tap.

- **Helper** `bin/oats-link` (native arm64, source `../link-helper/oats_link.cpp`, build `../link-helper/build.sh`,
  SDK `../third_party/link`, official clone with submodules). It joins Link (start/stop sync on, follow only), samples
  `captureAppSessionState()` at 100 Hz and sends `/oats/tempo/link f bpm, d beat, f phase (quantum 4), i peers,
  i playing` to 127.0.0.1:7000 at ~50 Hz plus on every tempo change. `--set-tempo-from-osc` (off) also listens on
  127.0.0.1:7010 for `/oats/link/tempo f`. `--test-peer 128 [--secs N]` = a smoke-test peer that joins at 128 BPM.
  `m0.sh start` starts it (when `bin/oats-link` exists) in its own restart loop (restart 1 s after it dies);
  `m0.sh stop` stops it; `m0.sh link start|stop|restart|status`; log `logs/oats-link.log`. Exits cleanly on SIGTERM.
- **Player**: Link counts when a message is < 1 s old and peers ≥ 1 (the helper itself is not a peer). A PLL bends the
  clock rate (max ±25 %, ~1 s time constant) until beat mod 4 matches Link's beat, so phase 0 of quantum 4 = bar
  start = beat 1; beat mod, autopilot beats, generator beat sync, Shapes Burst, scripts and strobes then land on
  djay's beats. No jumps and the beat never runs backwards: a bar off by 2 beats takes ~3–4 s to lock. When Link goes
  stale (djay quits / Link off: 1 s) the clock carries on from where it is at the DMX/tap/OSC BPM, or, if none is given,
  at Link's last BPM (source `link-held`).
- **MA3 forward** (off): `/oats/tempo/forward s 192.168.1.141:<port>` sends `/cmd "Master 3.1 At BPM 128.0"` while Link
  leads. MA3 needs OSC input enabled (Menu > In & Out > OSC: a line with Receive + Receive Command on, that port, no
  prefix); the port is yours to choose. Don't drive the same speed master from MA3's DMX BPM back to the player.
- **djay quirks**: Link may hold the old tempo on a track change (keep Sync on; nudge/re-sync in djay). A peer that
  joins an existing session adopts the session's tempo: if the helper's session is up first, djay may jump to the
  session tempo when you enable Link; press Sync / give the tempo in djay once and the player follows.
- **Licence**: the Ableton Link SDK is **GPL-2.0-or-later**, or Ableton's proprietary licence on request
  (link-devs@ableton.com). It stays in the separate helper, which is GPL-2.0-or-later with its source in
  `../link-helper`; the player only receives OSC from it. Selling VJ VIZZIES later needs either Ableton's licence or
  keeping the helper separate and shipped as GPL with its source.
- **Columns** (Resolume-like): column c = slot c on every layer whose current bank has a slot c (OSC
  `/oats/column/{c}/go`, `/composition/columns/{c}/connect i 1`, DMX Master ch 8, the GUI column row).

## Clip bins in the GUI (bank / slot numbering)

- The bank tabs are the library's banks, the cells are its slots: **bank B, slot S in the GUI = DMX Layer ch 2 = B,
  ch 3 = S = OSC `/oats/layers/{n}/play i B i S`**, and column c = slot c. Moving a clip in the GUI changes its slot
  number, so cues that use slot numbers play whatever is in that slot now. The GDTF slot names come from bank 1 at
  the time `make_gdtf.py` ran: re-run it (new REVISION) after reorganising bank 1 if MA3's names should match.
- "+" adds a bank (next free number, folder `media/bank<N>-<NAME>/`); double-click a tab to rename it.
- Drop files from Finder onto a cell (that slot; a taken slot's clip moves to the first free one), onto the empty
  area or a tab (first free slot). `.mov .mp4 .m4v` are stored as they are; `.png .jpg` become a 10 s H.264 loop
  (ffmpeg). Uploads stream to disk (`POST /api/upload`, at most 4 GB, safe file names, never outside `media/`), then
  ffprobe fills duration / fps / size, ffmpeg makes a thumbnail (`media/.thumbs/`), library.json is rewritten and the
  player reloads it (`/oats/library/reload`, no restart).
- Drag a cell onto another cell (or another bank's tab) to move / swap. ✕ or right-click removes it **from the bin
  only**: the file stays on disk. Clicking a cell plays it on the selected layer (its chip / ✎ Edit, or keys 1–4); the dock's Content tab (Clip source) also lists a bank's clips for that layer.
- Same access rules as the rest of the GUI (allowed networks, optional PIN, same-origin POST).

## VJ → lights (planned; analysis built, MA3 side not yet)

**Built (cheap):** every 6th frame the composite canvas (× dimmer) is box-filtered on the GPU to 64×36; a small
k-means (k = 3) on a utility queue gives 3 dominant colours with their share of the frame, about 10 Hz, well under
1 ms. status.json `analysis` (colors, hex, weights, hz, osc_out). OSC out is **off by default**:
`/oats/analysis/out s "192.168.1.141:8000"` or `--analysis-out host:port` sends `/oats/analysis/colors` (9 floats,
r g b × 3, heaviest first, 0..1) and `/oats/analysis/weights` (3 floats). The GUI shows them as a bar.

**Plan (from the local MA3 2.3.2 manual):**
1. **Recommended: OSC to faders.** MA3 Menu > In & Out > OSC: a line with Enable Input, Receive = Yes and the
   PC's port (e.g. 8000; a line uses one port for send and receive, so add a second line next to the existing
   one); no bundles (the player sends single messages). The player would send `/Page1/Fader201,f,<0..100>` etc.
   (percent): three executors per colour hold "full red / green / blue" sequences on the wash group (HTP or Temp
   fader), so the output colour = the mix; one triple for colour 1 is enough to start. The show programming stays in
   control (masters, priorities, Clear). To do: a small mapping in the player (`--analysis-faders page:fader,…`) and
   the MA3 executors.
2. **Alternative, smooth and direct: sACN in.** Menu > DMX Protocols > sACN: Enable Input, a row Input Unicast,
   e.g. sACN universe 10 → local universe 10, Merge Mode Prio (level Super/High) or HTP. Either onto the fixtures'
   own universe (the player must know their RGB addresses; bypasses the programmer) or onto a spare universe read by
   **DMX Remotes** (Menu > In & Out > DMX Remotes: address → executor fader, In/Out ranges), same executors as 1.
   onPC needs an unlocked parameter count for DMX in/out (it already outputs universe 5, so it has one).
3. **Not for streaming:** `/cmd,s,Fixture … Attribute "ColorRGB_R" At …` works (Receive Command = Yes) but writes the
   programmer and the command history 10 times a second; keep `/cmd` for occasional cue / preset triggers. Lua
   (`GetDMXValue` + `Timer`) could read an input universe, but the manual documents no Lua socket/OSC listener.
Avoid feedback: don't link the same group both ways (Color 8 → video → analysis → those lights) without a damping
amount.

**sACN port sharing (fixed 2026-10-22):** grandMA3 onPC on this Mac also listens on *:5568, and macOS gives each unicast packet to only one wildcard socket. The player now binds sACN to en0's own address (e.g. 192.168.1.148:5568), which always wins for unicast, so MA3 onPC can start before or after the player. With `--sacn-multicast-if` it binds 0.0.0.0 instead (multicast needs that). Since 2026-10-23 there is no 0.0.0.0 fallback: with no en0 address the receiver retries en0 every 5 s (logged). OSC 7000 is bound the same way (127.0.0.1 + en0, re-bound when en0 changes; status.json `listen` lists the addresses), the per-message OSC log is limited to 20 lines/s ("N OSC messages not logged"), the player log rotates at 50 MB (3 kept, files 0600, logs/ 0700), and `/oats/tempo/forward` / `/oats/analysis/out` accept only lighting-network or 127.x destinations. Local test senders must now target 192.168.1.148, not 127.0.0.1.

## Generator looks and scripts

`tools/gen_presets.json` holds 27 generator **looks** (generator params plus an optional FX preset, blend and opacity) and 5 beat **scripts** (Geometry Tour, Build Up, Drop Hits, Chill Drift, Tunnel Ride). Edit the file freely; it is read on every command, so no restart is needed. `tools/oats_script.py` runs them over OSC:

```bash
python3 -I tools/oats_script.py list
python3 -I tools/oats_script.py look "Ring Pulse" --layer 2
python3 -I tools/oats_script.py run "Geometry Tour" --layer 2
python3 -I tools/oats_script.py stop --layer 2
```

Star looks (2026-10-23): **Star Field Trails** (small sparse Dots + Star Trails), **Night Sky Spin** (denser Dots + Long
Exposure), **Warp Stars** (Dots + Warp Speed), **Ring Trails** (Circles, tiled 2×2, + Orbit Trails: the ring centres orbit the
frame centre), **Ray Vortex** (Rays + Vortex Trails). Dots is a regular offset grid, so the trails are evenly spaced arcs
(a stylised sky, not random stars).

A script holds each step for N beats at the player's BPM (MA3, tap or OSC tempo; re-read every step) and runs one per layer: starting a new one on a layer replaces the old one. The GUI has buttons for both (dock > Looks).

**Lit indicators (2026-10-24).** The player remembers which look stands on each layer and reports it in status.json: `layers[].fx_look` (FX look, `/fx/preset`), `layers[].gen_look` (gen look: the GUI server sends `/oats/layers/N/gen/look s NAME` after the look's params; the address only records the name), `fractal.look` (= `formula.preset`); scenes store and recall the names, so a recalled scene lights its looks. All three GUI pages glow the matching look / preset button (desktop Filters + Looks tabs, Deep zoom quick looks; phone Looks and Fractal pages; iPad remote grid cells and layer tiles), like the master FX presets.
A look is "on" only while its values stand: changing by hand (OSC, GUI or DMX) a slot type / amount / speed clears `fx_look`, a gen type / param clears `gen_look`, a fractal modifier clears `fractal.look`; `/fx/reset` clears the FX look too (Reset glows while the layer is neutral). Self-test section 26 (`--selftest-dmx`) covers apply → clear by hand → back from a scene.

## NDI modes + frame budget (2026-10-23, `src/ndiring.swift`, `src/ndiout.swift`, `src/ndihelper.swift`)

The player is native arm64. The render thread never calls NDI: each frame is copied on the GPU into a free slot of a POSIX
shared-memory ring (`/oatsndi.<OSC port>`, 3 slots of 1920×1080 UYVY), published with one atomic store and a `sem_post`. A sender
that falls behind costs dropped NDI frames (status `ndi.dropped`), never a render or HDMI frame. Modes (`--ndi`, OSC `/oats/ndi/mode s`):

| Mode | Who sends | Notes |
|---|---|---|
| `helper` | `bin/oats-ndi` (x86_64, libndi 6.3.2 under Rosetta) | freeze-free 1080p; name, groups, adapters pin (NDI_CONFIG_DIR), metadata in the helper. m0.sh (and the app) restart it 1 s after it dies; the player kills it (SIGKILL) when one send call or its heartbeat is stuck 3 s. It keeps its sender through a player restart (15 s) |
| `native` | a thread in the player (arm64 libndi) | 6.3.2 arm64 still freezes ~4–5 s at a time on 1-pixel detail (NDI only: measured on 2026-10-23 with the renderer at 60.0 fps, max frame gap 17.7 ms) |
| `native-soft` | native + a soft NDI copy | `--ndi-soft half` (default: 960×540) or `blur` (3×3 at 1080p); HDMI and preview untouched |
| `auto` (default) | helper if Rosetta is installed, else native-soft | |
| `off` | nobody | HDMI only |

Quick freeze check (2026-10-23, `ndi-bench` with the new `--soft off|blur|half`, 20 s each, 6.3.2 arm64 async UYVY, results in
`../ndi-bench/out/results.jsonl` tags `S_*`): plain native froze on DEEP (23 fps, calls 4.2 s) and NOISE (0.7 fps); **half** passed
DEEP and NOISE (59.99 fps, max call 0.4 / 17.7 ms, no receiver stalls); **blur** passed DEEP and did not freeze on NOISE (max call 28 ms,
no receiver stalls; 58.7 fps under a load of 10 from another program). In the player: native-soft on DEEP content 20 s at 59.8 fps
received, no gaps. A short check, not a soak.

The watchdog now only watches the render thread (exit 75 when it is stuck > 1 s); NDI stalls are alarms (`ALARM NDI …`).

**NDI quality (2026-10-23, `--ndi-quality previs|full`, OSC `/oats/ndi/quality s`, GUI Output row Previs / Full).** The show is
HDMI; NDI is only Vision previs. **previs** (default): the frame is box-filtered 2×2 on the GPU into the ring (960×540 UYVY) on every
2nd frame only, and the NDI frame rate is 30/1 (half the output rate). **full**: 1920×1080 at the output rate, as before (native-soft
keeps its own soft pass). Either way, while the sender reports **no connection** (`NDIlib_send_get_no_connections` = 0, polled 2×/s)
nothing is copied or sent except one keep-alive frame a second. status.json `ndi.quality`, `ndi.send_format`, `ndi.idle`,
`ndi.skipped_no_receiver`, `ndi.skipped_previs`; top level `ndi_quality`; the STATUS line `ndi_quality=`. Measured 2026-10-23 (helper,
3–4 receivers incl. Vision at Low bandwidth, 20 s each): helper CPU 46.7 % (full) -> 21.9 % (previs); no helper send call over 50 ms
since (before: one every 20–60 s).

The 2060 ms send call (helper log 04:15:53, 2026-10-23): it was inside a 2-minute burst (04:14:54–04:16:50) where every process was
starved: the render thread woke up to 440 ms late, snapshot PNG writes took 7–17 s (normally 0.2 s), while a local tool fired
`/oats/system/snapshot` every 1–3 s and a background Whisper transcription batch ran at ~400 % CPU. NDI connections stayed at 3 the
whole time (no receiver joining or leaving). Not an NDI problem; the 3 s helper kill stays as the safety net.

**Frame budget:** one constant, 15.2 ms (`--frame-budget-ms`, status `budget_ms`). The governor trips when the frame's GPU p95 goes over
the budget (it was 12 ms) and settles back inside it (goal 0.6×, step up only while predicted ≤ 0.7×, low 0.4×, panic 1.65×). The render
loop counts a **late frame** when the frame's GPU time or the tick's own work (wake-up delay + GPU wait + encode) passes the budget
(status `late_frames_window` / `late_frames_total`, a `LATE frame` log line at most once a second).

## Fractal phasers (2026-10-23, `src/phasers.swift`)

**Spread ↔ Tighten** (`/oats/fractal/1/spread f`, −1…+1): palette density ×4^v; on the tighten side the smooth colouring goes toward
whole iterations (crisper band edges, up to 85 %). **3 phasers** (LFOs): target (spread, palette offset ±0.5, zoom breathe ±0.5 decade
drawn around the depth (the auto-zoom, the loop and DMX depth keep their own value), rotation wobble ±45°, iterations ×0.5–2, Julia morph
±0.5 and warp ±0.15 (only on a look that is already on the direct path, so the depth cap never moves), Julia orbit (constant on a
circle, radius 0.05), kaleido twist (fold / fold-c seams ± half a sector), trap size ×0.5–2, trap mix ±0.5), shape (sine, triangle,
saw, square, random step, smooth random), rate in beats 1/4…32 from the tempo clock (Link / DMX / tap) or seconds, depth 0…1, phase.
They fade in / out over 0.25 s, hold while DMX freeze is on, and are stored in scenes (`fractal.mods.spread` / `phasers`) and may be
set by looks (`spread`, `phasers` in a preset's `set`; otherwise a look keeps them). Presets (`phaser_presets` in
`tools/fractal_presets.json`): Breathe, Pulse 1/4, Tide, Heartbeat, Mutate, Wobble. GUI: Deep zoom card > Phasers.
The preset name (`phaser_preset`) stays while the 3 phasers equal a preset and comes back when single phaser messages make them equal
again (e.g. `tools/oats_state.py restore` after a restart, 2026-10-23); a change away from it clears it.
status.json `fractal.spread`, `spread_shown`, `phasers` (with each one's `value`), `phaser_preset`, `phaser_note`, `depth_shown`.
**DMX: none.** Fractal 24 has no free channel (all 24 are used), so Spread and the phaser presets are OSC / GUI only; the GDTF stays v0.7.

## Audio react (2026-10-23, `src/audio.swift`, `tools/audio_presets.json`)

**Input** (`/oats/audio/source s off|ndi|device`, default off; GUI Master column > Audio react):
- **NDI**: an audio-only NDI receiver inside the player (native arm64; the arm64 libndi freeze is in send only), on the first source
  whose name contains `/oats/audio/ndi s NAME` (case ignored: `djay` is enough). Own thread, 100 ms capture timeout; recreated when
  a capture call blocks > 1 s, when the name changes, or when no audio came for 4 s (backing off to 30 s while a source stays silent).
  FLTP planar float -> mono. **djay on the other Mac mini**: turn on its NDI output with audio (or NDI Tools' "NDI Audio"
  / Scan Converter / "macOS AV Output" on that Mac), then `/oats/audio/sources` (GUI ↻), pick it in the Input list (or
  `/oats/audio/ndi s djay`) and Source NDI. The source must be in group Public on the lighting network (192.168.1.x).
- **Device**: AVAudioEngine input from a CoreAudio device (`/oats/audio/device s NAME`, `/oats/audio/channel i` 0 = mix, n = channel).
  **macOS asks for microphone permission** for the process that runs the player the first time Device is chosen (Terminal when started
  with m0.sh, the app for the standalone VJ VIZZIES.app); until it is allowed the input is silence (status `audio.mic_permission`).
  This Mac mini has no built-in microphone; inputs seen: Insta360 Link 2, NDI Audio (NDI Tools virtual input), BlackHole 2ch.
- `/oats/audio/gain f` dB (−24…24), `/oats/audio/agc i` (default on), `/oats/audio/attack f` / `release f` ms (5 / 120),
  `/oats/audio/band/{kick,bass,lowmid,mid,high,air,snare_body,snare_crack} f lo f hi` Hz, `/oats/audio/sensitivity f` 0…1 (onsets, 0.6),
  `/oats/audio/quantize f` beats (0 off, 0.25 / 0.5 / 1: onsets snap to the beat grid while Link leads), `/oats/audio/sources`
  (NDI sources + audio devices into status.json `audio.available`).

**Analysis**: FFT 2048 (vDSP, Hann), hop = rate / 93.75 (512 at 48 kHz: 10.7 ms, ~94 Hz). Bands kick 20–120 (was 40–120 until
2026-10-23 evening; sub-heavy kicks), bass 120–250, lowmid
250–1k, mid 1–4k, high 4–10k, air 10–16k; level 0…1 = dB above (AGC reference − 24 dB), the reference following each band's peaks
(rise 0.3 s, fall 2 dB/s; AGC off = fixed −48…0 dBFS). Onsets kick / snare / hat: positive log-spectral flux in the kick band / the
snare bands / high+air, threshold = EMA mean + k·sd (~1 s) + floor, hold-off 150 / 150 / 70 ms; snare and hat only count when their
band is within 30 / 35 dB of the whole spectrum (no kick bleed). Each hit is a count + an envelope (150 / 130 / 80 ms).
**Kick presence gate + return ramp** (2026-10-23 evening, after a show report: a DJ high-pass filtering the kick gave false kick
hits, and the hits slammed back when the filter opened): log flux does not care about level, and the AGC pumped the near-empty kick
band back up, so anything leaking through fired. Now the *absolute* (pre-AGC) kick-band dB is held against a slow reference (the 95th
percentile of its 100 ms maxima over the last 10 s, rising in ~1 s, floor −50 dB; release 6 dB/s while kicks are being accepted — a quieter track re-adapts in seconds — and 1 dB/s while none are, so the gate holds while the kick is filtered): a kick hit needs the band within
15 dB of that reference, and its strength (the envelope height) is a **confidence** 0…1 between −15 and −6 dB of a peak follower
(fall 6 dB/s), so hits come back gently rather than at once. After ≥ 1.5 s without an accepted kick the hits (and the continuous
`kick` level) fade out over 0.5 s and ease back in from 0.2 to 1 over ~1 s once a kick is accepted again (or the presence rises back
through 0.5): a filter roll-back fades the effect into the scene. The continuous **`kick` source = AGC level × confidence**, so a route
from `kick` to FX speed / amount fades out while the kick is filtered and back in on return; the other bands are unchanged.
status.json `audio.kick_confidence`, `/audio.json` `kc`. Note: a passage with kicks more than 1.5 s apart also opens the gap, so the
`kick` source and the hits ease in again after each such pause (seen live: a sparse-kick section drove the confidence to 0 between
hits; steady 4/4 stays at 1.0). **Snare** = crack **1.5–5 kHz** onset (flux threshold, as before) AND body **150–300 Hz** rising ≥ 3 dB within 3 hops (~30 ms; the
43 ms FFT window spreads a transient over ~4 hops, and the body band also carries bass and kick harmonics) and above −60 dB, the two
within 3 hops of each other, plus the existing kick mask and backbeat gate; claps / vocals / hats jump the crack alone, a bass note
the body alone. `/oats/audio/snarebody i` (default 1) turns the body requirement off (crack only). The two ranges are settable like
the bands (`/oats/audio/band/snare_body`, `/oats/audio/band/snare_crack`; status `audio.bands`); status `snare_crack_onsets` (crack
onsets without a body) and `snare_body_onsets` show the live ratio. **Live note 2026-10-23/24**: the binary installed at 23:56 (body
≥ 6 dB in 2 hops) gave 0 snares against 63 crack onsets in a minute of 124 BPM music; the ≥ 3 dB / 3 hops version in the source tree
(bin/oats-m0.new, 00:01, self-test PASS) is NOT installed yet; if snares stay rare, `/oats/audio/snarebody 0`. Self-test
`--selftest-dmx` section 24 feeds synthetic audio through the analyzer (`AudioAnalyzer.analyze`): 55 Hz kick train → hits; the same
at −24 dB → none, confidence 0; return → confidence eases 0.3 → 1 over ~1 s; 200 Hz + 1.5–5 kHz snare burst → one snare, body or crack
alone → none. Energy = 1.5 s RMS vs its slow peak;
build = energy slope over 8 bars (tempo clock BPM); drop = fast energy > the 4 bars before by 0.3, after a build or a quiet section,
kick present, hold-off 8 bars (envelope 1.5 s). **Latency** (status `audio.latency_ms`): NDI frame + hop + 1/8 window + NDI transport
(timestamp age): ~36 ms with the local test sender (10 ms frames + 16 ms analysis + 10 ms transport), plus up to one render frame.

**Mod matrix** (8 routes, stored in scenes as `audio.routes`; `/oats/audio/route/{1-8}/{source s, target s, layer i, scene i, amount f,
curve s, smooth f, on i, clear}`, `/oats/audio/routes/clear`): source kick bass lowmid mid high air energy build kick_hit snare_hit
hat_hit drop -> target. Values are added on top of what is drawn each frame (like the phasers; base values and owners never change;
held while DMX freeze is on; master targets off in safe look; blackout wins). At amount 1: layer opacity +1, scale ×(1+a), rotation
+90°, spin +1 turn/s, pos x/y +1, FX 1/2 amount +1, generator count / thickness / speed +1, **FX 1/2 speed +1** (`fx1_speed`,
`fx2_speed`, clamped 0…1; for Star / Warp / Spiral trails the speed is the spin, 0.5 = still, so a + amount spins the trails on a hit
and they ease back through the route's smoothing), overlay opacity +1; fractal spread +1, zoom pulse +½ decade
(the phaser breathe), rotation kick +45°, palette offset +½, Julia morph +½ (direct-path looks), trap size ×2; master dimmer pulse
(a > 0: ×(1 − a + a·v), dark between hits; a < 0: ducks on hits), master FX amount +1, master FX speed +1 (`masterfx_speed`), strobe flash (toward white × dimmer, in
to_uyvy); scene go (on kick/snare/hat hits and drops, or a level rising through 0.85; scene 0 = next stored in the bank; 2 s hold-off).
Curves: linear, soft (ease-out), hard (cube). **Presets** `/oats/audio/preset s NAME [i layer]` (layer targets go to that layer,
default 1; `off` clears): Kick pump, Bass breathe, Hat sparkle, Drop hit, Full react, **Star trails · kick** (expects a Stars generator
layer with Star trails in FX slot 1: kick hit → fx1_speed +0.35 hard 0.25 s, **kick (band) → fx1_speed +0.15 soft 0.4 s** (2026-10-23
evening: a spin floor that follows the kick presence, so it fades out while the DJ filters the kick and back in on the return; the
hits add the nudges), bass → fx1 +0.3, energy → gen_count +0.3, drop → fx1 −0.5).
GUI: Master column > Audio react > the preset buttons; targets "FX 1 speed" / "FX 2 speed" / "Master FX speed" in the route rows.

status.json `audio`: source, connected, name, rate, levels{…}, onsets{kick,snare,hat counts}, hits{…}, energy, build, drop, drops,
kick_confidence (0…1, presence × return ramp), kick_abs_db, kick_ref_db, snare_crack_onsets, snare_body_onsets, snare_body_gate, bands (incl. snare_body / snare_crack), latency_ms (+ latency{frame_ms, analysis_ms, transport_ms}), dropouts, recreated, note, routes (with each `value`), presets, available;
`layers[n].transform.scale_shown`. GUI meter: `GET http://<mac>:8091/audio.json` (the preview port), polled ≤ 30 Hz only while a source
is on and the tab is visible. Test sender: `tests/ndi_audio_send.swift` (build line in the file; `NDI_CONFIG_DIR=ndi-config arch -x86_64
bin/ndi-audio-send --secs 20`: "OATS AUDIO TEST", Public, 48 kHz stereo FLTP, a 120 BPM kick + a 440 Hz sine).
**DMX: none** (OSC / GUI only).
