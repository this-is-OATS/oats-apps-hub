#!/usr/bin/env python3
"""VJ VIZZIES GUI v0: a web control window for the running oats-m0 player. Stdlib only.

Run:  python3 -I gui/server.py      (or gui/run.sh, which starts it in the background)

Routes
  GET  /             gui/index.html; a phone (iPhone / iPod / Android "Mobile" user agent) is sent to /phone (302)
                     unless it chose "Desktop view" (cookie oatsview=desktop) or asks for /?desktop=1
  GET  /phone, /phone.html   gui/phone.html, the dedicated phone controller (no-cache)
  GET  /remote, /remote.html   gui/remote.html, the iPad touch remote (no-cache); not logged in -> /login?next=/remote
  GET  /apc, /apc.html   gui/apc.html, the virtual Akai APC mini and the Web MIDI bridge for the real one (Chrome/Edge
                     at http://127.0.0.1:8090/apc on this Mac); not logged in -> /login?next=/apc
  GET  /mapping, /mapping.html   gui/mapping.html: LED wall output mapping (canvas size, slices per output display,
                     cabinet test pattern, clip scaling, venue presets); everything goes to the player as OSC
  POST /api/restart  restart the player to apply a new canvas: tools/oats_state.py save logs/restart-state.json,
                     m0.sh restart (the loop keeps its arguments, e.g. --ndi helper), then restore the look and the
                     output window display once the new player writes its status (in the background)
  GET  /api/status   logs/status.json plus "age_s" (seconds since the player last wrote it; cached 200 ms, gzip
                     when the client accepts it). Includes the player's
                     "preview" block (clients, fps, size, encode_ms_avg, dropped, ...) for the Preview pill.
                     ?client=remote marks the caller as an iPad remote; "gui.remotes" lists the remotes seen in
                     the last 6 s (ip, seen_s_ago) for the desktop GUI's Remote pill.
  POST /api/osc      JSON {"address": "/oats/...", "args": [["f", 0.3]]} -> OSC over UDP to the player
  The live preview does not go through this server: index.html plays MJPEG straight from oats-m0
  (http://<host>:8091/preview.mjpg, 256x144 at 30 fps). /api/preview below is only its fallback ("slow preview").
  GET  /api/preview  asks for /oats/system/snapshot, waits up to ~450 ms for logs/snapshot.png to change,
                     returns it as image/png. At most 2 snapshots per second, shared by all clients
                     (otherwise the cached image is returned), because each one costs the render loop a little.
                     ?w=640|960|1280 returns a downscaled JPEG instead (macOS sips, ~50 ms): about 80 KB
                     instead of ~2 MB per frame, which is what index.html uses (keeps en0 free for NDI).
  GET  /api/library  ../media/library.json (M2a clip banks and slots, for the clip grid)
  GET  /api/thumb?bank=B&slot=S   JPEG thumbnail of a slot (ffmpeg, cached in media/.thumbs/)
  POST /api/upload?bank=B&slot=S&name=FILE   raw file body (octet-stream, streamed to disk, at most 4 GB):
                     .mov/.mp4/.m4v, or .png/.jpg (made into a 10 s loop); slot 0 = first free. Then reload.
  GET  /api/scenes   scenes.json without the stored looks (bank / slot / name / colour / fade / flags)
  GET  /api/scenethumb?n=N   the scene's 160x90 JPEG (media/.scenes/<bank>-<slot>.jpg)
  GET  /api/genpresets  tools/gen_presets.json (generator looks + beat scripts)
  GET  /api/stacks      tools/stacks.json (multi-layer busk stacks, the APC mini STACKS pads; re-read on every request)
  POST /api/genlook  JSON {"layer", "name"} -> tools/oats_script.py look NAME --layer N --to OATS_OSC_TO
  POST /api/script   JSON {"layer", "name", "action": "run"|"stop"}: run starts oats_script.py run detached
                     (log logs/script-layer<n>.log); /api/status adds "scripts_running" {layer: {pid, name}}
  POST /api/bins     JSON {"op": "add_bank", "name"} | {"op": "rename_bank", "bank", "name"} | {"op": "remove_bank", "bank"} (empty only) |
                     {"op": "move", "from": [b, s], "to": [b, s]} (swap if taken) | {"op": "remove", "bank", "slot"}
                     (removes it from the bin only; the file stays on disk). Every change rewrites library.json and
                     sends /oats/library/reload to the player.
  GET  /manifest.webmanifest, /favicon.ico, /icons/*.png   app manifest + icons (no PIN, allowed networks only)
  GET  /thumbs/index.json (no-cache), /thumbs/<gen|fx|fractal|master|shape|place>/<slug>.jpg (public, 1 h): look thumbnails
  GET/POST /login    only when OATS_GUI_PIN is set. ?next=/remote, /phone or /apc (exactly those three) is kept as a hidden field
                     and a right PIN goes there instead of "/" (a Home Screen web app has its own cookie jar)

Who may use it: only 127.0.0.0/8 (this Mac) and en0's network (the lighting network), read from ifconfig en0 at
start (and again, at most every 5 s, when a refused address shows up). Every other source gets 403.
Where it listens: 127.0.0.1 and en0's IPv4 address (one socket each, never 0.0.0.0); en0 is re-read every 5 s and
its socket re-bound when the address appears or changes. Host header: only this Mac's own names (localhost,
127.0.0.1, en0's address, <LocalHostName>.local), else 403 (DNS rebinding). Connections: 10 s timeout, at most 64
at once; uploads one at a time and only with 2 GB + the file's size free; /api/restart at most once a minute;
with a PIN, 5 wrong PINs lock the login for 60 s. The log (gui/run/gui.log) rotates at 20 MB (3 kept).

Environment
  OATS_GUI_BIND  (default "auto" = 127.0.0.1 + en0; or one address)   OATS_GUI_PORT (default 8090)
  OATS_GUI_PIN   (unset = no PIN)    OATS_OSC_TO   (default 127.0.0.1:7000)
  OATS_GUI_ALLOW CIDR[,CIDR...] in place of en0's network (127.0.0.0/8 always stays), or "any" = no filter
"""
import gzip
import hmac
import http.server
import ipaddress
import json
import math
import os
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
from http import cookies

GUI_DIR = os.path.dirname(os.path.abspath(__file__))
M0_DIR = os.path.dirname(GUI_DIR)
LOGS = os.environ.get("OATS_GUI_LOGS") or os.path.join(M0_DIR, "logs")   # OATS_GUI_LOGS: a test player's log dir
STATUS_PATH = os.path.join(LOGS, "status.json")
SNAP_PATH = os.path.join(LOGS, "snapshot.png")
INDEX_PATH = os.path.join(GUI_DIR, "index.html")
PHONE_PATH = os.path.join(GUI_DIR, "phone.html")
REMOTE_PATH = os.path.join(GUI_DIR, "remote.html")
MAPPING_PATH = os.path.join(GUI_DIR, "mapping.html")
APC_PATH = os.path.join(GUI_DIR, "apc.html")          # virtual APC mini + Web MIDI bridge (2026-11-02)
PHONE_UA = re.compile(r"iPhone|iPod|Android.*Mobile|Mobile.*Android")   # phones only (iPads and Android tablets keep the desktop page)
LIBRARY_PATH = os.path.join(os.path.dirname(M0_DIR), "media", "library.json")   # M2a clip library (tools/make_library.swift)
SCENES_PATH = os.path.join(M0_DIR, "scenes.json")                                 # player scenes (src/scenes.swift)
SCENE_THUMBS = os.path.join(os.path.dirname(M0_DIR), "media", ".scenes")
RUN_DIR = os.path.join(GUI_DIR, "run")
THUMBS_DIR = os.path.join(GUI_DIR, "thumbs")                                       # look thumbnails
THUMB_RE = re.compile(r"/thumbs/(gen|fx|fractal|master|shape|place)/([a-z0-9][a-z0-9-]{0,80}\.jpg)")   # safe: no dots, no slashes
STATIC = {                                   # app manifest + icons (Mac app, Edge app window on the PC)
    "/manifest.webmanifest": ("manifest.webmanifest", "application/manifest+json"),
    "/vu": ("vu.html", "text/html; charset=utf-8"),             # simple audio VU meter page
    "/boot.js": ("boot.js", "text/javascript; charset=utf-8"),   # MS-DOS style loading screen
    "/vu.html": ("vu.html", "text/html; charset=utf-8"),
    "/favicon.ico": ("icons/favicon.ico", "image/x-icon"),
    "/icons/icon-192.png": ("icons/icon-192.png", "image/png"),
    "/icons/icon-512.png": ("icons/icon-512.png", "image/png"),
    "/icons/apple-touch-icon.png": ("icons/apple-touch-icon.png", "image/png"),
}

sys.path.append(os.path.join(M0_DIR, "tests"))   # appended, so the stdlib always wins
from osc_send import encode_message, parse_hostport  # noqa: E402
sys.path.append(GUI_DIR)
import oats_media  # noqa: E402

BIND = os.environ.get("OATS_GUI_BIND", "auto")
if BIND in ("0.0.0.0", ""):                 # the old default: never listen on every interface (building Wi-Fi, Tailscale)
    BIND = "auto"
PORT = int(os.environ.get("OATS_GUI_PORT", "8090"))
OSC_TO = parse_hostport(os.environ.get("OATS_OSC_TO", "127.0.0.1:7000"))
OSC_TO_TEXT = "%s:%d" % OSC_TO                # for tools/oats_script.py --to (looks, scripts): the same player as /api/osc
PIN = os.environ.get("OATS_GUI_PIN") or None
PREVIEW_PORT = 8091                         # oats-m0's MJPEG preview (index.html connects to it directly)
TOKEN = secrets.token_hex(24)              # session cookie value; a server restart logs everyone out

SNAP_MIN_INTERVAL = 0.5                     # s between snapshot requests (2 per second, all clients)
SNAP_WAIT = 0.45                            # s to wait for the player to write the new PNG
MAX_BODY = 4096
CONN_TIMEOUT = 10                           # s per socket read / write (slowloris): a stalled connection is dropped
MAX_CONNS = 64                              # connections served at once; more are closed at once
RESTART_MIN_INTERVAL = 60                   # s between two player restarts (/api/restart, the mapping page's restart)
LOGIN_MAX_FAILS, LOGIN_LOCK_S = 5, 60       # with a PIN: 5 wrong PINs (from anywhere) lock the login for 60 s
LOG_MAX_BYTES, LOG_KEEP = 20 * 1024 * 1024, 3
OSC_TYPES = set("ifdhsTFN")
BLOCKED_PREFIXES = ("/oats/debug/",)        # /oats/debug/stall freezes the render thread (watchdog test)

_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


_log_lock = threading.Lock()


def _log_path():
    """The file stderr is appended to (gui/run.sh: gui/run/gui.log), or None for a terminal / pipe."""
    try:
        st = os.fstat(2)
        p = os.path.join(RUN_DIR, "gui.log")
        if os.path.exists(p) and os.path.samestat(st, os.stat(p)):
            return p
    except OSError:
        pass
    return None


def _rotate_if_big():
    """gui.log -> gui.log.1 -> .2 -> .3 at LOG_MAX_BYTES; stdout and stderr then point at a fresh gui.log (0600)."""
    try:
        if os.fstat(2).st_size < LOG_MAX_BYTES:
            return
    except OSError:
        return
    p = _log_path()
    if not p:
        return
    try:
        for i in range(LOG_KEEP - 1, 0, -1):
            if os.path.exists(f"{p}.{i}"):
                os.replace(f"{p}.{i}", f"{p}.{i + 1}")
        os.replace(p, p + ".1")
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        os.dup2(fd, 2)
        os.dup2(fd, 1)
        os.close(fd)
        sys.stderr.write(time.strftime("%Y-%m-%d %H:%M:%S ") + f"log rotated at {LOG_MAX_BYTES >> 20} MB (older lines in gui.log.1 .. .{LOG_KEEP})\n")
    except OSError:
        pass


def log(msg):
    with _log_lock:
        _rotate_if_big()
        sys.stderr.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
        sys.stderr.flush()


FORBIDDEN_MSG = "VJ VIZZIES controls are only available on the lighting network\n"
LOOPBACK = ipaddress.ip_network("127.0.0.0/8")


def en0_networks():
    """en0's IPv4 networks from `ifconfig en0` (a self-assigned 169.254.x.x doesn't count)."""
    try:
        out = subprocess.run(["/sbin/ifconfig", "en0"], capture_output=True, text=True, timeout=2).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    nets = []
    for m in re.finditer(r"\binet (\d+\.\d+\.\d+\.\d+) netmask 0x([0-9a-fA-F]{8})", out):
        ip = ipaddress.ip_address(m.group(1))
        if ip.is_link_local:
            continue
        mask = int(m.group(2), 16)
        bits = bin(mask).count("1")
        if bits < 8 or mask != (0xFFFFFFFF << (32 - bits)) & 0xFFFFFFFF:   # garbled: never widen to "everything"
            bits = 24
        nets.append((ipaddress.ip_network(f"{ip}/{bits}", strict=False), ip))
    return nets


def en0_ip():
    """en0's IPv4 address as text, or None."""
    n = en0_networks()
    return str(n[0][1]) if n else None


def _local_hostname():
    try:
        out = subprocess.run(["/usr/sbin/scutil", "--get", "LocalHostName"], capture_output=True, text=True, timeout=2).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None
    return (out.lower() + ".local") if out and " " not in out else None


LOCAL_NAME = _local_hostname()               # "obshost.local"


class En0Watch:
    """en0's address, re-read at most every 5 s (shared by the Host check and the listener re-bind)."""

    def __init__(self):
        self.lock = threading.Lock()
        self.ip = en0_ip()
        self.t = time.monotonic()

    def get(self, max_age=5.0):
        with self.lock:
            if time.monotonic() - self.t < max_age:
                return self.ip
            self.t = time.monotonic()
        ip = en0_ip()
        with self.lock:
            self.ip = ip
        return ip


EN0 = En0Watch()


def split_hostport(v):
    """'Host: a.b.c.d:8090' -> ('a.b.c.d', 8090); ('name', None) without a port; None when malformed / IPv6."""
    v = (v or "").strip().lower()
    if not v or v.startswith("["):
        return None
    host, port = v, None
    if ":" in v:
        host, _, ps = v.rpartition(":")
        if not ps.isdigit() or not 0 < int(ps) < 65536:
            return None
        port = int(ps)
    host = host.rstrip(".")
    return (host, port) if host else None


def is_self_name(h):
    return h in ("localhost", "127.0.0.1") or (LOCAL_NAME is not None and h == LOCAL_NAME) or h == EN0.get()


def host_ok(v):
    """DNS rebinding guard: the Host header must name this Mac (localhost, 127.0.0.1, en0's address,
    <LocalHostName>.local), with no port or our own port."""
    hp = split_hostport(v)
    if not hp:
        return False
    h, port = hp
    return (port is None or port == PORT) and is_self_name(h)


def host_names_text():
    return ", ".join(x for x in ("localhost", "127.0.0.1", EN0.get(), LOCAL_NAME) if x)


def _dedupe(nets):
    out = []
    for n in nets:
        if n not in out:
            out.append(n)
    return out


class AllowList:
    """127.0.0.0/8 + en0's network (or OATS_GUI_ALLOW). Logs the first refusal per address once."""

    def __init__(self):
        env = os.environ.get("OATS_GUI_ALLOW", "").strip()
        self.lock = threading.Lock()
        self.any = env.lower() == "any"
        self.from_en0 = not env
        self.seen = set()
        self.rejected = 0
        self.last_check = time.monotonic()
        self.en0 = []
        if self.any:
            self.nets = []
        elif env:
            self.nets = _dedupe([LOOPBACK] + [ipaddress.ip_network(x.strip(), strict=False)
                                              for x in env.split(",") if x.strip()])
        else:
            self.en0 = en0_networks()
            self.nets = _dedupe([LOOPBACK] + [n for n, _ in self.en0])

    def text(self):
        with self.lock:
            return "any (OATS_GUI_ALLOW=any)" if self.any else ", ".join(str(n) for n in self.nets)

    def describe(self):
        if self.any:
            return ["control allowed from: any source (OATS_GUI_ALLOW=any)"]
        lines = [f"control allowed from: {self.text()} "
                 f"({'127.0.0.0/8 + en0' if self.from_en0 else '127.0.0.0/8 + OATS_GUI_ALLOW'}); others get 403"]
        if self.from_en0 and not self.en0:
            lines.append("WARNING: en0 has no IPv4 address: only this Mac (127.0.0.0/8) until en0 has one "
                         "(re-read at most every 5 s when a refused address shows up)")
        return lines

    def allows(self, host):
        if self.any:
            return True
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            return False
        if ip.version == 6 and ip.ipv4_mapped:
            ip = ip.ipv4_mapped
        with self.lock:
            nets = self.nets
        if any(ip in n for n in nets):
            return True
        if not self.from_en0:
            return False
        with self.lock:                          # en0 may have come up (or changed) since start
            now = time.monotonic()
            if now - self.last_check < 5:
                return False
            self.last_check = now
        fresh = _dedupe([LOOPBACK] + [n for n, _ in en0_networks()])
        with self.lock:
            changed = fresh != self.nets
            self.nets = fresh
        if changed:
            log("en0 changed: control allowed from " + ", ".join(str(n) for n in fresh))
        return any(ip in n for n in fresh)

    def note_reject(self, host, what):
        with self.lock:
            self.rejected += 1
            first = host not in self.seen and len(self.seen) < 256
            if first:
                self.seen.add(host)
        if first:
            log(f"REFUSED {host} ({what[:100]!r}): not on an allowed network ({self.text()}); "
                f"further requests from it get 403 without a log line")


ALLOW = AllowList()


class HostLog:
    """A wrong Host header is logged once per (address, host) pair, 256 pairs at most."""

    def __init__(self):
        self.lock = threading.Lock()
        self.seen = set()
        self.count = 0

    def note(self, addr, host):
        key = (addr, (host or "")[:80])
        with self.lock:
            self.count += 1
            first = key not in self.seen and len(self.seen) < 256
            if first:
                self.seen.add(key)
        if first:
            log(f"403 wrong Host {key[1]!r} from {addr} (allowed: {host_names_text()}; DNS rebinding guard); "
                f"further ones from it are only counted")


HOSTLOG = HostLog()


def send_osc(address, args=()):
    pkt = encode_message(address, args)
    _sock.sendto(pkt, OSC_TO)
    return len(pkt)


def validate_osc(body):
    """Returns (address, [(type, value)]) or raises ValueError with a reason."""
    if not isinstance(body, dict):
        raise ValueError("body must be a JSON object")
    addr = body.get("address")
    if not isinstance(addr, str) or not addr.startswith("/oats/"):
        raise ValueError("address must start with /oats/")
    if len(addr) > 160 or any(c in addr for c in " \t\r\n\0#,?*[]{}"):
        raise ValueError("bad characters in address")
    if addr.startswith(BLOCKED_PREFIXES):
        raise ValueError("debug addresses are not allowed from the GUI")
    raw = body.get("args", [])
    if not isinstance(raw, list) or len(raw) > 8:
        raise ValueError("args must be a list of at most 8 [type, value] pairs")
    out = []
    for a in raw:
        if not isinstance(a, (list, tuple)) or len(a) not in (1, 2) or a[0] not in OSC_TYPES:
            raise ValueError("each arg must be [type, value] with type one of i f d h s T F N")
        t = a[0]
        v = a[1] if len(a) == 2 else None
        if t in "ih":
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
                raise ValueError("int arg must be a number")
            v = int(v)
            if t == "i" and not -2**31 <= v < 2**31:
                raise ValueError("int arg out of range")
        elif t in "fd":
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
                raise ValueError("float arg must be a finite number")
            v = float(v)
        elif t == "s":
            cap = 3500 if addr == "/oats/output/slices" else 64     # the mapping page sends the slice list as JSON
            if not isinstance(v, str) or len(v) > cap:
                raise ValueError(f"string arg must be text, at most {cap} characters")
        else:
            v = None
        out.append((t, v))
    return addr, out


class Snapshots:
    """Shared snapshot cache. One request to the player at a time, at most one per SNAP_MIN_INTERVAL."""

    def __init__(self):
        self.lock = threading.Lock()
        self.data = None
        self.mtime = 0.0
        self.last_req = 0.0
        self.count = 0
        self.gen = 0                              # bumps whenever the cached PNG changes
        self.small = {}                           # width -> (gen, jpeg bytes)
        self.small_lock = threading.Lock()

    @staticmethod
    def _sig():
        try:
            st = os.stat(SNAP_PATH)
            return (st.st_ino, st.st_mtime_ns, st.st_size)
        except OSError:
            return None

    def _read(self):
        try:
            with open(SNAP_PATH, "rb") as f:
                d = f.read()
            if d[:8] == b"\x89PNG\r\n\x1a\n":
                if d != self.data:                # a still picture gives identical bytes: keep the JPEG cache
                    self.data = d
                    self.gen += 1
                self.mtime = os.stat(SNAP_PATH).st_mtime
        except OSError:
            pass

    def get(self):
        """Returns (png bytes or None, fresh: bool, age_s of the image)."""
        if not self.lock.acquire(blocking=False):      # another client is waiting for a fresh one
            if self.data is None and self.lock.acquire(timeout=0.7):   # cold start: wait for its result
                self.lock.release()
            return self.data, False, self.age()
        try:
            now = time.monotonic()
            if now - self.last_req < SNAP_MIN_INTERVAL:
                if self.data is None:
                    self._read()
                return self.data, False, self.age()
            self.last_req = now
            before = self._sig()
            try:
                send_osc("/oats/system/snapshot")
            except OSError as e:
                log(f"snapshot request failed: {e}")
            deadline = now + SNAP_WAIT
            while time.monotonic() < deadline:
                time.sleep(0.02)
                s = self._sig()
                if s is not None and s != before:
                    self._read()
                    self.count += 1
                    return self.data, True, self.age()
            if self.data is None:
                self._read()
            return self.data, False, self.age()
        finally:
            self.lock.release()

    def scaled(self, width):
        """Downscaled JPEG of the current cached PNG (None if sips fails)."""
        with self.small_lock:
            gen, data = self.gen, self.data
            hit = self.small.get(width)
            if hit and hit[0] == gen:
                return hit[1]
            src, dst = os.path.join(RUN_DIR, ".pv-src.png"), os.path.join(RUN_DIR, f".pv-{width}.jpg")
            try:
                os.makedirs(RUN_DIR, exist_ok=True)
                with open(src, "wb") as f:
                    f.write(data)
                subprocess.run(["/usr/bin/sips", "-s", "format", "jpeg", "-s", "formatOptions", "72",
                                "-Z", str(width), src, "--out", dst],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3, check=True)
                with open(dst, "rb") as f:
                    out = f.read()
            except (OSError, subprocess.SubprocessError) as e:
                log(f"preview downscale failed ({e.__class__.__name__}); sending PNG")
                return None
            self.small = {width: (gen, out)}
            return out

    def age(self):
        return round(time.time() - self.mtime, 2) if self.data else None


SNAPS = Snapshots()


def read_status():
    try:
        with open(STATUS_PATH, "rb") as f:
            st = json.loads(f.read())
    except (OSError, ValueError) as e:
        return 503, {"error": f"status.json unreadable ({e.__class__.__name__})", "age_s": None}
    upd = st.get("updated_unix")
    st["age_s"] = round(time.time() - upd, 2) if isinstance(upd, (int, float)) else None
    st.setdefault("preview", None)                 # an older player build has no live preview
    st["gui"] = {"pin": bool(PIN), "snapshots": SNAPS.count, "preview_port": PREVIEW_PORT,
                 "allowed": ALLOW.text(), "rejected": ALLOW.rejected, "listen": LISTENERS.bound(),
                 "wrong_host": HOSTLOG.count, "conns_refused": Server.refused, "remotes": REMOTES.seen()}
    st["scripts_running"] = scripts_running()      # {layer: {pid, name}} (generator beat scripts)
    return 200, st


class Remotes:
    """iPad remotes (gui/remote.html) poll /api/status?client=remote at 2 Hz while they are on screen: each caller's
    address is kept 6 s, so the desktop GUI's Remote pill lights while an iPad is open and goes out a few seconds
    after it leaves the page or sleeps. No name lookups (nothing may block the status thread)."""
    HOLD_S = 6.0

    def __init__(self):
        self.lock, self.last = threading.Lock(), {}

    def touch(self, ip):
        with self.lock:
            self.last[ip] = time.monotonic()

    def seen(self):
        now = time.monotonic()
        with self.lock:
            self.last = {ip: t for ip, t in self.last.items() if now - t <= self.HOLD_S}
            return [{"ip": ip, "seen_s_ago": round(now - t, 1)} for ip, t in sorted(self.last.items())]


REMOTES = Remotes()

# /api/status is polled by every open control window (desktop 700 ms, phone 700 ms, hidden 2 s): the encoded answer
# is kept for 200 ms (one status.json read + JSON encode for all of them) and sent gzip-compressed when the client
# accepts it (~24 KB -> ~7 KB). age_s is then up to 0.2 s old.
STATUS_CACHE_S = 0.2
_status_lock = threading.Lock()
_status_cache = {"t": -1.0, "code": 0, "body": b"", "gz": b""}


def status_payload():
    now = time.monotonic()
    with _status_lock:
        c = _status_cache
        if c["body"] and now - c["t"] < STATUS_CACHE_S:
            return c["code"], c["body"], c["gz"]
        code, st = read_status()
        body = json.dumps(st, separators=(",", ":")).encode("utf-8")
        c.update(t=now, code=code, body=body, gz=gzip.compress(body, compresslevel=5, mtime=0))
        return code, body, c["gz"]


# ---- generator looks + beat scripts (tools/gen_presets.json, tools/oats_script.py)
TOOLS_DIR = os.path.join(M0_DIR, "tools")
GEN_PRESETS = os.path.join(TOOLS_DIR, "gen_presets.json")
STACKS = os.path.join(TOOLS_DIR, "stacks.json")          # multi-layer busk stacks for the APC mini page (2026-11-02)
SCRIPT_PY = os.path.join(TOOLS_DIR, "oats_script.py")


def gen_presets():
    with open(GEN_PRESETS, "rb") as f:
        return json.loads(f.read())


def _pid_alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def scripts_running():
    """{layer: name} for scripts whose pidfile (written by oats_script.py) names a live process."""
    out = {}
    for n in range(0, 5):
        try:
            with open(os.path.join(LOGS, f"script-layer{n}.pid")) as f:
                pid = int(f.read().strip())
        except (OSError, ValueError):
            continue
        if not _pid_alive(pid):
            continue
        name = None
        try:                                        # side file written by /api/script run: {"pid", "name"}
            with open(os.path.join(LOGS, f"script-layer{n}.name.json")) as f:
                meta = json.load(f)
            if meta.get("pid") == pid:
                name = meta.get("name")
        except (OSError, ValueError):
            pass
        out[str(n)] = {"pid": pid, "name": name or "script"}
    return out


def _layer_name(b, kind):
    layer, name = int(b["layer"]), str(b["name"])
    if not 0 <= layer <= 4:
        raise ValueError("layer must be 0 (BG) - 4")
    if name not in gen_presets().get(kind, {}):
        raise ValueError(f"unknown {kind[:-1]} '{name}'")
    return layer, name


LOGIN_HTML = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>VJ VIZZIES: PIN</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#000008;color:#c8e8ff;
font-family:"Avenir Next","Segoe UI",Roboto,system-ui,sans-serif}
form{border:1px solid rgba(0,245,255,.25);background:rgba(0,20,40,.85);padding:28px;border-radius:4px;width:min(320px,90vw)}
h1{margin:0 0 18px;font-size:22px;letter-spacing:8px;color:#00f5ff}h1 span{color:#ff00ff}
input{width:100%;box-sizing:border-box;font:20px ui-monospace,Menlo,monospace;padding:10px;background:#000814;
color:#c8e8ff;border:1px solid rgba(0,245,255,.3);border-radius:3px;letter-spacing:6px}
button{margin-top:14px;width:100%;padding:10px;background:transparent;color:#00f5ff;border:1px solid #00f5ff;
border-radius:3px;font-weight:700;letter-spacing:3px;cursor:pointer}p{color:#ff2244;font-size:13px;margin:10px 0 0}</style>
</head><body><form method="post" action="/login"><h1>VJ<span>VIZZIES</span></h1>
<input name="pin" type="password" inputmode="numeric" autocomplete="current-password" placeholder="PIN" autofocus>
%NEXT%<button>ENTER</button>%MSG%</form></body></html>"""
LOGIN_NEXT = ("/remote", "/phone", "/apc")      # the only pages a login may continue to (else "/")


def login_next(query):
    """The ?next= / form "next" value when it is exactly one of LOGIN_NEXT, else None."""
    v = (urllib.parse.parse_qs(query or "").get("next") or [""])[0]
    return v if v in LOGIN_NEXT else None


class LoginGuard:
    """With a PIN: LOGIN_MAX_FAILS wrong PINs in a row (from any address, so parallel guessing doesn't help) lock
    every login for LOGIN_LOCK_S seconds. A right PIN resets the count."""

    def __init__(self):
        self.lock = threading.Lock()
        self.fails = 0
        self.until = 0.0

    def locked(self):
        with self.lock:
            return max(0.0, self.until - time.monotonic())

    def failed(self):
        with self.lock:
            self.fails += 1
            if self.fails >= LOGIN_MAX_FAILS:
                self.fails = 0
                self.until = time.monotonic() + LOGIN_LOCK_S
                return True
            return False

    def ok(self):
        with self.lock:
            self.fails = 0


LOGIN = LoginGuard()
_upload_lock = threading.Lock()                # one upload at a time (429 otherwise)


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "oats-gui/0"
    protocol_version = "HTTP/1.1"
    timeout = CONN_TIMEOUT                    # socket timeout for every read and write (slowloris, idle keep-alive)

    # ---- helpers
    def _send(self, code, body=b"", ctype="application/json", headers=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        if "Cache-Control" not in (headers or {}):
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, separators=(",", ":")))

    def _wants_phone(self):
        """A phone asking for / goes to /phone, unless it chose the desktop page (cookie or ?desktop=1)."""
        if not PHONE_UA.search(self.headers.get("User-Agent", "")):
            return False
        if "desktop=1" in (urllib.parse.urlsplit(self.path).query or ""):
            return False
        c = cookies.SimpleCookie()
        try:
            c.load(self.headers.get("Cookie", ""))
        except cookies.CookieError:
            return True
        m = c.get("oatsview")
        return not (m and m.value == "desktop")

    def _authed(self):
        if not PIN:
            return True
        c = cookies.SimpleCookie()
        try:
            c.load(self.headers.get("Cookie", ""))
        except cookies.CookieError:
            return False
        m = c.get("oatsgui")
        return bool(m) and hmac.compare_digest(m.value, TOKEN)

    def _same_origin(self):
        origin = self.headers.get("Origin")
        if not origin:
            return True
        return urllib.parse.urlsplit(origin).netloc == self.headers.get("Host", "")

    def _length(self):
        """Content-Length as an int >= 0; ValueError when it is missing-but-garbled, negative or not a number."""
        v = (self.headers.get("Content-Length") or "0").strip()
        if not v.isdigit():                     # "-1", "+5", "1e9", " 12 13": refused (a negative one read to EOF)
            raise ValueError("bad Content-Length")
        return int(v)

    def _body(self):
        n = self._length()
        if n > MAX_BODY:
            raise ValueError("body too large")
        return self.rfile.read(n) if n else b""

    def log_message(self, fmt, *args):
        pass                                  # quiet: polling would flood the log; OSC is logged below

    def parse_request(self):
        """Every request from a source that is not on an allowed network gets 403 (any method, any path)."""
        if not super().parse_request():
            return False
        host = self.client_address[0]
        if not ALLOW.allows(host):             # normally already refused in verify_request, before any read
            ALLOW.note_reject(host, f"{self.command} {self.path}")
            self.close_connection = True
            self._send(403, FORBIDDEN_MSG, "text/plain; charset=utf-8", {"Connection": "close"})
            return False
        if not host_ok(self.headers.get("Host")):
            HOSTLOG.note(host, self.headers.get("Host"))
            self.close_connection = True
            self._send(403, "wrong Host header: use this Mac's address\n", "text/plain; charset=utf-8", {"Connection": "close"})
            return False
        return True

    # ---- routes
    def do_GET(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == "/login":
            if not PIN:
                return self._send(303, headers={"Location": "/"})
            lk = LOGIN.locked()
            msg = (f'<p>Too many wrong PINs: try again in {math.ceil(lk)} s.</p>' if lk > 0
                   else '<p>Wrong PIN.</p>' if "bad=1" in self.path else "")
            nxt = login_next(urllib.parse.urlsplit(self.path).query)
            hidden = f'<input type="hidden" name="next" value="{nxt}">' if nxt else ""
            return self._send(200, LOGIN_HTML.replace("%NEXT%", hidden).replace("%MSG%", msg), "text/html; charset=utf-8")
        if path in STATIC:                    # manifest + icons: no PIN needed (still only from allowed networks)
            fn, ctype = STATIC[path]
            try:
                with open(os.path.join(GUI_DIR, fn), "rb") as f:
                    cc = "public, max-age=3600" if fn.startswith("icons/") else "no-cache"   # pages + scripts: always fresh
                    return self._send(200, f.read(), ctype, {"Cache-Control": cc})
            except OSError:
                return self._json(404, {"error": "not found"})
        if not self._authed():
            if path.startswith("/api/"):
                return self._json(401, {"error": "PIN required"})
            if path in ("/remote", "/remote.html"):     # the iPad remote comes back to itself after the PIN
                return self._send(303, headers={"Location": "/login?next=/remote"})
            if path in ("/apc", "/apc.html"):           # so does the APC mini page
                return self._send(303, headers={"Location": "/login?next=/apc"})
            return self._send(303, headers={"Location": "/login"})
        if path == "/" and self._wants_phone():
            return self._send(302, headers={"Location": "/phone", "Cache-Control": "no-store", "Vary": "User-Agent, Cookie"})
        if path in ("/phone", "/phone.html"):
            try:
                with open(PHONE_PATH, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8", {"Cache-Control": "no-cache"})
            except OSError:
                return self._json(500, {"error": "phone.html missing"})
        if path in ("/remote", "/remote.html"):
            try:
                with open(REMOTE_PATH, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8", {"Cache-Control": "no-cache"})
            except OSError:
                return self._json(500, {"error": "remote.html missing"})
        if path in ("/apc", "/apc.html"):
            try:
                with open(APC_PATH, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8", {"Cache-Control": "no-cache"})
            except OSError:
                return self._json(500, {"error": "apc.html missing"})
        if path in ("/mapping", "/mapping.html"):
            try:
                with open(MAPPING_PATH, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8", {"Cache-Control": "no-cache"})
            except OSError:
                return self._json(500, {"error": "mapping.html missing"})
        if path in ("/", "/index.html"):
            try:
                with open(INDEX_PATH, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            except OSError:
                return self._json(500, {"error": "index.html missing"})
        if path == "/api/status":
            if "client=remote" in (urllib.parse.urlsplit(self.path).query or ""):
                REMOTES.touch(self.client_address[0])
            code, body, gz = status_payload()
            if "gzip" in self.headers.get("Accept-Encoding", ""):
                return self._send(code, gz, headers={"Content-Encoding": "gzip", "Vary": "Accept-Encoding"})
            return self._send(code, body, headers={"Vary": "Accept-Encoding"})
        if path == "/api/preview":
            data, fresh, age = SNAPS.get()
            if data is None:
                return self._json(503, {"error": "no snapshot yet"})
            hdr = {"X-Snapshot-Fresh": "1" if fresh else "0", "X-Snapshot-Age": "" if age is None else str(age)}
            w = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("w", [""])[0]
            if w in ("640", "960", "1280"):
                small = SNAPS.scaled(int(w))
                if small:
                    return self._send(200, small, "image/jpeg", hdr)
            return self._send(200, data, "image/png", hdr)
        if path == "/api/library":
            try:
                with open(LIBRARY_PATH, "rb") as f:
                    return self._send(200, f.read(), "application/json")
            except OSError:
                return self._json(404, {"error": "no media/library.json"})
        if path == "/api/thumb":
            q = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            try:
                tp = oats_media.thumb_for(int(q.get("bank", ["0"])[0]), int(q.get("slot", ["0"])[0]))
                with open(tp, "rb") as f:
                    data = f.read()
            except (ValueError, OSError):
                return self._json(404, {"error": "no thumbnail"})
            except oats_media.MediaError as e:
                return self._json(e.code, {"error": str(e)})
            return self._send(200, data, "image/jpeg", {"Cache-Control": "private, max-age=300"})
        if path == "/api/scenes":
            try:
                with open(SCENES_PATH, "rb") as f:
                    j = json.load(f)
            except FileNotFoundError:
                return self._json(200, {"bank": 1, "banks": []})
            except (OSError, ValueError) as e:
                return self._json(500, {"error": f"scenes.json unreadable ({e})"})
            for b in j.get("banks", []):
                for sc in b.get("scenes", []):
                    sc.pop("look", None)
            return self._json(200, j)
        if path == "/api/scenethumb":
            q = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            try:
                n = int(q.get("n", ["0"])[0])
                if not 1 <= n <= 128:
                    raise ValueError
                with open(os.path.join(SCENE_THUMBS, "%d-%02d.jpg" % ((n - 1) // 16 + 1, (n - 1) % 16 + 1)), "rb") as f:
                    data = f.read()
            except (ValueError, OSError):
                return self._json(404, {"error": "no scene thumbnail"})
            return self._send(200, data, "image/jpeg", {"Cache-Control": "private, max-age=3600"})
        if path == "/api/stacks":
            try:
                with open(STACKS, "rb") as f:
                    return self._send(200, f.read(), "application/json", {"Cache-Control": "no-store"})
            except OSError:
                return self._json(200, {"stacks": []})
        if path == "/api/genpresets":
            try:
                return self._json(200, gen_presets())
            except (OSError, ValueError) as e:
                return self._json(500, {"error": f"gen_presets.json unreadable ({e})"})
        if path.startswith("/thumbs/"):          # look thumbnails (tools/make_look_thumbs.py)
            if path == "/thumbs/index.json":
                try:
                    with open(os.path.join(THUMBS_DIR, "index.json"), "rb") as f:
                        return self._send(200, f.read(), "application/json", {"Cache-Control": "no-cache"})
                except OSError:
                    return self._json(404, {"error": "no thumbnails yet"})
            m = THUMB_RE.fullmatch(path)
            if not m:
                return self._json(404, {"error": "not found"})
            try:
                with open(os.path.join(THUMBS_DIR, m.group(1), m.group(2)), "rb") as f:
                    return self._send(200, f.read(), "image/jpeg", {"Cache-Control": "public, max-age=3600"})
            except OSError:
                return self._json(404, {"error": "no thumbnail"})
        return self._json(404, {"error": "not found"})

    def do_POST(self):
        path = urllib.parse.urlsplit(self.path).path
        if not self._same_origin():
            return self._json(403, {"error": "cross-origin request refused"})
        if path == "/api/upload":                   # streamed: never read into memory
            if not self._authed():
                return self._json(401, {"error": "PIN required"})
            q = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            try:
                bank, slot = int(q.get("bank", ["0"])[0]), int(q.get("slot", ["0"])[0])
                n = self._length()
            except ValueError:
                self.close_connection = True
                return self._json(400, {"error": "bank, slot and Content-Length must be numbers"})
            name = q.get("name", [""])[0]
            if not _upload_lock.acquire(blocking=False):
                self.close_connection = True                  # the body is unread
                return self._json(429, {"error": "another upload is running: one at a time"})
            try:
                rec = oats_media.upload(bank, slot, name, self.rfile, n)
            except oats_media.MediaError as e:
                self.close_connection = True                  # the body may be unread
                return self._json(e.code, {"error": str(e)})
            except OSError as e:
                self.close_connection = True
                return self._json(500, {"error": "write failed: %s" % e})
            finally:
                _upload_lock.release()
            send_osc("/oats/library/reload")
            log(f"upload {self.client_address[0]} -> bank {rec['bank']} slot {rec['slot']} {rec['file']} ({n} bytes)")
            return self._json(200, {"ok": True, **rec})
        try:
            raw = self._body()
        except ValueError as e:
            return self._json(413, {"error": str(e)})
        if path == "/login":
            if not PIN:
                return self._send(303, headers={"Location": "/"})
            wait = LOGIN.locked()
            if wait > 0:
                return self._send(303, headers={"Location": "/login?locked=%d" % math.ceil(wait)})
            form = urllib.parse.parse_qs(raw.decode("utf-8", "replace"))
            given = (form.get("pin") or [""])[0]
            nxt = login_next(raw.decode("utf-8", "replace"))
            keep = f"&next={nxt}" if nxt else ""           # a wrong PIN keeps the way back to the remote / phone
            if hmac.compare_digest(given.encode(), PIN.encode()):
                LOGIN.ok()
                log(f"login ok from {self.client_address[0]}" + (f" -> {nxt}" if nxt else ""))
                return self._send(303, headers={
                    "Location": nxt or "/",
                    "Set-Cookie": f"oatsgui={TOKEN}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000"})
            log(f"login FAILED from {self.client_address[0]}")
            if LOGIN.failed():
                log(f"login: {LOGIN_MAX_FAILS} wrong PINs in a row: every login locked for {LOGIN_LOCK_S} s")
                return self._send(303, headers={"Location": "/login?locked=%d" % LOGIN_LOCK_S + keep})
            time.sleep(1.0)
            return self._send(303, headers={"Location": "/login?bad=1" + keep})
        if not self._authed():
            return self._json(401, {"error": "PIN required"})
        if path == "/api/bins":
            try:
                b = json.loads(raw or b"null")
                op = b.get("op")
                if op == "add_bank":
                    res = {"bank": oats_media.add_bank(b.get("name", ""))}
                elif op == "rename_bank":
                    oats_media.rename_bank(int(b["bank"]), b.get("name", "")); res = {}
                elif op == "move":
                    (fb, fs), (tb, ts) = b["from"], b["to"]
                    oats_media.move(int(fb), int(fs), int(tb), int(ts)); res = {}
                elif op == "remove_bank":
                    oats_media.remove_bank(int(b["bank"])); res = {}
                elif op == "remove":
                    res = {"kept_file": oats_media.remove(int(b["bank"]), int(b["slot"]))}
                else:
                    return self._json(400, {"error": "op must be add_bank, rename_bank, remove_bank, move or remove"})
            except oats_media.MediaError as e:
                return self._json(e.code, {"error": str(e)})
            except (ValueError, KeyError, TypeError, AttributeError) as e:
                return self._json(400, {"error": "bad request: %s" % e})
            send_osc("/oats/library/reload")
            log(f"bins {self.client_address[0]} -> {op} {json.dumps(b)[:200]}")
            return self._json(200, {"ok": True, **res})
        if path in ("/api/genlook", "/api/script"):
            try:
                b = json.loads(raw or b"null")
                if path == "/api/genlook":
                    layer, name = _layer_name(b, "looks")
                    r = subprocess.run([sys.executable, "-I", SCRIPT_PY, "look", name, "--layer", str(layer), "--to", OSC_TO_TEXT],
                                       capture_output=True, text=True, timeout=10)
                    if r.returncode:
                        return self._json(500, {"error": (r.stderr or r.stdout).strip()[:300]})
                    # after the look's params: its name, so status.json gen_look lights the look's button (2026-10-24)
                    send_osc(f"/oats/layers/{layer}/gen/look", [("s", name)])
                    log(f"genlook {self.client_address[0]} -> layer {layer} {name}")
                    return self._json(200, {"ok": True, "layer": layer, "look": name})
                action = b.get("action")
                if action == "stop":
                    layer = int(b["layer"])
                    if not 0 <= layer <= 4:
                        raise ValueError("layer must be 0 (BG) - 4")
                    subprocess.run([sys.executable, "-I", SCRIPT_PY, "stop", "--layer", str(layer)],
                                   capture_output=True, text=True, timeout=10)
                    log(f"script {self.client_address[0]} -> layer {layer} stop")
                    return self._json(200, {"ok": True, "layer": layer, "action": "stop"})
                if action != "run":
                    raise ValueError("action must be run or stop")
                layer, name = _layer_name(b, "scripts")
                with open(os.path.join(LOGS, f"script-layer{layer}.log"), "ab") as lf:
                    p = subprocess.Popen([sys.executable, "-I", SCRIPT_PY, "run", name, "--layer", str(layer), "--to", OSC_TO_TEXT],
                                         stdin=subprocess.DEVNULL, stdout=lf, stderr=subprocess.STDOUT,
                                         cwd=M0_DIR, start_new_session=True)
                with open(os.path.join(LOGS, f"script-layer{layer}.name.json"), "w") as f:
                    json.dump({"pid": p.pid, "name": name}, f)
                log(f"script {self.client_address[0]} -> layer {layer} run {name} (pid {p.pid})")
                return self._json(200, {"ok": True, "layer": layer, "script": name, "pid": p.pid})
            except (ValueError, KeyError, TypeError, AttributeError) as e:
                return self._json(400, {"error": "bad request: %s" % e})
            except (OSError, subprocess.SubprocessError) as e:
                return self._json(500, {"error": str(e)})
        if path == "/api/restart":
            return self._json(*restart_player(self.client_address[0]))
        if path != "/api/osc":
            return self._json(404, {"error": "not found"})
        if not (self.headers.get("Content-Type") or "").startswith("application/json"):
            return self._json(415, {"error": "Content-Type must be application/json"})
        try:
            addr, args = validate_osc(json.loads(raw or b"null"))
        except (ValueError, UnicodeDecodeError) as e:
            return self._json(400, {"error": str(e)})
        try:
            n = send_osc(addr, args)
        except OSError as e:
            return self._json(502, {"error": f"UDP send failed: {e}"})
        shown = " ".join(t if v is None else f"{t}:{v}" for t, v in args)
        log(f"osc {self.client_address[0]} -> {addr} {shown}")
        return self._json(200, {"ok": True, "address": addr, "bytes": n})


_restart_lock = threading.Lock()
_restart_last = [-1e9]                        # time.monotonic() of the last accepted restart


def restart_player(who):
    """Save the look, m0.sh restart, restore it (+ the output display) once the new player is up. Background thread.
    At most one every RESTART_MIN_INTERVAL seconds (each one is a few seconds of black)."""
    if not _restart_lock.acquire(blocking=False):
        return 409, {"error": "a restart is already running"}
    since = time.monotonic() - _restart_last[0]
    if since < RESTART_MIN_INTERVAL:
        _restart_lock.release()
        wait = math.ceil(RESTART_MIN_INTERVAL - since)
        log(f"restart {who}: refused (the last one was {since:.0f} s ago; at most one per {RESTART_MIN_INTERVAL} s)")
        return 429, {"error": f"the player was restarted {since:.0f} s ago: at most one restart per minute, try again in {wait} s"}
    _restart_last[0] = time.monotonic()
    try:
        with open(STATUS_PATH) as f:
            old = json.load(f)
    except (OSError, ValueError) as e:
        _restart_lock.release()
        return 503, {"error": f"no player status ({e})"}
    saved = os.path.join(LOGS, "restart-state.json")
    py, state = sys.executable, os.path.join(M0_DIR, "tools", "oats_state.py")

    def run():
        try:
            subprocess.run([py, "-I", state, "save", saved], capture_output=True, timeout=10)
            r = subprocess.run([os.path.join(M0_DIR, "m0.sh"), "restart"], capture_output=True, text=True, timeout=20)
            log(f"restart {who}: {(r.stdout or r.stderr).strip()[-200:]}")
            t0 = time.time()
            while time.time() - t0 < 30:
                time.sleep(0.5)
                try:
                    with open(STATUS_PATH) as f:
                        st = json.load(f)
                except (OSError, ValueError):
                    continue
                if st.get("pid") != old.get("pid") and st.get("render_running") and st.get("fps", 0) > 1:
                    break
            time.sleep(1.0)
            r = subprocess.run([py, "-I", state, "restore", saved, "--to", "%s:%d" % OSC_TO], capture_output=True, text=True, timeout=30)
            log(f"restart {who}: {(r.stdout or r.stderr).strip()[-200:]}")
        except (OSError, subprocess.SubprocessError) as e:
            log(f"restart {who} FAILED: {e}")
        finally:
            _restart_lock.release()
    threading.Thread(target=run, daemon=True).start()
    return 200, {"ok": True, "note": "restarting the player (a few seconds of black); the look and the output window come back by themselves"}


_conn_sem = threading.BoundedSemaphore(MAX_CONNS)    # shared by every listener


class Server(http.server.ThreadingHTTPServer):
    """One listening socket (127.0.0.1 or en0's address). Sources that are not allowed are refused right after
    accept(), before anything is read; at most MAX_CONNS connections are served at once (shared by all listeners)."""
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32
    refused = 0

    def verify_request(self, request, client_address):
        host = client_address[0]
        if ALLOW.allows(host):
            return True
        ALLOW.note_reject(host, "connection")
        try:
            request.setblocking(False)
            body = FORBIDDEN_MSG.encode()
            request.send(b"HTTP/1.1 403 Forbidden\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: %d\r\n"
                         b"Connection: close\r\n\r\n%s" % (len(body), body))
        except OSError:
            pass
        return False

    def process_request(self, request, client_address):
        if not _conn_sem.acquire(blocking=False):      # connection flood: close at once, no thread
            Server.refused += 1
            if Server.refused in (1, 10, 100) or Server.refused % 1000 == 0:
                log(f"connection limit ({MAX_CONNS}) reached: refused {Server.refused} so far (last from {client_address[0]})")
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            _conn_sem.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            request.settimeout(CONN_TIMEOUT)
            super().process_request_thread(request, client_address)
        finally:
            _conn_sem.release()


class Listeners:
    """127.0.0.1:PORT always, plus en0's address:PORT, re-bound when en0's address appears or changes (checked
    every 5 s). OATS_GUI_BIND=<address> listens on that one address only."""

    def __init__(self):
        self.lock = threading.Lock()
        self.srv = {}                              # address -> Server

    def _start(self, addr):
        try:
            srv = Server((addr, PORT), Handler)
        except OSError as e:
            log(f"cannot listen on {addr}:{PORT}: {e}")
            return False
        threading.Thread(target=srv.serve_forever, kwargs={"poll_interval": 0.5}, daemon=True,
                         name=f"http-{addr}").start()
        with self.lock:
            self.srv[addr] = srv
        log(f"listening on http://{addr}:{PORT}")
        return True

    def _stop(self, addr):
        with self.lock:
            srv = self.srv.pop(addr, None)
        if srv:
            srv.shutdown()
            srv.server_close()
            log(f"stopped listening on {addr}:{PORT}")

    def bound(self):
        with self.lock:
            return [f"{a}:{PORT}" for a in self.srv]

    def run(self):
        """Blocks: keeps the listeners in step with en0."""
        if BIND != "auto":
            if not self._start(BIND):
                sys.exit(1)
            while True:
                time.sleep(3600)
        if not self._start("127.0.0.1"):
            sys.exit(1)
        cur, warned = None, False
        while True:
            ip = EN0.get(max_age=0)
            if ip != cur:
                if cur:
                    self._stop(cur)
                cur = None
                if ip:
                    if self._start(ip):
                        cur, warned = ip, False
                elif not warned:
                    warned = True
                    log("en0 has no IPv4 address: listening on 127.0.0.1 only for now; retrying en0 every 5 s (never 0.0.0.0)")
            time.sleep(5)


LISTENERS = Listeners()


def main():
    try:                                              # logs hold addresses and OSC history: this user only
        os.chmod(RUN_DIR, 0o700)
        p = _log_path()
        if p:
            os.chmod(p, 0o600)
    except OSError:
        pass
    log(f"VJ VIZZIES GUI v0 on port {PORT} ({'127.0.0.1 + en0' if BIND == 'auto' else BIND}; OSC to {OSC_TO[0]}:{OSC_TO[1]}, "
        f"PIN {'on' if PIN else 'off'}, pid {os.getpid()}); Host must be one of: {host_names_text()}")
    for line in ALLOW.describe():
        log(line)
    try:
        LISTENERS.run()
    except KeyboardInterrupt:
        pass
    finally:
        log("stopped")


if __name__ == "__main__":
    main()
