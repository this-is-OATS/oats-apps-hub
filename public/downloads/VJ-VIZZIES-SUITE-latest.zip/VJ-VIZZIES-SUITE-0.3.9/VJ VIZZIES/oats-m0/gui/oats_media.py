"""Clip bins for the GUI (Resolume-style): banks = bins, slots = cells. Edits ../media/library.json (the same file the
player and tools/make_library.swift use), stores uploads in media/bank<N>-<NAME>/, makes thumbnails with ffmpeg
(media/.thumbs/), and tells the player to reload the library (/oats/library/reload). Stdlib only.

Bank and slot numbers are exactly the DMX Layer 16 bank (ch 2) / slot (ch 3) values and the OSC
/oats/layers/{n}/play i bank i slot numbers. Removing a slot only removes it from library.json: the file stays on disk.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import threading
import time

MEDIA_DIR = os.path.realpath(os.path.expanduser(os.environ.get("OATS_MEDIA", "~/Developer/oats-viz/media")))
LIBRARY_PATH = os.path.join(MEDIA_DIR, "library.json")
THUMBS = os.path.join(MEDIA_DIR, ".thumbs")
MAX_UPLOAD = 4 * 1024 ** 3
FREE_RESERVE = 2 * 1024 ** 3             # an upload must leave 2 GB free (status.json, scenes, logs, macOS itself)
VIDEO_EXT = {".mov", ".mp4", ".m4v"}
STILL_EXT = {".png", ".jpg", ".jpeg"}
STILL_SECONDS = 10                       # a still becomes a 10 s H.264 loop (the player plays video only)
MAX_SLOT = 255

LOCK = threading.Lock()
_thumb_sem = threading.Semaphore(2)


def _tool(name):
    for d in ("/opt/homebrew/bin", "/usr/local/bin", "/usr/bin"):
        p = os.path.join(d, name)
        if os.access(p, os.X_OK):
            return p
    return shutil.which(name)


FFMPEG, FFPROBE = _tool("ffmpeg"), _tool("ffprobe")


class MediaError(Exception):
    def __init__(self, code, msg):
        super().__init__(msg)
        self.code = code


def load():
    with open(LIBRARY_PATH) as f:
        j = json.load(f)
    if not isinstance(j.get("banks"), list):
        raise MediaError(500, "library.json has no banks list")
    return j


def save(j):
    for b in j["banks"]:
        b["slots"].sort(key=lambda s: s["slot"])
    j["banks"].sort(key=lambda b: b["bank"])
    tmp = LIBRARY_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(j, f, indent=2, sort_keys=True)
    os.replace(tmp, LIBRARY_PATH)


def _bank(j, n):
    for b in j["banks"]:
        if b.get("bank") == n:
            return b
    raise MediaError(404, "no bank %s" % n)


def safe_name(s, maxlen=60):
    s = re.sub(r"[^A-Za-z0-9._ -]+", "_", str(s)).strip(" ._-")
    return (s or "clip")[:maxlen]


def _inside(path):
    rp = os.path.realpath(path)
    return rp == MEDIA_DIR or rp.startswith(MEDIA_DIR + os.sep)


def bank_dir(b):
    """The folder of a bank: the folder its first clip lives in, else bank<N>-<NAME>."""
    for s in b.get("slots", []):
        d = os.path.dirname(s.get("file", ""))
        if d:
            return d
    return "bank%d-%s" % (b["bank"], safe_name(b.get("name", ""), 24).replace(" ", "_").upper())


def add_bank(name):
    name = safe_name(name, 24).upper()
    if not name:
        raise MediaError(400, "bank name required")
    with LOCK:
        j = load()
        used = {b["bank"] for b in j["banks"]}
        n = next(i for i in range(1, 256) if i not in used)
        b = {"bank": n, "name": name, "slots": []}
        j["banks"].append(b)
        os.makedirs(os.path.join(MEDIA_DIR, bank_dir(b)), exist_ok=True)
        save(j)
    return n


def rename_bank(n, name):
    with LOCK:
        j = load()
        _bank(j, n)["name"] = safe_name(name, 24).upper()
        save(j)


def remove_bank(n):
    """Removes an EMPTY bank from library.json (its folder stays)."""
    with LOCK:
        j = load()
        b = _bank(j, n)
        if b["slots"]:
            raise MediaError(409, "bank %d is not empty" % n)
        j["banks"].remove(b)
        save(j)


def probe(path):
    """(duration_s, fps, width, height, vcodec) via ffprobe; raises MediaError if there is no video stream."""
    if not FFPROBE:
        raise MediaError(500, "ffprobe not found")
    r = subprocess.run([FFPROBE, "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "stream=codec_name,width,height,avg_frame_rate,r_frame_rate:stream_tags=rotate:stream_side_data=rotation:format=duration",
                        "-of", "json", path], capture_output=True, text=True, timeout=60)
    try:
        j = json.loads(r.stdout or "{}")
        st = j["streams"][0]
    except (ValueError, KeyError, IndexError):
        raise MediaError(415, "no video stream (ffprobe: %s)" % (r.stderr.strip()[:200] or "nothing"))
    def rate(x):
        try:
            a, b = x.split("/")
            return float(a) / float(b) if float(b) else 0.0
        except (ValueError, AttributeError):
            return 0.0
    fps = rate(st.get("avg_frame_rate")) or rate(st.get("r_frame_rate"))
    w, h = int(st.get("width") or 0), int(st.get("height") or 0)
    rot = 0
    for sd in st.get("side_data_list", []) or []:
        if "rotation" in sd:
            rot = int(sd["rotation"])
    if abs(rot) % 180 == 90:
        w, h = h, w
    dur = float(j.get("format", {}).get("duration") or 0)
    return round(dur, 3), round(fps, 3), w, h, st.get("codec_name", "")


def still_to_video(src, dst):
    if not FFMPEG:
        raise MediaError(500, "ffmpeg not found (needed for stills)")
    r = subprocess.run([FFMPEG, "-v", "error", "-y", "-loop", "1", "-i", src, "-t", str(STILL_SECONDS), "-r", "30",
                        "-vf", "scale='min(1920,iw)':-2:force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2",
                        "-pix_fmt", "yuv420p", "-c:v", "h264_videotoolbox", "-b:v", "8M", "-movflags", "+faststart", dst],
                       capture_output=True, text=True, timeout=300)
    if r.returncode != 0 or not os.path.exists(dst):
        raise MediaError(415, "could not convert the still: " + r.stderr.strip()[:200])


def thumb_path(rel):
    return os.path.join(THUMBS, hashlib.sha1(rel.encode()).hexdigest()[:16] + ".jpg")


def make_thumb(rel, force=False):
    """Thumbnail (192 px wide JPEG, 1 s in or the first frame) of a library file; returns its path or None."""
    src = os.path.join(MEDIA_DIR, rel)
    out = thumb_path(rel)
    if not force and os.path.exists(out) and os.path.getmtime(out) >= os.path.getmtime(src):
        return out
    if not FFMPEG or not _inside(src) or not os.path.exists(src):
        return None
    os.makedirs(THUMBS, exist_ok=True)
    with _thumb_sem:
        tmp = out + ".tmp.jpg"
        for ss in ("1", "0"):
            r = subprocess.run([FFMPEG, "-v", "error", "-y", "-ss", ss, "-i", src, "-frames:v", "1", "-vf", "scale=192:-2", "-q:v", "5", tmp],
                               capture_output=True, timeout=60)
            if r.returncode == 0 and os.path.exists(tmp) and os.path.getsize(tmp) > 0:
                os.replace(tmp, out)
                return out
    return None


def thumb_for(bank, slot):
    with LOCK:
        j = load()
        s = next((x for x in _bank(j, bank)["slots"] if x["slot"] == slot), None)
    if not s:
        raise MediaError(404, "empty slot")
    p = make_thumb(s["file"])
    if not p:
        raise MediaError(404, "no thumbnail")
    return p


def upload(bank, slot, filename, rfile, length):
    """Streams `length` bytes from rfile into the bank's folder, then adds it at `slot` (0 = first free slot).
    Returns the new slot record."""
    if length <= 0 or length > MAX_UPLOAD:
        raise MediaError(413, "file size must be 1 byte .. 4 GB")
    free = shutil.disk_usage(MEDIA_DIR).free
    if free < FREE_RESERVE + length * (2 if os.path.splitext(filename or "")[1].lower() in STILL_EXT else 1):
        raise MediaError(507, "not enough disk space: %.1f GB free, this upload needs %.1f GB plus 2 GB kept free"
                         % (free / 1024 ** 3, length / 1024 ** 3))
    base, ext = os.path.splitext(os.path.basename(filename or ""))
    ext = ext.lower()
    if ext not in VIDEO_EXT | STILL_EXT:
        raise MediaError(415, "only .mov .mp4 .m4v (video) or .png .jpg (still)")
    with LOCK:
        j = load()
        b = _bank(j, bank)
        folder = bank_dir(b)
    d = os.path.join(MEDIA_DIR, folder)
    os.makedirs(d, exist_ok=True)
    stem = safe_name(base)
    final_ext = ".mp4" if ext in STILL_EXT else ext
    target = os.path.join(d, stem + final_ext)
    i = 2
    while os.path.exists(target):
        target = os.path.join(d, "%s-%d%s" % (stem, i, final_ext)); i += 1
    if not _inside(target):
        raise MediaError(400, "bad file name")
    part = target + ".part" + ext
    left = length
    try:
        with open(part, "wb") as f:
            while left > 0:
                chunk = rfile.read(min(1 << 20, left))
                if not chunk:
                    raise MediaError(400, "upload cut short (%d bytes missing)" % left)
                f.write(chunk)
                left -= len(chunk)
        if ext in STILL_EXT:
            still_to_video(part, target)
            os.remove(part)
        else:
            os.replace(part, target)
        dur, fps, w, h, vc = probe(target)
    except BaseException:
        for p in (part, target):                              # target did not exist before: both are ours
            try:
                if os.path.exists(p):
                    os.remove(p)
            except OSError:
                pass
        raise
    rel = os.path.relpath(target, MEDIA_DIR)
    rec = {"slot": 0, "name": safe_name(base.replace("-", " ").replace("_", " "), 60), "file": rel, "duration_s": dur,
           "fps": fps, "width": w, "height": h, "vcodec": vc}
    with LOCK:
        j = load()
        b = _bank(j, bank)
        used = {s["slot"] for s in b["slots"]}
        if slot <= 0 or slot > MAX_SLOT:
            slot = next((k for k in range(1, MAX_SLOT + 1) if k not in used), 0)
            if not slot:
                raise MediaError(409, "bank is full")
        elif slot in used:                                   # an occupied slot: the old clip moves to the first free one
            free = next((k for k in range(1, MAX_SLOT + 1) if k not in used), 0)
            for s in b["slots"]:
                if s["slot"] == slot:
                    s["slot"] = free
            if not free:
                b["slots"] = [s for s in b["slots"] if s["slot"]]
        rec["slot"] = slot
        b["slots"].append(rec)
        save(j)
    make_thumb(rel)
    return dict(rec, bank=bank)


def move(fb, fs, tb, ts):
    """Moves slot (fb, fs) to (tb, ts); a clip already at the target swaps into the source's place."""
    if not (1 <= ts <= MAX_SLOT):
        raise MediaError(400, "slot must be 1..255")
    with LOCK:
        j = load()
        a, b = _bank(j, fb), _bank(j, tb)
        src = next((s for s in a["slots"] if s["slot"] == fs), None)
        if not src:
            raise MediaError(404, "empty source slot")
        dst = next((s for s in b["slots"] if s["slot"] == ts), None)
        a["slots"].remove(src)
        if dst:
            b["slots"].remove(dst)
            dst["slot"] = fs
            a["slots"].append(dst)
        src["slot"] = ts
        b["slots"].append(src)
        save(j)


def remove(bank, slot):
    """Removes the slot from the bin (library.json only); the file stays on disk."""
    with LOCK:
        j = load()
        b = _bank(j, bank)
        s = next((x for x in b["slots"] if x["slot"] == slot), None)
        if not s:
            raise MediaError(404, "empty slot")
        b["slots"].remove(s)
        save(j)
    return s["file"]
