#!/bin/bash
# VJ VIZZIES GUI v0: start/stop the control-window web server in the background.
#   gui/run.sh          start (nohup, pidfile gui/run/gui.pid, log gui/run/gui.log)
#   gui/run.sh stop     stop it
#   gui/run.sh status   is it running, and the URLs
# Environment: OATS_GUI_PIN (optional PIN), OATS_GUI_PORT (8090), OATS_GUI_BIND (0.0.0.0)
set -u
GUI_DIR="$(cd "$(dirname "$0")" && pwd)"
RUN_DIR="$GUI_DIR/run"
PIDFILE="$RUN_DIR/gui.pid"
LOG="$RUN_DIR/gui.log"
PORT="${OATS_GUI_PORT:-8090}"
mkdir -p "$RUN_DIR"

running_pid() {
  [ -f "$PIDFILE" ] || return 1
  local pid; pid="$(cat "$PIDFILE" 2>/dev/null)"
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null || { rm -f "$PIDFILE"; return 1; }
  ps -p "$pid" -o command= 2>/dev/null | grep -q "gui/server.py" || { rm -f "$PIDFILE"; return 1; }
  echo "$pid"
}

urls() {
  local ip; ip="$(ipconfig getifaddr en0 2>/dev/null)"
  echo "  http://localhost:$PORT"
  echo "  http://${ip:-192.168.1.148}:$PORT   (phone/laptop on your LAN)"
  [ -n "${OATS_GUI_PIN:-}" ] && echo "  PIN is on"
  return 0
}

case "${1:-start}" in
  start)
    if pid="$(running_pid)"; then echo "GUI already running (pid $pid)"; urls; exit 0; fi
    nohup python3 -I "$GUI_DIR/server.py" >>"$LOG" 2>&1 </dev/null &
    echo $! >"$PIDFILE"
    for _ in 1 2 3 4 5 6 7 8 9 10; do
      sleep 0.2
      if ! running_pid >/dev/null; then echo "GUI failed to start; last log lines:"; tail -n 5 "$LOG"; exit 1; fi
      curl -fs -o /dev/null "http://127.0.0.1:$PORT/api/status" 2>/dev/null && break
    done
    echo "GUI started (pid $(cat "$PIDFILE")), log $LOG"
    urls ;;
  stop)
    if ! pid="$(running_pid)"; then echo "GUI not running"; exit 0; fi
    kill "$pid"
    for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do kill -0 "$pid" 2>/dev/null || break; sleep 0.2; done
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid"
    rm -f "$PIDFILE"; echo "GUI stopped" ;;
  status)
    if pid="$(running_pid)"; then echo "GUI running (pid $pid)"; urls; else echo "GUI not running"; exit 1; fi ;;
  *) echo "usage: $0 [start|stop|status]"; exit 64 ;;
esac
