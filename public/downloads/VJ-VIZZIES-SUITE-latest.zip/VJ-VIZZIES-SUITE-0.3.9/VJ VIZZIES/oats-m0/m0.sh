#!/bin/zsh
# oats-m0 run script (PLAN 13.1). Subcommands:
#   build [--x86]                 compile bin/oats-m0 (native arm64; --x86 = the old x86_64 build for Rosetta) and the NDI helper
#                                 bin/oats-ndi (x86_64). Command Line Tools only; OATS_BUILD_OUT=FILE / OATS_NDI_OUT=FILE build
#                                 elsewhere (also while running); OATS_BUILD_ONLY=player|helper builds one of them
#   start [--test] [--gate] [args] start the restart loop in the background
#   stop                          stop the loop and the program (SIGTERM, wait up to 5 s)
#   restart                       SIGTERM the program only; the loop starts it again
#   status                        status.json, running state, NDI pin, en0 address and rate, UDP port holders
#   pin-check <bogus-IP>          check that NDI_CONFIG_DIR + adapters.allowed pins NDI to one adapter
#   net                           en0 address/mask/router, Wi-Fi power, route to the PC, en0 bytes
#   link [start|stop|restart|status] the Ableton Link helper bin/oats-link (own restart loop; `start` starts it too)
#   ndi [start|stop|restart|status]  the NDI helper bin/oats-ndi (x86_64 under Rosetta, own restart loop; `start` starts
#                                 it too when Rosetta is installed; it idles until the player is in NDI helper mode)
# The program's own log is logs/oats-m0-<stamp>.log; the loop logs to logs/loop.log.
emulate -L zsh
setopt no_unset pipe_fail

M=${0:A:h}
BIN=$M/bin/oats-m0
LOGS=$M/logs
RUN=$M/run
NDICFG=$M/ndi-config
LOOPPID=$RUN/loop.pid
CHILDPID=$RUN/oats-m0.pid
STOPFILE=$RUN/stop
RESTARTFILE=$RUN/restart
LOOPLOG=$LOGS/loop.log
LINKBIN=$M/bin/oats-link                  # Ableton Link -> OSC helper (../link-helper, native arm64, GPL)
LINKLOOPPID=$RUN/link-loop.pid
LINKPID=$RUN/oats-link.pid
LINKSTOP=$RUN/link-stop
LINKLOG=$LOGS/oats-link.log
NDIBIN=$M/bin/oats-ndi                    # NDI helper (x86_64, libndi under Rosetta; src/ndihelper.swift)
NDILOOPPID=$RUN/ndi-loop.pid
NDIPID=$RUN/oats-ndi.pid
NDISTOP=$RUN/ndi-stop
NDILOG=$LOGS/oats-ndi-loop.log
BENCH_RECV="$M/../ndi-bench/bin/receiver"
PC_IP=${OATS_PC_IP:-192.168.1.141}        # previs PC, static since 2026-10-21
mkdir -p $LOGS $RUN
[[ -f $M/m0.env ]] && source $M/m0.env   # OATS_NDI_MACHINE / OATS_NDI_IF for this install (written by install.sh)

ts() { date '+%Y-%m-%d %H:%M:%S' }
now_ms() { python3 -I -c 'import datetime; print(datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3])' }
alive() { [[ -n "${1:-}" ]] && kill -0 $1 2>/dev/null }
readpid() { [[ -f $1 ]] && cat $1 2>/dev/null || true }
# A pid from a pidfile is trusted only if that process is really ours (pidfiles survive SIGKILL and power cuts).
isloop()  { alive "${1:-}" && ps -o command= -p $1 2>/dev/null | grep -q "m0.sh _loop" }
ischild() { alive "${1:-}" && ps -o command= -p $1 2>/dev/null | grep -qF "$BIN" }
islinkloop() { alive "${1:-}" && ps -o command= -p $1 2>/dev/null | grep -q "m0.sh _linkloop" }
islink()  { alive "${1:-}" && ps -o command= -p $1 2>/dev/null | grep -qF "$LINKBIN" }
isndiloop() { alive "${1:-}" && ps -o command= -p $1 2>/dev/null | grep -q "m0.sh _ndiloop" }
isndi()   { alive "${1:-}" && ps -o command= -p $1 2>/dev/null | grep -qF "$NDIBIN" }
rosetta() { [[ $(uname -m) == x86_64 || -e /Library/Apple/usr/libexec/oah/libRosettaRuntime ]] }   # Intel: x86_64 binaries are native, nothing to install
# how to run the player binary: natively when it has an arm64 slice, else under Rosetta (an old --x86 build)
# Architecture of a binary via /usr/bin/file (lipo is an Xcode shim: under launchd it printed nothing on 2026-10-24,
# and an empty answer used to mean "run under Rosetta", which crash-looped a native build). Prints arm64 / x86_64 / both.
binarch() { local f=$(file -b "$1" 2>/dev/null); case $f in *arm64*x86_64*|*x86_64*arm64*) print arm64+x86_64 ;; *arm64*) print arm64 ;; *x86_64*) print x86_64 ;; *) print unknown ;; esac }
runner() { if [[ $(binarch $BIN) == *arm64* ]]; then print -r -- ""; else print -r -- "arch -x86_64"; fi }
# checked_pid <pidfile> <isloop|ischild>: prints the pid if it is ours; removes a stale pidfile.
checked_pid() {
  local p=$(readpid $1)
  [[ -z $p ]] && return 0
  if $2 $p; then print -r -- $p; else rm -f $1; echo "stale pidfile removed: ${1:t} (pid $p is not $2)" >&2; fi
}
# en0's IPv4; a self-assigned 169.254.x.x (no DHCP answer) counts as none.
en0ip() { local ip=$(ipconfig getifaddr ${OATS_NDI_IF:-en0} 2>/dev/null); [[ $ip == 169.254.* ]] && ip=""; print -r -- "$ip" }

# write_ndi_config <dir> <ip> [probe]: copy of ~/.ndi/ndi-config.v1.json (if present) with
# ndi.adapters.allowed = [ip] (OATS_NDI_ALLOWED_FORM=array, the default) or "ip" (=string).
# probe: also sets ndi.machinename/machineName, so pin-check can see that libndi read this folder.
# Without a probe the machine name is pinned to OATS_NDI_MACHINE or OBS.HOST (renamed from MAC.LOCALDOMAIN on
# 2026-10-25 at the user's request; receivers such as Vision on the PC must re-pick "OBS.HOST (OATS VIZ Program)").
# HostName is unset, so the hostname libndi would otherwise use follows DHCP (it has been OBSHOST.LOCAL,
# OBSHOST.LOCALDOMAIN and Mac.localdomain), and every change loses the source in receivers that select by name.
write_ndi_config() {
  mkdir -p $1 || return 1
  local mname=${OATS_NDI_MACHINE:-OBS.HOST}
  python3 -I - "$HOME/.ndi/ndi-config.v1.json" "$1/ndi-config.v1.json" "$2" "${OATS_NDI_ALLOWED_FORM:-array}" "${3:-}" "$mname" <<'EOF'
import json, os, sys
src, dst, ip, form, probe, mach = sys.argv[1:7]
cfg = {}
if os.path.exists(src):
    try:
        with open(src) as f:
            cfg = json.load(f)
    except Exception as e:
        print(f"warning: could not read {src}: {e}; starting from an empty config", file=sys.stderr)
        cfg = {}
if not isinstance(cfg, dict):
    cfg = {}
ndi = cfg.setdefault("ndi", {})
if not isinstance(ndi, dict):
    ndi = cfg["ndi"] = {}
ad = ndi.setdefault("adapters", {})
if not isinstance(ad, dict):
    ad = ndi["adapters"] = {}
ad["allowed"] = [ip] if form == "array" else ip
if probe or mach:
    ndi["machinename"] = probe or mach
    ndi["machineName"] = probe or mach
tmp = dst + ".tmp"
with open(tmp, "w") as f:
    json.dump(cfg, f, indent=2)
os.replace(tmp, dst)
print(f"NDI config {dst}: ndi.adapters.allowed = {json.dumps(ad['allowed'])} ({form} form)"
      + (f", machinename probe {probe!r}" if probe else f", machinename {mach!r}" if mach else ""))
EOF
}

# wait_load_gate <loop|stdout> <honour-stop-file 1|0>: wait until the 1-min load is 8 or less
# (PLAN 13.1: runs start only then), polling every 30 s, at most 15 min, then start anyway and say so.
wait_load_gate() {
  local where=$1 honour=$2 waited=0 load msg
  glog() { if [[ $where == loop ]]; then echo "$(ts) $1" >> $LOOPLOG; else echo "$(ts) $1"; fi }
  while true; do
    load=$(sysctl -n vm.loadavg | awk '{print $2}')
    if (( load <= 8.0 )); then glog "load gate: 1-min load $load <= 8, starting ($(sysctl -n vm.swapusage | awk '{print "swap used " $6}'))"; return 0; fi
    if (( waited >= 900 )); then glog "load gate: still $load after 15 min, starting anyway"; return 0; fi
    if (( honour )) && [[ -f $STOPFILE ]]; then glog "stop file during load gate"; return 1; fi
    glog "load gate: 1-min load $load > 8, waiting 30 s"
    sleep 30; (( waited += 30 ))
  done
}

cmd_build() {
  local x86=0
  [[ ${1:-} == --x86 ]] && x86=1
  local lp=$(checked_pid $LOOPPID isloop)
  if [[ -n $lp && -z ${OATS_BUILD_OUT:-} && ${OATS_BUILD_ONLY:-} != helper ]]; then
    echo "oats-m0 loop is running (pid $lp): ./m0.sh stop first, or build to a temp file with OATS_BUILD_OUT=bin/oats-m0.new (the loop would start the new binary on its next restart)" >&2; exit 1
  fi
  cd $M || exit 1
  local free_mb=$(df -m / | awk 'NR==2 {print $4}')
  if (( free_mb < 600 )); then
    echo "Only ${free_mb} MB free on / - free some space first (the module cache alone is ~320 MB)." >&2
    exit 1
  fi
  local mc=${OATS_MC:-./mc}
  trap "rm -rf $mc" EXIT INT TERM                      # never leave the ~320 MB module cache behind
  mkdir -p bin
  local rc=0
  if [[ ${OATS_BUILD_ONLY:-} != helper ]]; then
    local -a srcs=(src/common.swift src/ndi.swift src/log.swift src/state.swift src/shaders.swift src/osc.swift \
                   src/sacn.swift src/dmx.swift src/preview.swift src/deep.swift src/layers.swift src/gen.swift src/playback.swift src/scenes.swift src/fx.swift src/testcard.swift src/analysis.swift \
                   src/ndiring.swift src/ndiout.swift src/ndiin.swift src/phasers.swift src/audio.swift src/engine.swift src/watchdog.swift src/mapping.swift src/output.swift src/recorder.swift src/status.swift src/app.swift)
    local target=arm64-apple-macos14 an=arm64
    (( x86 )) && { target=x86_64-apple-macos14; an="x86_64 (--x86: runs under Rosetta)"; }
    echo "$(ts) building bin/oats-m0 ($an) ..."
    swiftc -O -swift-version 5 -parse-as-library -target $target -module-cache-path $mc \
      -import-objc-header src/ndi_min.h $srcs \
      -framework Metal -framework CoreGraphics -framework ImageIO -framework AVFoundation -framework CoreVideo -framework CoreMedia -framework AppKit -framework QuartzCore -framework CoreImage -framework CoreText -framework Accelerate -framework CoreAudio -framework AudioToolbox -framework IOKit -o "${OATS_BUILD_OUT:-bin/oats-m0}"
    rc=$?
    if (( rc != 0 )); then rm -rf $mc; echo "$(ts) BUILD FAILED (oats-m0, exit $rc)" >&2; exit $rc; fi
    local out=${OATS_BUILD_OUT:-bin/oats-m0}
    echo "$(ts) built $(binarch $out) $out ($(stat -f %z $out) bytes)"
  fi
  if [[ ${OATS_BUILD_ONLY:-} != player ]]; then
    local nout=${OATS_NDI_OUT:-bin/oats-ndi}
    echo "$(ts) building $nout (x86_64 NDI helper, runs under Rosetta) ..."
    swiftc -O -swift-version 5 -parse-as-library -target x86_64-apple-macos14 -module-cache-path $mc \
      -import-objc-header src/ndi_min.h src/common.swift src/log.swift src/ndi.swift src/ndiring.swift src/ndihelper.swift -o "$nout.tmp"
    rc=$?
    if (( rc != 0 )); then rm -rf $mc "$nout.tmp"; echo "$(ts) BUILD FAILED (oats-ndi, exit $rc)" >&2; exit $rc; fi
    codesign -s - -f "$nout.tmp" 2>/dev/null || echo "$(ts) warning: ad-hoc signing $nout failed" >&2   # x86_64 links unsigned; sign it like the others
    mv -f "$nout.tmp" "$nout"                        # rename: a running helper keeps its old file
    echo "$(ts) built $(binarch $nout) $nout ($(stat -f %z $nout) bytes)"
  fi
  rm -rf $mc
  echo "module cache removed. The player runs natively; the helper's first start takes a few seconds (Rosetta translation)"
}

# The restart loop (runs in the background, started by `start`).
cmd__loop() {
  local gate=$1; shift
  local -a args=("$@")
  local n=0 child code ip
  local -a recent=()
  trap 'touch $STOPFILE; OATS_TRAP_C=$(readpid $CHILDPID); ischild $OATS_TRAP_C && kill -TERM $OATS_TRAP_C' TERM INT
  echo "$(ts) loop started pid=$$ args: ${args[*]}" >> $LOOPLOG
  if [[ $gate == 1 ]]; then
    wait_load_gate loop 1 || { echo "$(ts) loop ends" >> $LOOPLOG; rm -f $LOOPPID; return 0; }
  fi
  while true; do
    [[ -f $STOPFILE ]] && { echo "$(ts) stop file present, loop ends" >> $LOOPLOG; break; }
    ip=$(en0ip)
    if [[ -z $ip ]]; then
      echo "$(ts) en0 has no usable IPv4 address (none, or self-assigned 169.254.x.x): cannot pin NDI to the cable; retrying in 5 s" >> $LOOPLOG
      sleep 5; continue
    fi
    if ! write_ndi_config $NDICFG $ip >> $LOOPLOG 2>&1; then
      echo "$(ts) cannot write $NDICFG/ndi-config.v1.json: NOT starting unpinned; retry in 5 s" >> $LOOPLOG
      sleep 5; continue
    fi
    [[ -f $STOPFILE ]] && { echo "$(ts) stop file present, loop ends" >> $LOOPLOG; break; }
    export NDI_CONFIG_DIR=$NDICFG
    # stdout is the same text as the program's own log file: keep only stderr (dyld, Rosetta, crash text).
    # Native arm64 when the binary has that slice (since 2026-10-22), else under Rosetta (an old --x86 build).
    local -a run=(${=$(runner)})
    # a restart by this loop (watchdog exit 75, crash, `m0.sh restart`) passes --restart: no startup test card
    local -a again=(); (( n > 0 )) && again=(--restart)
    $run $BIN --log-dir $LOGS "${args[@]}" $again > /dev/null 2>> $LOGS/console.err < /dev/null &
    child=$!
    echo $child > $CHILDPID
    echo "$(ts) started oats-m0 pid=$child (${run[*]:-native} $(binarch $BIN); en0 $ip, NDI_CONFIG_DIR=$NDICFG)" >> $LOOPLOG
    wait $child; code=$?
    # `wait` returns early when the trap fires; wait again for the real exit
    while alive $child; do wait $child; code=$?; done
    rm -f $CHILDPID
    if [[ -f $STOPFILE ]]; then echo "$(ts) oats-m0 exited $code after stop request, loop ends" >> $LOOPLOG; break; fi
    if (( code == 0 )) && [[ ! -f $RESTARTFILE ]]; then echo "$(ts) oats-m0 exited 0, loop ends" >> $LOOPLOG; break; fi
    if (( code == 2 || code == 64 || code == 78 )); then
      echo "$(ts) oats-m0 exited $code (refused / bad arguments / config error): NOT restarting, loop ends" >> $LOOPLOG; break
    fi
    (( n += 1 ))
    local why="exit code $code"
    (( code == 75 )) && why="watchdog stall exit 75"
    (( code > 128 )) && why="killed by signal $((code - 128))"
    [[ -f $RESTARTFILE ]] && { why="restart requested (exit $code)"; rm -f $RESTARTFILE; }
    echo "$(ts) RESTART #$n at $(date '+%H:%M:%S') ($why)" >> $LOOPLOG
    # crash-loop guard: more than 10 restarts in 60 s -> wait 10 s instead of 0.5 s
    local now=$(date +%s)
    recent=(${recent[@]} $now)
    local -a keep=()
    for t in $recent; do (( now - t <= 60 )) && keep+=($t); done
    recent=($keep)
    if (( ${#recent} > 10 )); then echo "$(ts) crash loop: ${#recent} restarts in 60 s, waiting 10 s" >> $LOOPLOG; sleep 10; else sleep 0.5; fi
  done
  rm -f $LOOPPID $CHILDPID
  echo "$(ts) loop exit" >> $LOOPLOG
}

# The Link helper's own restart loop: runs bin/oats-link (follow only), restarts it 1 s after it dies, ends on the
# link-stop file (m0.sh link stop / m0.sh stop).
cmd__linkloop() {
  local child code
  trap 'touch $LINKSTOP; OATS_TRAP_C=$(readpid $LINKPID); islink $OATS_TRAP_C && kill -TERM $OATS_TRAP_C' TERM INT
  echo "$(ts) link loop started pid=$$" >> $LINKLOG
  while [[ ! -f $LINKSTOP ]]; do
    $LINKBIN "$@" >> $LINKLOG 2>&1 < /dev/null &
    child=$!; echo $child > $LINKPID
    wait $child; code=$?
    while alive $child; do wait $child; code=$?; done
    rm -f $LINKPID
    [[ -f $LINKSTOP ]] && break
    echo "$(ts) oats-link exited $code: restarting in 1 s" >> $LINKLOG
    (( code == 64 )) && { echo "$(ts) bad arguments: link loop ends" >> $LINKLOG; break; }
    sleep 1
  done
  rm -f $LINKLOOPPID $LINKPID
  echo "$(ts) link loop exit" >> $LINKLOG
}

# The NDI helper's restart loop: runs bin/oats-ndi under Rosetta with the pinned NDI config, restarts it 1 s after it
# dies (10 s if more than 10 restarts in 60 s), ends on the ndi-stop file. The helper idles until the player asks for it.
cmd__ndiloop() {
  local key=$1 child code ip
  local -a recent=()
  trap 'touch $NDISTOP; OATS_TRAP_C=$(readpid $NDIPID); isndi $OATS_TRAP_C && kill -TERM $OATS_TRAP_C' TERM INT
  echo "$(ts) ndi loop started pid=$$ key=$key" >> $NDILOG
  while [[ ! -f $NDISTOP ]]; do
    ip=$(en0ip)
    if [[ -n $ip ]] && write_ndi_config $NDICFG $ip >> $NDILOG 2>&1; then export NDI_CONFIG_DIR=$NDICFG
    else echo "$(ts) no en0 address / config not written: waiting 5 s (the helper never starts unpinned)" >> $NDILOG; sleep 5; continue; fi
    arch -x86_64 $NDIBIN --key $key --log-dir $LOGS > /dev/null 2>> $LOGS/oats-ndi.err < /dev/null &
    child=$!; echo $child > $NDIPID
    echo "$(ts) started oats-ndi pid=$child (key $key, en0 $ip)" >> $NDILOG
    wait $child; code=$?
    while alive $child; do wait $child; code=$?; done
    rm -f $NDIPID
    [[ -f $NDISTOP ]] && break
    (( code == 64 )) && { echo "$(ts) oats-ndi: bad arguments: ndi loop ends" >> $NDILOG; break; }
    local now=$(date +%s)
    recent=(${recent[@]} $now)
    local -a keep=(); for t in $recent; do (( now - t <= 60 )) && keep+=($t); done; recent=($keep)
    echo "$(ts) oats-ndi exited $code$( (( code > 128 )) && echo " (signal $((code - 128)))"): restarting" >> $NDILOG
    if (( ${#recent} > 10 )); then sleep 10; else sleep 1; fi
  done
  rm -f $NDILOOPPID $NDIPID
  echo "$(ts) ndi loop exit" >> $NDILOG
}

ndi_start() {
  local key=${1:-7000}
  [[ -x $NDIBIN ]] || { echo "no $NDIBIN (./m0.sh build): NDI helper mode unavailable"; return 0; }
  rosetta || { echo "Rosetta 2 is not installed: NDI helper not started (auto mode uses native-soft; helper mode needs: softwareupdate --install-rosetta --agree-to-license)"; return 0; }
  local lp=$(checked_pid $NDILOOPPID isndiloop)
  if [[ -n $lp ]]; then echo "NDI helper already running (loop pid $lp, oats-ndi pid $(checked_pid $NDIPID isndi))"; return 0; fi
  local orphan=$(pgrep -f "$NDIBIN" | tr '\n' ' ')
  [[ -n $orphan ]] && { echo "oats-ndi already runs as pid $orphan (not ours): kill -TERM it first" >&2; return 1; }
  rm -f $NDISTOP
  nohup python3 -I -c 'import os, sys; os.setsid(); os.execvp(sys.argv[1], sys.argv[1:])' \
    zsh $M/m0.sh _ndiloop $key < /dev/null >> $NDILOG 2>&1 &
  echo $! > $NDILOOPPID
  disown 2>/dev/null || true
  echo "$(ts) NDI helper loop pid $(readpid $NDILOOPPID) (bin/oats-ndi under Rosetta, key $key; idles unless the player is in helper mode; logs $LOGS/oats-ndi-*.log)"
}

ndi_stop() {
  local lp=$(checked_pid $NDILOOPPID isndiloop) cp=$(checked_pid $NDIPID isndi)
  touch $NDISTOP
  [[ -n $cp ]] && kill -TERM $cp
  local i=0
  while (( i < 30 )) && { alive ${cp:-} || alive ${lp:-} }; do sleep 0.1; (( i += 1 )); done
  alive ${cp:-} && kill -KILL $cp
  alive ${lp:-} && kill -TERM $lp 2>/dev/null
  rm -f $NDILOOPPID $NDIPID
  [[ -n $lp$cp ]] && echo "$(ts) NDI helper stopped (oats-ndi pid ${cp:-?}, loop pid ${lp:-?})" || echo "NDI helper not running"
}

cmd_ndi() {
  case ${1:-status} in
    start) shift; ndi_start "${1:-7000}" ;;
    stop) ndi_stop ;;
    restart) ndi_stop; ndi_start "${2:-7000}" ;;
    status)
      local lp=$(checked_pid $NDILOOPPID isndiloop) cp=$(checked_pid $NDIPID isndi)
      if [[ -n $cp ]]; then echo "oats-ndi running: pid $cp (loop pid ${lp:-?})"; elif [[ -n $lp ]]; then echo "ndi loop running (pid $lp), oats-ndi restarting"; else echo "oats-ndi not running"; fi
      [[ -f $LOGS/status.json ]] && python3 -I -c 'import json,sys; n=json.load(open(sys.argv[1])).get("ndi",{}); h=n.get("helper",{}); print("player NDI mode %s (requested %s), sending %s, connections %s, dropped %s; helper alive %s state %s pid %s, sent %s, send max %s ms, stalls>50ms %s; note: %s" % (n.get("mode"), n.get("requested"), n.get("sending"), n.get("connections"), n.get("dropped"), h.get("alive"), h.get("state"), h.get("pid"), h.get("sent"), h.get("send_ms_max"), h.get("stalls_over_50ms"), n.get("note")))' $LOGS/status.json
      [[ -f $NDILOG ]] && tail -3 $NDILOG ;;
    *) echo "usage: m0.sh ndi [start|stop|restart|status]" >&2; exit 64 ;;
  esac
}

link_start() {
  [[ -x $LINKBIN ]] || { echo "no $LINKBIN (build it: ../link-helper/build.sh): Ableton Link off"; return 0; }
  local lp=$(checked_pid $LINKLOOPPID islinkloop)
  if [[ -n $lp ]]; then echo "Link helper already running (loop pid $lp, oats-link pid $(checked_pid $LINKPID islink))"; return 0; fi
  local orphan=$(pgrep -f "$LINKBIN" | tr '\n' ' ')
  [[ -n $orphan ]] && { echo "oats-link already runs as pid $orphan (not ours): kill -TERM it first" >&2; return 1; }
  rm -f $LINKSTOP
  nohup python3 -I -c 'import os, sys; os.setsid(); os.execvp(sys.argv[1], sys.argv[1:])' \
    zsh $M/m0.sh _linkloop "$@" < /dev/null >> $LINKLOG 2>&1 &
  echo $! > $LINKLOOPPID
  disown 2>/dev/null || true
  echo "$(ts) Link helper loop pid $(readpid $LINKLOOPPID) (bin/oats-link -> OSC /oats/tempo/link to 127.0.0.1:7000; log $LINKLOG)"
}

link_stop() {
  local lp=$(checked_pid $LINKLOOPPID islinkloop) cp=$(checked_pid $LINKPID islink)
  touch $LINKSTOP
  [[ -n $cp ]] && kill -TERM $cp
  local i=0
  while (( i < 30 )) && { alive ${cp:-} || alive ${lp:-} }; do sleep 0.1; (( i += 1 )); done
  alive ${cp:-} && kill -KILL $cp
  alive ${lp:-} && kill -TERM $lp 2>/dev/null
  rm -f $LINKLOOPPID $LINKPID
  [[ -n $lp$cp ]] && echo "$(ts) Link helper stopped (oats-link pid ${cp:-?}, loop pid ${lp:-?})" || echo "Link helper not running"
}

cmd_link() {
  case ${1:-status} in
    start) shift; link_start "$@" ;;
    stop) link_stop ;;
    restart) link_stop; link_start ;;
    status)
      local lp=$(checked_pid $LINKLOOPPID islinkloop) cp=$(checked_pid $LINKPID islink)
      if [[ -n $cp ]]; then echo "oats-link running: pid $cp (loop pid ${lp:-?})"; elif [[ -n $lp ]]; then echo "link loop running (pid $lp), oats-link restarting"; else echo "oats-link not running"; fi
      [[ -f $LOGS/status.json ]] && python3 -I -c 'import json,sys; t=json.load(open(sys.argv[1])).get("tempo",{}); print("tempo: source %s, %s BPM, beat %s, setting %s, link %s" % (t.get("source"), t.get("bpm"), t.get("beat"), t.get("setting"), json.dumps(t.get("link"))))' $LOGS/status.json
      [[ -f $LINKLOG ]] && tail -3 $LINKLOG ;;
    *) echo "usage: m0.sh link [start|stop|restart|status]" >&2; exit 64 ;;
  esac
}

cmd_start() {
  local test=0 gate=0
  local -a extra=()
  while (( $# )); do
    case $1 in
      --test) test=1 ;;
      --gate) gate=1 ;;
      *) extra+=("$1") ;;
    esac
    shift
  done
  local lp=$(checked_pid $LOOPPID isloop) cp=$(checked_pid $CHILDPID ischild)
  if [[ -n $lp ]]; then echo "already running (loop pid $lp, oats-m0 pid ${cp:-none}); use stop first" >&2; exit 1; fi
  if pgrep -f "$BIN" >/dev/null || pgrep -f "ndi-bench/bin/sender" >/dev/null; then
    echo "another oats-m0 or ndi-bench sender is running (pgrep); stop it first (one sender at a time)" >&2; exit 1
  fi
  [[ -x $BIN ]] || { echo "no $BIN: run ./m0.sh build first" >&2; exit 1; }
  local ip=$(en0ip)
  if [[ -z $ip ]]; then echo "en0 has no usable IPv4 address (none or 169.254.x.x): plug in the Ethernet cable / check DHCP (NDI is pinned to en0)" >&2; exit 1; fi
  [[ $ip == 192.168.1.* ]] || echo "WARNING: en0 $ip is not on 192.168.1.0/24 (PLAN 3): update MA3's OSC line and sACN row"
  local dup=$(ifconfig | awk -v p="${ip%.*}." -v me="$ip" '/inet /{ if (index($2, p) == 1 && $2 != me) print $2 }' | tr '\n' ' ')
  [[ -n $dup ]] && echo "WARNING: another interface has $dup on en0's subnet (Wi-Fi on?): NDI between the machines may break"
  local -a args=()
  (( test )) && args+=(--name "OATS VIZ Test" --groups oatsbench --debug)
  args+=("${extra[@]}")
  rm -f $STOPFILE $RESTARTFILE
  # own session (setsid via python3 -I), so the loop survives the shell that started it
  nohup python3 -I -c 'import os, sys; os.setsid(); os.execvp(sys.argv[1], sys.argv[1:])' \
    zsh $M/m0.sh _loop $gate "${args[@]}" < /dev/null >> $LOOPLOG 2>&1 &
  echo $! > $LOOPPID
  disown 2>/dev/null || true
  echo "$(ts) started restart loop pid $(readpid $LOOPPID): en0 $ip, args: ${args[*]}"
  (( gate )) && echo "load gate on: waits until the 1-min load is 8 or less (max 15 min)"
  echo "logs: $LOGS (oats-m0-*.log, status.json, loop.log)"
  link_start
  local key=7000 i=1
  while (( i < ${#extra} )); do [[ ${extra[$i]} == --osc-port ]] && key=${extra[$((i + 1))]}; (( i += 1 )); done
  ndi_start $key
}

cmd_stop() {
  local lp=$(checked_pid $LOOPPID isloop) cp=$(checked_pid $CHILDPID ischild)
  touch $STOPFILE
  if [[ -z $lp && -z $cp ]]; then
    local orphan=$(pgrep -f "$BIN" | tr '\n' ' ')
    [[ -n $orphan ]] && echo "WARNING: no loop/pidfile, but oats-m0 runs as pid $orphan (started by hand?): kill -TERM it yourself"
    echo "not running"; rm -f $LOOPPID $CHILDPID; link_stop; ndi_stop; return 0
  fi
  [[ -n $cp ]] && kill -TERM $cp
  local i=0 c2
  while (( i < 50 )); do
    c2=$(readpid $CHILDPID)                          # the loop may have started a new child meanwhile
    if [[ -n $c2 && $c2 != ${cp:-} ]] && ischild $c2; then cp=$c2; kill -TERM $cp 2>/dev/null; fi
    alive ${cp:-} || alive ${lp:-} || break
    sleep 0.1; (( i += 1 ))
  done
  if alive ${cp:-}; then echo "oats-m0 pid $cp still alive after 5 s: SIGKILL"; kill -KILL $cp; echo "$(ts) stop: SIGKILL $cp after 5 s" >> $LOOPLOG; fi
  sleep 0.3
  alive ${lp:-} && { kill -TERM $lp 2>/dev/null; sleep 0.3; }
  alive ${lp:-} && kill -KILL $lp 2>/dev/null
  rm -f $LOOPPID $CHILDPID
  local left=$(pgrep -f "$BIN" | tr '\n' ' ')
  [[ -n $left ]] && echo "WARNING: oats-m0 still running: pid $left"
  echo "$(ts) stopped (oats-m0 pid ${cp:-?}, loop pid ${lp:-?}) after $(printf '%.1f' $(( i / 10.0 ))) s"
  link_stop
  ndi_stop
}

cmd_restart() {
  local cp=$(checked_pid $CHILDPID ischild)
  [[ -n $cp ]] || { echo "oats-m0 is not running" >&2; exit 1; }
  touch $RESTARTFILE
  kill -TERM $cp
  echo "restart requested at $(now_ms) (SIGTERM to pid $cp; the loop starts it again)"
  local i=0
  while alive $cp && (( i < 60 )); do sleep 0.1; (( i += 1 )); done
  if alive $cp; then
    echo "pid $cp still alive after 6 s: SIGKILL (the loop restarts it)"; kill -KILL $cp
    echo "$(ts) restart: SIGKILL $cp after 6 s" >> $LOOPLOG
  fi
  echo "old process gone at $(now_ms)"
}

cmd_status() {
  local lp=$(checked_pid $LOOPPID isloop) cp=$(checked_pid $CHILDPID ischild)
  if [[ -f $LOGS/status.json ]]; then python3 -I -m json.tool $LOGS/status.json; else echo "(no status.json yet)"; fi
  if [[ -n $cp ]]; then echo "running: oats-m0 pid $cp, loop pid ${lp:-?}"
  elif [[ -n $lp ]]; then echo "loop running (pid $lp), oats-m0 not running right now"
  else echo "not running"; fi
  [[ -f $LOGS/status.json ]] && python3 -I -c 'import json,sys,time; d=json.load(open(sys.argv[1])); print("status.json age %.1f s" % (time.time()-d.get("updated_unix",0)))' $LOGS/status.json
  local ip=$(en0ip)
  echo "en0 IPv4: ${ip:-none}"
  [[ -f $LOGS/status.json ]] && python3 -I -c 'import json,sys; d=json.load(open(sys.argv[1])); a=d.get("ndi_adapters_allowed",[]); print("NDI pin OK (adapters.allowed %s)" % a if sys.argv[2] and sys.argv[2] in a else "NDI PIN MISMATCH: pinned %s, en0 now %s -> m0.sh restart" % (a, sys.argv[2] or "none"))' $LOGS/status.json "$ip"
  netstat -ibI en0 | awk 'NR==1 || /<Link/'
  local i1=$(netstat -ibI en0 | awk '/<Link/{print $7}') o1=$(netstat -ibI en0 | awk '/<Link/{print $10}')
  sleep 2
  local i2=$(netstat -ibI en0 | awk '/<Link/{print $7}') o2=$(netstat -ibI en0 | awk '/<Link/{print $10}')
  printf 'en0 out: %.1f Mbit/s, in: %.1f Mbit/s (over 2 s)\n' $(( (o2 - o1) * 4 / 1000000.0 )) $(( (i2 - i1) * 4 / 1000000.0 ))
  echo "UDP 5568 (sACN) / 7000 (OSC) holders:"
  local holders=$(lsof -nP -iUDP:5568 -iUDP:7000 2>/dev/null)
  if [[ -n $holders ]]; then print -r -- $holders | sed 's/^/  /'; else echo "  (none)"; fi
  local others=$(lsof -nP -iUDP:5568 2>/dev/null | awk 'NR>1 && $1 != "oats-m0" {print $1 " pid " $2}' | sort -u | tr '\n' ' ')
  [[ -n $others ]] && echo "WARNING: $others also listens on UDP 5568: macOS gives each unicast packet to only one of them, so oats-m0 may miss MA3's DMX (it then holds the last look)"
}

cmd_net() {
  local ip=$(en0ip)
  echo "en0 IPv4: ${ip:-none}"
  echo "en0 mask: $(ifconfig en0 | awk '/inet /{print $4}')"
  echo "router (en0 DHCP): $(ipconfig getoption en0 router 2>/dev/null || echo '?')"
  echo "default route: $(route -n get default 2>/dev/null | awk '/gateway/{print $2}') via $(route -n get default 2>/dev/null | awk '/interface/{print $2}')"
  local wdev=$(networksetup -listallhardwareports 2>/dev/null | awk '/Hardware Port: Wi-Fi/{getline; print $2}')
  [[ -n $wdev ]] && echo "Wi-Fi ($wdev): $(networksetup -getairportpower $wdev 2>/dev/null)"
  echo "route to previs PC $PC_IP: $(route -n get $PC_IP 2>/dev/null | awk '/interface/{print "interface " $2} /gateway/{print "gateway " $2}' | tr '\n' ' ')"
  netstat -ibI en0 | awk 'NR==1 || /<Link/'
}

# pin_run <label> <allowed-ip> <probe-name>: one 12 s sender run with its own NDI config and log dir.
# Evidence is specific to en0: dns-sd Add records on en0's interface index and the sender's sockets.
# Returns 0 = advertised on en0, 1 = not advertised on en0, 2 = inconclusive (sender not ready or died).
# Sets PR_ON_EN0, PR_SOCK_EN0, PR_PROBE, PR_FRAMES, PR_URL.
pin_run() {
  local label=$1 ip=$2 probe=${3:-}
  local dir=$M/ndi-config-pincheck ld=$LOGS/pincheck/$label out=$LOGS/pincheck-$label
  local sp="" rp="" dp="" k=0 idx=$PIN_IDX en0=$PIN_EN0
  typeset -g PR_ON_EN0=0 PR_SOCK_EN0=0 PR_PROBE=0 PR_FRAMES=0 PR_URL=""
  trap 'kill -TERM $sp $rp $dp 2>/dev/null' INT TERM
  rm -rf $ld; mkdir -p $ld; rm -f $out.*(N)
  echo "--- run '$label': adapters.allowed=$ip (${OATS_NDI_ALLOWED_FORM:-array} form), probe machinename '$probe'"
  if ! write_ndi_config $dir $ip $probe > $out.config.txt 2>&1; then
    echo "  => cannot write the config ($(cat $out.config.txt)): INCONCLUSIVE"; trap - INT TERM; return 2
  fi
  local -a run=(${=$(runner)})
  NDI_CONFIG_DIR=$dir $run $BIN --name "OATS VIZ Test" --groups oatsbench --debug --ndi native --no-sacn --osc-port 7101 --preview-port 8191 --log-dir $ld \
    > $out.sender.txt 2>&1 < /dev/null &
  sp=$!
  local -a lf=()
  while (( k < 300 )) && alive $sp; do
    lf=($ld/oats-m0-*.log(N))
    (( ${#lf} )) && grep -qs "render loop started" $lf && break
    sleep 0.1; (( k += 1 ))
  done
  if ! alive $sp || (( k >= 300 )); then
    echo "  => sender not running/ready after $((k / 10.0)) s (see $out.sender.txt, $ld): INCONCLUSIVE"
    kill -TERM $sp 2>/dev/null; wait $sp 2>/dev/null; trap - INT TERM; return 2
  fi
  echo "  sender ready after $((k / 10.0)) s"
  dns-sd -B _ndi._tcp > $out.dnssd.txt 2>&1 & dp=$!
  sleep 1
  env -u NDI_CONFIG_DIR $BENCH_RECV --match "OATS VIZ Test" --groups oatsbench --findwait 8 --secs 3 > $out.recv.txt 2>&1 & rp=$!
  sleep 10
  lsof -nP -a -p $sp -i > $out.lsof.txt 2>&1           # before stopping the sender: which local addresses NDI bound
  sleep 1                                               # the sender runs 12 s after it is ready
  local died=0
  alive $sp || died=1
  kill $dp 2>/dev/null
  kill -TERM $sp 2>/dev/null
  local j=0; while alive $sp && (( j < 50 )); do sleep 0.1; (( j += 1 )); done
  alive $sp && kill -KILL $sp 2>/dev/null
  j=0; while alive $rp && (( j < 40 )); do sleep 0.1; (( j += 1 )); done
  alive $rp && kill -TERM $rp 2>/dev/null
  wait $sp $rp $dp 2>/dev/null
  trap - INT TERM
  if (( died )); then echo "  => sender died during the run (see $out.sender.txt): INCONCLUSIVE"; return 2; fi
  PR_URL=$(sed -n 's/.*found source .*(OATS VIZ Test).* url=\([0-9.]*\):.*/\1/p' $out.recv.txt | head -1)
  PR_ON_EN0=$(awk -v i=$idx '$2 == "Add" && $4 == i && /\(OATS VIZ Test\)/' $out.dnssd.txt | wc -l | tr -d ' ')
  PR_SOCK_EN0=$(awk -v a="$en0:" 'NR > 1 && index($9, a) == 1' $out.lsof.txt | wc -l | tr -d ' ')
  grep -q "FIRST FRAME" $out.recv.txt && PR_FRAMES=1
  [[ -n $probe ]] && grep -qsF "$probe (OATS VIZ Test)" $out.dnssd.txt $out.recv.txt && PR_PROBE=1
  echo "  dns-sd: $PR_ON_EN0 Add record(s) for OATS VIZ Test on en0 (if $idx); all OATS VIZ Test records:"
  { grep -F "(OATS VIZ Test)" $out.dnssd.txt || echo "(none)" } | sed 's/^/    /'
  echo "  sender sockets: $(awk 'NR > 1 {print $8 ":" $9}' $out.lsof.txt | sort -u | tr '\n' ' ')"
  echo "  sockets bound to the en0 address $en0: $PR_SOCK_EN0"
  grep -E "found source .*OATS VIZ Test|FIRST FRAME|WINDOW|ERROR" $out.recv.txt | sed 's/^/  receiver: /'
  [[ $PR_URL == 127.0.0.1 ]] && echo "  receiver url=127.0.0.1 (loopback): its frames do not test the en0 pin"
  [[ -n $probe ]] && echo "  machinename probe '$probe' shown: $(( PR_PROBE ? 1 : 0 )) (1 = libndi read this NDI_CONFIG_DIR)"
  lf=($ld/oats-m0-*.log(N))
  (( ${#lf} )) && grep -hE "NDI_CONFIG_DIR|WARNING" $lf | tail -2 | sed 's/^/  sender: /'
  (( PR_ON_EN0 > 0 )) && return 0
  return 1
}

cmd_pin_check() {
  local bogus=${1:-}
  [[ -n $bogus ]] || { echo "usage: m0.sh pin-check <bogus-IP>   (an address that is NOT on this Mac, e.g. 192.0.2.1)" >&2; exit 64; }
  local lp=$(checked_pid $LOOPPID isloop)
  if [[ -n $lp ]] || pgrep -f "$BIN" >/dev/null || pgrep -f "ndi-bench/bin/sender" >/dev/null; then
    echo "a sender is running: m0.sh stop first (one sender at a time)" >&2; exit 1
  fi
  typeset -g PIN_EN0=$(en0ip)
  [[ -n $PIN_EN0 ]] || { echo "en0 has no usable IPv4 address" >&2; exit 1; }
  [[ -x $BENCH_RECV ]] || { echo "bench receiver missing: $BENCH_RECV" >&2; exit 1; }
  typeset -g PIN_IDX=$(python3 -I -c 'import socket; print(socket.if_nametoindex("en0"))')
  wait_load_gate stdout 0
  mkdir -p $LOGS/pincheck
  echo "$(ts) pin-check: bogus=$bogus real en0=$PIN_EN0 (interface index $PIN_IDX); sender 'OATS VIZ Test', group oatsbench, 12 s per run"
  local form=${OATS_NDI_ALLOWED_FORM:-array}
  pin_run bogus-$form $bogus OATSPIN; local rb=$? b_sock=$PR_SOCK_EN0
  sleep 2
  pin_run real-$form $PIN_EN0 OATSPIN; local rr=$? r_probe=$PR_PROBE
  echo "--- verdict ($form form)"
  pin_verdict $rb $b_sock $rr $r_probe $bogus $form
  local v=$?
  if (( v == 1 )) && [[ $form == array ]]; then
    echo "--- the array form did not pin NDI: repeating with the string form (\"adapters\": {\"allowed\": \"IP\"}, as NDI Access Manager writes it)"
    sleep 2
    OATS_NDI_ALLOWED_FORM=string pin_run bogus-string $bogus OATSPIN; rb=$?; b_sock=$PR_SOCK_EN0
    sleep 2
    OATS_NDI_ALLOWED_FORM=string pin_run real-string $PIN_EN0 OATSPIN; rr=$?; r_probe=$PR_PROBE
    echo "--- verdict (string form)"
    pin_verdict $rb $b_sock $rr $r_probe $bogus string
    (( $? == 0 )) && echo "=> libndi honours the STRING form: start the loop with OATS_NDI_ALLOWED_FORM=string"
  fi
  echo "logs: $LOGS/pincheck-* and $LOGS/pincheck/<run>/"
}

# pin_verdict <bogus rc> <bogus sockets on en0> <real rc> <real probe seen> <bogus ip> <form>; returns 0 PASS, 1 FAIL, 2 INCONCLUSIVE
pin_verdict() {
  local rb=$1 bsock=$2 rr=$3 rprobe=$4 bogus=$5 form=$6
  (( rprobe )) && echo "libndi read NDI_CONFIG_DIR: yes (the machinename probe appeared in the real-IP run)" \
               || echo "libndi read NDI_CONFIG_DIR: NOT PROVEN (the machinename probe did not appear; NDI may ignore machinename)"
  if (( rb == 1 && bsock == 0 && rr == 0 )); then
    echo "PASS ($form form): with adapters.allowed=$bogus OATS VIZ Test was not advertised on en0 and no socket was bound to the en0 address; with the real en0 IP it was advertised on en0."
    return 0
  elif (( rb == 0 )); then
    echo "FAIL ($form form, still advertised on en0): with adapters.allowed=$bogus OATS VIZ Test was still advertised on en0, so the pin had no effect in this form."
    return 1
  fi
  echo "INCONCLUSIVE ($form form): bogus run rc=$rb (0 advertised on en0, 1 not, 2 no run), en0 sockets $bsock; real run rc=$rr. Confirm from the PC in Part A."
  return 2
}

case ${1:-} in
  build) shift; cmd_build "$@" ;;
  ndi) shift; cmd_ndi "$@" ;;
  _ndiloop) shift; cmd__ndiloop "$@" ;;
  start) shift; cmd_start "$@" ;;
  stop) shift; cmd_stop ;;
  restart) shift; cmd_restart ;;
  status) shift; cmd_status ;;
  net) shift; cmd_net ;;
  pin-check) shift; cmd_pin_check "$@" ;;
  _loop) shift; cmd__loop "$@" ;;
  link) shift; cmd_link "$@" ;;
  _linkloop) shift; cmd__linkloop "$@" ;;
  *) sed -n '2,15p' $0 | sed 's/^# \{0,1\}//'; exit 64 ;;
esac
