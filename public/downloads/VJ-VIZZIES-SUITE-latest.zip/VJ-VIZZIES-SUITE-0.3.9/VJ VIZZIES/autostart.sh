#!/bin/zsh
# VJ VIZZIES login item (written as ~/Library/LaunchAgents/com.fooknoats.oatsviz.plist by install.sh): waits a little after
# login (Metal was reported to hang right after login), waits for the lighting interface's address, then starts the player
# loop and the controls (GUI). Both refuse to start twice. "autostart.sh now" skips the login wait.
# Mirrors the show Mac's oats-m0/autostart.sh: m0.sh start --no-ndi-meta --universe 5 --ndi helper (Apple Silicon: the
# x86_64 NDI helper under Rosetta does not freeze) / --ndi native (Intel: the x86_64 NDI library IS the native one).
D=${0:A:h}
M=$D/oats-m0
cd $M
say() { print -r -- "$(date '+%Y-%m-%d %H:%M:%S') autostart: $*"; }
[[ -f $M/m0.env ]] && source $M/m0.env          # OATS_NDI_MACHINE, OATS_NDI_IF (install.sh)
IF=${OATS_NDI_IF:-en0}
if [[ ${1:-} == now ]]; then say "start now"; else say "login start; waiting 20 s"; sleep 20; fi
for i in {1..60}; do ipconfig getifaddr $IF >/dev/null 2>&1 && break; sleep 2; done
say "$IF $(ipconfig getifaddr $IF || echo 'has no address')"
if [[ $(uname -m) == arm64 ]]; then ndi=helper; else ndi=native; fi
./m0.sh start --no-ndi-meta --universe 5 --ndi $ndi
say "player start exit $?"
gui/run.sh start
say "gui start exit $?"
exit 0
