#!/bin/zsh
# VJ VIZZIES uninstaller: stops the player and the controls, removes the login item. The folder stays (scenes, media, settings).
DEST=${OATS_VIZ_DEST:-"$HOME/Applications/VJ VIZZIES"}; PLIST="$HOME/Library/LaunchAgents/com.fooknoats.oatsviz.plist"
"$DEST/oats-m0/gui/run.sh" stop >/dev/null 2>&1 || true
"$DEST/oats-m0/m0.sh" stop >/dev/null 2>&1 || true
"$DEST/oats-m0/m0.sh" ndi stop >/dev/null 2>&1 || true
"$DEST/oats-m0/m0.sh" link stop >/dev/null 2>&1 || true
launchctl unload "$PLIST" 2>/dev/null || true; rm -f "$PLIST"
echo "stopped and removed the login item. The folder $DEST is left for you to delete (scenes, media, settings)."
echo "The app in /Applications/VJ VIZZIES.app (if you installed it) can be dragged to the Trash."
