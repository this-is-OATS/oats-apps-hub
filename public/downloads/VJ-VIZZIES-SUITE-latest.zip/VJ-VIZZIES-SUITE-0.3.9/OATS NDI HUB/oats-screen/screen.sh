#!/bin/zsh
# oats-screen supervisor: a display as an NDI source (ScreenCaptureKit -> libndi).
#   screen.sh build | start | stop | restart | status | log [N] | list
# Settings via env or screen.env: SCREEN_NAME ("Display 2"), SCREEN_DISPLAY (secondary|main|ID), SCREEN_SIZE (native), SCREEN_FPS (30),
# SCREEN_ARCH (x86_64: libndi under Rosetta like oats-ndi, freeze-free on fine detail), SCREEN_EXTRA (e.g. --no-cursor)
setopt no_unset pipefail 2>/dev/null
C=${0:A:h}
BIN=$C/bin/oats-screen
LOGS=$C/logs
RUN=$C/run
PID=$RUN/oats-screen.pid
LOOPPID=$RUN/oats-screen-loop.pid
LOOPLOG=$LOGS/oats-screen-loop.log
[[ -f $C/screen.env ]] && source $C/screen.env
: ${SCREEN_NAME:="Display 2"} ${SCREEN_DISPLAY:=secondary} ${SCREEN_SIZE:=} ${SCREEN_FPS:=30} ${SCREEN_ARCH:=x86_64} ${SCREEN_EXTRA:=}
[[ -d $C/../ndi-config ]] && : ${NDI_CONFIG_DIR:=$C/../ndi-config}   # this install's machine name + adapter pin (install.sh)
[[ -d $C/../oats-m0/ndi-config ]] && : ${NDI_CONFIG_DIR:=$C/../oats-m0/ndi-config}   # share the vizzies' NDI pin when installed next to them
: ${NDI_CONFIG_DIR:=$HOME/.ndi}
export NDI_CONFIG_DIR
mkdir -p $LOGS $RUN $C/bin
ts() { date '+%Y-%m-%d %H:%M:%S' }
readpid() { [[ -f $1 ]] && cat $1 2>/dev/null || true }
alive() { [[ -n ${1:-} ]] && kill -0 $1 2>/dev/null }

build() {
  local mc=$C/.modcache arch=$SCREEN_ARCH target
  [[ $arch == arm64 ]] && target=arm64-apple-macos14 || target=x86_64-apple-macos14
  mkdir -p $mc
  echo "$(ts) building bin/oats-screen ($arch)"
  swiftc -O -swift-version 5 -parse-as-library -target $target -module-cache-path $mc \
    -import-objc-header $C/src/bridge.h $C/src/log.swift $C/src/ndi.swift $C/src/screen.swift $C/src/app.swift \
    -framework Foundation -framework ScreenCaptureKit -framework CoreMedia -framework CoreVideo -framework CoreGraphics \
    -o $BIN.tmp && mv $BIN.tmp $BIN || { rm -f $BIN.tmp; echo "$(ts) BUILD FAILED (oats-screen)" >&2; return 1 }
  echo "$(ts) built $BIN ($(/usr/bin/file -b $BIN | sed 's/Mach-O 64-bit executable //'))"
}
runner() { [[ $(/usr/bin/file -b $BIN) == *arm64* ]] && print -r -- "" || print -r -- "arch -x86_64" }

loop() {
  echo "$(ts) screen loop started pid=$$ name='$SCREEN_NAME' display=$SCREEN_DISPLAY fps=$SCREEN_FPS" >> $LOOPLOG
  while true; do
    ${=$(runner)} $BIN --name $SCREEN_NAME --display $SCREEN_DISPLAY --fps $SCREEN_FPS ${SCREEN_SIZE:+--size $SCREEN_SIZE} ${=SCREEN_EXTRA} --log-dir $LOGS > /dev/null 2>> $LOGS/oats-screen.err < /dev/null &
    local child=$!
    echo $child > $PID
    echo "$(ts) started oats-screen pid=$child" >> $LOOPLOG
    wait $child; local code=$?
    rm -f $PID
    (( code == 0 )) && { echo "$(ts) oats-screen exited 0: screen loop ends" >> $LOOPLOG; break; }
    (( code == 64 || code == 78 || code == 77 )) && { echo "$(ts) oats-screen exited $code (arguments / libndi / screen recording permission): screen loop ends" >> $LOOPLOG; break; }
    echo "$(ts) oats-screen exited $code$( (( code > 128 )) && echo " (signal $((code - 128)))"): restarting in 2 s" >> $LOOPLOG
    sleep 2
  done
  rm -f $LOOPPID
  echo "$(ts) screen loop exit" >> $LOOPLOG
}
start() {
  local lp=$(readpid $LOOPPID)
  alive $lp && { echo "oats-screen already running (loop pid $lp, oats-screen pid $(readpid $PID))"; return 0 }
  [[ -x $BIN ]] || build || return 1
  # own session (setsid) so the loop survives whatever shell or tool started it (m0.sh does the same)
  nohup python3 -I -c 'import os, sys; os.setsid(); os.execvp(sys.argv[1], sys.argv[1:])' zsh $C/screen.sh _loop > /dev/null 2>&1 < /dev/null &
  echo $! > $LOOPPID
  disown 2>/dev/null || true
  echo "$(ts) oats-screen loop pid $! (NDI '$SCREEN_NAME' from display $SCREEN_DISPLAY @ $SCREEN_FPS fps; logs $LOGS/oats-screen-*.log)"
}
stop() {
  local lp=$(readpid $LOOPPID) p=$(readpid $PID)
  alive $lp && kill -TERM $lp 2>/dev/null
  if alive $p; then kill -TERM $p 2>/dev/null; for i in {1..30}; do alive $p || break; sleep 0.1; done; alive $p && kill -KILL $p 2>/dev/null; fi
  rm -f $LOOPPID $PID
  echo "$(ts) oats-screen stopped"
}
status() {
  local lp=$(readpid $LOOPPID) p=$(readpid $PID)
  echo "loop: $( alive $lp && echo "running pid $lp" || echo "not running" )   oats-screen: $( alive $p && echo "running pid $p" || echo "not running" )"
  [[ -f $LOGS/screen-status.json ]] && python3 -I -c "
import json; d=json.load(open('$LOGS/screen-status.json'))
print(f\"NDI '{d['name']}' {d['display']} -> {d['format']} fps={d['fps']:.1f} conns={d['ndi_connections']} sent={d['sent']} captured={d['captured']} repeats={d['repeats']} send_ms max={d['send_ms_max']:.1f} stalls>50ms={d['stalls_over_50ms']} uptime={d['uptime_s']:.0f}s updated {d['updated']}\")"
}
case ${1:-status} in
  _loop) loop ;;
  build) build ;;
  start) start ;;
  stop) stop ;;
  restart) stop; start ;;
  status) status ;;
  log) tail -n ${2:-30} $(ls -t $LOGS/oats-screen-2*.log | head -1) ;;
  list) ${=$(runner)} $BIN --list ;;
  *) echo "usage: screen.sh build|start|stop|restart|status|log [N]|list"; exit 64 ;;
esac
