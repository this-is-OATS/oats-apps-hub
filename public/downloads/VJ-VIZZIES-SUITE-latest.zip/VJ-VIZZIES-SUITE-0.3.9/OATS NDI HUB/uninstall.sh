#!/bin/zsh
# OATS NDI HUB uninstaller: stops every sender and the hub, removes the login item. The folder stays (your settings).
DEST=${OATS_HUB_DEST:-"$HOME/Applications/OATS NDI HUB"}; PLIST="$HOME/Library/LaunchAgents/com.fooknoats.oatsndihub.plist"
for e in "$DEST"/oats-cam/cam.*.env(N); do p=${${e:t}#cam.}; p=${p%.env}; "$DEST/oats-cam/cam.sh" -p $p stop >/dev/null 2>&1 || true; done
for m in oats-hub oats-cam oats-screen; do "$DEST/$m/"*.sh stop >/dev/null 2>&1 || true; done
launchctl unload "$PLIST" 2>/dev/null || true; rm -f "$PLIST"
echo "stopped and removed the login item. The folder $DEST is left for you to delete (it holds your presets and settings)."
