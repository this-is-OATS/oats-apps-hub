#!/bin/zsh
# Writes this install's NDI config (<install>/ndi-config/ndi-config.v1.json): machine name + adapter pin, from
# <install>/suite.env (NDI_MACHINE, NDI_IF written by install.sh). The senders and the hub read it through NDI_CONFIG_DIR.
#   ndi-config.sh            write (re-derives the adapter's current IPv4 address: DHCP may have changed it)
#   ndi-config.sh show       print what would be written
# Every install must have its OWN machine name: two Macs with the same name on one network collide
# ("OBS.HOST (Link Cam)" twice), and receivers see only one of them.
D=${0:A:h}
[[ -f $D/suite.env ]] && source $D/suite.env
: ${NDI_MACHINE:=$(hostname -s | tr '[:lower:]' '[:upper:]' | tr -c 'A-Z0-9.\n' '-')} ${NDI_IF:=}
ip=""
if [[ -n $NDI_IF ]]; then ip=$(ipconfig getifaddr $NDI_IF 2>/dev/null); [[ $ip == 169.254.* ]] && ip=""; fi
if [[ ${1:-} == show ]]; then
  echo "machine name: $NDI_MACHINE"; echo "adapter pin:  ${NDI_IF:-none (all adapters)} ${ip:+= $ip}"; exit 0
fi
mkdir -p $D/ndi-config
python3 -I - "$HOME/.ndi/ndi-config.v1.json" "$D/ndi-config/ndi-config.v1.json" "$NDI_MACHINE" "$ip" <<'PY'
import json, os, sys
src, dst, mach, ip = sys.argv[1:5]
cfg = {}
if os.path.exists(src):
    try: cfg = json.load(open(src))        # start from NDI Tools' own settings (groups, discovery server ...)
    except Exception: cfg = {}
if not isinstance(cfg, dict): cfg = {}
ndi = cfg.setdefault("ndi", {})
if not isinstance(ndi, dict): ndi = cfg["ndi"] = {}
ad = ndi.setdefault("adapters", {})
if not isinstance(ad, dict): ad = ndi["adapters"] = {}
if ip: ad["allowed"] = [ip]
else: ad.pop("allowed", None)
ndi["machinename"] = mach; ndi["machineName"] = mach
tmp = dst + ".tmp"
json.dump(cfg, open(tmp, "w"), indent=2); os.replace(tmp, dst)
print(f"NDI config {dst}: machine name {mach}, adapters.allowed = {json.dumps(ad.get('allowed', 'all'))}")
PY
