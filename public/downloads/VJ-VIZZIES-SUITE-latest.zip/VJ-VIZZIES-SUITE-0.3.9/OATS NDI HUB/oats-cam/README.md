# oats-cam: a UVC webcam as an NDI source with PTZ

Sends the Insta360 Link 2 (or any UVC camera) as an NDI source and answers NDI PTZ commands
from multiviewers / Studio Monitor / vMix etc. by driving the camera's UVC pan, tilt, zoom and
focus controls directly. The Insta360 Link Controller app is not needed (and is better closed:
its auto-tracking fights the remote control).

    cam.sh start | stop | restart | status | log [N]   supervisor (restart loop, like m0.sh)
    cam.sh build                                       compile bin/oats-cam (x86_64, libndi under Rosetta like oats-ndi)
    cam.sh list                                        cameras + formats
    cam.sh ptz info | pantilt PAN TILT | zoom N | raw UNIT CS REQ LEN [bytes]   direct UVC (bin/uvcprobe)
    cam.sh audio on | off | toggle | status            the camera's mic into the NDI feed (muted at start; CAM_AUDIO_START=1)
    bin/ptztest "OBS.HOST (Link Cam)" abs 0 0 speed 0.5 0 1.5 zoom 0.5 store 1 recall 1 af
                                                       receiver-side PTZ test through the real NDI API

Feedback protection (`src/audio.swift` FeedbackDetector, one 1024-pt FFT per 512 samples): a howl is a narrowband peak with
nothing around it (tonality: peak vs the ±3..12 neighbouring bins > 20 dB; speech and hum have harmonics there), peak-to-
average > 12 dB, above -50 dBFS, on one bin for 30 hops (~320 ms), and growing >= 6 dB (or already > -15 dBFS); one event
per 2 s. On detection: CAM_FEEDBACK=mute (default: mic muted, log + status show "feedback=1250Hz age=3s"),
duck (-26 dB for 2 s), warn, off. Tunables: --fb-papr --fb-level --fb-hold. `bin/fbtest` (tests/main.swift) runs synthetic-signal checks: howl detected with
and without the gate, steady tone and hum not flagged, gate opens for speech and closes ~0.75 s after.
Monitoring-loop (self-echo) detection: the sender correlates what it just sent with what the mic hears (8 kHz, lags
40..900 ms, every 250 ms). Our own audio coming back = speakers in the room are playing the feed. CAM_ECHO=mute (default) |
duck | warn | off; the log and status show the loop lag ("loop=370ms"), which is the monitoring chain's latency.
Tunables: echo_corr (0.45), echo_hold (3 checks). `bin/ndilisten "OBS.HOST (Link Cam)" 5 [--tone]` receives the feed on
this Mac and reports level, frame size and one-way NDI latency from the sender timestamps (measured 2026-10-25: avg 3 ms).
Voice mode (CAM_AUDIO_MODE=voice, `cam.sh audio voice on|off|toggle`, hub key V): the mic only passes while speech is
detected (300..3400 Hz band > noise floor + 9 dB, tonality < 20 dB, in-band spectral flux > 0.4: speech measures 0.4..13,
hum and tones < 0.3), 750 ms hangover,
-40 dB otherwise, gain ramped per buffer. Howls, hum and room noise never open the gate, so feedback cannot build.
Note: the Link 2's own noise suppression outputs digital silence in a quiet room and takes ~1-2 s to open on first use.
Sender audio latency: one 512-sample buffer = 10.7 ms at 48 kHz; receivers add their own buffering (typically 20-100 ms).

Audio: `src/audio.swift` captures the Link 2's own mic (or `--audio-device MATCH`) at 48 kHz float and sends it
as NDI audio while on. Toggle: `cam.sh audio toggle`, UDP "audio toggle" to 127.0.0.1:7001 (CAM_CONTROL_PORT),
SIGUSR1, the hub's Audio button / key A, or a macOS Shortcut bound to a hotkey that opens
http://127.0.0.1:7080/api/audio/obs-host-link-cam/toggle (POST) or runs `cam.sh audio toggle`.

Settings: `cam.env` (sourced if present) or env: CAM_NAME ("Link Cam"), CAM_DEVICE ("Insta360 Link 2"),
CAM_SIZE (1920x1080), CAM_FPS (30), CAM_ARCH (x86_64). NDI_CONFIG_DIR defaults to ../oats-m0/ndi-config
so the source is pinned to the same adapter and machine name (OBS.HOST) as "OATS VIZ Program".
Started at login by oats-m0/autostart.sh after the player.

## How it works

- `src/capture.swift`: AVFoundation, picks the 2vuy (= NDI UYVY) format at the requested size/fps, so
  frames go to libndi with no conversion. Camera permission belongs to the launching app (Terminal).
- `src/app.swift`: libndi sender (dlopen, `src/ndi_min.h`), connection metadata
  `<ndi_capabilities ntk_ptz="true"/>` so receivers enable PTZ, a metadata thread that reads the
  receivers' `ntk_ptz_*` XML, tally logging, STATUS line + `logs/cam-status.json` every 5 s.
  Exits 70/71 on capture errors / no frames so the supervisor restarts it; 64/77/78 stop the loop.
- `src/ptz.swift`: NDI PTZ -> UVC. The Link 2 only has absolute pan/tilt (±145° / -90..+100°, 1/3600°
  units, 1° resolution) and absolute zoom (100..400), no relative controls, so joystick speeds are
  integrated at 20 Hz into absolute targets (full speed = 60°/s pan, 45°/s tilt, half the zoom range
  per second; `--pan-rate --tilt-rate --zoom-rate`). A move starts from the camera's real position.
  Presets live in `presets.json`. Focus: `ntk_ptz_focus mode=auto|manual`.
- `src/linktrack.swift`: AI face tracking ("Find a face") for the Insta360 Link / Link 2 through its UVC extension unit
  (unit 9, selector 2 mode = 1 on / 0 off, read-back 0xff = on; selector 19 framing 1-3; selector 14 recentre). OBSBOT uses
  `tallyled.swift`'s channel. Both answer `track`, `track on|off [framing]` on the control port; a manual PTZ move turns it off.
- `src/uvc.c`: IOKit control requests on the camera's VideoControl interface. macOS holds the
  interface (kIOReturnExclusiveAccess) so requests go through the device's control pipe, which works
  while AVFoundation (or any app) streams the camera.

Metadata the NDI 6 receiver API sends (verified 2026-10-25 with bin/ptztest):
`ntk_ptz_pan_tilt pan= tilt=` (-1..1), `ntk_ptz_pan_tilt_speed pan_speed= tilt_speed=`,
`ntk_ptz_zoom zoom=` (0..1), `ntk_ptz_zoom_speed zoom_speed=`, `ntk_ptz_store_preset index=`,
`ntk_ptz_recall_preset index= speed=`, `ntk_ptz_focus mode="auto"` / `mode="manual" distance=`.
Unknown commands are logged as `meta (unhandled)` so new ones can be added in `PTZ.handle`.

## Several cameras (profiles)

One camera per profile. The default profile `link` is the Insta360 Link 2 with the original paths (`cam.env`, `logs/`,
`run/`, `presets.json`, control port 7001). Any other profile `NAME` reads `cam.NAME.env` and gets its own `logs/NAME`,
`run/NAME` and `presets.NAME.json`, so cameras run side by side:

    cam.sh -p obsbot start | stop | restart | status | log      (or CAM_PROFILE=obsbot cam.sh ...)

`cam.obsbot.env` = an OBSBOT (Tiny / Tiny 2 / Meet ...) as NDI "OBSBOT Cam", 1280x720@30, control port 7002, mic off at
start. `CAM_DEVICE` is a name match: run `cam.sh list` with the camera plugged in and copy the exact name if "OBSBOT"
doesn't match. PTZ ranges are read from the camera (UVC GET_MIN/MAX), so a gimbal camera gets pan/tilt/zoom in the hub
automatically; a fixed camera just shows no PTZ. Close the OBSBOT Center app while oats-cam runs (its auto-tracking
fights remote control, same as the Insta360 Link Controller). An OBSBOT Tail Air has native NDI (its own app): no oats-cam
needed for that one. `autostart.sh` starts the `link` profile and then every `cam.*.env` profile at login; the hub's
Audio button needs the camera in `oats-hub/hub.env` HUB_AUDIO_CTL. Camera permission belongs to the launching app: start
from Terminal (or let autostart do it), not from a tool shell.
