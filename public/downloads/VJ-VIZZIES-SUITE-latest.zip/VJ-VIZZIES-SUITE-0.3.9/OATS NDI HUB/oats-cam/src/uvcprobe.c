// uvcprobe: query and drive UVC pan/tilt/zoom on a camera. Usage:
//   uvcprobe [--vid 0x2e1a --pid 0x4c04] info | xu   (xu = dump vendor extension units, read-only)
//   uvcprobe ... pantilt PAN_ARCSEC TILT_ARCSEC    (absolute, 1/3600 degree units)
//   uvcprobe ... zoom VALUE
//   uvcprobe ... ptrel PANDIR PANSPEED TILTDIR TILTSPEED   (relative: dir 0 stop, 1 +, -1 -)
#include "uvc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void dump(const char *label, uvc_dev *d, int unit, int cs, int req, int len) {
    uint8_t b[16] = {0}; int kr = 0;
    int n = uvc_get(d, unit, cs, req, b, len, &kr);
    printf("  %-22s", label);
    if (n < 0) { printf("ERR 0x%08x\n", kr); return; }
    printf("[%d] ", n); for (int i = 0; i < n; i++) printf("%02x ", b[i]);
    if (len == 2) printf(" = %d", (int16_t)(b[0] | b[1] << 8));
    if (len == 8) printf(" = pan %d tilt %d", (int32_t)(b[0] | b[1] << 8 | b[2] << 16 | (uint32_t)b[3] << 24), (int32_t)(b[4] | b[5] << 8 | b[6] << 16 | (uint32_t)b[7] << 24));
    printf("\n");
}

int main(int argc, char **argv) {
    int vid = 0x2e1a, pid = 0x4c04, i = 1;
    while (i < argc && argv[i][0] == '-') {
        if (!strcmp(argv[i], "--vid") && i + 1 < argc) vid = (int)strtol(argv[++i], NULL, 0);
        else if (!strcmp(argv[i], "--pid") && i + 1 < argc) pid = (int)strtol(argv[++i], NULL, 0);
        i++;
    }
    char err[256];
    uvc_dev *d = uvc_open(vid, pid, err, sizeof err);
    if (!d) { fprintf(stderr, "open failed: %s\n", err); return 1; }
    int ct = uvc_camera_terminal(d);
    printf("device %04x:%04x VC interface %d camera terminal %d processing unit %d ct_controls 0x%06x%s%s\n", vid, pid, uvc_interface_number(d), ct, uvc_processing_unit(d), uvc_ct_controls(d), uvc_last_error(d)[0] ? "\n  note: " : "", uvc_last_error(d));
    const char *cmd = i < argc ? argv[i] : "info";
    if (!strcmp(cmd, "info")) {
        printf("zoom absolute (0x0B):\n"); dump("info", d, ct, UVC_CT_ZOOM_ABSOLUTE, UVC_GET_INFO, 1); dump("min", d, ct, UVC_CT_ZOOM_ABSOLUTE, UVC_GET_MIN, 2); dump("max", d, ct, UVC_CT_ZOOM_ABSOLUTE, UVC_GET_MAX, 2); dump("res", d, ct, UVC_CT_ZOOM_ABSOLUTE, UVC_GET_RES, 2); dump("def", d, ct, UVC_CT_ZOOM_ABSOLUTE, UVC_GET_DEF, 2); dump("cur", d, ct, UVC_CT_ZOOM_ABSOLUTE, UVC_GET_CUR, 2);
        printf("pan/tilt absolute (0x0D):\n"); dump("info", d, ct, UVC_CT_PANTILT_ABSOLUTE, UVC_GET_INFO, 1); dump("min", d, ct, UVC_CT_PANTILT_ABSOLUTE, UVC_GET_MIN, 8); dump("max", d, ct, UVC_CT_PANTILT_ABSOLUTE, UVC_GET_MAX, 8); dump("res", d, ct, UVC_CT_PANTILT_ABSOLUTE, UVC_GET_RES, 8); dump("def", d, ct, UVC_CT_PANTILT_ABSOLUTE, UVC_GET_DEF, 8); dump("cur", d, ct, UVC_CT_PANTILT_ABSOLUTE, UVC_GET_CUR, 8);
        printf("pan/tilt relative (0x0E):\n"); dump("info", d, ct, UVC_CT_PANTILT_RELATIVE, UVC_GET_INFO, 1); dump("min", d, ct, UVC_CT_PANTILT_RELATIVE, UVC_GET_MIN, 4); dump("max", d, ct, UVC_CT_PANTILT_RELATIVE, UVC_GET_MAX, 4);
        printf("zoom relative (0x0C):\n"); dump("info", d, ct, UVC_CT_ZOOM_RELATIVE, UVC_GET_INFO, 1); dump("min", d, ct, UVC_CT_ZOOM_RELATIVE, UVC_GET_MIN, 3); dump("max", d, ct, UVC_CT_ZOOM_RELATIVE, UVC_GET_MAX, 3);
        printf("focus auto (0x08) / absolute (0x06):\n"); dump("auto info", d, ct, UVC_CT_FOCUS_AUTO, UVC_GET_INFO, 1); dump("auto cur", d, ct, UVC_CT_FOCUS_AUTO, UVC_GET_CUR, 1); dump("abs info", d, ct, UVC_CT_FOCUS_ABSOLUTE, UVC_GET_INFO, 1); dump("abs min", d, ct, UVC_CT_FOCUS_ABSOLUTE, UVC_GET_MIN, 2); dump("abs max", d, ct, UVC_CT_FOCUS_ABSOLUTE, UVC_GET_MAX, 2); dump("abs cur", d, ct, UVC_CT_FOCUS_ABSOLUTE, UVC_GET_CUR, 2);
    } else if (!strcmp(cmd, "pantilt") && i + 2 < argc) {
        int32_t pan = (int32_t)strtol(argv[i + 1], NULL, 0), tilt = (int32_t)strtol(argv[i + 2], NULL, 0);
        uint8_t b[8]; memcpy(b, &pan, 4); memcpy(b + 4, &tilt, 4); int kr = 0;
        int n = uvc_set(d, ct, UVC_CT_PANTILT_ABSOLUTE, b, 8, &kr);
        printf("set pan %d tilt %d -> %s (IOKit 0x%08x)\n", pan, tilt, n < 0 ? "ERR" : "ok", kr);
    } else if (!strcmp(cmd, "zoom") && i + 1 < argc) {
        int16_t z = (int16_t)strtol(argv[i + 1], NULL, 0); int kr = 0;
        int n = uvc_set(d, ct, UVC_CT_ZOOM_ABSOLUTE, &z, 2, &kr);
        printf("set zoom %d -> %s (IOKit 0x%08x)\n", z, n < 0 ? "ERR" : "ok", kr);
    } else if (!strcmp(cmd, "ptrel") && i + 4 < argc) {
        uint8_t b[4] = { (uint8_t)atoi(argv[i + 1]), (uint8_t)atoi(argv[i + 2]), (uint8_t)atoi(argv[i + 3]), (uint8_t)atoi(argv[i + 4]) }; int kr = 0;
        int n = uvc_set(d, ct, UVC_CT_PANTILT_RELATIVE, b, 4, &kr);
        printf("set ptrel -> %s (IOKit 0x%08x)\n", n < 0 ? "ERR" : "ok", kr);
    } else if (!strcmp(cmd, "xu")) {
        // xu: list the extension units and, for every advertised selector, its INFO / LEN / CUR / MIN / MAX / DEF (read-only).
        int n = uvc_xu_count(d);
        printf("extension units: %d\n", n);
        for (int x = 0; x < n; x++) {
            int id, nc, csz; uint8_t g[16]; uint32_t bm;
            if (uvc_xu_info(d, x, &id, g, &nc, &csz, &bm)) continue;
            printf("XU unit %d guid %02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x controls=%d bControlSize=%d bmControls=0x%08x\n",
                   id, g[3], g[2], g[1], g[0], g[5], g[4], g[7], g[6], g[8], g[9], g[10], g[11], g[12], g[13], g[14], g[15], nc, csz, bm);
            for (int bit = 0; bit < 32; bit++) {
                if (!(bm & (1u << bit))) continue;
                int cs = bit + 1, kr = 0; uint8_t info = 0, lenb[2] = {0, 0};
                int ri = uvc_get(d, (uint8_t)id, (uint8_t)cs, UVC_GET_INFO, &info, 1, &kr);
                int rl = uvc_get(d, (uint8_t)id, (uint8_t)cs, UVC_GET_LEN, lenb, 2, &kr);
                int len = rl > 0 ? (lenb[0] | (lenb[1] << 8)) : 0;
                printf("  cs %2d: info %s0x%02x (%s%s)  len %d", cs, ri < 0 ? "ERR " : "", info, (info & 1) ? "GET" : "-", (info & 2) ? " SET" : "", len);
                if (len > 0 && len <= 64) {
                    const char *names[] = {"cur", "min", "max", "def"}; const uint8_t reqs[] = {UVC_GET_CUR, UVC_GET_MIN, UVC_GET_MAX, UVC_GET_DEF};
                    for (int q = 0; q < 4; q++) {
                        uint8_t b[64] = {0}; int rr = uvc_get(d, (uint8_t)id, (uint8_t)cs, reqs[q], b, (uint16_t)len, &kr);
                        printf("  %s=", names[q]); if (rr < 0) printf("ERR"); else for (int k = 0; k < rr; k++) printf("%02x", b[k]);
                    }
                }
                printf("\n");
            }
        }
    } else if (!strcmp(cmd, "raw") && i + 3 < argc) {
        // raw UNIT CS REQ LEN [bytes...]: REQ 0x81 GET_CUR 0x82 MIN 0x83 MAX 0x86 INFO 0x87 DEF, or 0x01 SET_CUR with bytes
        int unit = (int)strtol(argv[i + 1], NULL, 0), cs = (int)strtol(argv[i + 2], NULL, 0), req = (int)strtol(argv[i + 3], NULL, 0);
        int len = i + 4 < argc ? atoi(argv[i + 4]) : 1; uint8_t b[64] = {0}; int kr = 0, n;
        if (req == UVC_SET_CUR) { for (int k = 0; k < len && i + 5 + k < argc; k++) b[k] = (uint8_t)strtol(argv[i + 5 + k], NULL, 0); n = uvc_set(d, unit, cs, b, len, &kr); printf("set unit %d cs 0x%02x -> %s (IOKit 0x%08x)\n", unit, cs, n < 0 ? "ERR" : "ok", kr); }
        else { n = uvc_get(d, unit, cs, req, b, len, &kr); printf("unit %d cs 0x%02x req 0x%02x -> ", unit, cs, req); if (n < 0) printf("ERR 0x%08x\n", kr); else { printf("[%d]", n); for (int k = 0; k < n; k++) printf(" %02x", b[k]); printf("\n"); } }
    } else if (!strcmp(cmd, "reenum")) {
        uvc_close(d); d = NULL;
        char e[256]; int rc = uvc_reenumerate(vid, pid, e, sizeof e);
        printf("reenumerate -> %s (%s)\n", rc == 0 ? "ok" : "FAILED", e);
        return rc == 0 ? 0 : 1;
    } else { fprintf(stderr, "unknown command\n"); uvc_close(d); return 64; }
    uvc_close(d);
    return 0;
}
