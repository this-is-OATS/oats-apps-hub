import Foundation

/// AI face tracking on the camera itself ("Find a face" on the hub). One interface, two cameras:
/// TallyLED (OBSBOT, vendor channel tag 0x16) and LinkTracking (Insta360 Link / Link 2, extension unit below).
protocol AITracker: AnyObject {
    var tracking: Bool? { get }            // last known state (nil = never set / unknown)
    var framing: UInt8 { get set }
    var framingRange: ClosedRange<UInt8> { get }
    var kind: String { get }
    @discardableResult func setTracking(_ on: Bool, _ via: String) -> Bool
    var trackingText: String { get }
}
extension TallyLED: AITracker {
    var framingRange: ClosedRange<UInt8> { 0...4 }
    var kind: String { "obsbot" }
}

/// Insta360 Link / Link 2: extension unit GUID faf1672d-b71b-4793-8c91-7b1c9b7f95f8 (unit 9 on our Link 2).
/// Selector 2 is the mode control (GET_LEN bytes, 61 on the Link 2): write a zeroed buffer with byte[0] = mode,
/// byte[1] = flag; mode 1/0 = AI tracking on, 0/0 = normal. Read-back byte[0] is 0xff while tracking is on, 0 when off
/// (verified on our Link 2 2026-11-02: the camera levelled itself the moment tracking went on). Selector 19 (1 byte) is the
/// framing: 1 head, 2 half body, 3 full body. Selector 14 (1 byte, write 1) re-centres the gimbal.
/// Map from vrwallace/Insta360-Link-1-and-2-Controller-for-Linux (confirmed there by watching the official app on Windows).
final class LinkTracking: AITracker {
    static let guid: [UInt8] = [0x2d, 0x67, 0xf1, 0xfa, 0x1b, 0xb7, 0x93, 0x47, 0x8c, 0x91, 0x7b, 0x1c, 0x9b, 0x7f, 0x95, 0xf8]
    let dev: OpaquePointer
    let q: DispatchQueue
    let unit: UInt8
    /// The firmware swings the gimbal to its centre view the moment tracking goes on (seen on our Link 2 2026-11-05). With a
    /// PTZ object we read the position just before and hold it there for a moment, so the search starts where the camera was.
    weak var ptz: PTZ?
    var holdPosition = true
    /// Lost-target scan (--scan): the firmware tells us nothing about the gimbal (UVC GET_CUR echoes what the host last set,
    /// no extension-unit selector changes with the pose: checked 2026-11-05), so we watch the picture instead (FaceWatch).
    /// Tracking on and no face for scanLostAfter s = lost: we tilt up to scanTilt and pan limit to limit (scanPeriod s per cycle)
    /// starting the way the face left, until a face is back in the picture (the firmware takes it from there) or tracking is off.
    var scan = true
    var scanTilt: Double = 10, scanLostAfter: Double = 3, scanPeriod: Double = 24
    var faces: FaceWatch? = nil
    private var scanGen: UInt64 = 0
    private(set) var scanning = false, scans: UInt64 = 0
    private(set) var tracking: Bool? = nil
    var framing: UInt8 = 0                 // 0 = leave the camera's own setting
    var framingRange: ClosedRange<UInt8> { 1...3 }
    var kind: String { "link" }
    private(set) var writes: UInt64 = 0, errors: UInt64 = 0
    private var modeLen: UInt16 = 61

    init?(dev: OpaquePointer, queue: DispatchQueue) {
        var found: Int? = nil
        for i in 0..<Int(uvc_xu_count(dev)) {
            var id: Int32 = 0, nc: Int32 = 0, csz: Int32 = 0, bm: UInt32 = 0; var g = [UInt8](repeating: 0, count: 16)
            guard uvc_xu_info(dev, Int32(i), &id, &g, &nc, &csz, &bm) == 0 else { continue }
            if g == LinkTracking.guid { found = Int(id); break }
        }
        guard let u = found else { return nil }
        self.dev = dev; self.q = queue; self.unit = UInt8(u)
        var len: UInt16 = 0; var kr: Int32 = 0
        if uvc_get(dev, unit, 2, UInt8(UVC_GET_LEN), &len, 2, &kr) == 2, len > 2, len <= 512 { modeLen = UInt16(littleEndian: len) }
        tracking = readTracking()
        olog("tracking: Insta360 Link AI tracking on extension unit \(u) (mode selector 2, \(modeLen) bytes), camera reports \(tracking.map { $0 ? "ON" : "off" } ?? "unknown")")
    }

    /// Ask the camera (selector 2 byte 0: 0xff / 1 = tracking on).
    func readTracking() -> Bool? {
        var buf = [UInt8](repeating: 0, count: Int(modeLen)); var kr: Int32 = 0
        var r: Int32 = -1
        q.sync { r = uvc_get(dev, unit, 2, UInt8(UVC_GET_CUR), &buf, modeLen, &kr) }
        guard r > 0 else { return nil }
        return buf[0] != 0
    }

    @discardableResult func setTracking(_ on: Bool, _ via: String) -> Bool {
        let keep = on && holdPosition && tracking != true ? ptz?.readPanTilt() : nil
        var buf = [UInt8](repeating: 0, count: Int(modeLen))
        buf[0] = on ? 0x01 : 0x00; buf[1] = 0x00
        var kr: Int32 = 0; var ok = false
        q.sync {
            ok = uvc_set(dev, unit, 2, buf, modeLen, &kr) >= 0
            if ok, on, framing >= 1, framing <= 3 { var f = framing; _ = uvc_set(dev, unit, 19, &f, 1, &kr) }
        }
        if ok { writes &+= 1; tracking = on; olog("tracking: \(on ? "ON (find a face)" : "off")\(framing > 0 ? " framing \(framing)" : "") (\(via))") }
        if ok, let (p, t) = keep, let z = ptz {   // hold the position against the firmware's recentre, ~2.5 s, then let the tracker drive
            Thread { for _ in 0..<8 { usleep(300_000); guard self.tracking == true else { return }; z.holdPanTilt(p, t) }
                     olog("tracking: searching from pan \(p / 3600)° tilt \(t / 3600)° (held, not recentred)") }.start()
        }
        scanGen &+= 1; scanning = false
        if ok, on, scan, ptz != nil { let gen = scanGen; Thread { self.monitor(gen, settle: keep != nil ? 3.0 : 0.5) }.start() }
        else { errors &+= 1; olog("tracking: write failed IOKit 0x\(String(UInt32(bitPattern: kr), radix: 16)) (\(via))") }
        return ok
    }

    /// The lost-target watcher (one per "tracking on"; a newer generation or tracking off ends it).
    private func monitor(_ gen: UInt64, settle: Double) {
        guard ptz != nil, let fw = faces else { return }
        usleep(UInt32(settle * 1e6))
        let armed = Date()
        while tracking == true, scanGen == gen {
            usleep(250_000)
            let since = fw.lastSeen.map { Date().timeIntervalSince($0) } ?? Date().timeIntervalSince(armed)
            if since >= scanLostAfter { runScan(gen, dir: fw.exitDir) }
        }
    }
    /// Tilt up and pan limit to limit until the firmware takes the gimbal somewhere else (a face) or tracking ends.
    private func runScan(_ gen: UInt64, dir: Double) {
        guard let z = ptz, let fw = faces else { return }
        scanning = true; scans &+= 1
        let tilt = Int32(scanTilt * 3600), lo = Double(z.panMin), hi = Double(z.panMax)
        // the gimbal's real pan is unknown (the firmware moved it): start from the last pan we set, heading the way the face left
        var phase0 = asin(max(-1, min(1, (Double(z.pan) - (lo + hi) / 2) / ((hi - lo) / 2))))
        if dir < 0 { phase0 = Double.pi - phase0 }
        olog("tracking: face lost for \(Int(scanLostAfter)) s: scanning \(dir < 0 ? "left" : "right") first, tilt \(Int(scanTilt))°, \(Int(scanPeriod)) s per sweep")
        let t0 = Date()
        while tracking == true, scanGen == gen {
            if let s = fw.lastSeen, Date().timeIntervalSince(s) < 0.8 { olog("tracking: scan ended, a face is back (x \(String(format: "%.2f", fw.lastX)))"); break }
            let ph = phase0 + 2 * Double.pi * Date().timeIntervalSince(t0) / scanPeriod
            z.holdPanTilt(Int32(((lo + hi) / 2 + (hi - lo) / 2 * sin(ph)).rounded()), tilt)
            usleep(200_000)
        }
        scanning = false
    }

    /// Raw GET_CUR of an extension-unit selector: hex bytes and, when the length allows, little-endian floats (diagnosis).
    func dumpSelector(_ sel: UInt8) -> String {
        var len: UInt16 = 0; var kr: Int32 = 0
        var r: Int32 = -1
        q.sync { r = uvc_get(dev, unit, sel, UInt8(UVC_GET_LEN), &len, 2, &kr) }
        guard r == 2, len > 0, len <= 512 else { return "xu \(sel): no length (r=\(r) kr=0x\(String(UInt32(bitPattern: kr), radix: 16)))" }
        var buf = [UInt8](repeating: 0, count: Int(len))
        q.sync { r = uvc_get(dev, unit, sel, UInt8(UVC_GET_CUR), &buf, len, &kr) }
        guard r > 0 else { return "xu \(sel) len \(len): read failed kr=0x\(String(UInt32(bitPattern: kr), radix: 16))" }
        let hex = buf.map { String(format: "%02x", $0) }.joined(separator: " ")
        var floats = ""
        if len % 4 == 0 { floats = " floats " + stride(from: 0, to: Int(len), by: 4).map { i in String(format: "%.3g", buf[i..<i+4].withUnsafeBytes { $0.loadUnaligned(as: Float.self) }) }.joined(separator: " ") }
        return "xu \(sel) len \(len): \(hex)\(floats)"
    }

    /// Gimbal re-centre (selector 14).
    func recenter() { var one: UInt8 = 1; var kr: Int32 = 0; q.sync { _ = uvc_set(dev, unit, 14, &one, 1, &kr) } }

    var trackingText: String { "tracking=\(tracking.map { $0 ? "on" : "off" } ?? "unknown") framing=\(framing) kind=link" }
    func statusDict() -> [String: Any] { ["kind": "link", "on": (tracking as Any?) ?? NSNull(), "framing": Int(framing), "unit": Int(unit), "writes": Int(writes), "errors": Int(errors), "scanning": scanning, "scans": Int(scans), "faces": faces?.text ?? "off"] }
}
