import Foundation
import Vision
import CoreVideo

/// Looks at the camera's own frames a few times a second (Vision face rectangles) so the sender knows what the Link's AI
/// tracker cannot tell us: whether there is a face in the picture, and which way it left. Cheap: one small request at ~2 Hz.
final class FaceWatch {
    private let q = DispatchQueue(label: "oats-cam.face", qos: .utility)
    private var busy = false
    private var lastRunNs: UInt64 = 0
    var intervalMs: UInt64 = 500
    private(set) var lastSeen: Date? = nil        // when a face was last in frame
    private(set) var lastX: Double = 0.5          // its centre, 0 = left edge of the picture, 1 = right
    private(set) var exitDir: Double = 1          // +1: it was last heading / seen right of centre, -1: left
    private(set) var frames: UInt64 = 0, faces: UInt64 = 0, errors: UInt64 = 0
    private var prevX: Double? = nil

    func consider(_ pb: CVPixelBuffer) {
        let now = monoNs()
        guard !busy, now - lastRunNs > intervalMs * 1_000_000 else { return }
        busy = true; lastRunNs = now
        q.async { [self] in
            defer { busy = false }
            let req = VNDetectFaceRectanglesRequest()
            do { try VNImageRequestHandler(cvPixelBuffer: pb, orientation: .up, options: [:]).perform([req]) }
            catch { errors &+= 1; if errors <= 3 { olog("face: detector failed: \(error.localizedDescription)") }; return }
            frames &+= 1
            if let f = (req.results ?? []).max(by: { $0.boundingBox.width < $1.boundingBox.width }) {
                faces &+= 1
                let x = Double(f.boundingBox.midX)
                if let p = prevX, abs(x - p) > 0.02 { exitDir = x > p ? 1 : -1 } else { exitDir = x >= 0.5 ? 1 : -1 }
                prevX = x; lastX = x; lastSeen = Date()
            } else { prevX = nil }
        }
    }
    var text: String { "face=\(lastSeen.map { String(format: "%.1fs ago", Date().timeIntervalSince($0)) } ?? "never") x=\(String(format: "%.2f", lastX)) dir=\(exitDir > 0 ? "right" : "left") frames=\(frames) faces=\(faces)" }
}
