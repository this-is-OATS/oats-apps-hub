import Foundation

/// On-camera tally: drives the camera's own status LED from the NDI tally the receivers set on us.
/// Only the OBSBOT Tiny family has a reachable LED: vendor extension unit GUID 9a1e7291-6843-4683-6d92-39bc7906ee49,
/// selector 6 is its command channel: `1a 01 v` = brightness 0 (off) … 3 (full) (confirmed on our Tiny 2 2026-11-01: the
/// status block byte 0x21 follows the write), `18 01 b` = solid (0) / blink (1) (from the obsbot4linux / cgevans captures of
/// OBSBOT Center). Colour is firmware-owned (green idle, blue tracking, yellow lost, purple hand, red fault), so the signal
/// is: not live = off, program = full, preview = blink (mode "blink") or full (mode "on").
/// The Insta360 Link 2's ring belongs to its gimbal MCU: nothing on USB reaches it, so there `supported` stays false.
final class TallyLED {
    enum Mode: String { case off, on, blink }   // off = never touch the LED
    static let obsbotGUID: [UInt8] = [0x91, 0x72, 0x1e, 0x9a, 0x43, 0x68, 0x83, 0x46, 0x6d, 0x92, 0x39, 0xbc, 0x79, 0x06, 0xee, 0x49]
    let dev: OpaquePointer
    let q: DispatchQueue            // the PTZ queue: one thread talks to the camera's control pipe
    let unit: UInt8
    var mode: Mode
    private(set) var program = false, preview = false
    private(set) var writes: UInt64 = 0, errors: UInt64 = 0
    private var lastLevel = -1, lastBlink = -1

    /// nil when the camera has no known LED control (then the sender just logs tally, as before).
    init?(dev: OpaquePointer, queue: DispatchQueue, mode: Mode) {
        var found: Int? = nil
        for i in 0..<Int(uvc_xu_count(dev)) {
            var id: Int32 = 0, nc: Int32 = 0, csz: Int32 = 0, bm: UInt32 = 0; var g = [UInt8](repeating: 0, count: 16)
            guard uvc_xu_info(dev, Int32(i), &id, &g, &nc, &csz, &bm) == 0 else { continue }
            if g == TallyLED.obsbotGUID { found = Int(id); break }
        }
        guard let u = found else { return nil }
        self.dev = dev; self.q = queue; self.unit = UInt8(u); self.mode = mode
        olog("tally led: OBSBOT LED control on extension unit \(u), mode \(mode.rawValue)")
    }

    /// Called from the NDI metadata thread whenever the tally changes.
    func apply(program p: Bool, preview v: Bool) {
        program = p; preview = v
        guard mode != .off else { return }
        let level = p || (v && mode == .on) ? 3 : (v ? 3 : 0)
        let blink = (v && !p && mode == .blink) ? 1 : 0
        q.async { [self] in
            if level != lastLevel { if cmd([0x1a, 0x01, UInt8(level)]) { lastLevel = level } }
            if blink != lastBlink { if cmd([0x18, 0x01, UInt8(blink)]) { lastBlink = blink } }
        }
    }

    /// Hand the LED back to the camera (full, solid) before we exit, so a stopped sender doesn't leave it dark.
    func restore() {
        guard mode != .off else { return }
        q.sync { [self] in _ = cmd([0x18, 0x01, 0x00]); _ = cmd([0x1a, 0x01, 0x03]); lastLevel = 3; lastBlink = 0 }
    }

    func setMode(_ m: Mode) { let was = mode; mode = m; if m == .off && was != .off { restore() } else { apply(program: program, preview: preview) } }

    private func cmd(_ b: [UInt8]) -> Bool {
        var kr: Int32 = 0
        if uvc_set(dev, unit, 6, b, UInt16(b.count), &kr) < 0 {
            errors &+= 1; if errors < 5 || errors % 100 == 0 { olog("tally led: write failed IOKit 0x\(String(UInt32(bitPattern: kr), radix: 16)) (\(errors))") }
            return false
        }
        writes &+= 1; return true
    }

    // MARK: AI tracking ("find a face"), same channel: tag 0x16, 2 bytes [enable 0x02 on / 0x00 off, framing 0 normal
    // 1 upper-body 2 close-up 3 headless 4 lower-body] (lxman/obsbot-mcp tiny2_specification §5). The firmware drops to manual
    // whenever the host moves the gimbal (any remote pan/tilt), so the hub re-sends "track on" after PTZ when tracking is wanted.
    private(set) var tracking: Bool? = nil     // last state we set (nil = never set)
    var framing: UInt8 = 0
    @discardableResult func setTracking(_ on: Bool, _ via: String) -> Bool {
        var ok = false
        q.sync { [self] in ok = cmd([0x16, 0x02, on ? 0x02 : 0x00, framing]) }
        if ok { tracking = on; olog("tracking: \(on ? "ON" : "off") framing \(framing) (\(via))") }
        return ok
    }
    var trackingText: String { "tracking=\(tracking.map { $0 ? "on" : "off" } ?? "unknown") framing=\(framing)" }

    var statusText: String { "led=\(mode.rawValue) level=\(lastLevel) blink=\(lastBlink) writes=\(writes) err=\(errors)" }
    func statusDict() -> [String: Any] { ["mode": mode.rawValue, "tracking": (tracking as Any?) ?? NSNull(), "framing": Int(framing), "unit": Int(unit), "level": lastLevel, "blink": lastBlink == 1, "writes": Int(writes), "errors": Int(errors)] }
}

/// The last tally the receivers set on this sender (program = on air somewhere, preview = cued somewhere). NDI merges the
/// tally of every receiver, so this is the truth the hub and any external lamp should show, not the hub's own selection.
final class TallyState {
    private let lock = NSLock()
    private var p = false, v = false
    func set(program: Bool, preview: Bool) { lock.lock(); p = program; v = preview; lock.unlock() }
    var program: Bool { lock.lock(); defer { lock.unlock() }; return p }
    var preview: Bool { lock.lock(); defer { lock.unlock() }; return v }
    var text: String { "tally program=\(program ? 1 : 0) preview=\(preview ? 1 : 0)" }
}
