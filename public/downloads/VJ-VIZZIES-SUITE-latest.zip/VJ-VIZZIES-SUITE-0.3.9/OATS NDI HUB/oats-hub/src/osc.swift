import Foundation

/// OSC input (UDP, HUB_OSC_PORT, default 7081): camera moves, selection and mic control for a lighting console
/// (grandMA3 `SendOSC`) and for automation (OBS scene macros, scripts). Same actions as the HTTP API.
/// <cam> is a source id ("obs-host-obsbot-cam") or any unique part of it ("obsbot", "link"), or "selected".
///   /ptz/<cam>/recall i [f speed 0..1]     /ptz/<cam>/store i          /ptz/<cam>/home
///   /ptz/<cam>/abs f pan f tilt (-1..1)    /ptz/<cam>/zoom f (0..1)    /ptz/<cam>/focus f   /ptz/<cam>/af
///   /ptz/<cam>/speed f pan f tilt (-1..1)  /ptz/<cam>/zoom_speed f     /ptz/<cam>/stop
///   /select <cam> | /select none           /audio/<cam>/on|off|toggle|voice-on|voice-off
///   /track/<cam>/on|off|toggle  (OBSBOT AI face tracking; any remote pan/tilt turns it off on the camera)
///   /sweep/<cam>/on|off|toggle [f range 0..1] [f period s] [f tilt]   (slow pan back and forth until off; a manual pan ends it)
/// Ints and floats are accepted for every number. OSC bundles are unpacked. Replies are not sent.
final class OSCServer {
    let hub: Hub
    let port: UInt16
    private var fd: Int32 = -1
    private(set) var received: UInt64 = 0, unknown: UInt64 = 0
    private var speedLogged: UInt64 = 0

    init(hub: Hub, port: UInt16) { self.hub = hub; self.port = port }

    /// nil on success, else why it could not listen.
    func start() -> String? {
        fd = socket(AF_INET, SOCK_DGRAM, 0)
        guard fd >= 0 else { return "socket() failed" }
        var one: Int32 = 1
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, socklen_t(MemoryLayout<Int32>.size))
        var addr = sockaddr_in(); addr.sin_family = sa_family_t(AF_INET); addr.sin_port = port.bigEndian; addr.sin_addr.s_addr = INADDR_ANY
        let r = withUnsafePointer(to: &addr) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) } }
        guard r == 0 else { close(fd); fd = -1; return "bind 0.0.0.0:\(port) failed: \(String(cString: strerror(errno)))" }
        let t = Thread { [self] in self.run() }
        t.name = "osc-in"; t.start()
        return nil
    }

    private func run() {
        var buf = [UInt8](repeating: 0, count: 4096)
        while true {
            var from = sockaddr_in(); var flen = socklen_t(MemoryLayout<sockaddr_in>.size)
            let n = withUnsafeMutablePointer(to: &from) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { recvfrom(fd, &buf, buf.count, 0, $0, &flen) } }
            guard n > 0 else { usleep(10_000); continue }
            received &+= 1
            let ip = String(cString: inet_ntoa(from.sin_addr))
            for (address, args) in OSCServer.messages(Array(buf[0..<n])) { handle(address, args, from: ip) }
        }
    }

    // MARK: parsing

    static func messages(_ d: [UInt8]) -> [(String, [Any])] {
        if d.count >= 16, String(decoding: d[0..<7], as: UTF8.self) == "#bundle" {
            var out: [(String, [Any])] = []; var i = 16
            while i + 4 <= d.count {
                let len = Int(d[i]) << 24 | Int(d[i + 1]) << 16 | Int(d[i + 2]) << 8 | Int(d[i + 3]); i += 4
                guard len > 0, i + len <= d.count else { break }
                out += messages(Array(d[i..<i + len])); i += len
            }
            return out
        }
        guard let m = message(d) else { return [] }
        return [m]
    }

    static func message(_ d: [UInt8]) -> (String, [Any])? {
        var i = 0
        func str() -> String? {
            guard let z = d[i...].firstIndex(of: 0) else { return nil }
            let s = String(decoding: d[i..<z], as: UTF8.self)
            i = (z + 1 + 3) & ~3
            return s
        }
        guard let address = str(), address.hasPrefix("/") else { return nil }
        guard i < d.count, let tags = str(), tags.hasPrefix(",") else { return (address, []) }
        var args: [Any] = []
        for t in tags.dropFirst() {
            switch t {
            case "i": guard i + 4 <= d.count else { return (address, args) }
                args.append(Int(Int32(bitPattern: UInt32(d[i]) << 24 | UInt32(d[i + 1]) << 16 | UInt32(d[i + 2]) << 8 | UInt32(d[i + 3])))); i += 4
            case "f": guard i + 4 <= d.count else { return (address, args) }
                args.append(Float(bitPattern: UInt32(d[i]) << 24 | UInt32(d[i + 1]) << 16 | UInt32(d[i + 2]) << 8 | UInt32(d[i + 3]))); i += 4
            case "d": guard i + 8 <= d.count else { return (address, args) }
                var v: UInt64 = 0; for k in 0..<8 { v = v << 8 | UInt64(d[i + k]) }; args.append(Float(Double(bitPattern: v))); i += 8
            case "s", "S": guard let s = str() else { return (address, args) }; args.append(s)
            case "T": args.append(1); case "F": args.append(0); case "N": args.append(0)
            default: return (address, args)
            }
        }
        return (address, args)
    }

    // MARK: actions

    private func num(_ a: [Any], _ k: Int) -> Float? {
        guard k < a.count else { return nil }
        if let f = a[k] as? Float { return f }; if let i = a[k] as? Int { return Float(i) }
        if let s = a[k] as? String { return Float(s) }
        return nil
    }
    private func text(_ a: [Any], _ k: Int) -> String? {
        guard k < a.count else { return nil }
        if let s = a[k] as? String { return s }; if let i = a[k] as? Int { return String(i) }; if let f = a[k] as? Float { return String(f) }
        return nil
    }

    /// "selected", an exact id, or a unique part of an id.
    private func resolve(_ cam: String) -> Source? {
        let c = cam.lowercased()
        if c == "selected" { return hub.selected.flatMap { hub.source($0) } }
        if let s = hub.source(c) { return s }
        let hits = hub.sourcesSnapshot().filter { $0.id.contains(c) }
        return hits.count == 1 ? hits[0] : nil
    }

    private func handle(_ address: String, _ args: [Any], from ip: String) {
        let p = address.split(separator: "/").map(String.init)
        guard !p.isEmpty else { return }
        switch p[0] {
        case "ptz":
            guard p.count == 3 else { return bad(address, ip) }
            guard let src = resolve(p[1]) else { return bad(address, ip, "no camera '\(p[1])'") }
            let cmd = p[2]
            var a: [String: Any] = [:]
            switch cmd {
            case "recall", "store": a["index"] = NSNumber(value: Int(num(args, 0) ?? 1)); if let s = num(args, 1) { a["speed"] = NSNumber(value: s) }
            case "abs", "speed": a["pan"] = NSNumber(value: num(args, 0) ?? 0); a["tilt"] = NSNumber(value: num(args, 1) ?? 0)
            case "zoom", "zoom_speed": a["zoom"] = NSNumber(value: num(args, 0) ?? 0)
            case "focus": a["distance"] = NSNumber(value: num(args, 0) ?? 0)
            case "home":
                _ = src.ptz("abs", ["pan": NSNumber(value: 0), "tilt": NSNumber(value: 0)]); _ = src.ptz("zoom", ["zoom": NSNumber(value: 0)])
                olog("osc \(ip) \(address) -> \(src.id) home"); return
            case "stop", "af", "wb_auto", "exposure_auto": break
            default: return bad(address, ip, "unknown ptz command '\(cmd)'")
            }
            let (ok, err) = src.ptz(cmd, a)
            if cmd == "speed" || cmd == "zoom_speed" { speedLogged &+= 1; if speedLogged % 100 == 1 { olog("osc \(ip) \(address) \(args) -> \(src.id) \(ok ? "ok" : err) (speed messages: \(speedLogged))") } }
            else { olog("osc \(ip) \(address) \(args) -> \(src.id) \(ok ? "ok" : err)") }
        case "select":
            let who = p.count > 1 ? p[1] : (text(args, 0) ?? "")
            if who == "none" || who.isEmpty { hub.select(nil); olog("osc \(ip) select none"); return }
            guard let src = resolve(who) else { return bad(address, ip, "no camera '\(who)'") }
            hub.select(src.id); olog("osc \(ip) select -> \(src.id)")
        case "track":   // /track/<cam>/on|off|toggle  (OBSBOT AI face tracking)
            guard p.count == 3, let src = resolve(p[1]) else { return bad(address, ip) }
            let want = p[2] == "toggle" ? (src.tracking == true ? "off" : "on") : p[2]
            let r = src.trackCommand(want)
            olog("osc \(ip) \(address) -> \(src.id) \(r ?? "no control port")")
        case "sweep":   // /sweep/<cam>/on|off|toggle [f range 0..1] [f period s] [f tilt -1..1]  (panning sweep; any manual pan ends it)
            guard p.count == 3, let src = resolve(p[1]) else { return bad(address, ip) }
            let want = p[2] == "toggle" ? (src.sweeping ? "off" : "on") : p[2]
            if want == "on" { src.sweepStart(range: num(args, 0) ?? 1, period: Double(num(args, 1) ?? 16), tilt: num(args, 2) ?? 0) } else { src.sweepStop() }
            olog("osc \(ip) \(address) -> \(src.id) sweep \(src.sweeping ? "on" : "off")")
        case "audio":
            guard p.count == 3, let src = resolve(p[1]) else { return bad(address, ip) }
            let r = src.audioCommand(p[2].replacingOccurrences(of: "-", with: " "))
            olog("osc \(ip) \(address) -> \(src.id) \(r ?? "no control port")")
        default: bad(address, ip)
        }
    }

    private func bad(_ address: String, _ ip: String, _ why: String = "unknown address") {
        unknown &+= 1
        if unknown <= 20 || unknown % 100 == 0 { olog("osc \(ip) \(address): \(why)") }
    }
}
