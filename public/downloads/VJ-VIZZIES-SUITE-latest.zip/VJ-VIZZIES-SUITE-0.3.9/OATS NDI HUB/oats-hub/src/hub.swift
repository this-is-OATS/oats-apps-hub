import Foundation
import ImageIO
import CoreGraphics

/// One NDI source: a low-bandwidth (proxy) receiver, the latest JPEG preview, PTZ passthrough, tally.
final class Source {
    let lib: NDILib
    let name: String
    let id: String
    var url: String
    let recv: NDIlib_recv_instance_t
    let lock = NSLock()
    let cond = NSCondition()
    private(set) var jpeg = Data()
    private(set) var seq: UInt64 = 0
    private(set) var width = 0, height = 0
    private(set) var frames: UInt64 = 0
    private(set) var lastFrameNs: UInt64 = 0
    private(set) var ptzSupported = false
    private(set) var connected = false
    var lastSeenNs: UInt64 = monoNs()
    var tally = false                 // what THIS hub set on the source (program or preview, per Source.tallyMode)
    static var tallyMode = "program"   // program | preview | off: what a hub selection means
    var program: Bool? = nil, preview: Bool? = nil, led: String? = nil   // the sender's merged NDI tally (oats-cam "tally" query), nil = not ours
    var lastLive: Bool? = nil
    /// On air: the sender's own program tally when it reports one (NDI merges every receiver), else this hub's selection in program mode.
    var live: Bool { program ?? (Source.tallyMode == "program" && tally) }
    var cued: Bool { preview ?? (Source.tallyMode == "preview" && tally) }
    var audio: String? = nil          // "on" / "off" from the sender's control port, nil = no control for this source
    var control: (String, UInt16)? = nil
    var ndiOn: Bool? = nil            // oats-cam "ndi on|off" (sending or idle), nil = unknown / no control
    var voice: Bool? = nil            // speech-gate mode (oats-cam "voice=on|off")
    var tracking: Bool? = nil         // OBSBOT AI face tracking (oats-cam "tracking=on|off"), nil = unknown / not an OBSBOT
    var gateOpen: Bool? = nil
    // panning sweep: a slow pan back and forth (abs pan = range * sin, tilt held) until it is turned off; any manual pan stops it
    private(set) var sweeping = false
    private var sweepThread: Thread?
    private var sweepGen: UInt64 = 0
    var feedbackHz = 0, feedbackAgeS = -1, feedbackEvents = 0
    var loopMs = 0, loopAgeS = -1, loopEvents = 0   // monitoring loop (own audio back through the mic)
    var previewFps: Double
    var quality: Double
    private var lastEncodeNs: UInt64 = 0
    private var thread: Thread?
    var stopping = false

    static func makeID(_ name: String) -> String {
        // url-safe id from the NDI name: "MAC.LOCALDOMAIN (Link Cam)" -> "mac-localdomain-link-cam"
        let s = name.lowercased().map { $0.isLetter || $0.isNumber ? String($0) : "-" }.joined()
        return s.split(separator: "-", omittingEmptySubsequences: true).joined(separator: "-")
    }

    init?(lib: NDILib, name: String, url: String, previewFps: Double, quality: Double, bandwidth: Int32) {
        self.lib = lib; self.name = name; self.url = url; self.id = Source.makeID(name); self.previewFps = previewFps; self.quality = quality
        var inst: NDIlib_recv_instance_t? = nil
        name.withCString { n in
            url.withCString { u in
                "oats-hub".withCString { rn in
                    var c = NDIlib_recv_create_v3_t(source_to_connect_to: NDIlib_source_t(p_ndi_name: n, p_url_address: url.isEmpty ? nil : u), color_format: 0 /* BGRX_BGRA */, bandwidth: bandwidth, allow_video_fields: false, p_ndi_recv_name: rn)
                    inst = lib.recv_create_v3(&c)
                }
            }
        }
        guard let r = inst else { return nil }
        recv = r
    }

    func start() {
        let t = Thread { [self] in self.loop() }
        t.name = "recv \(id)"; t.qualityOfService = .userInitiated; t.start(); thread = t
    }

    private func loop() {
        var sinceStatus: UInt64 = 0
        while !stopping {
            var vf = NDIlib_video_frame_v2_t(); var mf = NDIlib_metadata_frame_t()
            let t = lib.recv_capture_v2(recv, &vf, nil, &mf, 200)
            switch t {
            case 1:
                frames &+= 1
                let now = monoNs()
                lastFrameNs = now
                let minGap = UInt64(1e9 / max(previewFps, 1))
                if now - lastEncodeNs >= minGap, let d = encode(&vf) {
                    lastEncodeNs = now
                    cond.lock(); jpeg = d; seq &+= 1; width = Int(vf.xres); height = Int(vf.yres); cond.broadcast(); cond.unlock()
                }
                lib.recv_free_video_v2(recv, &vf)
            case 3:
                lib.recv_free_metadata(recv, &mf)
            case 100:
                ptzSupported = lib.ptz_is_supported(recv)
                connected = lib.recv_get_no_connections(recv) > 0
                olog("\(name): status change: connected=\(connected) ptz=\(ptzSupported)")
            default: break
            }
            sinceStatus &+= 1
            if sinceStatus % 10 == 0 {   // ~2 s: refresh connection + PTZ flags without waiting for status events
                let c = lib.recv_get_no_connections(recv) > 0
                let p = lib.ptz_is_supported(recv)
                if c != connected || p != ptzSupported { olog("\(name): connected=\(c) ptz=\(p)") }
                connected = c; ptzSupported = p
            }
        }
        lib.recv_destroy(recv)
    }

    /// BGRA frame -> JPEG via ImageIO.
    private func encode(_ f: inout NDIlib_video_frame_v2_t) -> Data? {
        guard let p = f.p_data, f.xres > 0, f.yres > 0 else { return nil }
        let len = Int(f.line_stride_in_bytes) * Int(f.yres)
        guard let provider = CGDataProvider(dataInfo: nil, data: p, size: len, releaseData: { _, _, _ in }) else { return nil }
        let info = CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)
        guard let img = CGImage(width: Int(f.xres), height: Int(f.yres), bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: Int(f.line_stride_in_bytes), space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: info, provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent) else { return nil }
        let out = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(out, "public.jpeg" as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(dest, img, [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary)
        guard CGImageDestinationFinalize(dest) else { return nil }
        return out as Data
    }

    /// The latest frame without waiting: (seq, jpeg); seq 0 = none yet.
    func latest() -> (UInt64, Data) { cond.lock(); defer { cond.unlock() }; return (seq, jpeg) }
    /// Wait for a frame newer than `after` (up to timeout). Returns (seq, jpeg) or nil.
    func waitFrame(after: UInt64, timeout: TimeInterval) -> (UInt64, Data)? {
        cond.lock(); defer { cond.unlock() }
        let deadline = Date().addingTimeInterval(timeout)
        while seq <= after { if !cond.wait(until: deadline) { return nil } }
        return (seq, jpeg)
    }

    func setTally(program: Bool, preview: Bool) {
        var t = NDIlib_tally_t(on_program: program, on_preview: preview)
        _ = lib.recv_set_tally(recv, &t); tally = program || preview
    }

    /// "tally" to the sender's control port -> "tally program=1 preview=0 led=blink level=3 ..." (oats-cam). nil = no answer.
    func tallyQuery() -> String? {
        guard let (host, port) = control else { return nil }
        guard let r = udpQuery(host: host, port: port, msg: "tally", timeoutMs: 300), r.hasPrefix("tally ") else { return nil }
        for w in r.split(separator: " ") {
            let kv = w.split(separator: "=", maxSplits: 1); guard kv.count == 2 else { continue }
            switch kv[0] {
            case "program": program = kv[1] == "1"
            case "preview": preview = kv[1] == "1"
            case "led": led = String(kv[1])
            case "tracking": tracking = kv[1] == "on" ? true : kv[1] == "off" ? false : nil
            default: break
            }
        }
        return r
    }

    func ptz(_ cmd: String, _ a: [String: Any]) -> (Bool, String) {
        if sweeping, ["speed", "abs", "recall", "home"].contains(cmd), a["_sweep"] == nil { sweepStop() }   // a hand on the camera ends the sweep
        func d(_ k: String) -> Float { Float((a[k] as? NSNumber)?.doubleValue ?? 0) }
        func i(_ k: String) -> Int { (a[k] as? NSNumber)?.intValue ?? 0 }
        let ok: Bool
        switch cmd {
        case "speed": ok = lib.ptz_pan_tilt_speed(recv, d("pan"), d("tilt"))
        case "abs": ok = lib.ptz_pan_tilt(recv, d("pan"), d("tilt"))
        case "zoom_speed": ok = lib.ptz_zoom_speed(recv, d("zoom"))
        case "zoom": ok = lib.ptz_zoom(recv, d("zoom"))
        case "store": ok = lib.ptz_store_preset(recv, Int32(i("index")))
        case "recall": ok = lib.ptz_recall_preset(recv, Int32(i("index")), a["speed"] == nil ? 1 : d("speed"))
        case "af": ok = lib.ptz_auto_focus(recv)
        case "focus": ok = lib.ptz_focus(recv, d("distance"))
        case "wb_auto": ok = lib.ptz_white_balance_auto(recv)
        case "exposure_auto": ok = lib.ptz_exposure_auto(recv)
        case "stop": ok = lib.ptz_pan_tilt_speed(recv, 0, 0) && lib.ptz_zoom_speed(recv, 0)
        default: return (false, "unknown command \(cmd)")
        }
        return (ok, ok ? "" : "receiver refused (not connected or no PTZ)")
    }

    /// Panning sweep, limit to limit: an absolute pan to +range, then to -range, every period/2 seconds. The camera glides to
    /// each target at its own hardware speed (smooth); a half period shorter than the travel just reverses it earlier.
    /// Called while sweeping it only updates the parameters.
    var sweepRange: Float = 1, sweepPeriod: Double = 16, sweepTilt: Float = 0
    func sweepStart(range: Float = 1, period: Double = 16, tilt: Float = 0) {
        sweepRange = max(0.05, min(1, range)); sweepPeriod = max(2, period); sweepTilt = tilt
        if sweeping { return }
        sweepGen &+= 1; let gen = sweepGen
        sweeping = true
        let th = Thread { [self] in
            var dir: Float = 1, next = Date()
            while sweeping, sweepGen == gen, !stopping {
                if Date() >= next {
                    _ = ptz("abs", ["pan": NSNumber(value: sweepRange * dir), "tilt": NSNumber(value: sweepTilt), "_sweep": true])
                    dir = -dir; next = Date().addingTimeInterval(sweepPeriod / 2)
                }
                usleep(50_000)
            }
        }
        th.name = "sweep-\(id)"; sweepThread = th; th.start()
        olog("sweep \(id): on (range \(sweepRange) period \(sweepPeriod)s tilt \(sweepTilt))")
    }
    func sweepStop() {
        guard sweeping else { return }
        sweeping = false; sweepGen &+= 1
        _ = ptz("stop", [:])
        olog("sweep \(id): off")
    }

    func status() -> [String: Any] {
        let now = monoNs()
        return ["id": id, "name": name, "url": url, "connected": connected, "ptz": ptzSupported, "frames": Int(frames), "width": width, "height": height,
                "age_ms": lastFrameNs == 0 ? -1 : Int((now &- lastFrameNs) / 1_000_000), "tally": tally, "live": live, "cued": cued,
                "program": (program as Any?) ?? NSNull(), "preview": (preview as Any?) ?? NSNull(), "led": (led as Any?) ?? NSNull(), "audio": (audio as Any?) ?? NSNull(), "voice": (voice as Any?) ?? NSNull(), "tracking": (tracking as Any?) ?? NSNull(), "sweep": sweeping, "sweep_period": sweepPeriod, "gate_open": (gateOpen as Any?) ?? NSNull(), "ndi_on": (ndiOn as Any?) ?? NSNull(),
                "feedback_hz": feedbackHz, "feedback_age_s": feedbackAgeS, "feedback_events": feedbackEvents,
                "loop_ms": loopMs, "loop_age_s": loopAgeS, "loop_events": loopEvents]
    }

    /// "track on|off|status" to the sender's control port (OBSBOT AI tracking). Returns the reply or nil.
    func trackCommand(_ cmd: String) -> String? {
        guard let (host, port) = control else { return nil }
        guard let r = udpQuery(host: host, port: port, msg: cmd == "status" ? "track" : "track \(cmd)", timeoutMs: 400) else { return nil }
        if r.hasPrefix("tracking=on") { tracking = true } else if r.hasPrefix("tracking=off") { tracking = false } else if r.hasPrefix("tracking=none") { tracking = nil }
        return r
    }

    /// "ndi on|off|toggle|status" to the sender's control port: oats-cam stops / resumes sending frames (camera stays open). Returns the reply or nil.
    func ndiCommand(_ cmd: String) -> String? {
        guard let (host, port) = control else { return nil }
        guard let r = udpQuery(host: host, port: port, msg: cmd == "status" ? "ndi" : "ndi \(cmd)", timeoutMs: 400) else { return nil }
        if r.hasPrefix("ndi on") { ndiOn = true } else if r.hasPrefix("ndi off") { ndiOn = false } else { ndiOn = nil }   // an older oats-cam answers "error: unknown command"
        return r
    }

    /// "audio on|off|toggle|status" to the sender's UDP control port (oats-cam). Returns the reply or nil.
    func audioCommand(_ cmd: String) -> String? {
        guard let (host, port) = control else { return nil }
        guard let r = udpQuery(host: host, port: port, msg: "audio \(cmd)", timeoutMs: 400) else { return nil }
        if r.hasPrefix("audio on") { audio = "on" } else if r.hasPrefix("audio off") { audio = "off" }
        // "audio on voice=on gate=open feedback=1250Hz age=3s events=2"
        var hz = 0, age = -1, ev = 0
        for w in r.split(separator: " ") {
            let kv = w.split(separator: "=", maxSplits: 1); guard kv.count == 2 else { continue }
            switch kv[0] {
            case "voice": voice = kv[1] == "on"
            case "gate": gateOpen = kv[1] == "open"
            case "feedback": hz = Int(kv[1].replacingOccurrences(of: "Hz", with: "")) ?? 0
            case "age": age = Int(kv[1].replacingOccurrences(of: "s", with: "")) ?? -1
            case "events": ev = Int(kv[1]) ?? 0
            case "loop": loopMs = Int(kv[1].replacingOccurrences(of: "ms", with: "")) ?? 0
            case "loopage": loopAgeS = Int(kv[1].replacingOccurrences(of: "s", with: "")) ?? -1
            case "loops": loopEvents = Int(kv[1]) ?? 0
            default: break
            }
        }
        feedbackHz = hz; feedbackAgeS = age; feedbackEvents = ev
        return r
    }
}

/// Minimal OSC 1.0 message: address + type tags, args are Int32 ("i") or String ("s").
func oscPacket(_ address: String, _ args: [Any]) -> Data {
    func pad(_ d: Data) -> Data { var d = d; d.append(0); while d.count % 4 != 0 { d.append(0) }; return d }
    var out = pad(Data(address.utf8))
    var tags = ","
    var body = Data()
    for a in args {
        if let i = a as? Int32 { tags += "i"; var be = i.bigEndian; body.append(Data(bytes: &be, count: 4)) }
        else if let str = a as? String { tags += "s"; body.append(pad(Data(str.utf8))) }
    }
    out.append(pad(Data(tags.utf8))); out.append(body)
    return out
}

func udpSend(host: String, port: UInt16, data: Data) {
    let fd = socket(AF_INET, SOCK_DGRAM, 0); guard fd >= 0 else { return }
    defer { close(fd) }
    var addr = sockaddr_in(); addr.sin_family = sa_family_t(AF_INET); addr.sin_port = port.bigEndian; addr.sin_addr.s_addr = inet_addr(host)
    _ = withUnsafePointer(to: &addr) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { p in data.withUnsafeBytes { sendto(fd, $0.baseAddress, data.count, 0, p, socklen_t(MemoryLayout<sockaddr_in>.size)) } } }
}

func udpQuery(host: String, port: UInt16, msg: String, timeoutMs: Int) -> String? {
    let fd = socket(AF_INET, SOCK_DGRAM, 0); guard fd >= 0 else { return nil }
    defer { close(fd) }
    var tv = timeval(tv_sec: 0, tv_usec: Int32(timeoutMs * 1000)); setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
    var addr = sockaddr_in(); addr.sin_family = sa_family_t(AF_INET); addr.sin_port = port.bigEndian; addr.sin_addr.s_addr = inet_addr(host)
    let sent = withUnsafePointer(to: &addr) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { p in msg.withCString { sendto(fd, $0, strlen($0), 0, p, socklen_t(MemoryLayout<sockaddr_in>.size)) } } }
    guard sent > 0 else { return nil }
    var buf = [UInt8](repeating: 0, count: 256)
    let n = recv(fd, &buf, buf.count, 0); guard n > 0 else { return nil }
    return String(decoding: buf[0..<n], as: UTF8.self)
}

/// Finds sources and keeps one Source per NDI name.
final class Hub {
    let lib: NDILib
    let lock = NSLock()
    private(set) var sources: [String: Source] = [:]   // by id
    var order: [String] = []
    var selected: String? = nil
    let previewFps: Double, quality: Double, bandwidth: Int32
    let tallyMode: String             // program | preview | off
    // tally out: OSC to a console (MA3) when a source goes on/off air. HUB_TALLY_OSC=host:port, HUB_TALLY_ON_CMD / HUB_TALLY_OFF_CMD
    // = the /cmd string with %s = the source's short name (e.g. Go+ Sequence "TALLY %s"); /tally/<id>,i,0|1 is always sent too.
    let tallyOSC: (String, UInt16)?
    let tallyOnCmd: String, tallyOffCmd: String
    private var find: NDIlib_find_instance_t?
    /// HUB_AUDIO_CTL="Link Cam=127.0.0.1:7001;Other Cam=192.168.1.20:7001": source short name -> oats-cam control port
    let audioCtl: [String: (String, UInt16)]

    init(lib: NDILib, previewFps: Double, quality: Double, bandwidth: Int32, tallyMode: String) {
        self.lib = lib; self.previewFps = previewFps; self.quality = quality; self.bandwidth = bandwidth; self.tallyMode = tallyMode
        Source.tallyMode = tallyMode
        let env = ProcessInfo.processInfo.environment
        if let hp = env["HUB_TALLY_OSC"]?.split(separator: ":"), hp.count == 2, let port = UInt16(hp[1]) { tallyOSC = (String(hp[0]), port) } else { tallyOSC = nil }
        tallyOnCmd = env["HUB_TALLY_ON_CMD"] ?? ""; tallyOffCmd = env["HUB_TALLY_OFF_CMD"] ?? ""
        if let t = tallyOSC { olog("hub: tally out -> osc \(t.0):\(t.1) on='\(tallyOnCmd)' off='\(tallyOffCmd)'") }
        var m: [String: (String, UInt16)] = [:]
        for e in (ProcessInfo.processInfo.environment["HUB_AUDIO_CTL"] ?? "").split(separator: ";") {
            let kv = e.split(separator: "=", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            guard kv.count == 2 else { continue }
            let hp = kv[1].split(separator: ":"); guard hp.count == 2, let port = UInt16(hp[1]) else { continue }
            m[kv[0]] = (String(hp[0]), port)
        }
        audioCtl = m
        if !m.isEmpty { olog("hub: audio control for \(m.keys.sorted().joined(separator: ", "))") }
    }
    /// "HOST (Short Name)" -> "Short Name"
    static func shortName(_ name: String) -> String {
        guard let l = name.lastIndex(of: "("), let r = name.lastIndex(of: ")"), l < r else { return name }
        return String(name[name.index(after: l)..<r])
    }

    func start() {
        var c = NDIlib_find_create_t(show_local_sources: true, p_groups: nil, p_extra_ips: nil)
        find = lib.find_create_v2(&c)
        guard find != nil else { olog("hub: NDIlib_find_create_v2 failed"); exit(70) }
        let t = Thread { [self] in
            while true {
                _ = lib.find_wait_for_sources(find, 1000)
                var n: UInt32 = 0
                guard let list = lib.find_get_current_sources(find, &n) else { continue }
                var seen = Set<String>()
                for k in 0..<Int(n) {
                    let s = list[k]
                    let name = s.p_ndi_name.map { String(cString: $0) } ?? ""
                    let url = s.p_url_address.map { String(cString: $0) } ?? ""
                    guard !name.isEmpty, !name.hasSuffix("(oats-hub)") else { continue }   // never receive ourselves, whatever the machine name
                    let id = Source.makeID(name)
                    seen.insert(id)
                    lock.lock()
                    if let src = sources[id] { src.lastSeenNs = monoNs(); src.url = url; lock.unlock(); continue }
                    guard let src = Source(lib: lib, name: name, url: url, previewFps: previewFps, quality: quality, bandwidth: bandwidth) else { lock.unlock(); olog("hub: recv_create failed for \(name)"); continue }
                    src.control = audioCtl[Hub.shortName(name)]
                    sources[id] = src; order.append(id)
                    lock.unlock()
                    src.start()
                    olog("hub: + \(name) [\(id)] \(url)")
                }
                // drop sources unseen for 60 s
                lock.lock()
                let now = monoNs()
                for (id, src) in sources where !seen.contains(id) && now - src.lastSeenNs > 60_000_000_000 {
                    olog("hub: - \(src.name) (gone 60 s)"); src.stopping = true; sources[id] = nil; order.removeAll { $0 == id }
                    if selected == id { selected = nil }
                }
                lock.unlock()
            }
        }
        t.name = "ndi-find"; t.start()
        // audio state poll for sources with a control port (every 2 s)
        let ap = Thread { [self] in
            while true {
                usleep(2_000_000)
                lock.lock(); let withCtl = sources.values.filter { $0.control != nil }; lock.unlock()
                for s in withCtl { if s.audioCommand("status") == nil { s.audio = nil; s.ndiOn = nil } else { _ = s.ndiCommand("status") } }
            }
        }
        ap.name = "audio-poll"; ap.start()
    }

    func source(_ id: String) -> Source? { lock.lock(); defer { lock.unlock() }; return sources[id] }
    func sourcesSnapshot() -> [Source] { lock.lock(); defer { lock.unlock() }; return order.compactMap { sources[$0] } }
    func list() -> [[String: Any]] {
        lock.lock(); defer { lock.unlock() }
        return order.compactMap { sources[$0]?.status() }
    }
    func select(_ id: String?) {
        lock.lock(); defer { lock.unlock() }
        selected = id
        guard tallyMode != "off" else { return }
        for (sid, s) in sources { s.setTally(program: tallyMode == "program" && sid == id, preview: tallyMode == "preview" && sid == id) }
    }

    /// Every 300 ms: ask our senders for their merged NDI tally, and on any source's on-air change send the tally-out OSC.
    func startTallyPoll() {
        let t = Thread { [self] in
            while true {
                usleep(300_000)
                for s in sourcesSnapshot() {
                    if s.control != nil, s.tallyQuery() == nil { s.program = nil; s.preview = nil; s.led = nil }
                    let now = s.live
                    if s.lastLive != now {
                        let first = s.lastLive == nil
                        s.lastLive = now
                        if first && !now { continue }        // startup, off: nothing to announce
                        olog("tally: \(Hub.shortName(s.name)) \(now ? "ON AIR" : "off")")
                        tallyOut(s, now)
                    }
                }
            }
        }
        t.name = "tally-poll"; t.start()
    }

    private func tallyOut(_ s: Source, _ on: Bool) {
        guard let (host, port) = tallyOSC else { return }
        udpSend(host: host, port: port, data: oscPacket("/tally/\(s.id)", [Int32(on ? 1 : 0)]))
        let tpl = on ? tallyOnCmd : tallyOffCmd
        if !tpl.isEmpty { udpSend(host: host, port: port, data: oscPacket("/cmd", [tpl.replacingOccurrences(of: "%s", with: Hub.shortName(s.name))])) }
    }
}
