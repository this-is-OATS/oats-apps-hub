@echo off
title VJ VIZZIES
rem VJ VIZZIES control window for Windows (console version of "VJ VIZZIES.vbs", which does the same without a console flash).
rem Opens the Mac's GUI in an Edge app window (Chrome if Edge is missing) with its own profile in %LOCALAPPDATA%\OATS VIZ (old folder name kept, so the saved size stays).
setlocal
set "URL=http://192.168.1.148:8090"
set "PROF=%LOCALAPPDATA%\OATS VIZ"
if not exist "%PROF%" mkdir "%PROF%"

set "EXE="
set "KIND=Edge"
for %%P in ("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" "%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe") do (
  if not defined EXE if exist "%%~P" set "EXE=%%~P"
)
if not defined EXE (
  set "KIND=Chrome"
  for %%P in ("%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe") do (
    if not defined EXE if exist "%%~P" set "EXE=%%~P"
  )
)
if not defined EXE (
  echo Neither Microsoft Edge nor Google Chrome was found. Open %URL% in any browser instead.
  pause
  exit /b 1
)

set "SIZE="
if not exist "%PROF%\%KIND%.sized" (
  set "SIZE=--window-size=1920,1080"
  type nul > "%PROF%\%KIND%.sized"
)
start "" "%EXE%" --app=%URL% --user-data-dir="%PROF%\%KIND%" --no-first-run --no-default-browser-check %SIZE%
exit /b 0
