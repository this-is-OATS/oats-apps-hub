' VJ VIZZIES control window for Windows: opens the Mac's GUI in an Edge app window (Chrome if Edge is missing),
' with its own profile in %LOCALAPPDATA%\OATS VIZ (old folder name kept), so it gets its own taskbar button and remembers its size.
' No console window. Double-click this file, or a desktop shortcut to it (see README.txt).
Option Explicit
Const URL = "http://192.168.1.148:8090"

Dim sh, fso, prof, exe, kind, args, marker
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

Function FindExe(paths)
  Dim p, x
  FindExe = ""
  For Each p In paths
    x = sh.ExpandEnvironmentStrings(p)
    If fso.FileExists(x) Then
      FindExe = x
      Exit Function
    End If
  Next
End Function

prof = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\OATS VIZ"
If Not fso.FolderExists(prof) Then fso.CreateFolder prof

kind = "Edge"
exe = FindExe(Array("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe", _
                    "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe", _
                    "%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"))
If exe = "" Then
  kind = "Chrome"
  exe = FindExe(Array("%ProgramFiles%\Google\Chrome\Application\chrome.exe", _
                      "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe", _
                      "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"))
End If
If exe = "" Then
  MsgBox "Neither Microsoft Edge nor Google Chrome was found." & vbCrLf & "Open " & URL & " in any browser instead.", vbExclamation, "VJ VIZZIES"
  WScript.Quit 1
End If

args = "--app=" & URL & " --user-data-dir=""" & prof & "\" & kind & """ --no-first-run --no-default-browser-check"
' 1920x1080 on the first start only: after that the window opens where and how big you left it
marker = prof & "\" & kind & ".sized"
If Not fso.FileExists(marker) Then
  args = args & " --window-size=1920,1080"
  fso.CreateTextFile(marker, True).Close
End If
sh.Run """" & exe & """ " & args, 1, False
