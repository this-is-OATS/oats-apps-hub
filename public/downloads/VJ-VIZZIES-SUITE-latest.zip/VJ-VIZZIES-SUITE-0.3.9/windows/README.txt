VJ VIZZIES for Windows (control window)
=======================================

This folder opens the VJ VIZZIES controls (the GUI on the Mac mini, http://192.168.1.148:8090) in its own
Edge window: no tabs, no address bar, its own taskbar button, and it remembers its size and position.
Chrome is used if Edge is missing. Nothing is installed.

Install (2 steps)
  1. Copy this whole "windows" folder to the PC, for example to  C:\VJ VIZZIES
     (USB stick, or the network; keep the files together).
  2. Right-click "VJ VIZZIES.vbs" > Send to > Desktop (create shortcut).
     Then right-click the new desktop shortcut > Properties > Change Icon... > Browse...,
     pick "VJ VIZZIES.ico" from the folder, OK, OK. Rename the shortcut to "VJ VIZZIES" if you like.

Start it from the desktop shortcut. The first start opens at 1920 x 1080; after that it opens where you left it.

Notes
  - The PC must be on the lighting network (192.168.1.x, cable or the Netgear Wi-Fi "gooats.net"):
    the Mac refuses the controls from every other network.
  - If the Mac's address ever changes, edit the URL line at the top of "VJ VIZZIES.vbs" (and "VJ VIZZIES.cmd").
  - "VJ VIZZIES.cmd" does the same with a console window (useful to see an error).
  - The window's profile (size, zoom) lives in %LOCALAPPDATA%\OATS VIZ (old name kept). Delete that folder to start fresh.
  - Why not "Install app" in Edge: that needs HTTPS, and the GUI is plain http on the local network.
