import Foundation
import AVFoundation
import CoreVideo
import Accelerate

// oats-cam: a UVC webcam as an NDI source with PTZ control, no vendor software needed.
// Captures the camera with AVFoundation (2vuy = NDI UYVY, no conversion), sends it with libndi, advertises PTZ in the
// connection metadata, and turns the receivers' ntk_ptz_* commands into UVC pan/tilt/zoom/focus requests (src/uvc.c).
//
//   oats-cam [--name NAME] [--device MATCH] [--size WxH] [--fps N] [--log-dir DIR] [--presets FILE] [--no-ptz]
//            [--pan-rate DEG_S] [--tilt-rate DEG_S] [--zoom-rate FRAC_S] [--libndi PATH] [--list]

let usage = "usage: oats-cam [--name NAME] [--device MATCH] [--size WxH] [--fps N] [--log-dir DIR] [--presets FILE] [--no-ptz] [--pan-rate DEG_S] [--tilt-rate DEG_S] [--zoom-rate FRAC_S] [--audio-device MATCH] [--audio-on] [--no-audio] [--control-port N] [--tracking on|off|keep] [--libndi PATH] [--list]"
final class AudioState {
    var on = false; var sent: UInt64 = 0
    var feedbackMode = "mute"            // mute | duck | warn | off
    var feedbackEvents = 0; var lastFeedbackHz: Float = 0; var lastFeedbackNs: UInt64 = 0
    var duckUntilNs: UInt64 = 0
    var voice = false                   // speech gate on/off
    var gateOpen = true
    var gain: Float = 1                 // last applied gain (ramped per buffer to avoid clicks)
    var gateDb: Float = -40             // voice gate closed attenuation
    var echoMode = "mute"               // self-echo (monitoring loop): mute | duck | warn | off
    var echoEvents = 0; var lastEchoMs = 0; var lastEchoNs: UInt64 = 0
    var echo: EchoDetector? = nil
    var settingsPath = ""
    /// live-tunable settings: name -> (get, set)
    var detector: FeedbackDetector? = nil
    func settings() -> [String: Float] {
        guard let d = detector else { return [:] }
        return ["fb_level": d.levelDbfs, "fb_papr": d.paprDb, "fb_hold_ms": Float(d.holdHops) * 10.67, "fb_grow": d.growDb,
                "voice_snr": d.voiceSnrDb, "voice_flux": d.voiceFluxMin, "voice_hang_ms": Float(d.voiceHangHops) * 10.67, "gate_db": gateDb,
                "echo_corr": echo?.threshold ?? 0.45, "echo_hold": Float(echo?.holdChecks ?? 3)]
    }
    @discardableResult func set(_ key: String, _ v: Float) -> Bool {
        guard let d = detector else { return false }
        switch key {
        case "fb_level": d.levelDbfs = max(-90, min(0, v))
        case "fb_papr": d.paprDb = max(3, min(30, v))
        case "fb_hold_ms": d.holdHops = max(5, min(300, Int(v / 10.67)))
        case "fb_grow": d.growDb = max(0, min(30, v))
        case "voice_snr": d.voiceSnrDb = max(0, min(40, v))
        case "voice_flux": d.voiceFluxMin = max(0.05, min(5, v))
        case "voice_hang_ms": d.voiceHangHops = max(5, min(500, Int(v / 10.67)))
        case "gate_db": gateDb = max(-80, min(0, v))
        case "echo_corr": echo?.threshold = max(0.1, min(0.95, v))
        case "echo_hold": echo?.holdChecks = max(1, min(20, Int(v)))
        default: return false
        }
        save(); return true
    }
    func save() {
        guard !settingsPath.isEmpty, let j = try? JSONSerialization.data(withJSONObject: settings().mapValues { Double($0) }, options: [.prettyPrinted, .sortedKeys]) else { return }
        try? j.write(to: URL(fileURLWithPath: settingsPath), options: .atomic)
    }
    func load() {
        guard !settingsPath.isEmpty, let d = FileManager.default.contents(atPath: settingsPath), let m = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] else { return }
        for (k, v) in m { if let x = (v as? NSNumber)?.floatValue { set(k, x) } }
    }
    func meterText() -> String {
        guard let d = detector else { return "meter n/a" }
        return String(format: "peak=%.0f papr=%.0f tonal=%.0f band=%.0f floor=%.0f flux=%.2f gate=%@ voice=%@ on=%@ gain=%.2f", d.lastPeakDb, d.lastPaprDb, d.lastTonalityDb, d.lastBandDb, d.lastFloorDb, d.lastFlux, gateOpen ? "open" : "closed", voice ? "on" : "off", on ? "1" : "0", gain)
    }
    var feedbackText: String {
        var t = " voice=\(voice ? "on" : "off") gate=\(gateOpen ? "open" : "closed")"
        if lastFeedbackNs > 0 { t += " feedback=\(Int(lastFeedbackHz))Hz age=\((monoNs() - lastFeedbackNs) / 1_000_000_000)s events=\(feedbackEvents)" }
        if lastEchoNs > 0 { t += " loop=\(lastEchoMs)ms loopage=\((monoNs() - lastEchoNs) / 1_000_000_000)s loops=\(echoEvents)" }
        if let e = echo { t += String(format: " corr=%.2f", e.lastCorr) }
        return t
    }
}
var gKeep: [Any] = []
var gNdiOn = true   // "ndi off" (control port / cam.sh ndi off): keep the camera open and the source advertised, send no frames
var gDetector: FeedbackDetector? = nil

final class Sender {
    let lib: NDILib
    let inst: NDIlib_send_instance_t
    var sent: UInt64 = 0
    var sendMsMax = 0.0, sendMsLast = 0.0
    var stallsOver50 = 0, stallsOver1s = 0
    var fps: Int
    init(lib: NDILib, name: String, fps: Int) throws {
        self.lib = lib; self.fps = fps
        var inst: NDIlib_send_instance_t? = nil
        name.withCString { n in
            var c = NDIlib_send_create_t(p_ndi_name: n, p_groups: nil, clock_video: false, clock_audio: false)
            inst = lib.send_create(&c)
        }
        guard let i = inst else { throw NDILib.LoadError(description: "NDIlib_send_create failed") }
        self.inst = i
        // advertise PTZ so receivers (multiviewers, Studio Monitor) enable their controls
        let caps = "<ndi_capabilities ntk_ptz=\"true\"/>"
        caps.withCString { c in
            var m = NDIlib_metadata_frame_t(length: Int32(strlen(c) + 1), timecode: Int64.max, p_data: UnsafeMutablePointer(mutating: c))
            lib.send_add_connection_metadata(i, &m)
        }
    }
    func send(_ pb: CVPixelBuffer) {
        CVPixelBufferLockBaseAddress(pb, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pb, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(pb) else { return }
        var f = NDIlib_video_frame_v2_t()
        f.xres = Int32(CVPixelBufferGetWidth(pb)); f.yres = Int32(CVPixelBufferGetHeight(pb))
        f.FourCC = fourccUYVY
        f.frame_rate_N = Int32(fps); f.frame_rate_D = 1
        f.picture_aspect_ratio = 0; f.frame_format_type = 1
        f.timecode = Int64.max
        f.p_data = base.assumingMemoryBound(to: UInt8.self)
        f.line_stride_in_bytes = Int32(CVPixelBufferGetBytesPerRow(pb))
        let t0 = monoNs()
        lib.send_send_video_v2(inst, &f)
        let ms = Double(monoNs() - t0) / 1e6
        sendMsLast = ms; if ms > sendMsMax { sendMsMax = ms }
        if ms > 1000 { stallsOver1s += 1 } else if ms > 50 { stallsOver50 += 1 }
        sent &+= 1
    }
    func connections() -> Int { Int(lib.send_get_no_connections(inst, 0)) }
    func destroy() { lib.send_destroy(inst) }
}

@main
struct OatsCam {
    static func main() {
        signal(SIGPIPE, SIG_IGN)
        setvbuf(stdout, nil, _IOLBF, 0)
        var name = "Link Cam", device = "Insta360 Link 2", width = 1920, height = 1080, fps = 30, logDir = "", presets = "", list = false, ptzOn = true
        var panRate = 60.0, tiltRate = 45.0, zoomRate = 0.5, libPath = "/usr/local/lib/libndi.dylib"
        var audioDevice = "", audioEnabled = true, controlPort: UInt16 = 7001, tallyLEDMode = TallyLED.Mode.on, trackingStart: Bool? = true, scanOpt = "on"
        var fbPapr: Float = 12, fbLevel: Float = -50, fbHold = 30
        let audioState = AudioState()
        var a = Array(CommandLine.arguments.dropFirst())
        func next(_ k: String) -> String { guard !a.isEmpty else { print("\(k) needs a value\n\(usage)"); exit(64) }; return a.removeFirst() }
        while !a.isEmpty {
            let k = a.removeFirst()
            switch k {
            case "--name": name = next(k)
            case "--device": device = next(k)
            case "--size": let p = next(k).split(separator: "x"); guard p.count == 2, let w = Int(p[0]), let h = Int(p[1]) else { print("--size WxH"); exit(64) }; width = w; height = h
            case "--fps": guard let v = Int(next(k)), v > 0 else { print("--fps N"); exit(64) }; fps = v
            case "--log-dir": logDir = next(k)
            case "--presets": presets = next(k)
            case "--no-ptz": ptzOn = false
            case "--pan-rate": panRate = Double(next(k)) ?? panRate
            case "--tilt-rate": tiltRate = Double(next(k)) ?? tiltRate
            case "--zoom-rate": zoomRate = Double(next(k)) ?? zoomRate
            case "--libndi": libPath = next(k)
            case "--audio-device": audioDevice = next(k)
            case "--audio-on": audioState.on = true
            case "--no-audio": audioEnabled = false
            case "--control-port": controlPort = UInt16(next(k)) ?? 7001
            case "--tally-led": tallyLEDMode = TallyLED.Mode(rawValue: next(k)) ?? .on   // off | on | blink (OBSBOT LED as tally)
            case "--scan": scanOpt = next(k)   // Link lost-target scan: on|off|TILT[,LOST_AFTER_S[,PERIOD_S[,RANGE_DEG]]] e.g. 10,3,12,90
            case "--tracking": let v = next(k); trackingStart = v == "on" ? true : v == "off" ? false : nil   // on (default) | off | keep: AI face tracking at start (OBSBOT)
            case "--feedback": audioState.feedbackMode = next(k)          // mute | duck | warn | off
            case "--audio-mode": audioState.voice = next(k) == "voice"     // normal | voice (speech gate)
            case "--echo": audioState.echoMode = next(k)                   // self-echo / monitoring loop: mute | duck | warn | off
            case "--fb-papr": fbPapr = Float(next(k)) ?? fbPapr            // peak-to-average dB (default 12; tonality > 20 dB is the main tone test)
            case "--fb-level": fbLevel = Float(next(k)) ?? fbLevel         // min peak level dBFS (default -45; the Link 2 gates quiet rooms to digital silence)
            case "--fb-hold": fbHold = Int(next(k)) ?? fbHold              // hops of 10.7 ms the tone must persist (default 30)
            case "--list": list = true
            case "-h", "--help": print(usage); exit(0)
            default: print("unknown option \(k)\n\(usage)"); exit(64)
            }
        }
        if list {
            for d in Capture.devices() {
                print(Capture.describe(d))
                for f in d.formats { print("    \(Capture.formatText(f))") }
            }
            exit(0)
        }
        if !logDir.isEmpty && !Logger.shared.open(dir: logDir, prefix: "oats-cam") { print("cannot open a log in \(logDir)"); exit(78) }
        if presets.isEmpty { presets = (logDir.isEmpty ? "." : (logDir as NSString).deletingLastPathComponent) + "/presets.json" }
        let activity = ProcessInfo.processInfo.beginActivity(options: [.userInitiated, .latencyCritical], reason: "oats-cam NDI send")
        _ = activity
        olog("oats-cam starting pid=\(getpid()) \(processArchText()) name='\(name)' device~'\(device)' \(width)x\(height)@\(fps) NDI_CONFIG_DIR=\(ProcessInfo.processInfo.environment["NDI_CONFIG_DIR"] ?? "(not set: ~/.ndi, NOT pinned)")")

        if let why = Capture.authorize(timeoutS: 120) { olog("oats-cam: \(why)"); Logger.shared.sync(); exit(77) }
        guard let cam = Capture.pick(match: device) else {
            olog("oats-cam: no camera matching '\(device)'. Cameras: \(Capture.devices().map(Capture.describe).joined(separator: " | "))"); Logger.shared.sync(); exit(69)
        }
        olog("camera: \(Capture.describe(cam.device))")

        let lib: NDILib
        do { lib = try NDILib(path: libPath) } catch { olog("oats-cam: \(error)"); Logger.shared.sync(); exit(78) }
        guard lib.initialize() else { olog("oats-cam: NDIlib_initialize failed"); Logger.shared.sync(); exit(70) }
        olog("libndi \(lib.versionText)")
        let sender: Sender
        do { sender = try Sender(lib: lib, name: name, fps: fps) } catch { olog("oats-cam: \(error)"); Logger.shared.sync(); exit(70) }
        olog("NDI sender '\(name)' created, PTZ advertised")

        var ptz: PTZ? = nil
        if ptzOn {
            if cam.vid == 0 { olog("ptz: camera has no USB ids (virtual camera?): PTZ off") }
            else { ptz = PTZ(vid: cam.vid, pid: cam.pid, presetsPath: presets, panRate: panRate, tiltRate: tiltRate, zoomRate: zoomRate); ptz?.start() }
        }
        let tallyState = TallyState()
        let tallyLED: TallyLED? = ptz.flatMap { TallyLED(dev: $0.dev, queue: $0.q, mode: tallyLEDMode) }
        if tallyLED == nil { olog("tally led: no controllable LED on this camera (tally is logged and reported only)") }
        // AI face tracking ("Find a face"): OBSBOT through its LED/command channel, Insta360 Link through its extension unit
        let tracker: AITracker? = tallyLED ?? ptz.flatMap { p -> LinkTracking? in
            let l = LinkTracking(dev: p.dev, queue: p.q); l?.ptz = p
            if scanOpt == "off" { l?.scan = false } else if scanOpt != "on" {
                let v = scanOpt.split(separator: ",").compactMap { Double($0) }
                if v.count > 0 { l?.scanTilt = v[0] }; if v.count > 1 { l?.scanLostAfter = v[1] }; if v.count > 2 { l?.scanPeriod = v[2] }; if v.count > 3 { l?.scanRange = v[3] }
            }
            l?.faces = FaceWatch()
            if let l = l, l.scan { olog("tracking: lost-target scan on (face watch; lost after \(Int(l.scanLostAfter)) s, pan ±\(Int(l.scanRange))°, tilt \(Int(l.scanTilt))°, \(Int(l.scanPeriod)) s per sweep)") }
            return l }
        if tracker == nil { olog("tracking: no AI tracking control on this camera") }
        if let t = tracker, let on = trackingStart { t.setTracking(on, "start") }   // "find a face" by default
        // a manual move from any receiver (joystick, absolute, preset) takes the camera back from the tracker, like the
        // OBSBOT firmware does by itself; the hub re-arms it with "Find a face"
        ptz?.onManual = { if let t = tracker, t.tracking == true { t.setTracking(false, "manual ptz") } }

        let cap = Capture()
        let faceWatch = (tracker as? LinkTracking)?.faces
        cap.onFrame = { pb in if gNdiOn { sender.send(pb) }; if let fw = faceWatch, tracker?.tracking == true { fw.consider(pb) } }
        cap.onError = { msg in olog("oats-cam: \(msg): exit 70 (supervisor restarts)"); Logger.shared.sync(); _exit(70) }
        do { try cap.start(cam: cam, width: width, height: height, fps: fps) } catch { olog("oats-cam: \(error.localizedDescription)"); Logger.shared.sync(); exit(69) }

        // audio: the camera's own mic (or --audio-device), captured always, sent only while audioState.on
        var audio: AudioCapture? = nil
        if audioEnabled {
            if let why = AudioCapture.authorize(timeoutS: 60) { olog("audio: off: \(why)") }
            else if let d = AudioCapture.pick(match: audioDevice.isEmpty ? device : audioDevice) {
                let a = AudioCapture()
                if let why = a.attach(to: cap.session, device: d) { olog("audio: off: \(why)") }
                else {
                    let detector = FeedbackDetector()                      // feedback + voice analysis (one FFT serves both)
                    gDetector = detector
                    detector?.paprDb = fbPapr; detector?.levelDbfs = fbLevel; detector?.holdHops = fbHold
                    audioState.detector = detector
                    audioState.echo = EchoDetector()
                    audioState.settingsPath = (presets as NSString).deletingLastPathComponent + "/audio.json"
                    audioState.load()
                    olog("audio: settings \(audioState.settings().sorted { $0.key < $1.key }.map { "\($0.key)=\(String(format: "%.2f", $0.value))" }.joined(separator: " ")) (\(audioState.settingsPath))")
                    var scratch = [Float](repeating: 0, count: 48000 * 2)
                    a.onAudio = { data, ch, n, sr in
                        guard gNdiOn, audioState.on else { detector?.reset(); audioState.gain = 1; return }
                        var p = UnsafeMutablePointer(mutating: data)
                        if let det = detector, det.voiceEnabled != audioState.voice { det.voiceEnabled = audioState.voice }   // setting it resets the hangover
                        if let det = detector, let hz = det.process(data, channels: ch, samples: n, rate: sr), audioState.feedbackMode != "off" {
                            audioState.feedbackEvents += 1; audioState.lastFeedbackHz = hz; audioState.lastFeedbackNs = monoNs()
                            switch audioState.feedbackMode {
                            case "duck": audioState.duckUntilNs = monoNs() + 2_000_000_000; olog("audio: FEEDBACK \(Int(hz)) Hz (peak \(String(format: "%.0f", det.lastPeakDb)) dBFS, papr \(String(format: "%.0f", det.lastPaprDb)) dB): ducking 2 s")
                            case "warn": olog("audio: FEEDBACK \(Int(hz)) Hz (peak \(String(format: "%.0f", det.lastPeakDb)) dBFS, papr \(String(format: "%.0f", det.lastPaprDb)) dB): warn only")
                            default: audioState.on = false; olog("audio: FEEDBACK \(Int(hz)) Hz (peak \(String(format: "%.0f", det.lastPeakDb)) dBFS, papr \(String(format: "%.0f", det.lastPaprDb)) dB): mic MUTED"); return
                            }
                        }
                        // gain: duck after feedback (-26 dB for 2 s), voice gate closed (-40 dB), else unity; ramped across the buffer
                        let open = detector?.voiceOpen ?? true
                        if audioState.voice && open != audioState.gateOpen { audioState.gateOpen = open; if audioState.voice { olog("audio: voice gate \(open ? "OPEN" : "closed") (band \(String(format: "%.0f", detector!.lastBandDb)) dBFS floor \(String(format: "%.0f", detector!.lastFloorDb)) flux \(String(format: "%.2f", detector!.lastFlux)))") } }
                        if !audioState.voice { audioState.gateOpen = true }
                        let target: Float = audioState.duckUntilNs > monoNs() ? 0.05 : (audioState.voice && !open ? powf(10, audioState.gateDb / 20) : 1)
                        if (target != 1 || audioState.gain != 1), ch * n <= scratch.count {
                            let g0 = audioState.gain
                            scratch.withUnsafeMutableBufferPointer { sp in
                                for i in 0..<n { let g = g0 + (target - g0) * Float(i) / Float(n); for c in 0..<ch { sp[c * n + i] = data[c * n + i] * g } }
                                p = sp.baseAddress!
                            }
                            audioState.gain = target
                        }
                        // self-echo check: is what we sent ~40..900 ms ago coming back in through the mic?
                        if audioState.echoMode != "off", let e = audioState.echo, let lagMs = e.process(sentBlock: UnsafePointer(p), micBlock: data, channels: ch, samples: n, sr: sr) {
                            audioState.echoEvents += 1; audioState.lastEchoMs = lagMs; audioState.lastEchoNs = monoNs()
                            let msg = "audio: MONITORING LOOP: our own audio returns through the mic \(lagMs) ms later (corr \(String(format: "%.2f", e.lastCorr))): speakers near the camera are playing the Link Cam feed"
                            switch audioState.echoMode {
                            case "duck": audioState.duckUntilNs = monoNs() + 2_000_000_000; olog(msg + " -> ducking 2 s")
                            case "warn": olog(msg + " -> warn only")
                            default: audioState.on = false; olog(msg + " -> mic MUTED"); return
                            }
                        }
                        var f = NDIlib_audio_frame_v2_t(sample_rate: Int32(sr), no_channels: Int32(ch), no_samples: Int32(n), timecode: Int64.max,
                                                        p_data: p, channel_stride_in_bytes: Int32(n * 4), p_metadata: nil, timestamp: 0)
                        lib.send_send_audio_v2(sender.inst, &f)
                        audioState.sent &+= 1
                    }
                    audio = a
                    cap.applyFormat("after audio attach")   // adding an input lets the session re-pick the video format
                    olog("audio: \(d.localizedName) attached, \(audioState.on ? "ON" : "muted") at start; feedback detector \(audioState.feedbackMode) (papr>\(Int(fbPapr)) dB, level>\(Int(fbLevel)) dBFS, hold \(fbHold) hops); control udp://127.0.0.1:\(controlPort) (audio on|off|toggle|status), SIGUSR1 toggles")
                }
            } else { olog("audio: off: no microphone matching '\(audioDevice.isEmpty ? device : audioDevice)'. Mics: \(AudioCapture.devices().map { $0.localizedName }.joined(separator: " | "))") }
        }
        func setNdi(_ on: Bool, _ via: String) { if gNdiOn != on { gNdiOn = on; olog("ndi: \(on ? "ON (sending)" : "OFF (camera open, source advertised, nothing sent)") (\(via))") } }
        func setAudio(_ on: Bool, _ via: String) { if audioState.on != on { audioState.on = on; olog("audio: \(on ? "ON" : "off") (\(via))") } }
        let control = ControlPort(port: controlPort)
        control.handler = { cmd in
            let w = cmd.lowercased().split(separator: " ").map(String.init)
            if w.count >= 1, w[0] == "tally" {   // "tally" -> state; "tally led off|on|blink" -> LED mode
                if w.count >= 3, w[1] == "led" {
                    guard let led = tallyLED else { return tallyState.text + " led=none" }
                    guard let m = TallyLED.Mode(rawValue: w[2]) else { return "error: tally led off|on|blink" }
                    led.setMode(m); olog("tally led: mode \(m.rawValue) (udp)")
                }
                return tallyState.text + " " + (tallyLED?.statusText ?? "led=none") + " " + (tracker?.trackingText ?? "tracking=none")
            }
            if w.count >= 1, w[0] == "track" {   // "track" -> state; "track on|off [framing]" (OBSBOT 0-4, Insta360 Link 1-3); "track recenter" (Link)
                guard let t = tracker else { return "tracking=none" }
                if w.count >= 2, w[1] == "on" || w[1] == "off" {
                    if w.count >= 3, let f = UInt8(w[2]), t.framingRange.contains(f) { t.framing = f }
                    guard t.setTracking(w[1] == "on", "udp") else { return "error: tracking write failed" }
                }
                if w.count >= 2, w[1] == "recenter", let l = t as? LinkTracking { l.recenter(); olog("tracking: gimbal recentre (udp)") }
                if w.count >= 2, w[1] == "xu", w.count >= 3, let sel = UInt8(w[2]), let l = t as? LinkTracking { return l.dumpSelector(sel) }   // raw read of an extension-unit selector (diagnosis)
                if w.count >= 2, w[1] == "pos" {   // the gimbal's real position as the camera reports it (UVC GET_CUR), for diagnosis
                    guard let (p, tl) = ptz?.readPanTilt() else { return "pos=none" }
                    return "pos pan=\(String(format: "%.1f", Double(p) / 3600)) tilt=\(String(format: "%.1f", Double(tl) / 3600)) \((t as? LinkTracking).map { "scanning=\($0.scanning) scans=\($0.scans) \($0.faces?.text ?? "no face watch")" } ?? "")"
                }
                return t.trackingText
            }
            if w.count >= 1, w[0] == "ndi" {   // "ndi" -> state; "ndi on|off|toggle": stop / resume sending (video + audio); the source stays advertised, the camera stays open
                switch w.count > 1 ? w[1] : "status" {
                case "on": setNdi(true, "udp")
                case "off": setNdi(false, "udp")
                case "toggle": setNdi(!gNdiOn, "udp")
                default: break
                }
                return gNdiOn ? "ndi on" : "ndi off"
            }
            guard w.count >= 1, w[0] == "audio" else { return "error: unknown command" }
            guard audio != nil else { return "audio unavailable" }
            switch w.count > 1 ? w[1] : "status" {
            case "on": setAudio(true, "udp")
            case "off": setAudio(false, "udp")
            case "toggle": setAudio(!audioState.on, "udp")
            case "voice":   // audio voice on|off|toggle
                let v = w.count > 2 ? w[2] : "toggle"
                let newV = v == "on" ? true : v == "off" ? false : !audioState.voice
                if newV != audioState.voice { audioState.voice = newV; olog("audio: voice gate mode \(newV ? "ON" : "off") (udp)") }
            case "set":     // audio set <key> <value>
                guard w.count > 3, let v = Float(w[3]) else { return "error: audio set <key> <value>" }
                guard audioState.set(w[2], v) else { return "error: unknown key \(w[2]) (\(audioState.settings().keys.sorted().joined(separator: ",")))" }
                olog("audio: set \(w[2])=\(v) (udp)")
                return "ok " + audioState.settings().sorted { $0.key < $1.key }.map { "\($0.key)=\(String(format: "%.2f", $0.value))" }.joined(separator: " ")
            case "get": return "settings " + audioState.settings().sorted { $0.key < $1.key }.map { "\($0.key)=\(String(format: "%.2f", $0.value))" }.joined(separator: " ")
            case "meter": return audioState.meterText()
            case "reset":
                for (k, v) in ["fb_level": Float(-50), "fb_papr": 12, "fb_hold_ms": 320, "fb_grow": 6, "voice_snr": 9, "voice_flux": 0.4, "voice_hang_ms": 750, "gate_db": -40] { audioState.set(k, v) }
                olog("audio: settings reset to defaults (udp)")
                return "ok " + audioState.settings().sorted { $0.key < $1.key }.map { "\($0.key)=\(String(format: "%.2f", $0.value))" }.joined(separator: " ")
            default: break
            }
            return (audioState.on ? "audio on" : "audio off") + audioState.feedbackText
        }
        if let why = control.start() { olog("control port: \(why)") }
        signal(SIGUSR1, SIG_IGN)
        let usr1 = DispatchSource.makeSignalSource(signal: SIGUSR1, queue: .main)
        usr1.setEventHandler { if audio != nil { setAudio(!audioState.on, "SIGUSR1") } }
        usr1.resume(); gKeep.append(usr1)

        // signals: stop capture, destroy the sender, exit 0
        var sigs: [DispatchSourceSignal] = []
        for s in [SIGTERM, SIGINT] {
            signal(s, SIG_IGN)
            let src = DispatchSource.makeSignalSource(signal: s, queue: .main)
            src.setEventHandler {
                olog("oats-cam: \(s == SIGTERM ? "SIGTERM" : "SIGINT"): stop capture + NDIlib_send_destroy, exit")
                let back = Thread { usleep(2_000_000); olog("oats-cam: shutdown hung: _exit(75)"); Logger.shared.sync(); _exit(75) }
                back.start()
                tallyLED?.restore()   // hand the LED back to the camera (full, solid) so a stopped sender doesn't leave it dark
                cap.stop(); sender.destroy(); lib.destroy()
                olog("oats-cam exit 0"); Logger.shared.sync(); _exit(0)
            }
            src.resume(); sigs.append(src)
        }

        // receiver metadata (PTZ commands) + tally, on its own thread
        let meta = Thread {
            var tally = NDIlib_tally_t(on_program: false, on_preview: false)
            var metaSeen: UInt64 = 0
            while true {
                var m = NDIlib_metadata_frame_t()
                let t = lib.send_capture(sender.inst, &m, 250)
                if t == 3, let p = m.p_data {
                    let xml = String(cString: p)
                    metaSeen &+= 1
                    let known = ptz?.handle(xml) ?? false
                    if !known || metaSeen <= 20 { olog("meta\(known ? "" : " (unhandled)"): \(xml.prefix(300))") }
                    lib.send_free_metadata(sender.inst, &m)
                } else if t == 100 {
                    olog("NDI status change: connections \(sender.connections())")
                }
                var nt = NDIlib_tally_t(on_program: false, on_preview: false)
                if lib.send_get_tally(sender.inst, &nt, 0), nt.on_program != tally.on_program || nt.on_preview != tally.on_preview {
                    tally = nt; olog("tally: program=\(nt.on_program) preview=\(nt.on_preview)")
                    tallyState.set(program: nt.on_program, preview: nt.on_preview)
                    tallyLED?.apply(program: nt.on_program, preview: nt.on_preview)
                }
            }
        }
        meta.name = "ndi-meta"; meta.start()

        // status line every 5 s + status.json; exit if frames stop
        let statusPath = logDir.isEmpty ? "" : (logDir as NSString).appendingPathComponent("cam-status.json")
        var lastFrames: UInt64 = 0, lastT = monoNs(), noFrameSince: UInt64 = 0
        let start = monoNs()
        let status = DispatchSource.makeTimerSource(queue: .global(qos: .utility))
        status.schedule(deadline: .now() + 5, repeating: 5)
        status.setEventHandler {
            let now = monoNs(), dt = Double(now - lastT) / 1e9
            let fr = cap.frames, measured = Double(fr - lastFrames) / max(dt, 0.001)
            lastFrames = fr; lastT = now
            let conns = sender.connections()
            olog("STATUS fps=\(String(format: "%.2f", measured)) frames=\(fr) sent=\(sender.sent) dropped=\(cap.dropped) ndi=\(gNdiOn ? "on" : "OFF") ndi_conns=\(conns) send_ms last=\(String(format: "%.1f", sender.sendMsLast)) max=\(String(format: "%.1f", sender.sendMsMax)) stalls>50ms=\(sender.stallsOver50) >1s=\(sender.stallsOver1s) | audio \(audio == nil ? "n/a" : audioState.on ? "ON" : "muted") sent=\(audioState.sent)\(audio.map { " \($0.sampleRate)Hz x\($0.channels)" } ?? "")\(gDetector.map { " peak \(String(format: "%.0f", $0.lastPeakDb))dBFS papr \(String(format: "%.0f", $0.lastPaprDb)) tonal \(String(format: "%.0f", $0.lastTonalityDb)) band \(String(format: "%.0f", $0.lastBandDb)) floor \(String(format: "%.0f", $0.lastFloorDb)) flux \(String(format: "%.2f", $0.lastFlux))" } ?? "")\(audioState.voice ? " voice gate \(audioState.gateOpen ? "open" : "closed")" : "")\(ptz.map { " | ptz \($0.statusText)" } ?? " | ptz off")")
            let sinceFrame = Int64(bitPattern: now) - Int64(bitPattern: cap.lastFrameNs)   // may be negative: a frame landed after `now` was read
            if fr == 0 || sinceFrame > 10_000_000_000 {
                if noFrameSince == 0 { noFrameSince = now }
                if Int64(bitPattern: now) - Int64(bitPattern: noFrameSince) > 45_000_000_000 { olog("oats-cam: no camera frames for 45 s: exit 71 (supervisor restarts)"); Logger.shared.sync(); _exit(71) }
            } else { noFrameSince = 0 }
            if !statusPath.isEmpty {
                var d: [String: Any] = ["name": name, "device": Capture.describe(cam.device), "format": "\(width)x\(height) @ \(fps) fps UYVY", "fps": measured, "frames": Int(fr), "sent": Int(sender.sent), "dropped": Int(cap.dropped),
                                        "ndi_connections": conns, "ndi_on": gNdiOn, "send_ms_last": sender.sendMsLast, "send_ms_max": sender.sendMsMax, "stalls_over_50ms": sender.stallsOver50, "stalls_over_1s": sender.stallsOver1s,
                                        "uptime_s": Double(now - start) / 1e9, "pid": Int(getpid()), "arch": processArchText(), "libndi": lib.versionText, "updated": ISO8601DateFormatter().string(from: Date())]
                d["ptz"] = ptz?.statusDict() ?? NSNull()
                d["tally"] = ["program": tallyState.program, "preview": tallyState.preview, "led": tallyLED?.statusDict() ?? NSNull()] as [String: Any]
                d["tracking"] = tracker.map { ["kind": $0.kind, "on": ($0.tracking as Any?) ?? NSNull(), "framing": Int($0.framing)] as [String: Any] } ?? NSNull()
                d["audio"] = audio == nil ? NSNull() : ["on": audioState.on, "sent": Int(audioState.sent), "device": audio!.device?.localizedName ?? "", "sample_rate": audio!.sampleRate, "channels": audio!.channels, "control_port": Int(controlPort),
                                                        "voice": audioState.voice, "gate_open": audioState.gateOpen, "feedback_mode": audioState.feedbackMode, "feedback_events": audioState.feedbackEvents, "feedback_last_hz": Int(audioState.lastFeedbackHz),
                                                        "feedback_age_s": audioState.lastFeedbackNs == 0 ? -1 : Int((monoNs() - audioState.lastFeedbackNs) / 1_000_000_000),
                                                        "echo_mode": audioState.echoMode, "loop_events": audioState.echoEvents, "loop_last_ms": audioState.lastEchoMs,
                                                        "loop_age_s": audioState.lastEchoNs == 0 ? -1 : Int((monoNs() - audioState.lastEchoNs) / 1_000_000_000), "loop_corr": Double(audioState.echo?.lastCorr ?? 0)] as [String: Any]
                do { let j = try JSONSerialization.data(withJSONObject: d, options: [.prettyPrinted, .sortedKeys]); try j.write(to: URL(fileURLWithPath: statusPath), options: .atomic) }
                catch { olog("status.json: \(error)") }
            }
        }
        status.resume()
        RunLoop.main.run()
    }
}
