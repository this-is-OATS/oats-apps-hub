#!/bin/zsh
# oats-cam supervisor: a UVC webcam (Insta360 Link 2 by default) as an NDI source with PTZ, no vendor app needed.
#   cam.sh build            compile bin/oats-cam (x86_64 like oats-ndi: libndi under Rosetta; CAM_ARCH=arm64 for native)
#   cam.sh start|stop|restart|status|log
#   cam.sh list             cameras and formats
#   cam.sh ptz ...          bin/uvcprobe passthrough (info | pantilt PAN TILT | zoom N), arcseconds
# Settings via env or ../oats-cam/cam.env: CAM_NAME (NDI name, default "Link Cam"), CAM_DEVICE, CAM_SIZE, CAM_FPS.
setopt no_unset pipefail 2>/dev/null   # no err_return: the loop must survive a non-zero child exit
C=${0:A:h}
# Profiles: one camera per profile. `cam.sh -p NAME cmd` or CAM_PROFILE=NAME. The default profile "link" keeps the
# original paths (cam.env, logs/, run/, presets.json, port 7001). Any other profile reads cam.NAME.env and gets its own
# logs/NAME, run/NAME and presets.NAME.json, so several cameras (Link 2 + OBSBOT ...) run side by side.
if [[ ${1:-} == -p ]]; then CAM_PROFILE=${2:?profile name}; shift 2; fi
: ${CAM_PROFILE:=link}
BIN=$C/bin/oats-cam
if [[ $CAM_PROFILE == link ]]; then
  LOGS=$C/logs; RUN=$C/run; ENVF=$C/cam.env; PRESETS=$C/presets.json
else
  LOGS=$C/logs/$CAM_PROFILE; RUN=$C/run/$CAM_PROFILE; ENVF=$C/cam.$CAM_PROFILE.env; PRESETS=$C/presets.$CAM_PROFILE.json
  [[ -f $ENVF ]] || { echo "no $ENVF: create it with CAM_NAME, CAM_DEVICE, CAM_CONTROL_PORT (see cam.obsbot.env)" >&2; exit 64 }
fi
PID=$RUN/oats-cam.pid
LOOPPID=$RUN/oats-cam-loop.pid
LOOPLOG=$LOGS/oats-cam-loop.log
[[ -f $ENVF ]] && source $ENVF
: ${CAM_NAME:="Link Cam"} ${CAM_DEVICE:="Insta360 Link 2"} ${CAM_SIZE:=1920x1080} ${CAM_FPS:=30} ${CAM_ARCH:=x86_64}
: ${CAM_CONTROL_PORT:=7001} ${CAM_AUDIO_START:=} ${CAM_AUDIO_MODE:=normal} ${CAM_FEEDBACK:=mute} ${CAM_ECHO:=mute} ${CAM_TALLY_LED:=on} ${CAM_TRACKING:=on} ${CAM_SCAN:=on} ${CAM_EXTRA:=}
# CAM_TALLY_LED off|on|blink: the camera's own status LED as tally (OBSBOT only; off = not live, full = program, blink = preview)
# CAM_TRACKING on|off|keep: AI face tracking at start (on = find a face). CAM_SCAN on|off|TILT,LOST_AFTER_S,PERIOD_S,RANGE_DEG (Link: no face for LOST_AFTER_S while tracking = lost: tilt up and pan ±RANGE, the way the face left, until a face is back; default 10,3,16,90). CAM_AUDIO_START=1 starts with the mic on; CAM_AUDIO_MODE normal|voice (speech gate); CAM_FEEDBACK mute|duck|warn|off; CAM_EXTRA e.g. --audio-device "USB Mic"
[[ -d $C/../ndi-config ]] && : ${NDI_CONFIG_DIR:=$C/../ndi-config}   # this install's machine name + adapter pin (install.sh)
[[ -d $C/../oats-m0/ndi-config ]] && : ${NDI_CONFIG_DIR:=$C/../oats-m0/ndi-config}   # share the vizzies' NDI pin when installed next to them
: ${NDI_CONFIG_DIR:=$HOME/.ndi}   # same adapter pin + machine name as the vizzies sender
export NDI_CONFIG_DIR
mkdir -p $LOGS $RUN
ts() { date '+%Y-%m-%d %H:%M:%S' }
readpid() { [[ -f $1 ]] && cat $1 2>/dev/null || true }
alive() { [[ -n ${1:-} ]] && kill -0 $1 2>/dev/null }

build() {
  local mc=$C/.modcache arch=$CAM_ARCH target
  [[ $arch == arm64 ]] && target=arm64-apple-macos14 || target=x86_64-apple-macos14
  mkdir -p $mc $C/build
  echo "$(ts) building bin/oats-cam ($arch)"
  clang -O2 -Wall -arch $arch -mmacosx-version-min=14.0 -c $C/src/uvc.c -o $C/build/uvc-$arch.o || { echo "$(ts) BUILD FAILED (uvc.c)" >&2; return 1 }
  swiftc -O -swift-version 5 -parse-as-library -target $target -module-cache-path $mc \
    -import-objc-header $C/src/bridge.h $C/src/log.swift $C/src/ndi.swift $C/src/capture.swift $C/src/audio.swift $C/src/ptz.swift $C/src/tallyled.swift $C/src/linktrack.swift $C/src/facewatch.swift $C/src/app.swift \
    $C/build/uvc-$arch.o -framework IOKit -framework CoreFoundation -framework AVFoundation -framework Vision -framework CoreMedia -framework CoreVideo -framework Foundation \
    -o $BIN.tmp && mv $BIN.tmp $BIN || { rm -f $BIN.tmp; echo "$(ts) BUILD FAILED (oats-cam)" >&2; return 1 }
  clang -O2 -Wall -o $C/bin/ptztest $C/src/ptztest.c /usr/local/lib/libndi.dylib -Wl,-rpath,/usr/local/lib
  clang -O2 -Wall -o $C/bin/uvcprobe $C/src/uvc.c $C/src/uvcprobe.c -framework IOKit -framework CoreFoundation
  echo "$(ts) built $BIN ($(/usr/bin/file -b $BIN | sed 's/Mach-O 64-bit executable //'))"
}

runner() { [[ $(/usr/bin/file -b $BIN) == *arm64* ]] && print -r -- "" || print -r -- "arch -x86_64" }

loop() {
  echo "$(ts) cam loop started pid=$$ name='$CAM_NAME' device='$CAM_DEVICE' $CAM_SIZE@$CAM_FPS" >> $LOOPLOG
  while true; do
    ${=$(runner)} $BIN --name $CAM_NAME --device $CAM_DEVICE --size $CAM_SIZE --fps $CAM_FPS --log-dir $LOGS --presets $PRESETS --control-port $CAM_CONTROL_PORT ${CAM_AUDIO_START:+--audio-on} --audio-mode $CAM_AUDIO_MODE --feedback $CAM_FEEDBACK --echo $CAM_ECHO --tally-led $CAM_TALLY_LED --tracking $CAM_TRACKING --scan $CAM_SCAN ${=CAM_EXTRA} > /dev/null 2>> $LOGS/oats-cam.err < /dev/null &
    local child=$!
    echo $child > $PID
    echo "$(ts) started oats-cam pid=$child" >> $LOOPLOG
    wait $child; local code=$?
    rm -f $PID
    (( code == 0 )) && { echo "$(ts) oats-cam exited 0: cam loop ends" >> $LOOPLOG; break; }
    (( code == 64 || code == 78 || code == 77 )) && { echo "$(ts) oats-cam exited $code (arguments / libndi / camera permission): cam loop ends" >> $LOOPLOG; break; }
    local wait=2; (( code == 71 || code == 69 )) && wait=20   # 71 no camera frames / 69 camera not found (unplugged): slow retry, reconnects when it is back
    echo "$(ts) oats-cam exited $code$( (( code > 128 )) && echo " (signal $((code - 128)))"): restarting in $wait s" >> $LOOPLOG
    sleep $wait
  done
  rm -f $LOOPPID
  echo "$(ts) cam loop exit" >> $LOOPLOG
}

start() {
  local lp=$(readpid $LOOPPID)
  alive $lp && { echo "oats-cam already running (loop pid $lp, oats-cam pid $(readpid $PID))"; return 0 }
  [[ -x $BIN ]] || build
  # own session (setsid) so the loop survives whatever shell or tool started it (m0.sh does the same)
  nohup python3 -I -c 'import os, sys; os.setsid(); os.execvp(sys.argv[1], sys.argv[1:])' zsh $C/cam.sh -p $CAM_PROFILE _loop > /dev/null 2>&1 < /dev/null &
  echo $! > $LOOPPID
  disown 2>/dev/null || true
  echo "$(ts) oats-cam[$CAM_PROFILE] loop pid $! (NDI '$CAM_NAME' from '$CAM_DEVICE' $CAM_SIZE@$CAM_FPS, $(runner) ; logs $LOGS/oats-cam-*.log)"
}
stop() {
  local lp=$(readpid $LOOPPID) p=$(readpid $PID)
  alive $lp && kill -TERM $lp 2>/dev/null
  if alive $p; then kill -TERM $p 2>/dev/null; for i in {1..30}; do alive $p || break; sleep 0.1; done; alive $p && kill -KILL $p 2>/dev/null; fi
  rm -f $LOOPPID $PID
  echo "$(ts) oats-cam stopped"
}
status() {
  local lp=$(readpid $LOOPPID) p=$(readpid $PID)
  echo "profile $CAM_PROFILE: loop: $( alive $lp && echo "running pid $lp" || echo "not running" )   oats-cam: $( alive $p && echo "running pid $p" || echo "not running" )"
  [[ -f $LOGS/cam-status.json ]] && python3 -I -c "
import json,sys; d=json.load(open('$LOGS/cam-status.json')); p=d.get('ptz') or {}
print(f\"NDI '{d['name']}' {d['format']} fps={d['fps']:.1f} conns={d['ndi_connections']} sent={d['sent']} dropped={d['dropped']} send_ms max={d['send_ms_max']:.1f} stalls>50ms={d['stalls_over_50ms']} uptime={d['uptime_s']:.0f}s updated {d['updated']}\")
print('PTZ off' if not p else f\"PTZ pan {p['pan_deg']:.1f}° tilt {p['tilt_deg']:.1f}° zoom {p['zoom']} ({p['zoom_min']}..{p['zoom_max']}) cmds={p['commands']} unknown={p['unknown_commands']} uvc_err={p['uvc_errors']} presets={p['presets']}\")"
}
case ${1:-status} in
  _loop) loop ;;
  build) build ;;
  start) start ;;
  stop) stop ;;
  restart) stop; sleep 3; start ;;   # let the camera stack release the device (an instant re-open wedged it on 2026-10-25)
  status) status ;;
  log) tail -n ${2:-30} $(ls -t $LOGS/oats-cam-2*.log | head -1) ;;
  list) ${=$(runner)} $BIN --list ;;
  ptz) shift; $C/bin/uvcprobe "$@" ;;
  tally) python3 -I -c "
import socket,sys; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.settimeout(1.0)
port=sys.argv[1]; words=sys.argv[2:]
s.sendto(('tally '+' '.join(words)).strip().encode(),('127.0.0.1',int(port)))
try: print(s.recv(256).decode())
except socket.timeout: print('no answer from oats-cam on udp %s (not running?)'%port); sys.exit(1)" $CAM_CONTROL_PORT "${@:2}" ;;
  track) python3 -I -c "
import socket,sys; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.settimeout(1.0)
port=sys.argv[1]; words=sys.argv[2:]
s.sendto(('track '+' '.join(words)).strip().encode(),('127.0.0.1',int(port)))
try: print(s.recv(256).decode())
except socket.timeout: print('no answer from oats-cam on udp %s (not running?)'%port); sys.exit(1)" $CAM_CONTROL_PORT "${@:2}" ;;
  ndi) python3 -I -c "
import socket,sys; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.settimeout(1.0)
port=sys.argv[1]; words=sys.argv[2:] or ['status']
s.sendto(('ndi '+' '.join(words)).encode(),('127.0.0.1',int(port)))
try: print(s.recv(256).decode())
except socket.timeout: print('no answer from oats-cam on udp %s (not running?)'%port); sys.exit(1)" $CAM_CONTROL_PORT "${@:2}" ;;
  audio) python3 -I -c "
import socket,sys; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.settimeout(1.0)
port=sys.argv[1]; words=sys.argv[2:] or ['status']
s.sendto(('audio '+' '.join(words)).encode(),('127.0.0.1',int(port)))
try: print(s.recv(256).decode())
except socket.timeout: print('no answer from oats-cam on udp %s (not running?)'%port); sys.exit(1)" $CAM_CONTROL_PORT "${@:2}" ;;
  *) echo "usage: cam.sh [-p PROFILE] build|start|stop|restart|status|log [N]|list|ptz ...|ndi [on|off|toggle|status]|audio [on|off|toggle|status|voice on|off|toggle]|tally [led off|on|blink]|track [on|off [framing 0-4]]" ; exit 64 ;;
esac
