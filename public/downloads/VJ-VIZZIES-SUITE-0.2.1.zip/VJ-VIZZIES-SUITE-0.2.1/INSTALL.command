#!/bin/zsh
# VJ VIZZIES SUITE: double-click installer. Runs the OATS NDI HUB installer (camera suite) and the VJ VIZZIES installer
# (player folder + the control-window app in /Applications, quarantine removed), asking the NDI machine name and the
# lighting interface ONCE, then prints the Terminal-first camera permission step.
#   INSTALL.command [--dry-run] [--yes] [--machine-name NAME] [--lighting-nic en0] [--hub-only] [--player-only]
emulate -L zsh; setopt pipe_fail null_glob
S=${0:A:h}
cd "$S"
HUB=1 PLAYER=1 MNAME="" NIC=""; ARGS=()
while (( $# )); do
  case $1 in
    --hub-only) PLAYER=0 ;; --player-only) HUB=0 ;;
    --machine-name) MNAME=${2:?}; shift ;; --lighting-nic|--nic) NIC=${2:?}; shift ;;
    --dry-run|--yes|-y|--no-start) ARGS+=($1) ;;
    *) echo "unknown option $1"; exit 64 ;;
  esac; shift
done
echo "=== VJ VIZZIES SUITE $(head -1 "$S/VERSION" | awk '{print $4}') installer  ($(uname -m), macOS $(sw_vers -productVersion)) ==="
echo "Installs: OATS NDI HUB -> ~/Applications/OATS NDI HUB      VJ VIZZIES -> ~/Applications/VJ VIZZIES (+ the app in /Applications)"
echo
if [[ ! -f /usr/local/lib/libndi.dylib ]]; then
  # some NDI Tools builds install the apps but not the runtime package: use the bundled copy (administrator password)
  if [[ -f "$S/NDI runtime/libndi.dylib" ]]; then
    echo "NDI runtime not found at /usr/local/lib/libndi.dylib: installing the bundled one (NDI $(strings "$S/NDI runtime/libndi.dylib" | grep -m1 -oE 'NDI SDK APPLE [0-9.]+' | awk '{print $4}'))."
    if (( ${ARGS[(I)--dry-run]} )); then echo "  (dry run: would sudo install it)"
    else sudo mkdir -p /usr/local/lib && sudo install -m 755 "$S/NDI runtime/libndi.dylib" /usr/local/lib/libndi.dylib && sudo install -m 644 "$S/NDI runtime/libndi_licenses.txt" /usr/local/lib/libndi_licenses.txt \
      || { echo "!! could not install the NDI runtime"; read -s -k '?Press any key to close. '; exit 1; }
    fi
  else
    echo "!! NDI runtime not found (no /usr/local/lib/libndi.dylib). Install NDI Tools from https://ndi.video/tools/ first, then double-click INSTALL.command again."; echo; read -s -k '?Press any key to close. '; exit 1
  fi
fi
if [[ $(uname -m) == arm64 && ! -e /Library/Apple/usr/libexec/oah/libRosettaRuntime ]]; then
  echo "!! Apple Silicon without Rosetta 2: the camera / display senders and the NDI helper need it. In Terminal:"
  echo "     softwareupdate --install-rosetta --agree-to-license      (then run this again; continuing anyway)"; echo
fi
# one set of answers for both installers
def_name=$(hostname -s | tr '[:lower:]' '[:upper:]' | tr -c 'A-Z0-9.\n' '-')
if [[ -z $MNAME ]]; then
  if (( ${ARGS[(I)--yes]} )); then MNAME=$def_name
  else echo "Every Mac on the NDI network needs its OWN machine name (sources appear as \"NAME (Link Cam)\", \"NAME (OATS VIZ Program)\")."
       read "MNAME?NDI machine name for this Mac [$def_name]: "; MNAME=${MNAME:-$def_name}; fi
fi
if [[ -z $NIC ]]; then
  if (( ${ARGS[(I)--yes]} )); then NIC=en0
  else echo "Network interfaces with an address:"
       for i in $(ifconfig -l); do ip=$(ipconfig getifaddr $i 2>/dev/null) || continue; [[ $ip == 169.254.* ]] && continue
         port=$(networksetup -listallhardwareports 2>/dev/null | grep -B1 "Device: $i$" | head -1 | sed 's/Hardware Port: //'); echo "  $i  $ip  ${port:-}"; done
       read "NIC?Lighting / NDI network interface (sACN, OSC and NDI use it) [en0]: "; NIC=${NIC:-en0}; fi
fi
echo
rc=0
if (( HUB )); then
  echo "----- OATS NDI HUB -----"
  "$S/OATS NDI HUB/install.sh" --machine-name "$MNAME" --lighting-nic "$NIC" "${ARGS[@]}" || rc=$?
  echo
fi
if (( PLAYER )); then
  echo "----- VJ VIZZIES (player + controls app) -----"
  "$S/VJ VIZZIES/install.sh" --machine-name "$MNAME" --lighting-nic "$NIC" "${ARGS[@]}" || rc=$?
  echo
fi
cat <<TXT
=========================================================================================================
LAST STEP, ONCE, FROM THIS TERMINAL WINDOW (camera + microphone permission belong to the app that starts the sender):
    "$HOME/Applications/OATS NDI HUB/oats-cam/cam.sh" restart
  and click Allow for the camera and the microphone (and the local network). The login item then inherits it.
  Extra camera (OBSBOT): copy "OATS NDI HUB/oats-cam/examples/cam.obsbot.env" to ~/Applications/OATS NDI HUB/oats-cam/
  and run  cam.sh -p obsbot start.  One camera per USB port. Close OBSBOT Center / Insta360 Link Controller.
Hub: http://<this Mac>:7080/    Player controls: http://<this Mac>:8090    (see READ ME FIRST.txt)
=========================================================================================================
TXT
(( rc )) && echo "!! an installer reported exit $rc: read the lines above."
[[ -t 0 ]] && read -s -k '?Press any key to close. '
exit $rc
