// VJ VIZZIES: MS-DOS style loading screen. Shown while the controls load and while the player is (re)starting.
// Real checks drive the boot lines (from /api/status). Click or any key skips. Stays up only until the player
// answers (min ~2 s). Never blocks the controls underneath; removes itself completely when done.
(() => {
  const MIN_MS = 5200, LINE_MS = 260;
  const css = `
  #dosboot{position:fixed;inset:0;z-index:9999;background:#000;color:#c0c0c0;font:16px/1.25 "Px437 IBM VGA8","Perfect DOS VGA 437",ui-monospace,Menlo,Consolas,monospace;
           padding:28px 36px;overflow:hidden;cursor:default;transition:opacity .35s ease;letter-spacing:.5px;text-shadow:0 0 2px rgba(255,255,255,.25)}
  #dosboot.out{opacity:0;pointer-events:none}
  #dosboot .bios{color:#fff}
  #dosboot .hi{color:#fff} #dosboot .ok{color:#55ff55} #dosboot .warn{color:#ffff55} #dosboot .bad{color:#ff5555} #dosboot .dim{color:#808080}
  #dosboot .blogo{margin:16px 0 14px;display:flex;gap:.55em;align-items:center;overflow:visible}
  #dosboot .bk{position:relative;animation:bkslide .55s cubic-bezier(.2,.8,.2,1) both}
  #dosboot .dia{position:relative;animation:bkdrop .75s cubic-bezier(.25,.75,.3,1) both}   /* no overshoot: a clean cascade */
  #dosboot .dias{display:flex;flex-direction:column;gap:11px;align-items:center;justify-content:center;margin:0 .2em}
  #dosboot .bk{margin:0;font:36px/1 ui-monospace,Menlo,Consolas,monospace;white-space:pre;letter-spacing:0}
  #dosboot .dia::before{content:"";position:absolute;left:44%;right:44%;bottom:100%;height:0;
       background:linear-gradient(to top,#fff,var(--c) 18%,transparent);filter:blur(1.5px);opacity:0;border-radius:2px;
       animation:bktrail .9s ease-out both;animation-delay:inherit}
  #dosboot .dia{width:.44em;height:.44em;font-size:36px;transform-origin:center}
  #dosboot .dia i{position:absolute;inset:0;transform:rotate(45deg);background:linear-gradient(135deg,#38d9ff,#e05cff);
       box-shadow:0 0 14px #e05cffaa}
  #dosboot .bk.gap{width:.6em}
  #dosboot .bl-sub{margin-top:-4px;color:#808080;letter-spacing:3px;animation:blfade .6s ease 1.1s both}
  #dosboot .hl{display:grid;gap:3px;margin:10px 0;max-width:900px}
  #dosboot .hl i{display:block;height:3px;transform-origin:left;animation:hlgrow .7s cubic-bezier(.2,.8,.2,1) both}
  #dosboot .hl.r i{transform-origin:right}
  @keyframes hlgrow{from{transform:scaleX(0)}to{transform:scaleX(1)}}
  @keyframes bkslide{from{transform:translateX(100vw)}to{transform:translateX(0)}}
  @keyframes bkdrop{from{transform:translateY(-110vh)}to{transform:translateY(0)}}
  @keyframes bktrail{0%{height:65vh;opacity:.9}55%{height:40vh;opacity:.8}100%{height:0;opacity:0}}
  @keyframes blfade{from{opacity:0}to{opacity:1}}
  @media (max-width:1000px){#dosboot .bk,#dosboot .dia{font-size:26px}}
  @media (max-width:700px){#dosboot .bk,#dosboot .dia{font-size:20px}}
  #dosboot .cur{display:inline-block;width:.6em;background:#c0c0c0;animation:dosblink 1s steps(1) infinite}
  #dosboot .bar{color:#55ffff}
  #dosboot .scan{position:relative;display:inline-block;width:34ch;height:1.1em;vertical-align:middle;border:1px solid #555;margin-left:1ch;overflow:hidden}
  #dosboot .scan i{position:absolute;top:1px;bottom:1px;width:7ch;background:linear-gradient(90deg,transparent,#55ffff 35%,#fff 50%,#55ffff 65%,transparent);animation:dosscan 1.6s ease-in-out infinite alternate}
  @keyframes dosscan{from{left:0}to{left:calc(100% - 7ch)}}
  #dosboot .lbar{position:absolute;left:36px;bottom:44px;font-size:16px;color:#c0c0c0}
  @media (max-width:600px){#dosboot .lbar{left:16px;bottom:36px;font-size:11px}}
  /* "VJ": vertical scan bars sliding sideways + a vertical wave (columns ripple up and down) */
  /* "VJ" wave: the wrapper slides in like the other letters; inside, an invisible base keeps the size and the
     visible slices bob up and down out of phase, so the letters bend in a rolling wave */
  /* warped-VHS look: pronounced scanlines (mask), an RGB split, the small sideways ripple, and a tracking glitch now and then */
  #dosboot .vjw{position:relative;display:block;animation:bkslide .55s cubic-bezier(.2,.8,.2,1) both,vhsjit 3.7s steps(1) .6s infinite;
       -webkit-mask-image:repeating-linear-gradient(0deg,#000 0 2px,rgba(0,0,0,.18) 2px 4px);mask-image:repeating-linear-gradient(0deg,#000 0 2px,rgba(0,0,0,.18) 2px 4px)}
  #dosboot .vjw .vjs{text-shadow:-2px 0 rgba(56,217,255,.55),2px 0 rgba(255,30,90,.7),0 0 10px rgba(51,255,102,.55)!important}
  @keyframes vhsjit{0%,88%,100%{transform:none;filter:none} 89%{transform:translateX(6px) skewX(-6deg);filter:brightness(1.4)} 90%{transform:translateX(-4px)} 91%{transform:translateX(2px) skewX(3deg)} 92%{transform:none}}
  #dosboot .vjw .vjbase{visibility:hidden;animation:none}
  #dosboot .vjs{position:absolute;left:0;top:0;margin:0;font:36px/1 ui-monospace,Menlo,Consolas,monospace;white-space:pre;
       animation:vjwave 1.2s ease-in-out infinite alternate}
  @keyframes vjwave{from{transform:translateX(-2px)}to{transform:translateX(2px)}}   /* very small sideways ripple */
  @media (max-width:1000px){#dosboot .vjs{font-size:26px}} @media (max-width:700px){#dosboot .vjs{font-size:20px}}
  @keyframes vjscan{from{-webkit-mask-position:0 0;mask-position:0 0}to{-webkit-mask-position:0 8px;mask-position:0 8px}}
  #dosboot .skip{position:absolute;right:24px;bottom:16px;color:#808080;font-size:13px}
  #dosboot::after{content:"";position:absolute;inset:0;pointer-events:none;background:repeating-linear-gradient(0deg,rgba(0,0,0,.28) 0 1px,transparent 1px 3px)}
  @keyframes dosblink{50%{opacity:0}}
  @media (max-width:600px){#dosboot{font-size:12px;padding:16px}}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
  const el = document.createElement("div"); el.id = "dosboot";
  const out = document.createElement("div"); el.appendChild(out);
  const skip = document.createElement("div"); skip.className = "skip"; skip.textContent = "Press any key to skip"; el.appendChild(skip);
  const mount = () => document.body.appendChild(el);
  document.body ? mount() : document.addEventListener("DOMContentLoaded", mount);

  let done = false, t0 = performance.now(), status = null;
  const line = (html = "") => { const d = document.createElement("div"); d.innerHTML = html; out.appendChild(d); return d; };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const esc = s => String(s ?? "").replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  async function poll() {
    try { const r = await fetch("/api/status", { cache: "no-store" }); if (r.ok) { const s = await r.json(); if ((s.fps || 0) > 0) status = s; } } catch (e) {}
    if (!done) setTimeout(poll, 400);
  }
  function finish() {
    if (done) return; done = true;
    el.classList.add("out"); setTimeout(() => { el.remove(); st.remove(); }, 400);
    removeEventListener("keydown", finish, true);
  }
  el.addEventListener("pointerdown", finish); addEventListener("keydown", finish, true);

  async function run() {
    line('<span class="bios">VIZZIES BIOS v4.51PG, An Energy Star Ally</span>');
    line('<span class="dim">Copyright (C) 1984-2026, Fook\'n Oats Enterprises</span>');
    line("");
    const mem = line("Memory Test : 0K");
    for (let k = 0; k <= 640 && !done; k += 32) { mem.textContent = "Memory Test : " + k + "K"; await sleep(45); }
    mem.innerHTML = 'Memory Test : 640K <span class="ok">OK</span>';
    line("");
    line('Starting VIZZIES-DOS...');
    // The loading bar runs the whole time the logo and the drivers load: pinned at the bottom of the screen,
    // filling with elapsed time (held under 95 % until everything is really ready), then 100 % at the end.
    const bar = document.createElement("div"); bar.className = "lbar"; el.appendChild(bar);
    const W = 40, EST = 4600, tb = performance.now(); let barDone = false;
    const drawBar = f => { const i = Math.round(f * W); bar.innerHTML = 'Loading <span class="bar">' + "\u2588".repeat(i) + "\u2591".repeat(W - i) + "</span> " + Math.round(f * 100) + "%"; };
    const barTimer = setInterval(() => { if (!barDone) drawBar(Math.min(0.95, (performance.now() - tb) / EST)); }, 60);
    drawBar(0);
    await sleep(LINE_MS * 4);
    const G = { O: ["█▀▀█", "█  █", "▀▀▀▀"], A: ["█▀▀█", "█▄▄█", "▀  ▀"], T: ["▀▀█▀▀", "  █  ", "  ▀  "], S: ["█▀▀▀", "▀▀▀█", "▀▀▀▀"],
                V: ["█  █", "▀▄▄▀", " ▀▀ "], I: ["▀█▀", " █ ", "▀▀▀"], Z: ["▀▀▀█", "▄▀▀ ", "▀▀▀▀"],
                J: ["  ▀█", "▄  █", "▀▀▀▀"], E: ["█▀▀▀", "█▀▀ ", "▀▀▀▀"] };
    const COL = ["#38d9ff", "#e05cff", "#ffb020", "#a3e635"];          // per-letter cycle, repeating
    const VJCOL = "#33ff66";   // phosphor green (final logo)
    let html = '<div class="blogo">', k = 0, n = 0, vj = true;
    for (const ch of "VJ VIZZIES") {
      if (ch === " ") {
        vj = false;                                            // 3 diamonds drop in with star trails
        html += '<span class="dias">' + [0, 1, 2].map(j => `<span class="dia" style="--c:${COL[j % 4]};animation-delay:${1.25 + (2 - j) * 0.18}s"><i></i></span>`).join("") + "</span>";
        continue;
      }
      const c = vj ? VJCOL : COL[k % COL.length];                 // "VJ" is one colour of its own
      if (vj) {
        // "VJ": a small sideways ripple. Each letter is drawn as SL thin horizontal strips (clip-path) that sway
        // left and right a little, each strip a little behind the one above, like a heat-haze / water ripple.
        const SL = 12, txt = G[ch].join("\n");
        let sl = `<pre class="bk vjbase" style="--c:${c};color:${c};animation-delay:${n * 0.12}s">${txt}</pre>`;
        for (let i = 0; i < SL; i++) {
          const ph = (i / SL) * 2;                                     // 2 ripples from top to bottom
          sl += `<pre class="vjs" style="--c:${c};color:${c};text-shadow:0 0 10px ${c}99;clip-path:inset(${i * 100 / SL}% 0 ${100 - (i + 1) * 100 / SL}% 0);animation-delay:${-(ph % 1) * 1.2}s">${txt}</pre>`;
        }
        html += `<span class="vjw" style="animation-delay:${n * 0.12}s">${sl}</span>`;
      } else
      html += `<pre class="bk" style="--c:${c};color:${c};text-shadow:0 0 10px ${c}99;animation-delay:${n * 0.12}s">${G[ch].join("\n")}</pre>`;
      n++; if (!vj) k++;
    }
    const HL = (cls) => '<div class="hl ' + cls + '">' + COL.slice(0, 4).map((c, i) => `<i style="background:${c};box-shadow:0 0 8px ${c}88;animation-delay:${i * 0.08}s"></i>`).join("") + "</div>";
    line(HL("")); line(html + "</div>"); line('<div class="bl-sub">live visuals engine \u00b7 v1.0</div>'); line(HL("r"));
    await sleep(1300);
    // wait for the player (or show the classic error while it is down)
    let warned = null;
    while (!status && !done) {
      if (!warned && performance.now() - t0 > 2500) warned = line('<span class="warn">Not ready reading drive C:</span> <span class="dim">(player starting)</span>  Abort, Retry, Fail?<span class="cur">&nbsp;</span>');
      await sleep(200);
    }
    if (done) return;
    if (warned) warned.innerHTML = '<span class="warn">Not ready reading drive C:</span> Abort, <span class="hi">Retry</span>, Fail? R';
    const s = status, ndi = s.ndi && typeof s.ndi === "object" ? s.ndi.mode : (s.ndi_mode || "");
    const tp = s.tempo || {}, au = s.audio || {}, dmx = s.dmx || {};
    const L = [
      ["HIMEM.SYS", "Metal " + esc(s.gpu_name || "Apple GPU") + ", budget " + esc(s.budget_ms || 16.7) + " ms", "ok"],
      ["NDI.SYS", ndi ? "mode " + esc(ndi) + ", " + (s.ndi_connections | 0) + " receiver(s)" : "loaded", (s.ndi_connections | 0) > 0 ? "ok" : "dim"],
      ["SACN.SYS", "universe " + esc(s.universe || (dmx.universe ?? 5)) + ", " + ((dmx.pps || 0) > 0 ? "console live" : "waiting for console"), (dmx.pps || 0) > 0 ? "ok" : "warn"],
      ["LINK.COM", tp.source && String(tp.source).startsWith("link") ? "locked " + Math.round(tp.bpm || 0) + " BPM, " + (tp.peers | 0) + " peer(s)" : "no session (tap / DMX tempo)", tp.source && String(tp.source).startsWith("link") ? "ok" : "dim"],
      ["AUDIO.DRV", au.source && au.source !== "off" ? esc(au.name || au.source) + (au.connected ? "" : " (no signal)") : "off", au.connected ? "ok" : "dim"],
      ["FRACTAL.OVL", "deep zoom ready to 10^28", "ok"],
    ];
    for (const [f, d, c] of L) { if (done) return; line('C:\\VIZZIES\\' + f.padEnd(12, " ").replace(/ /g, "&nbsp;") + ' <span class="' + c + '">' + d + "</span>"); await sleep(LINE_MS); }
    line("");
    const prompt = line("C:\\VIZZIES&gt; ");
    for (const ch of "VIZZIES.EXE") { if (done) return; prompt.innerHTML += ch; await sleep(110); }
    await sleep(LINE_MS);
    while (!done && performance.now() - tb < EST) await sleep(60);   // let the bar catch up, then fill the rest
    barDone = true; clearInterval(barTimer);
    for (let f = Math.min(0.95, (performance.now() - tb) / EST); f < 1 && !done; f += 0.05) { drawBar(f); await sleep(40); }
    drawBar(1);
    line(""); line('<span class="ok">' + Math.round(s.fps || 60) + " fps. Ready.</span>");
    await sleep(900);
    finish();
  }
  poll(); run();
})();
